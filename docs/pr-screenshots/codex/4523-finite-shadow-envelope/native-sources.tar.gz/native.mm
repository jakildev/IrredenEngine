
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdint>
#include <cstdio>
int main(int argc,char** argv){@autoreleasepool{
    if(argc!=3)return 2;
    id<MTLDevice> device=MTLCreateSystemDefaultDevice();
    if(!device){std::fprintf(stderr,"No Metal device\n");return 2;}
    NSError* error=nil;
    NSString* source=[NSString stringWithContentsOfFile:@(argv[1])
                       encoding:NSUTF8StringEncoding error:&error];
    id<MTLLibrary> library=[device newLibraryWithSource:source options:nil error:&error];
    if(!library){std::fprintf(stderr,"%s\n",error.description.UTF8String);return 2;}
    id<MTLComputePipelineState> pipeline=[device newComputePipelineStateWithFunction:
        [library newFunctionWithName:@"coverage"] error:&error];
    if(!pipeline){std::fprintf(stderr,"%s\n",error.description.UTF8String);return 2;}
    NSData* fixtures=[NSData dataWithContentsOfFile:@(argv[2])];
    if(!fixtures.length||fixtures.length%128)return 2;
    const NSUInteger count=fixtures.length/128;
    id<MTLBuffer> inputs=[device newBufferWithBytes:fixtures.bytes length:fixtures.length
                         options:MTLResourceStorageModeShared];
    id<MTLBuffer> results=[device newBufferWithLength:6*sizeof(uint32_t)
                          options:MTLResourceStorageModeShared];
    uint32_t* words=(uint32_t*)results.contents;
    for(int i=0;i<6;++i)words[i]=0;
    words[5]=UINT32_MAX;
    id<MTLCommandQueue> queue=[device newCommandQueue];
    id<MTLCommandBuffer> command=[queue commandBuffer];
    id<MTLComputeCommandEncoder> encoder=[command computeCommandEncoder];
    [encoder setComputePipelineState:pipeline];
    [encoder setBuffer:inputs offset:0 atIndex:0];
    [encoder setBuffer:results offset:0 atIndex:1];
    [encoder dispatchThreads:MTLSizeMake(count,1,1)
          threadsPerThreadgroup:MTLSizeMake(MIN(256,pipeline.maxTotalThreadsPerThreadgroup),1,1)];
    [encoder endEncoding];[command commit];[command waitUntilCompleted];
    if(command.status!=MTLCommandBufferStatusCompleted){
        std::fprintf(stderr,"%s\n",command.error.description.UTF8String);return 2;
    }
    NSDictionary* report=@{@"device":device.name,@"fixture_samples":@(count),
        @"cascade_queries":@(words[0]),@"accepted_in_map":@(words[1]),
        @"rejected":@(words[2]),@"outside":@(words[3]),@"failures":@(words[4]),
        @"first_failure_query":@(words[5]),@"compile_options":@"nil (runtime default)",
        @"validation":@"native Metal predicate and index-bound containment"};
    NSData* json=[NSJSONSerialization dataWithJSONObject:report options:0 error:&error];
    std::fwrite(json.bytes,1,json.length,stdout);std::printf("\n");
    return 0;
}}
