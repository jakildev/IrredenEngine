#include <cstdio>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <initializer_list>
#include <iostream>
#include <vector>
using uint = std::uint32_t;
using atomic_uint = uint;
std::uint64_t atomicAdds=0, atomicMaxes=0, atomicExchanges=0;
using std::abs;
constexpr int memory_order_relaxed = 0;
struct vec2 {
    float x,y;
    vec2()=default;
    explicit vec2(float a):x(a),y(a){}
    vec2(float a,float b):x(a),y(b){}
};
struct ivec2 {
    int x,y;
    explicit ivec2(int a):x(a),y(a){}
    explicit ivec2(vec2 a):x(int(a.x)),y(int(a.y)){}
};
struct vec3 {
    float x,y,z;
    vec2 xy() const {return {x,y};}
    float operator[](uint i) const {return i==0?x:(i==1?y:z);}
};
vec2 operator+(vec2 a,vec2 b){return {a.x+b.x,a.y+b.y};}
vec2 operator-(vec2 a,vec2 b){return {a.x-b.x,a.y-b.y};}
vec2 operator/(vec2 a,vec2 b){return {a.x/b.x,a.y/b.y};}
vec2 operator*(vec2 a,float b){return {a.x*b,a.y*b};}
vec2 abs(vec2 a){return {std::abs(a.x),std::abs(a.y)};}
float min(float a,float b){return std::min(a,b);}
float max(float a,float b){return std::max(a,b);}
vec2 min(vec2 a,vec2 b){return {std::min(a.x,b.x),std::min(a.y,b.y)};}
vec2 max(vec2 a,vec2 b){return {std::max(a.x,b.x),std::max(a.y,b.y)};}
vec2 clamp(vec2 a,vec2 low,vec2 high){return min(max(a,low),high);}
ivec2 min(ivec2 a,ivec2 b){return ivec2(vec2(std::min(a.x,b.x),std::min(a.y,b.y)));}
ivec2 max(ivec2 a,ivec2 b){return ivec2(vec2(std::max(a.x,b.x),std::max(a.y,b.y)));}
vec2 floor(vec2 a){return {std::floor(a.x),std::floor(a.y)};}
uint floatBitsToUint(float a){uint b;std::memcpy(&b,&a,4);return b;}
float uintBitsToFloat(uint a){float b;std::memcpy(&b,&a,4);return b;}
template<class T,class U> T as_type(U a){T b;std::memcpy(&b,&a,4);return b;}
uint atomicAdd(uint& p,uint n){++atomicAdds;uint old=p;p+=n;return old;}
uint atomicMax(uint& p,uint n){++atomicMaxes;uint old=p;p=std::max(p,n);return old;}
uint atomicExchange(uint& p,uint n){++atomicExchanges;uint old=p;p=n;return old;}
uint atomic_exchange_explicit(uint* p,uint n,int){return atomicExchange(*p,n);}
uint atomic_fetch_add_explicit(uint* p,uint n,int){return atomicAdd(*p,n);}
uint atomic_fetch_max_explicit(uint* p,uint n,int){return atomicMax(*p,n);}
void atomic_store_explicit(uint* p,uint n,int){*p=n;}
struct FrameDataSun {
    vec2 cascadeOriginUV_0{0,0},cascadeOriginUV_1{-8,-8};
    vec2 cascadeTexelSize_0{1,1},cascadeTexelSize_1{2,3};
};
FrameDataSun sunFrame;
vec2 cascadeOriginUV_0{0,0},cascadeOriginUV_1{-8,-8};
vec2 cascadeTexelSize_0{1,1},cascadeTexelSize_1{2,3};
// GLSL indexes the bound SSBO and reads its length(); Metal takes the raw pointer.
struct BoundBuffer {
    uint* data;
    uint words;
    uint& operator[](uint i) const {return data[i];}
    int length() const {return int(words);}
};
BoundBuffer sunDepthBuf;

using std::min;
#ifndef IR_PROJECTED_FACE_INCLUDED
#define IR_PROJECTED_FACE_INCLUDED

inline float projectedFaceDeterminant(vec2 edgeU, vec2 edgeV) {
    return edgeU.x * edgeV.y - edgeU.y * edgeV.x;
}

// The caller rejects degenerate bases before dividing. Coverage ownership is
// separate: display faces are half-open; finite shadow footprints are closed.
inline vec2 projectedFaceCoordinates(vec2 delta, vec2 edgeU, vec2 edgeV, float determinant) {
    return vec2((delta.x * edgeV.y - delta.y * edgeV.x) / determinant,
                (edgeU.x * delta.y - edgeU.y * delta.x) / determinant);
}

// The sun-query envelope preserves exact represented faces at every orientation.
// Its arithmetic margin and the producer enclosure in sourceFaceIndexBounds
// are coupled; the derivation is in docs/design/sun-face-index-coverage.md.
inline bool sourceFaceWithinProjectedBounds(float point, float corner, float edgeU, float edgeV) {
    const float relativeMargin = 0.00000095367431640625;
    const float absoluteMargin = 3.7615819226313200255e-37;
    const float padding = relativeMargin * (abs(corner) + abs(edgeU) + abs(edgeV)) + absoluteMargin;
    const float low = corner + (edgeU < 0.0 ? edgeU : 0.0) + (edgeV < 0.0 ? edgeV : 0.0) - padding;
    const float high = corner + (edgeU > 0.0 ? edgeU : 0.0) + (edgeV > 0.0 ? edgeV : 0.0) + padding;
    return !(point < low || point > high);
}

// Conservative closed-edge predicates for independently rounded projected
// inputs and finite normal binary32 arithmetic. gamma(7) bounds input rounding,
// subtraction and two-product edge functions, not upstream projection error.
// The caller rejects degenerate bases and keeps uncertain-hit depth on the face.
inline bool projectedFaceContainsClosed(vec2 point, vec2 corner, vec2 edgeU, vec2 edgeV,
                                       float determinant, vec2 uv) {
    if (uv.x >= 0.0 && uv.y >= 0.0 && uv.x <= 1.0 && uv.y <= 1.0) return true;
    const float unitRoundoff = 0.000000059604644775390625;
    const float gamma7 = (7.0 * unitRoundoff) / (1.0 - 7.0 * unitRoundoff);
    const float dx = abs(point.x) + abs(corner.x);
    const float dy = abs(point.y) + abs(corner.y);
    const float detMagnitude = abs(edgeU.x * edgeV.y) + abs(edgeU.y * edgeV.x);
    const float errorU = gamma7 * (dx * abs(edgeV.y) + dy * abs(edgeV.x) + detMagnitude);
    const float errorV = gamma7 * (dx * abs(edgeU.y) + dy * abs(edgeU.x) + detMagnitude);
    const float deltaX = point.x - corner.x;
    const float deltaY = point.y - corner.y;
    const float numeratorU = deltaX * edgeV.y - deltaY * edgeV.x;
    const float numeratorV = edgeU.x * deltaY - edgeU.y * deltaX;
    const float orientation = determinant > 0.0 ? 1.0 : -1.0;
    return orientation * numeratorU >= -errorU &&
           orientation * (determinant - numeratorU) >= -errorU &&
           orientation * numeratorV >= -errorV &&
           orientation * (determinant - numeratorV) >= -errorV;
}

#endif

#ifndef IR_SUN_FACE_QUERY_LAYOUT_INCLUDED
#define IR_SUN_FACE_QUERY_LAYOUT_INCLUDED

// SunShadowDepthMap holds depth layers, primary tile lists, geometry and bounded spill lists.
const uint kSourceFaceMapDimension = 1024u;
const uint kSourceFaceCascadeCount = 2u;
const uint kSourceFaceTileEdge = 8u;
const uint kSourceFaceTilesPerAxis = kSourceFaceMapDimension / kSourceFaceTileEdge;
const uint kSourceFaceTileCount = kSourceFaceCascadeCount * kSourceFaceTilesPerAxis * kSourceFaceTilesPerAxis;
const uint kSourceFaceTileCapacity = 64u;
const uint kSourceFaceTileQueryCapacity = 256u;
const uint kSourceFaceSpillCapacity = 262144u;
const uint kSourceFaceSpillNodeWords = 2u;
const uint kSourceFaceCapacity = 65536u;
const uint kSourceFaceRecordWords = 10u;
const uint kSourceFaceFallbackOffset = kSourceFaceCascadeCount * kSourceFaceMapDimension * kSourceFaceMapDimension;
const uint kSourceFaceHeaderOffset = 2u * kSourceFaceFallbackOffset;
const uint kSourceFaceTileOffset = kSourceFaceHeaderOffset + 1u;
const uint kSourceFaceRecordOffset = kSourceFaceTileOffset + kSourceFaceTileCount * (kSourceFaceTileCapacity + 1u);
const uint kSourceFaceSpillCounterOffset = kSourceFaceRecordOffset + kSourceFaceCapacity * kSourceFaceRecordWords;
const uint kSourceFaceSpillHeadOffset = kSourceFaceSpillCounterOffset + 1u;
const uint kSourceFaceSpillNodeOffset = kSourceFaceSpillHeadOffset + kSourceFaceTileCount;
const uint kSourceFaceBufferWords = kSourceFaceSpillNodeOffset + kSourceFaceSpillCapacity * kSourceFaceSpillNodeWords;

inline uint sourceFaceTileBase(uint tileIndex) {
    return kSourceFaceTileOffset + tileIndex * (kSourceFaceTileCapacity + 1u);
}

inline bool sourceFaceQueryComplete(uint count) {
    return count <= kSourceFaceTileQueryCapacity;
}

// Positive separation is a front hit, including conservative rounded boundaries.
inline float sourceFaceRaySeparation(vec2 sunUV, float sunZ, vec3 corner, vec3 edgeU, vec3 edgeV
#if IR_SUN_QUERY_STATS
    , SunQueryStats &sunQueryStats
#endif
) {
    const float determinant = projectedFaceDeterminant(vec2(edgeU.x, edgeU.y), vec2(edgeV.x, edgeV.y));
    if (abs(determinant) < 0.000001 ||
        !sourceFaceWithinProjectedBounds(sunUV.x, corner.x, edgeU.x, edgeV.x) ||
        !sourceFaceWithinProjectedBounds(sunUV.y, corner.y, edgeU.y, edgeV.y)) {
#if IR_SUN_QUERY_STATS
        sunQueryStats.counts[kSunQueryFaceMisses] += 1u;
#endif
        return -1.0;
    }
    const vec2 uv = projectedFaceCoordinates(
        vec2(sunUV.x - corner.x, sunUV.y - corner.y),
        vec2(edgeU.x, edgeU.y), vec2(edgeV.x, edgeV.y), determinant);
    if (!projectedFaceContainsClosed(sunUV, vec2(corner.x, corner.y),
            vec2(edgeU.x, edgeU.y), vec2(edgeV.x, edgeV.y), determinant, uv)) {
#if IR_SUN_QUERY_STATS
        sunQueryStats.counts[kSunQueryFaceMisses] += 1u;
#endif
        return -1.0;
    }
    // An uncertain boundary hit must never extrapolate depth beyond the face.
    const float u = uv.x < 0.0 ? 0.0 : (uv.x > 1.0 ? 1.0 : uv.x);
    const float v = uv.y < 0.0 ? 0.0 : (uv.y > 1.0 ? 1.0 : uv.y);
    return sunZ - (corner.z + u * edgeU.z + v * edgeV.z);
}

#endif

#ifndef IR_SUN_FACE_BOUNDS_INCLUDED
#define IR_SUN_FACE_BOUNDS_INCLUDED

inline bool sourceFaceBoundFinite(float value) {
    return (as_type<uint>(value) & 0x7F800000u) != 0x7F800000u;
}

inline bool sourceFaceBoundNormalOrZero(float value) {
    const uint magnitude = as_type<uint>(value) & 0x7FFFFFFFu;
    return magnitude == 0u || (magnitude >= 0x00800000u && magnitude < 0x7F800000u);
}

// The minimum-normal enclosure also covers arithmetic that flushes subnormals.
inline float sourceFaceBoundUp(float value) {
    const uint bits = as_type<uint>(value);
    const uint magnitude = bits & 0x7FFFFFFFu;
    if (magnitude >= 0x7F800000u) return value;
    if (magnitude <= 0x00800000u) return as_type<float>(0x00800001u);
    return as_type<float>((bits & 0x80000000u) != 0u ? bits - 1u : bits + 1u);
}

inline float sourceFaceBoundDown(float value) {
    const uint bits = as_type<uint>(value);
    const uint magnitude = bits & 0x7FFFFFFFu;
    if (magnitude >= 0x7F800000u) return value;
    if (magnitude <= 0x00800000u) return as_type<float>(0x80800001u);
    return as_type<float>((bits & 0x80000000u) != 0u ? bits + 1u : bits - 1u);
}

// Independently compiled producer and receiver determinants may contract differently.
inline bool sourceFaceDefinitelyDegenerate(vec2 edgeU, vec2 edgeV, float determinant) {
    if (!sourceFaceBoundNormalOrZero(edgeU.x) || !sourceFaceBoundNormalOrZero(edgeU.y) ||
        !sourceFaceBoundNormalOrZero(edgeV.x) || !sourceFaceBoundNormalOrZero(edgeV.y) ||
        !sourceFaceBoundNormalOrZero(determinant)) return false;
    const vec2 absoluteU = abs(edgeU);
    const vec2 absoluteV = abs(edgeV);
    const float sumU = sourceFaceBoundUp(absoluteU.x + absoluteU.y);
    const float sumV = sourceFaceBoundUp(absoluteV.x + absoluteV.y);
    const float determinantMagnitude = sourceFaceBoundUp(
        sourceFaceBoundUp(absoluteU.x * absoluteV.y) +
        sourceFaceBoundUp(absoluteU.y * absoluteV.x));
    const float relativeError = as_type<float>(0x35800009u);
    const float absoluteError = sourceFaceBoundUp(
        sourceFaceBoundUp(32.0 * as_type<float>(0x00800000u)) *
        sourceFaceBoundUp(1.0 + sourceFaceBoundUp(sumU + sumV)));
    const float error = sourceFaceBoundUp(
        sourceFaceBoundUp(relativeError * determinantMagnitude) + absoluteError);
    const float receiverMagnitude = sourceFaceBoundUp(abs(determinant) + error);
    return sourceFaceBoundFinite(receiverMagnitude) && receiverMagnitude < 0.000001;
}

inline bool sourceFaceCascadeArithmeticSafe(vec2 origin, vec2 cellSize) {
    const uint originX = as_type<uint>(origin.x) & 0x7FFFFFFFu;
    const uint originY = as_type<uint>(origin.y) & 0x7FFFFFFFu;
    const uint sizeX = as_type<uint>(cellSize.x);
    const uint sizeY = as_type<uint>(cellSize.y);
    return (originX == 0u || originX >= 0x00800000u) &&
           (originY == 0u || originY >= 0x00800000u) &&
           originX <= 0x5C800000u && originY <= 0x5C800000u &&
           sizeX >= 0x00800000u && sizeX <= 0x58800000u &&
           sizeY >= 0x00800000u && sizeY <= 0x58800000u;
}

// The interval encloses receiver coordinates before floor and integer conversion.
inline vec2 sourceFaceTileInterval(float low, float high, float origin, float cellSize) {
    const float minimumNormal = as_type<float>(0x00800000u);
    const float maximumFinite = as_type<float>(0x7F7FFFFFu);
    const float differenceLow = sourceFaceBoundDown(low - origin);
    const float differenceHigh = sourceFaceBoundUp(high - origin);
    if (!sourceFaceBoundFinite(differenceLow) || !sourceFaceBoundFinite(differenceHigh))
        return vec2(-maximumFinite, maximumFinite);
    const float differenceMagnitude = max(abs(differenceLow), abs(differenceHigh));
    const float subtractionError = sourceFaceBoundUp(
        sourceFaceBoundUp(0.000000059604644775390625 * differenceMagnitude) +
        3.0 * minimumNormal);
    const float numeratorLow = sourceFaceBoundDown(differenceLow - subtractionError);
    const float numeratorHigh = sourceFaceBoundUp(differenceHigh + subtractionError);
    const float quotientLow = numeratorLow / cellSize;
    const float quotientHigh = numeratorHigh / cellSize;
    if (!sourceFaceBoundFinite(quotientLow) || !sourceFaceBoundFinite(quotientHigh))
        return vec2(-maximumFinite, maximumFinite);
    const float quotientMagnitude = max(abs(quotientLow), abs(quotientHigh));
    const float oneDivisionError = sourceFaceBoundUp(
        sourceFaceBoundUp(0.000000476837158203125 * quotientMagnitude) + minimumNormal);
    const float divisionError = sourceFaceBoundUp(2.0 * sourceFaceBoundUp(
        oneDivisionError * 1.00000059604644775390625));
    const vec2 interval = vec2(sourceFaceBoundDown(quotientLow - divisionError),
                               sourceFaceBoundUp(quotientHigh + divisionError));
    if (!sourceFaceBoundFinite(interval.x) || !sourceFaceBoundFinite(interval.y))
        return vec2(-maximumFinite, maximumFinite);
    return interval;
}

// False requests full-cascade indexing. The arithmetic contract and padding
// derivation are in docs/design/sun-face-index-coverage.md.
inline bool sourceFaceIndexBounds(vec2 corner, vec2 edgeU, vec2 edgeV, float determinant,
                           vec2 &low, vec2 &high) {
    if (!sourceFaceBoundNormalOrZero(corner.x) || !sourceFaceBoundNormalOrZero(corner.y) ||
        !sourceFaceBoundNormalOrZero(edgeU.x) || !sourceFaceBoundNormalOrZero(edgeU.y) ||
        !sourceFaceBoundNormalOrZero(edgeV.x) || !sourceFaceBoundNormalOrZero(edgeV.y) ||
        !sourceFaceBoundNormalOrZero(determinant)) return false;

    const vec2 absoluteCorner = abs(corner);
    const vec2 absoluteU = abs(edgeU);
    const vec2 absoluteV = abs(edgeV);
    const float maximumInput = as_type<float>(0x5D800000u);
    if (max(absoluteCorner.x, absoluteCorner.y) > maximumInput ||
        max(absoluteU.x, absoluteU.y) > maximumInput ||
        max(absoluteV.x, absoluteV.y) > maximumInput) return false;
    const vec2 extent = vec2(
        sourceFaceBoundUp(sourceFaceBoundUp(absoluteCorner.x + absoluteU.x) + absoluteV.x),
        sourceFaceBoundUp(sourceFaceBoundUp(absoluteCorner.y + absoluteU.y) + absoluteV.y));
    // The receiver margin is smaller: this encloses independently rounded
    // sourceFaceWithinProjectedBounds endpoints, including contraction and FTZ.
    const float relativeMargin = 0.0000019073486328125;
    const float absoluteMargin = 64.0 * as_type<float>(0x00800000u);
    const vec2 padding = vec2(
        sourceFaceBoundUp(sourceFaceBoundUp(relativeMargin * extent.x) + absoluteMargin),
        sourceFaceBoundUp(sourceFaceBoundUp(relativeMargin * extent.y) + absoluteMargin));

    low = vec2(
        sourceFaceBoundDown(sourceFaceBoundDown(
            sourceFaceBoundDown(corner.x + min(0.0, edgeU.x)) + min(0.0, edgeV.x)) - padding.x),
        sourceFaceBoundDown(sourceFaceBoundDown(
            sourceFaceBoundDown(corner.y + min(0.0, edgeU.y)) + min(0.0, edgeV.y)) - padding.y));
    high = vec2(
        sourceFaceBoundUp(sourceFaceBoundUp(
            sourceFaceBoundUp(corner.x + max(0.0, edgeU.x)) + max(0.0, edgeV.x)) + padding.x),
        sourceFaceBoundUp(sourceFaceBoundUp(
            sourceFaceBoundUp(corner.y + max(0.0, edgeU.y)) + max(0.0, edgeV.y)) + padding.y));
    return sourceFaceBoundFinite(low.x) && sourceFaceBoundFinite(low.y) &&
           sourceFaceBoundFinite(high.x) && sourceFaceBoundFinite(high.y);
}

#endif


// Cooperative callers provide identical geometry and cascade bounds on every lane.
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
inline void indexSourceSunGeometry(atomic_uint* sunDepthBuf, vec3 corner, vec3 edgeU, vec3 edgeV, uint type, vec2 low, vec2 high, const FrameDataSun& sunFrame, uint lane, threadgroup uint& sharedFaceIndex) {
#else
inline void indexSourceSunGeometry(atomic_uint* sunDepthBuf, vec3 corner, vec3 edgeU, vec3 edgeV, uint type, vec2 low, vec2 high, const FrameDataSun& sunFrame) {
#endif
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
    const uint stride = 64u;
#endif
    uint faceIndex = 0xFFFFFFFFu;
    for (uint cascade = 0u; cascade < kSourceFaceCascadeCount; ++cascade) {
        const vec2 origin = cascade == 0u ? sunFrame.cascadeOriginUV_0 : sunFrame.cascadeOriginUV_1;
        const vec2 cellSize = (cascade == 0u ? sunFrame.cascadeTexelSize_0 : sunFrame.cascadeTexelSize_1) * float(kSourceFaceTileEdge);
        const bool fullCascade = type == 0u && !sourceFaceCascadeArithmeticSafe(origin, cellSize);
        const vec2 tileX = fullCascade ? vec2(0.0, float(kSourceFaceTilesPerAxis - 1u))
            : sourceFaceTileInterval(low.x, high.x, origin.x, cellSize.x);
        const vec2 tileY = fullCascade ? vec2(0.0, float(kSourceFaceTilesPerAxis - 1u))
            : sourceFaceTileInterval(low.y, high.y, origin.y, cellSize.y);
        const ivec2 first = ivec2(clamp(floor(vec2(tileX.x, tileY.x)),
            vec2(0.0), vec2(float(kSourceFaceTilesPerAxis))));
        const ivec2 last = ivec2(clamp(floor(vec2(tileX.y, tileY.y)),
            vec2(-1.0), vec2(float(kSourceFaceTilesPerAxis - 1u))));
        if (first.x > last.x || first.y > last.y) continue;
        if (faceIndex == 0xFFFFFFFFu) {
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
            if (lane == 0u) {
#endif
            faceIndex = atomic_fetch_add_explicit(&sunDepthBuf[kSourceFaceHeaderOffset], 1u, memory_order_relaxed);
            if (faceIndex < kSourceFaceCapacity) {
                const uint record = kSourceFaceRecordOffset + faceIndex * kSourceFaceRecordWords;
                atomic_store_explicit(&sunDepthBuf[record + 9u], type, memory_order_relaxed);
                for (uint axis = 0; axis < 3u; ++axis) {
                    atomic_store_explicit(&sunDepthBuf[record + axis], as_type<uint>(corner[axis]), memory_order_relaxed);
                    atomic_store_explicit(&sunDepthBuf[record + 3u + axis], as_type<uint>(edgeU[axis]), memory_order_relaxed);
                    atomic_store_explicit(&sunDepthBuf[record + 6u + axis], as_type<uint>(edgeV[axis]), memory_order_relaxed);
                }
            }
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
            sharedFaceIndex = faceIndex;
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
            faceIndex = sharedFaceIndex;
            // Every lane must consume the shared record before the next face overwrites it.
            threadgroup_barrier(mem_flags::mem_threadgroup);
#endif
        }
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
        const uint width = uint(last.x - first.x + 1);
        const uint count = width * uint(last.y - first.y + 1);
        for (uint item = lane; item < count; item += stride) {
            const int x = first.x + int(item % width);
            const int y = first.y + int(item / width);
#else
        for (int y = first.y; y <= last.y; ++y) for (int x = first.x; x <= last.x; ++x) {
#endif
            const uint tile = cascade * kSourceFaceTilesPerAxis * kSourceFaceTilesPerAxis + uint(y) * kSourceFaceTilesPerAxis + uint(x);
            const uint base = sourceFaceTileBase(tile);
            if (faceIndex >= kSourceFaceCapacity) {
                atomic_fetch_max_explicit(&sunDepthBuf[base], kSourceFaceTileQueryCapacity + 1u, memory_order_relaxed);
                continue;
            }
            const uint slot = atomic_fetch_add_explicit(&sunDepthBuf[base], 1u, memory_order_relaxed);
            if (slot < kSourceFaceTileCapacity) {
                atomic_store_explicit(&sunDepthBuf[base + 1u + slot], faceIndex, memory_order_relaxed);
            } else if (slot < kSourceFaceTileQueryCapacity) {
                const uint spill = atomic_fetch_add_explicit(&sunDepthBuf[kSourceFaceSpillCounterOffset], 1u, memory_order_relaxed);
                if (spill < kSourceFaceSpillCapacity) {
                    const uint node = kSourceFaceSpillNodeOffset + spill * kSourceFaceSpillNodeWords;
                    atomic_store_explicit(&sunDepthBuf[node], faceIndex, memory_order_relaxed);
                    const uint previous = atomic_exchange_explicit(&sunDepthBuf[kSourceFaceSpillHeadOffset + tile], spill, memory_order_relaxed);
                    atomic_store_explicit(&sunDepthBuf[node + 1u], previous, memory_order_relaxed);
                } else {
                    atomic_fetch_max_explicit(&sunDepthBuf[base], kSourceFaceTileQueryCapacity + 1u, memory_order_relaxed);
                }
            }
        }
    }
}

#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
inline void indexSourceSunFace(atomic_uint* sunDepthBuf, vec3 corner, vec3 edgeU, vec3 edgeV, const FrameDataSun& sunFrame, uint lane, threadgroup uint& sharedFaceIndex) {
#else
inline void indexSourceSunFace(atomic_uint* sunDepthBuf, vec3 corner, vec3 edgeU, vec3 edgeV, const FrameDataSun& sunFrame) {
#endif
    const float determinant = projectedFaceDeterminant(edgeU.xy(), edgeV.xy());
    if (sourceFaceDefinitelyDegenerate(edgeU.xy(), edgeV.xy(), determinant)) return;
    vec2 low, high;
    if (!sourceFaceIndexBounds(corner.xy(), edgeU.xy(), edgeV.xy(), determinant, low, high)) {
        low = vec2(-3.4028234663852886e38);
        high = vec2(3.4028234663852886e38);
    }
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
    indexSourceSunGeometry(sunDepthBuf, corner, edgeU, edgeV, 0u, low, high, sunFrame, lane, sharedFaceIndex);
#else
    indexSourceSunGeometry(sunDepthBuf, corner, edgeU, edgeV, 0u, low, high, sunFrame);
#endif
}

std::vector<uint> storage(kSourceFaceBufferWords,0xccccccccu);
uint accepted=0,rejected=0,outside=0,incomplete=0,failures=0,fixtures=0;
uint nearDegenerateAccepted=0,negativeAccepted=0,zeroAccepted=0;
void reset(bool){}
void configure(vec2 origin0,vec2 origin1,vec2 texel0,vec2 texel1){
    cascadeOriginUV_0=origin0;cascadeOriginUV_1=origin1;
    cascadeTexelSize_0=texel0;cascadeTexelSize_1=texel1;
    sunFrame.cascadeOriginUV_0=origin0;sunFrame.cascadeOriginUV_1=origin1;
    sunFrame.cascadeTexelSize_0=texel0;sunFrame.cascadeTexelSize_1=texel1;
}
float adjacent(float value,int direction){
    if(direction==0)return value;
    return std::nextafter(value,direction<0?-INFINITY:INFINITY);
}

void query(vec3 c,vec3 u,vec3 v,vec2 p,bool){
    const float values[]={c.x,c.y,c.z,0,u.x,u.y,u.z,0,v.x,v.y,v.z,0,p.x,p.y,0,0,
        cascadeOriginUV_0.x,cascadeOriginUV_0.y,0,0,cascadeOriginUV_1.x,cascadeOriginUV_1.y,0,0,
        cascadeTexelSize_0.x,cascadeTexelSize_0.y,0,0,cascadeTexelSize_1.x,cascadeTexelSize_1.y,0,0};
    std::fwrite(values,sizeof(values),1,stdout);
}

void face(vec3 corner,vec3 u,vec3 v,bool exhausted=false){
    reset(exhausted);++fixtures;
    
    // Binary64 point construction does not share the shader's edge arithmetic.
    for(double a:{0.0,.5,1.0})for(double b:{0.0,.5,1.0}){
        const float x=float(double(corner.x)+a*double(u.x)+b*double(v.x));
        const float y=float(double(corner.y)+a*double(u.y)+b*double(v.y));
        for(int dx:{-1,0,1})for(int dy:{-1,0,1})
            query(corner,u,v,{adjacent(x,dx),adjacent(y,dy)},exhausted);
    }
    query(corner,u,v,{corner.x+u.x*4+v.x*4,corner.y+u.y*4+v.y*4},exhausted);
}
int main(){
    configure({0,0},{-8,-8},{1,1},{2,3});
    for(bool exhausted:{false,true}){
        reset(exhausted);++fixtures;
        const vec3 corner{std::nextafter(8.0f,9.0f),0,0},u{1,0,0},v{0,1,0};
        
        query(corner,u,v,{std::nextafter(8.0f,7.0f),.5f},exhausted);
    }
    const vec2 origins[][2]={{{0,0},{-64,-48}},{{-64,-32},{128,-128}},
                            {{96,64},{-1024,-512}}};
    const vec2 texels[][2]={{{1,1},{.5f,2}},{{.25f,3},{2,.125f}},
                           {{1.5f,.75f},{4,2}}};
    const vec3 edges[][2]={{{1,0,0},{0,1,0}},{{1,.25f,0},{-.5f,1,0}},
                          {{.70710677f,.70710677f,0},{-.70710677f,.70710677f,0}},
                          {{1,0,0},{.75f,2e-6f,0}},{{8,1,0},{8,1.000001f,0}}};
    for(uint config=0;config<3;++config){
        configure(origins[config][0],origins[config][1],texels[config][0],texels[config][1]);
        for(uint cascade=0;cascade<2;++cascade)for(int boundary:{0,1,8,127,128}){
            const vec2 origin=origins[config][cascade],texel=texels[config][cascade];
            const vec2 anchor{origin.x+boundary*8*texel.x,origin.y+boundary*8*texel.y};
            for(const auto& basis:edges)for(int winding=0;winding<8;++winding)
            for(int shift:{-1,0,1}){
                vec3 u=basis[0],v=basis[1];
                if(winding&1)std::swap(u,v);
                if(winding&2)u={-u.x,-u.y,0};
                if(winding&4)v={-v.x,-v.y,0};
                face({adjacent(anchor.x,shift),adjacent(anchor.y,-shift),0},u,v);
            }
        }
        // Zero and negative zero can be internal tile boundaries in translated cascades.
        for(float coordinate:{-8.0f,-0.0f,0.0f,8.0f})
            for(const auto& basis:edges)face({coordinate,coordinate,0},basis[0],basis[1]);
    }
return 0;}
