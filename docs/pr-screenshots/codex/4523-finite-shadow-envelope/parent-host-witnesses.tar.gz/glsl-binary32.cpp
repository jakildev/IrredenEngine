
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <initializer_list>
#include <iostream>
#include <vector>
using uint = std::uint32_t;
using atomic_uint = uint;
std::uint64_t atomicAdds=0, atomicMaxes=0, atomicExchanges=0;
using std::abs;
constexpr int memory_order_relaxed = 0;
struct vec2 {
    float x,y;
    vec2()=default;
    explicit vec2(float a):x(a),y(a){}
    vec2(float a,float b):x(a),y(b){}
};
struct ivec2 {
    int x,y;
    explicit ivec2(int a):x(a),y(a){}
    explicit ivec2(vec2 a):x(int(a.x)),y(int(a.y)){}
};
struct vec3 {
vec3(float a,float b,float c):x(a),y(b),z(c){}
    float x,y,z;
    vec2 xy() const {return {x,y};}
    float operator[](uint i) const {return i==0?x:(i==1?y:z);}
};
vec2 operator+(vec2 a,vec2 b){return {a.x+b.x,a.y+b.y};}
vec2 operator-(vec2 a,vec2 b){return {a.x-b.x,a.y-b.y};}
vec2 operator/(vec2 a,vec2 b){return {a.x/b.x,a.y/b.y};}
vec2 operator*(vec2 a,float b){return {a.x*b,a.y*b};}
vec2 abs(vec2 a){return {std::abs(a.x),std::abs(a.y)};}
float min(float a,float b){return std::min(a,b);}
float max(float a,float b){return std::max(a,b);}
vec2 min(vec2 a,vec2 b){return {std::min(a.x,b.x),std::min(a.y,b.y)};}
vec2 max(vec2 a,vec2 b){return {std::max(a.x,b.x),std::max(a.y,b.y)};}
vec2 clamp(vec2 a,vec2 low,vec2 high){return min(max(a,low),high);}
ivec2 min(ivec2 a,ivec2 b){return ivec2(vec2(std::min(a.x,b.x),std::min(a.y,b.y)));}
ivec2 max(ivec2 a,ivec2 b){return ivec2(vec2(std::max(a.x,b.x),std::max(a.y,b.y)));}
vec2 floor(vec2 a){return {std::floor(a.x),std::floor(a.y)};}
uint floatBitsToUint(float a){uint b;std::memcpy(&b,&a,4);return b;}
float uintBitsToFloat(uint a){float b;std::memcpy(&b,&a,4);return b;}
template<class T,class U> T as_type(U a){T b;std::memcpy(&b,&a,4);return b;}
uint atomicAdd(uint& p,uint n){++atomicAdds;uint old=p;p+=n;return old;}
uint atomicMax(uint& p,uint n){++atomicMaxes;uint old=p;p=std::max(p,n);return old;}
uint atomicExchange(uint& p,uint n){++atomicExchanges;uint old=p;p=n;return old;}
uint atomic_exchange_explicit(uint* p,uint n,int){return atomicExchange(*p,n);}
uint atomic_fetch_add_explicit(uint* p,uint n,int){return atomicAdd(*p,n);}
uint atomic_fetch_max_explicit(uint* p,uint n,int){return atomicMax(*p,n);}
void atomic_store_explicit(uint* p,uint n,int){*p=n;}
struct FrameDataSun {
    vec2 cascadeOriginUV_0{0,0},cascadeOriginUV_1{-8,-8};
    vec2 cascadeTexelSize_0{1,1},cascadeTexelSize_1{2,3};
};
FrameDataSun sunFrame;
const vec2 cascadeOriginUV_0{0,0},cascadeOriginUV_1{-8,-8};
const vec2 cascadeTexelSize_0{1,1},cascadeTexelSize_1{2,3};
// GLSL indexes the bound SSBO and reads its length(); Metal takes the raw pointer.
struct BoundBuffer {
    uint* data;
    uint words;
    uint& operator[](uint i) const {return data[i];}
    int length() const {return int(words);}
};
BoundBuffer sunDepthBuf;

#define MEASURE_ONLY 1
#ifndef IR_PROJECTED_FACE_INCLUDED
#define IR_PROJECTED_FACE_INCLUDED

float projectedFaceDeterminant(vec2 edgeU, vec2 edgeV) {
    return edgeU.x * edgeV.y - edgeU.y * edgeV.x;
}

// The caller rejects degenerate bases before dividing. Coverage ownership is
// separate: display faces are half-open; finite shadow footprints are closed.
vec2 projectedFaceCoordinates(vec2 delta, vec2 edgeU, vec2 edgeV, float determinant) {
    return vec2((delta.x * edgeV.y - delta.y * edgeV.x) / determinant,
                (edgeU.x * delta.y - edgeU.y * delta.x) / determinant);
}

// Conservative closed-edge predicates for independently rounded projected
// inputs and finite normal binary32 arithmetic. gamma(7) bounds input rounding,
// subtraction and two-product edge functions, not upstream projection error.
// The caller rejects degenerate bases and keeps uncertain-hit depth on the face.
bool projectedFaceContainsClosed(vec2 point, vec2 corner, vec2 edgeU, vec2 edgeV,
                                 float determinant, vec2 uv) {
    if (uv.x >= 0.0f && uv.y >= 0.0f && uv.x <= 1.0f && uv.y <= 1.0f) return true;
    const float unitRoundoff = 0.000000059604644775390625f;
    const float gamma7 = (7.0f * unitRoundoff) / (1.0f - 7.0f * unitRoundoff);
    const float dx = abs(point.x) + abs(corner.x);
    const float dy = abs(point.y) + abs(corner.y);
    const float detMagnitude = abs(edgeU.x * edgeV.y) + abs(edgeU.y * edgeV.x);
    const float errorU = gamma7 * (dx * abs(edgeV.y) + dy * abs(edgeV.x) + detMagnitude);
    const float errorV = gamma7 * (dx * abs(edgeU.y) + dy * abs(edgeU.x) + detMagnitude);
    const float deltaX = point.x - corner.x;
    const float deltaY = point.y - corner.y;
    const float numeratorU = deltaX * edgeV.y - deltaY * edgeV.x;
    const float numeratorV = edgeU.x * deltaY - edgeU.y * deltaX;
    const float orientation = determinant > 0.0f ? 1.0f : -1.0f;
    return orientation * numeratorU >= -errorU &&
           orientation * (determinant - numeratorU) >= -errorU &&
           orientation * numeratorV >= -errorV &&
           orientation * (determinant - numeratorV) >= -errorV;
}

#endif

#ifndef IR_SUN_FACE_QUERY_LAYOUT_INCLUDED
#define IR_SUN_FACE_QUERY_LAYOUT_INCLUDED

// SunShadowDepthMap holds depth layers, primary tile lists, geometry and bounded spill lists.
const uint kSourceFaceMapDimension = 1024u;
const uint kSourceFaceCascadeCount = 2u;
const uint kSourceFaceTileEdge = 8u;
const uint kSourceFaceTilesPerAxis = kSourceFaceMapDimension / kSourceFaceTileEdge;
const uint kSourceFaceTileCount = kSourceFaceCascadeCount * kSourceFaceTilesPerAxis * kSourceFaceTilesPerAxis;
const uint kSourceFaceTileCapacity = 64u;
const uint kSourceFaceTileQueryCapacity = 256u;
const uint kSourceFaceSpillCapacity = 262144u;
const uint kSourceFaceSpillNodeWords = 2u;
const uint kSourceFaceCapacity = 65536u;
const uint kSourceFaceRecordWords = 10u;
const uint kSourceFaceFallbackOffset = kSourceFaceCascadeCount * kSourceFaceMapDimension * kSourceFaceMapDimension;
const uint kSourceFaceHeaderOffset = 2u * kSourceFaceFallbackOffset;
const uint kSourceFaceTileOffset = kSourceFaceHeaderOffset + 1u;
const uint kSourceFaceRecordOffset = kSourceFaceTileOffset + kSourceFaceTileCount * (kSourceFaceTileCapacity + 1u);
const uint kSourceFaceSpillCounterOffset = kSourceFaceRecordOffset + kSourceFaceCapacity * kSourceFaceRecordWords;
const uint kSourceFaceSpillHeadOffset = kSourceFaceSpillCounterOffset + 1u;
const uint kSourceFaceSpillNodeOffset = kSourceFaceSpillHeadOffset + kSourceFaceTileCount;
const uint kSourceFaceBufferWords = kSourceFaceSpillNodeOffset + kSourceFaceSpillCapacity * kSourceFaceSpillNodeWords;

// Every header access passes `uint(sunDepthBuf.length())`: NVIDIA's cold link
// time grows with a compile-time-constant SSBO index, and this one costs minutes
// per program, while a runtime-derived index links in well under a second.
// Addresses the header word only while binding 28 holds the whole
// SunShadowDepthMap; a bindRange, a resize not derived from
// kSourceFaceBufferWords, or another buffer aliased onto slot 28 misaddresses it.
uint sourceFaceHeaderIndex(uint boundWords) {
    return boundWords - (kSourceFaceBufferWords - kSourceFaceHeaderOffset);
}

uint sourceFaceSpillCounterIndex(uint boundWords) {
    return boundWords - (kSourceFaceBufferWords - kSourceFaceSpillCounterOffset);
}

uint sourceFaceTileBase(uint tileIndex) {
    return kSourceFaceTileOffset + tileIndex * (kSourceFaceTileCapacity + 1u);
}

bool sourceFaceQueryComplete(uint count) {
    return count <= kSourceFaceTileQueryCapacity;
}

// Positive separation is a front hit, including conservative rounded boundaries.
float sourceFaceRaySeparation(vec2 sunUV, float sunZ, vec3 corner, vec3 edgeU, vec3 edgeV
#if IR_SUN_QUERY_STATS
    , inout SunQueryStats sunQueryStats
#endif
) {
    const float determinant = projectedFaceDeterminant(vec2(edgeU.x, edgeU.y), vec2(edgeV.x, edgeV.y));
    if (abs(determinant) < 0.000001f) {
#if IR_SUN_QUERY_STATS
        sunQueryStats.counts[kSunQueryFaceMisses] += 1u;
#endif
        return -1.0f;
    }
    const vec2 uv = projectedFaceCoordinates(
        vec2(sunUV.x - corner.x, sunUV.y - corner.y),
        vec2(edgeU.x, edgeU.y), vec2(edgeV.x, edgeV.y), determinant);
    if (!projectedFaceContainsClosed(sunUV, vec2(corner.x, corner.y),
            vec2(edgeU.x, edgeU.y), vec2(edgeV.x, edgeV.y), determinant, uv)) {
#if IR_SUN_QUERY_STATS
        sunQueryStats.counts[kSunQueryFaceMisses] += 1u;
#endif
        return -1.0f;
    }
    // An uncertain boundary hit must never extrapolate depth beyond the face.
    const float u = uv.x < 0.0f ? 0.0f : (uv.x > 1.0f ? 1.0f : uv.x);
    const float v = uv.y < 0.0f ? 0.0f : (uv.y > 1.0f ? 1.0f : uv.y);
    return sunZ - (corner.z + u * edgeU.z + v * edgeV.z);
}

#endif
#ifndef IR_SUN_FACE_BOUNDS_INCLUDED
#define IR_SUN_FACE_BOUNDS_INCLUDED

bool sourceFaceBoundFinite(float value) {
    return (floatBitsToUint(value) & 0x7F800000u) != 0x7F800000u;
}

bool sourceFaceBoundNormalOrZero(float value) {
    const uint magnitude = floatBitsToUint(value) & 0x7FFFFFFFu;
    return magnitude == 0u || (magnitude >= 0x00800000u && magnitude < 0x7F800000u);
}

// The minimum-normal enclosure also covers arithmetic that flushes subnormals.
float sourceFaceBoundUp(float value) {
    const uint bits = floatBitsToUint(value);
    const uint magnitude = bits & 0x7FFFFFFFu;
    if (magnitude >= 0x7F800000u) return value;
    if (magnitude <= 0x00800000u) return uintBitsToFloat(0x00800001u);
    return uintBitsToFloat((bits & 0x80000000u) != 0u ? bits - 1u : bits + 1u);
}

float sourceFaceBoundDown(float value) {
    const uint bits = floatBitsToUint(value);
    const uint magnitude = bits & 0x7FFFFFFFu;
    if (magnitude >= 0x7F800000u) return value;
    if (magnitude <= 0x00800000u) return uintBitsToFloat(0x80800001u);
    return uintBitsToFloat((bits & 0x80000000u) != 0u ? bits + 1u : bits - 1u);
}

// Four quotient ULPs give relative error at most 8u. This binary32 factor
// exceeds 1/(1-8u); one outward step encloses the final multiplication.
float sourceFaceBoundDivideUp(float numerator, float denominator) {
    const float quotient = sourceFaceBoundUp(numerator / denominator);
    return sourceFaceBoundUp(quotient * 1.00000059604644775390625f);
}

// Independently compiled producer and receiver determinants may contract differently.
bool sourceFaceDefinitelyDegenerate(vec2 edgeU, vec2 edgeV, float determinant) {
    if (!sourceFaceBoundNormalOrZero(edgeU.x) || !sourceFaceBoundNormalOrZero(edgeU.y) ||
        !sourceFaceBoundNormalOrZero(edgeV.x) || !sourceFaceBoundNormalOrZero(edgeV.y) ||
        !sourceFaceBoundNormalOrZero(determinant)) return false;
    const vec2 absoluteU = abs(edgeU);
    const vec2 absoluteV = abs(edgeV);
    const float sumU = sourceFaceBoundUp(absoluteU.x + absoluteU.y);
    const float sumV = sourceFaceBoundUp(absoluteV.x + absoluteV.y);
    const float determinantMagnitude = sourceFaceBoundUp(
        sourceFaceBoundUp(absoluteU.x * absoluteV.y) +
        sourceFaceBoundUp(absoluteU.y * absoluteV.x));
    const float relativeError = uintBitsToFloat(0x35800009u);
    const float absoluteError = sourceFaceBoundUp(
        sourceFaceBoundUp(32.0f * uintBitsToFloat(0x00800000u)) *
        sourceFaceBoundUp(1.0f + sourceFaceBoundUp(sumU + sumV)));
    const float error = sourceFaceBoundUp(
        sourceFaceBoundUp(relativeError * determinantMagnitude) + absoluteError);
    const float receiverMagnitude = sourceFaceBoundUp(abs(determinant) + error);
    return sourceFaceBoundFinite(receiverMagnitude) && receiverMagnitude < 0.000001f;
}

bool sourceFaceCascadeArithmeticSafe(vec2 origin, vec2 cellSize) {
    const uint originX = floatBitsToUint(origin.x) & 0x7FFFFFFFu;
    const uint originY = floatBitsToUint(origin.y) & 0x7FFFFFFFu;
    const uint sizeX = floatBitsToUint(cellSize.x);
    const uint sizeY = floatBitsToUint(cellSize.y);
    return (originX == 0u || originX >= 0x00800000u) &&
           (originY == 0u || originY >= 0x00800000u) &&
           originX <= 0x5C800000u && originY <= 0x5C800000u &&
           sizeX >= 0x00800000u && sizeX <= 0x58800000u &&
           sizeY >= 0x00800000u && sizeY <= 0x58800000u;
}

// The interval encloses receiver coordinates before floor and integer conversion.
vec2 sourceFaceTileInterval(float low, float high, float origin, float cellSize) {
    const float minimumNormal = uintBitsToFloat(0x00800000u);
    const float maximumFinite = uintBitsToFloat(0x7F7FFFFFu);
    const float differenceLow = sourceFaceBoundDown(low - origin);
    const float differenceHigh = sourceFaceBoundUp(high - origin);
    if (!sourceFaceBoundFinite(differenceLow) || !sourceFaceBoundFinite(differenceHigh))
        return vec2(-maximumFinite, maximumFinite);
    const float differenceMagnitude = max(abs(differenceLow), abs(differenceHigh));
    const float subtractionError = sourceFaceBoundUp(
        sourceFaceBoundUp(0.000000059604644775390625f * differenceMagnitude) +
        3.0f * minimumNormal);
    const float numeratorLow = sourceFaceBoundDown(differenceLow - subtractionError);
    const float numeratorHigh = sourceFaceBoundUp(differenceHigh + subtractionError);
    const float quotientLow = numeratorLow / cellSize;
    const float quotientHigh = numeratorHigh / cellSize;
    if (!sourceFaceBoundFinite(quotientLow) || !sourceFaceBoundFinite(quotientHigh))
        return vec2(-maximumFinite, maximumFinite);
    const float quotientMagnitude = max(abs(quotientLow), abs(quotientHigh));
    const float oneDivisionError = sourceFaceBoundUp(
        sourceFaceBoundUp(0.000000476837158203125f * quotientMagnitude) + minimumNormal);
    const float divisionError = sourceFaceBoundUp(2.0f * sourceFaceBoundUp(
        oneDivisionError * 1.00000059604644775390625f));
    const vec2 interval = vec2(sourceFaceBoundDown(quotientLow - divisionError),
                               sourceFaceBoundUp(quotientHigh + divisionError));
    if (!sourceFaceBoundFinite(interval.x) || !sourceFaceBoundFinite(interval.y))
        return vec2(-maximumFinite, maximumFinite);
    return interval;
}

// False requests full-cascade indexing. The arithmetic contract and padding
// derivation are in docs/design/sun-face-index-coverage.md.
bool sourceFaceIndexBounds(vec2 corner, vec2 edgeU, vec2 edgeV, float determinant,
                           vec2 &low, vec2 &high) {
    if (!sourceFaceBoundNormalOrZero(corner.x) || !sourceFaceBoundNormalOrZero(corner.y) ||
        !sourceFaceBoundNormalOrZero(edgeU.x) || !sourceFaceBoundNormalOrZero(edgeU.y) ||
        !sourceFaceBoundNormalOrZero(edgeV.x) || !sourceFaceBoundNormalOrZero(edgeV.y) ||
        !sourceFaceBoundNormalOrZero(determinant)) return false;

    const vec2 absoluteCorner = abs(corner);
    const vec2 absoluteU = abs(edgeU);
    const vec2 absoluteV = abs(edgeV);
    const float maximumInput = uintBitsToFloat(0x5D800000u);
    if (max(absoluteCorner.x, absoluteCorner.y) > maximumInput ||
        max(absoluteU.x, absoluteU.y) > maximumInput ||
        max(absoluteV.x, absoluteV.y) > maximumInput) return false;
    const float cornerExtent = max(absoluteCorner.x, absoluteCorner.y);
    const float extentU = max(absoluteU.x, absoluteU.y);
    const float extentV = max(absoluteV.x, absoluteV.y);
    const float sumU = sourceFaceBoundUp(absoluteU.x + absoluteU.y);
    const float sumV = sourceFaceBoundUp(absoluteV.x + absoluteV.y);
    const float edgeExtent = sourceFaceBoundUp(extentU + extentV);
    const float radius = sourceFaceBoundUp(cornerExtent + edgeExtent);
    const float determinantMagnitude = sourceFaceBoundUp(
        sourceFaceBoundUp(absoluteU.x * absoluteV.y) +
        sourceFaceBoundUp(absoluteU.y * absoluteV.x));
    const float coupling = sourceFaceBoundUp(
        sourceFaceBoundUp(extentU * sumV) + sourceFaceBoundUp(extentV * sumU));
    const float determinantTerm = sourceFaceBoundUp(edgeExtent * determinantMagnitude);

    // ceil_binary32(gamma(16)), with u = 2^-24.f
    const float relativeError = uintBitsToFloat(0x35800009u);
    const float absoluteError = sourceFaceBoundUp(
        sourceFaceBoundUp(32.0f * uintBitsToFloat(0x00800000u)) *
        sourceFaceBoundUp(1.0f + sourceFaceBoundUp(sumU + sumV)));
    const float denominatorError = sourceFaceBoundUp(
        sourceFaceBoundUp(relativeError *
            sourceFaceBoundUp(determinantMagnitude + coupling)) + absoluteError);
    const float denominator = sourceFaceBoundDown(abs(determinant) - denominatorError);
    if (!sourceFaceBoundFinite(denominator) || denominator <= 0.0f) return false;

    const float relativeNumerator = sourceFaceBoundUp(relativeError * sourceFaceBoundUp(
        sourceFaceBoundUp(sourceFaceBoundUp(radius + cornerExtent) * coupling) +
        determinantTerm));
    const float numerator = sourceFaceBoundUp(
        relativeNumerator + sourceFaceBoundUp(edgeExtent * absoluteError));
    const float padding = sourceFaceBoundDivideUp(numerator, denominator);
    if (!sourceFaceBoundFinite(padding)) return false;

    low = vec2(
        sourceFaceBoundDown(sourceFaceBoundDown(
            sourceFaceBoundDown(corner.x + min(0.0f, edgeU.x)) + min(0.0f, edgeV.x)) - padding),
        sourceFaceBoundDown(sourceFaceBoundDown(
            sourceFaceBoundDown(corner.y + min(0.0f, edgeU.y)) + min(0.0f, edgeV.y)) - padding));
    high = vec2(
        sourceFaceBoundUp(sourceFaceBoundUp(
            sourceFaceBoundUp(corner.x + max(0.0f, edgeU.x)) + max(0.0f, edgeV.x)) + padding),
        sourceFaceBoundUp(sourceFaceBoundUp(
            sourceFaceBoundUp(corner.y + max(0.0f, edgeU.y)) + max(0.0f, edgeV.y)) + padding));
    return sourceFaceBoundFinite(low.x) && sourceFaceBoundFinite(low.y) &&
           sourceFaceBoundFinite(high.x) && sourceFaceBoundFinite(high.y);
}

#endif


// Cooperative callers provide identical geometry and cascade bounds on every lane.
void indexSourceSunGeometry(vec3 corner, vec3 edgeU, vec3 edgeV, uint type, vec2 low, vec2 high) {
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
    const uint lane = gl_LocalInvocationID.x;
    const uint stride = 64u;
#endif
    uint faceIndex = 0xFFFFFFFFu;
    for (uint cascade = 0u; cascade < kSourceFaceCascadeCount; ++cascade) {
        const vec2 origin = cascade == 0u ? cascadeOriginUV_0 : cascadeOriginUV_1;
        const vec2 cellSize = (cascade == 0u ? cascadeTexelSize_0 : cascadeTexelSize_1) * float(kSourceFaceTileEdge);
        const bool fullCascade = type == 0u && !sourceFaceCascadeArithmeticSafe(origin, cellSize);
        const vec2 tileX = fullCascade ? vec2(0.0f, float(kSourceFaceTilesPerAxis - 1u))
            : sourceFaceTileInterval(low.x, high.x, origin.x, cellSize.x);
        const vec2 tileY = fullCascade ? vec2(0.0f, float(kSourceFaceTilesPerAxis - 1u))
            : sourceFaceTileInterval(low.y, high.y, origin.y, cellSize.y);
        const ivec2 first = ivec2(clamp(floor(vec2(tileX.x, tileY.x)),
            vec2(0.0f), vec2(float(kSourceFaceTilesPerAxis))));
        const ivec2 last = ivec2(clamp(floor(vec2(tileX.y, tileY.y)),
            vec2(-1.0f), vec2(float(kSourceFaceTilesPerAxis - 1u))));
        if (first.x > last.x || first.y > last.y) continue;
        if (faceIndex == 0xFFFFFFFFu) {
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
            if (lane == 0u) {
#endif
            faceIndex = atomicAdd(sunDepthBuf[sourceFaceHeaderIndex(uint(sunDepthBuf.length()))], 1u);
            if (faceIndex < kSourceFaceCapacity) {
                const uint record = kSourceFaceRecordOffset + faceIndex * kSourceFaceRecordWords;
                sunDepthBuf[record + 9u] = type;
                for (uint axis = 0; axis < 3u; ++axis) {
                    sunDepthBuf[record + axis] = floatBitsToUint(corner[axis]);
                    sunDepthBuf[record + 3u + axis] = floatBitsToUint(edgeU[axis]);
                    sunDepthBuf[record + 6u + axis] = floatBitsToUint(edgeV[axis]);
                }
            }
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
            sharedFaceIndex = faceIndex;
            }
            barrier();
            faceIndex = sharedFaceIndex;
            // Every lane must consume the shared record before the next face overwrites it.
            barrier();
#endif
        }
#ifdef IR_SUN_FACE_INDEX_COOPERATIVE
        const uint width = uint(last.x - first.x + 1);
        const uint count = width * uint(last.y - first.y + 1);
        for (uint item = lane; item < count; item += stride) {
            const int x = first.x + int(item % width);
            const int y = first.y + int(item / width);
#else
        for (int y = first.y; y <= last.y; ++y) for (int x = first.x; x <= last.x; ++x) {
#endif
            const uint tile = cascade * kSourceFaceTilesPerAxis * kSourceFaceTilesPerAxis + uint(y) * kSourceFaceTilesPerAxis + uint(x);
            const uint base = sourceFaceTileBase(tile);
            if (faceIndex >= kSourceFaceCapacity) {
                atomicMax(sunDepthBuf[base], kSourceFaceTileQueryCapacity + 1u);
                continue;
            }
            const uint slot = atomicAdd(sunDepthBuf[base], 1u);
            if (slot < kSourceFaceTileCapacity) {
                sunDepthBuf[base + 1u + slot] = faceIndex;
            } else if (slot < kSourceFaceTileQueryCapacity) {
                const uint spill = atomicAdd(sunDepthBuf[sourceFaceSpillCounterIndex(uint(sunDepthBuf.length()))], 1u);
                if (spill < kSourceFaceSpillCapacity) {
                    const uint node = kSourceFaceSpillNodeOffset + spill * kSourceFaceSpillNodeWords;
                    sunDepthBuf[node] = faceIndex;
                    sunDepthBuf[node + 1u] = atomicExchange(sunDepthBuf[kSourceFaceSpillHeadOffset + tile], spill);
                } else {
                    atomicMax(sunDepthBuf[base], kSourceFaceTileQueryCapacity + 1u);
                }
            }
        }
    }
}

void indexSourceSunFace(vec3 corner, vec3 edgeU, vec3 edgeV) {
    const float determinant = projectedFaceDeterminant(edgeU.xy(), edgeV.xy());
    if (sourceFaceDefinitelyDegenerate(edgeU.xy(), edgeV.xy(), determinant)) return;
    vec2 low, high;
    if (!sourceFaceIndexBounds(corner.xy(), edgeU.xy(), edgeV.xy(), determinant, low, high)) {
        low = vec2(-3.4028234663852886e38f);
        high = vec2(3.4028234663852886e38f);
    }
    indexSourceSunGeometry(corner, edgeU, edgeV, 0u, low, high);
}

float dot(vec3 a,vec3 b){return (a.x*b.x+a.y*b.y)+a.z*b.z;}
vec3 operator+(vec3 a,vec3 b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
vec3 operator*(vec3 a,float b){return {a.x*b,a.y*b,a.z*b};}
struct Basis {vec3 sun,u,v;};
Basis basis(float azimuthDegrees,float elevationDegrees){
    const float azimuth=azimuthDegrees*0.017453292519943295f;
    const float elevation=elevationDegrees*0.017453292519943295f;
    const float horizontal=std::cos(elevation);
    vec3 n{horizontal*std::cos(azimuth),horizontal*std::sin(azimuth),-std::sin(elevation)};
    const float length=std::sqrt(dot(n,n));
    n={n.x/length,n.y/length,n.z/length};
    const float s=std::copysign(1.0f,n.z),a=-1.0f/(s+n.z),b=(n.x*n.y)*a;
    return {n,{1.0f+((s*n.x)*n.x)*a,s*b,-s*n.x},{b,s+(n.y*n.y)*a,-n.y}};
}
vec3 sunSpaceProject(vec3 pos3D, vec3 uHat, vec3 vHat, vec3 sunDir) {
    return vec3(dot(pos3D, uHat), dot(pos3D, vHat), -dot(pos3D, sunDir));
}
struct Face {vec3 corner,u,v;};
Face boxFace(Basis frame,float edge,int axis,vec3 center){
    float c[3]={-edge*.5f,-edge*.5f,-edge*.5f},u[3]={},v[3]={};
    c[axis]=frame.sun[axis]>0?edge*.5f:-edge*.5f;
    u[(axis+1)%3]=edge;v[(axis+2)%3]=edge;
    return {sunSpaceProject(center+vec3{c[0],c[1],c[2]},frame.u,frame.v,frame.sun),
            sunSpaceProject({u[0],u[1],u[2]},frame.u,frame.v,frame.sun),
            sunSpaceProject({v[0],v[1],v[2]},frame.u,frame.v,frame.sun)};
}
std::vector<uint> storage(kSourceFaceBufferWords,0xccccccccu);
void reset(){
    sunDepthBuf={storage.data(),kSourceFaceBufferWords};
    sunDepthBuf[kSourceFaceHeaderOffset]=sunDepthBuf[kSourceFaceSpillCounterOffset]=0;
    atomicAdds=atomicMaxes=atomicExchanges=0;
    for(uint tile=0;tile<kSourceFaceTileCount;++tile){
        sunDepthBuf[sourceFaceTileBase(tile)]=0;
        sunDepthBuf[kSourceFaceSpillHeadOffset+tile]=0xffffffffu;
    }
}
void emit(Face face){const vec3 corner=face.corner,u=face.u,v=face.v;indexSourceSunFace(corner,u,v);}
void require(bool value,const char* message){
    if(!value){std::cerr<<message<<"\n";std::exit(1);}
}
void workload(bool check){
    for(float azimuth:{90.f,180.f})for(float edge:{2.f,4.f,5.f,10.f}){
        reset();const Basis frame=basis(azimuth,30);
        const int axis=azimuth==90?0:1;
        const Face first=boxFace(frame,edge,axis,{0,0,0});
        for(uint row=0;row<8;++row)for(uint column=0;column<16;++column)
            emit(boxFace(frame,edge,axis,frame.u*float(64+column*12)+frame.v*float(64+row*12)));
        const uint records=sunDepthBuf[kSourceFaceHeaderOffset];
        const uint spill=sunDepthBuf[kSourceFaceSpillCounterOffset];
        const auto inserts=atomicAdds-records-spill;
        uint incomplete=0,occupied=0;
        for(uint tile=0;tile<kSourceFaceTileCount;++tile){
            const uint count=sunDepthBuf[sourceFaceTileBase(tile)];
            incomplete+=!sourceFaceQueryComplete(count);occupied+=count!=0;
        }
        std::cout<<"azimuth="<<azimuth<<" edge="<<edge
                 <<" determinant="<<projectedFaceDeterminant(first.u.xy(),first.v.xy())
                 <<" records="<<records<<" tile_inserts="<<inserts
                 <<" spill_reservations="<<spill<<" incomplete="<<incomplete
                 <<" occupied="<<occupied<<"\n";
        if(check){
            require(inserts<128*64,"grazing grid must have a finite index workload");
            require(incomplete==0&&spill==0,"grazing grid must keep complete inline lists");
            if(edge==10)require(records==128,"nonzero thin box faces must remain indexed");
        }
    }
}
int main(){workload(MEASURE_ONLY==0);}
