| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.383 | 15.160–17.210 |
| frame p95 | 21.033 | 20.990–21.080 |
| frame p99 | 21.717 | 21.390–21.950 |
| steady frame avg | 15.937 | 15.620–16.230 |
| steady frame p95 | 21.003 | 20.890–21.090 |
| steady frame p99 | 21.670 | 21.360–21.840 |
| GPU frame commandBufferSpans | 6.254 | 6.144–6.353 |
| GPU frame envelope | 6.254 | 6.144–6.353 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 150 of each run excluded | 1350 | 15.936 | 21.018 | 21.673 | 23.285 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.97 | 0.90–1.00 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 2 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 3 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
