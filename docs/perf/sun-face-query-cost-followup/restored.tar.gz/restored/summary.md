| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.220 | 15.750–16.670 |
| frame p95 | 23.837 | 23.500–24.050 |
| frame p99 | 25.127 | 24.600–25.650 |
| steady frame avg | 16.723 | 15.290–17.990 |
| steady frame p95 | 23.760 | 23.120–24.160 |
| steady frame p99 | 24.700 | 24.020–25.230 |
| GPU frame commandBufferSpans | 5.479 | 5.371–5.571 |
| GPU frame envelope | 5.479 | 5.371–5.571 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 150 of each run excluded | 1350 | 16.721 | 23.797 | 24.735 | 26.466 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.97 | 0.90–1.00 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 2 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 3 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
