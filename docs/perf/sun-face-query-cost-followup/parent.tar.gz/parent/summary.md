| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.393 | 15.060–17.240 |
| frame p95 | 21.433 | 21.120–21.600 |
| frame p99 | 22.207 | 21.710–22.690 |
| steady frame avg | 17.113 | 16.100–18.950 |
| steady frame p95 | 21.450 | 21.190–21.620 |
| steady frame p99 | 22.080 | 21.670–22.630 |
| GPU frame commandBufferSpans | 6.067 | 5.969–6.203 |
| GPU frame envelope | 6.067 | 5.969–6.203 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 150 of each run excluded | 1350 | 17.109 | 21.493 | 22.158 | 23.231 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.97 | 0.90–1.00 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 2 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 3 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
