| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 13.670 | 10.250–17.590 |
| frame p95 | 22.107 | 20.990–23.190 |
| frame p99 | 23.873 | 23.370–24.520 |
| steady frame avg | 14.750 | 10.380–19.690 |
| steady frame p95 | 22.213 | 21.190–23.210 |
| steady frame p99 | 23.533 | 23.370–23.820 |
| GPU frame commandBufferSpans | 5.268 | 4.576–6.087 |
| GPU frame envelope | 5.268 | 4.576–6.087 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 150 of each run excluded | 1350 | 14.750 | 22.445 | 23.622 | 27.189 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.83 | 0.60–1.10 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 2 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 3 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
