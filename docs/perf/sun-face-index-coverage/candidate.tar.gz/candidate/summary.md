| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 14.470 | 11.790–16.670 |
| frame p95 | 20.590 | 20.190–20.830 |
| frame p99 | 21.363 | 20.900–21.640 |
| steady frame avg | 13.583 | 11.050–15.640 |
| steady frame p95 | 20.513 | 20.180–20.700 |
| steady frame p99 | 21.207 | 20.900–21.390 |
| GPU frame commandBufferSpans | 5.954 | 5.811–6.226 |
| GPU frame envelope | 5.954 | 5.811–6.226 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 150 of each run excluded | 1350 | 13.585 | 20.619 | 21.197 | 22.301 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.87 | 0.70–1.00 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 2 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 3 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
