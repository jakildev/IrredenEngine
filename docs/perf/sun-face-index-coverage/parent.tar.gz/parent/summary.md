| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.477 | 8.460–8.510 |
| frame p95 | 8.440 | 8.400–8.470 |
| frame p99 | 8.557 | 8.480–8.630 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.423 | 8.390–8.450 |
| steady frame p99 | 8.490 | 8.420–8.540 |
| GPU frame commandBufferSpans | 5.405 | 5.374–5.429 |
| GPU frame envelope | 5.405 | 5.374–5.429 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 150 of each run excluded | 1350 | 8.333 | 8.424 | 8.520 | 8.738 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 2 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
| 3 | True | 600 / 600 | 0 | 600 | 45.000 (0.000) | 403 / 0 (600) |
