| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.840 | 8.840–8.840 |
| frame p95 | 10.960 | 10.960–10.960 |
| frame p99 | 16.260 | 16.260–16.260 |
| steady frame avg | 8.470 | 8.470–8.470 |
| steady frame p95 | 10.220 | 10.220–10.220 |
| steady frame p99 | 11.400 | 11.400–11.400 |
| GPU frame commandBufferSpans | 4.906 | 4.906–4.906 |
| GPU frame envelope | 4.906 | 4.906–4.906 |
| GPU canvasClear | 0.027 | 0.027–0.027 |
| GPU computeLightVolume | 4.291 | 4.291–4.291 |
| GPU computeSunShadow | 0.125 | 0.125–0.125 |
| GPU computeVoxelAO | 0.091 | 0.091–0.091 |
| GPU fbToScreen | 0.063 | 0.063–0.063 |
| GPU fogToTrixel | 0.037 | 0.037–0.037 |
| GPU lightingToTrixel | 0.111 | 0.111–0.111 |
| GPU trixelToFb | 0.121 | 0.121–0.121 |
| GPU voxelCompact | 0.045 | 0.045–0.045 |
| GPU voxelStage1 | 0.594 | 0.594–0.594 |
| GPU voxelStage2 | 0.428 | 0.428–0.428 |
| GPU voxelSunFaces | 0.100 | 0.100–0.100 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.472 | 10.217 | 11.402 | 12.078 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
