| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.260 | 9.260–9.260 |
| frame p95 | 11.050 | 11.050–11.050 |
| frame p99 | 48.520 | 48.520–48.520 |
| steady frame avg | 8.340 | 8.340–8.340 |
| steady frame p95 | 9.910 | 9.910–9.910 |
| steady frame p99 | 10.550 | 10.550–10.550 |
| GPU frame commandBufferSpans | 3.732 | 3.732–3.732 |
| GPU frame envelope | 3.732 | 3.732–3.732 |
| GPU canvasClear | 0.138 | 0.138–0.138 |
| GPU computeLightVolume | 2.535 | 2.535–2.535 |
| GPU computeSunShadow | 0.053 | 0.053–0.053 |
| GPU computeVoxelAO | 0.056 | 0.056–0.056 |
| GPU fbToScreen | 0.038 | 0.038–0.038 |
| GPU fogToTrixel | 0.022 | 0.022–0.022 |
| GPU lightingToTrixel | 0.098 | 0.098–0.098 |
| GPU trixelToFb | 0.145 | 0.145–0.145 |
| GPU voxelCompact | 0.060 | 0.060–0.060 |
| GPU voxelStage1 | 0.347 | 0.347–0.347 |
| GPU voxelStage2 | 0.271 | 0.271–0.271 |
| GPU voxelSunFaces | 0.081 | 0.081–0.081 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.335 | 9.909 | 10.549 | 11.051 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
