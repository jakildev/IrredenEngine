| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.720 | 8.720–8.720 |
| frame p95 | 10.010 | 10.010–10.010 |
| frame p99 | 13.390 | 13.390–13.390 |
| steady frame avg | 8.320 | 8.320–8.320 |
| steady frame p95 | 9.540 | 9.540–9.540 |
| steady frame p99 | 10.030 | 10.030–10.030 |
| GPU frame commandBufferSpans | 5.175 | 5.175–5.175 |
| GPU frame envelope | 5.175 | 5.175–5.175 |
| GPU canvasClear | 0.026 | 0.026–0.026 |
| GPU computeLightVolume | 4.549 | 4.549–4.549 |
| GPU computeSunShadow | 0.138 | 0.138–0.138 |
| GPU computeVoxelAO | 0.095 | 0.095–0.095 |
| GPU fbToScreen | 0.067 | 0.067–0.067 |
| GPU fogToTrixel | 0.041 | 0.041–0.041 |
| GPU lightingToTrixel | 0.119 | 0.119–0.119 |
| GPU trixelToFb | 0.112 | 0.112–0.112 |
| GPU voxelCompact | 0.048 | 0.048–0.048 |
| GPU voxelStage1 | 0.635 | 0.635–0.635 |
| GPU voxelStage2 | 0.459 | 0.459–0.459 |
| GPU voxelSunFaces | 0.104 | 0.104–0.104 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.319 | 9.538 | 10.025 | 10.263 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
