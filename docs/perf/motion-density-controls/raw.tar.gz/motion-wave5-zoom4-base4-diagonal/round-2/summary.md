| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 18.270 | 18.270–18.270 |
| frame p95 | 18.190 | 18.190–18.190 |
| frame p99 | 26.040 | 26.040–26.040 |
| steady frame avg | 17.660 | 17.660–17.660 |
| steady frame p95 | 18.140 | 18.140–18.140 |
| steady frame p99 | 18.450 | 18.450–18.450 |
| GPU frame commandBufferSpans | 13.681 | 13.681–13.681 |
| GPU frame envelope | 13.681 | 13.681–13.681 |
| GPU canvasClear | 0.021 | 0.021–0.021 |
| GPU computeLightVolume | 10.647 | 10.647–10.647 |
| GPU computeSunShadow | 0.060 | 0.060–0.060 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.704 | 8.704–8.704 |
| GPU fbToScreen | 0.047 | 0.047–0.047 |
| GPU fogOverflow | 5.883 | 5.883–5.883 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.887 | 5.887–5.887 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.155 | 0.155–0.155 |
| GPU perAxisScatter | 1.602 | 1.602–1.602 |
| GPU resolvePerAxisScreenDepth | 0.140 | 0.140–0.140 |
| GPU trixelToFb | 0.079 | 0.079–0.079 |
| GPU voxelCompact | 0.356 | 0.356–0.356 |
| GPU voxelPerAxisFinalize | 2.981 | 2.981–2.981 |
| GPU voxelPerAxisOverflow | 3.732 | 3.732–3.732 |
| GPU voxelPerAxisStore | 2.087 | 2.087–2.087 |
| GPU voxelSunFaces | 0.667 | 0.667–0.667 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 17.663 | 18.145 | 18.445 | 19.187 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 7 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 745398 / 0 (180) |
