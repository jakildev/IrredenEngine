| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 18.310 | 18.310–18.310 |
| frame p95 | 18.700 | 18.700–18.700 |
| frame p99 | 26.070 | 26.070–26.070 |
| steady frame avg | 17.660 | 17.660–17.660 |
| steady frame p95 | 18.320 | 18.320–18.320 |
| steady frame p99 | 18.940 | 18.940–18.940 |
| GPU frame commandBufferSpans | 13.685 | 13.685–13.685 |
| GPU frame envelope | 13.685 | 13.685–13.685 |
| GPU canvasClear | 0.024 | 0.024–0.024 |
| GPU computeLightVolume | 10.650 | 10.650–10.650 |
| GPU computeSunShadow | 0.062 | 0.062–0.062 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.689 | 8.689–8.689 |
| GPU fbToScreen | 0.050 | 0.050–0.050 |
| GPU fogOverflow | 5.861 | 5.861–5.861 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.877 | 5.877–5.877 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.150 | 0.150–0.150 |
| GPU perAxisScatter | 1.601 | 1.601–1.601 |
| GPU resolvePerAxisScreenDepth | 0.140 | 0.140–0.140 |
| GPU trixelToFb | 0.072 | 0.072–0.072 |
| GPU voxelCompact | 0.341 | 0.341–0.341 |
| GPU voxelPerAxisFinalize | 2.973 | 2.973–2.973 |
| GPU voxelPerAxisOverflow | 3.734 | 3.734–3.734 |
| GPU voxelPerAxisStore | 2.080 | 2.080–2.080 |
| GPU voxelSunFaces | 0.664 | 0.664–0.664 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 17.659 | 18.317 | 18.939 | 19.205 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 7 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 745398 / 0 (180) |
