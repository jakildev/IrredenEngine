| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 18.330 | 18.330–18.330 |
| frame p95 | 18.700 | 18.700–18.700 |
| frame p99 | 25.340 | 25.340–25.340 |
| steady frame avg | 17.700 | 17.700–17.700 |
| steady frame p95 | 18.450 | 18.450–18.450 |
| steady frame p99 | 19.160 | 19.160–19.160 |
| GPU frame commandBufferSpans | 13.703 | 13.703–13.703 |
| GPU frame envelope | 13.703 | 13.703–13.703 |
| GPU canvasClear | 0.014 | 0.014–0.014 |
| GPU computeLightVolume | 10.665 | 10.665–10.665 |
| GPU computeSunShadow | 0.064 | 0.064–0.064 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.709 | 8.709–8.709 |
| GPU fbToScreen | 0.051 | 0.051–0.051 |
| GPU fogOverflow | 5.864 | 5.864–5.864 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.875 | 5.875–5.875 |
| GPU lightingPerAxis | 0.032 | 0.032–0.032 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.159 | 0.159–0.159 |
| GPU perAxisScatter | 1.601 | 1.601–1.601 |
| GPU resolvePerAxisScreenDepth | 0.141 | 0.141–0.141 |
| GPU trixelToFb | 0.077 | 0.077–0.077 |
| GPU voxelCompact | 0.348 | 0.348–0.348 |
| GPU voxelPerAxisFinalize | 2.974 | 2.974–2.974 |
| GPU voxelPerAxisOverflow | 3.745 | 3.745–3.745 |
| GPU voxelPerAxisStore | 2.075 | 2.075–2.075 |
| GPU voxelSunFaces | 0.668 | 0.668–0.668 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 17.702 | 18.451 | 19.159 | 19.781 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 7 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 745398 / 0 (180) |
