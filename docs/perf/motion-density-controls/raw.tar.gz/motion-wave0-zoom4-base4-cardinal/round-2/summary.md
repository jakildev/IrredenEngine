| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.230 | 9.230–9.230 |
| frame p95 | 11.590 | 11.590–11.590 |
| frame p99 | 17.100 | 17.100–17.100 |
| steady frame avg | 8.510 | 8.510–8.510 |
| steady frame p95 | 10.130 | 10.130–10.130 |
| steady frame p99 | 10.330 | 10.330–10.330 |
| GPU frame commandBufferSpans | 6.256 | 6.256–6.256 |
| GPU frame envelope | 6.256 | 6.256–6.256 |
| GPU canvasClear | 0.023 | 0.023–0.023 |
| GPU computeLightVolume | 2.522 | 2.522–2.522 |
| GPU computeSunShadow | 0.031 | 0.031–0.031 |
| GPU computeVoxelAO | 0.030 | 0.030–0.030 |
| GPU fbToScreen | 0.050 | 0.050–0.050 |
| GPU fogToTrixel | 0.016 | 0.016–0.016 |
| GPU lightingToTrixel | 0.037 | 0.037–0.037 |
| GPU trixelToFb | 0.065 | 0.065–0.065 |
| GPU voxelCompact | 0.029 | 0.029–0.029 |
| GPU voxelStage1 | 2.990 | 2.990–2.990 |
| GPU voxelStage2 | 1.377 | 1.377–1.377 |
| GPU voxelSunFaces | 0.088 | 0.088–0.088 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.511 | 10.133 | 10.330 | 10.895 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
