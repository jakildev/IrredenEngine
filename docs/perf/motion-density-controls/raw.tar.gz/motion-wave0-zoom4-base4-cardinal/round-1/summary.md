| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.400 | 11.400–11.400 |
| frame p95 | 13.200 | 13.200–13.200 |
| frame p99 | 26.950 | 26.950–26.950 |
| steady frame avg | 11.030 | 11.030–11.030 |
| steady frame p95 | 13.100 | 13.100–13.100 |
| steady frame p99 | 13.340 | 13.340–13.340 |
| GPU frame commandBufferSpans | 7.492 | 7.492–7.492 |
| GPU frame envelope | 7.492 | 7.492–7.492 |
| GPU canvasClear | 0.029 | 0.029–0.029 |
| GPU computeLightVolume | 3.242 | 3.242–3.242 |
| GPU computeSunShadow | 0.034 | 0.034–0.034 |
| GPU computeVoxelAO | 0.033 | 0.033–0.033 |
| GPU fbToScreen | 0.055 | 0.055–0.055 |
| GPU fogToTrixel | 0.026 | 0.026–0.026 |
| GPU lightingToTrixel | 0.044 | 0.044–0.044 |
| GPU trixelToFb | 0.082 | 0.082–0.082 |
| GPU voxelCompact | 0.044 | 0.044–0.044 |
| GPU voxelStage1 | 3.343 | 3.343–3.343 |
| GPU voxelStage2 | 1.642 | 1.642–1.642 |
| GPU voxelSunFaces | 0.104 | 0.104–0.104 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 11.029 | 13.098 | 13.340 | 13.449 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
