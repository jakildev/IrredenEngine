| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.050 | 9.050–9.050 |
| frame p95 | 10.550 | 10.550–10.550 |
| frame p99 | 18.390 | 18.390–18.390 |
| steady frame avg | 8.570 | 8.570–8.570 |
| steady frame p95 | 10.200 | 10.200–10.200 |
| steady frame p99 | 10.760 | 10.760–10.760 |
| GPU frame commandBufferSpans | 6.169 | 6.169–6.169 |
| GPU frame envelope | 6.169 | 6.169–6.169 |
| GPU canvasClear | 0.019 | 0.019–0.019 |
| GPU computeLightVolume | 2.522 | 2.522–2.522 |
| GPU computeSunShadow | 0.030 | 0.030–0.030 |
| GPU computeVoxelAO | 0.030 | 0.030–0.030 |
| GPU fbToScreen | 0.049 | 0.049–0.049 |
| GPU fogToTrixel | 0.016 | 0.016–0.016 |
| GPU lightingToTrixel | 0.036 | 0.036–0.036 |
| GPU trixelToFb | 0.073 | 0.073–0.073 |
| GPU voxelCompact | 0.028 | 0.028–0.028 |
| GPU voxelStage1 | 2.933 | 2.933–2.933 |
| GPU voxelStage2 | 1.354 | 1.354–1.354 |
| GPU voxelSunFaces | 0.086 | 0.086–0.086 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.574 | 10.202 | 10.759 | 12.362 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
