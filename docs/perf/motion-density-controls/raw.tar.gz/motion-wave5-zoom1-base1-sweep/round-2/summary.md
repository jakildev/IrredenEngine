| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.480 | 19.480–19.480 |
| frame p95 | 20.470 | 20.470–20.470 |
| frame p99 | 52.110 | 52.110–52.110 |
| steady frame avg | 18.780 | 18.780–18.780 |
| steady frame p95 | 20.200 | 20.200–20.200 |
| steady frame p99 | 20.860 | 20.860–20.860 |
| GPU frame commandBufferSpans | 14.842 | 14.842–14.842 |
| GPU frame envelope | 14.842 | 14.842–14.842 |
| GPU canvasClear | 0.013 | 0.013–0.013 |
| GPU computeLightVolume | 10.501 | 10.501–10.501 |
| GPU computeSunShadow | 0.111 | 0.111–0.111 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.740 | 8.740–8.740 |
| GPU fbToScreen | 0.042 | 0.042–0.042 |
| GPU fogOverflow | 5.806 | 5.806–5.806 |
| GPU fogPerAxis | 0.022 | 0.022–0.022 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.858 | 5.858–5.858 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.140 | 0.140–0.140 |
| GPU perAxisScatter | 3.299 | 3.299–3.299 |
| GPU resolvePerAxisScreenDepth | 0.029 | 0.029–0.029 |
| GPU trixelToFb | 0.075 | 0.075–0.075 |
| GPU voxelCompact | 0.174 | 0.174–0.174 |
| GPU voxelPerAxisFinalize | 3.041 | 3.041–3.041 |
| GPU voxelPerAxisOverflow | 3.768 | 3.768–3.768 |
| GPU voxelPerAxisStore | 2.088 | 2.088–2.088 |
| GPU voxelStage1 | 2.601 | 2.601–2.601 |
| GPU voxelStage2 | 0.628 | 0.628–0.628 |
| GPU voxelSunFaces | 0.283 | 0.283–0.283 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.777 | 20.198 | 20.864 | 21.711 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 749109 / 0 (176) |
