| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.470 | 19.470–19.470 |
| frame p95 | 20.570 | 20.570–20.570 |
| frame p99 | 63.170 | 63.170–63.170 |
| steady frame avg | 18.720 | 18.720–18.720 |
| steady frame p95 | 20.340 | 20.340–20.340 |
| steady frame p99 | 20.930 | 20.930–20.930 |
| GPU frame commandBufferSpans | 14.811 | 14.811–14.811 |
| GPU frame envelope | 14.811 | 14.811–14.811 |
| GPU canvasClear | 0.015 | 0.015–0.015 |
| GPU computeLightVolume | 10.471 | 10.471–10.471 |
| GPU computeSunShadow | 0.109 | 0.109–0.109 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.708 | 8.708–8.708 |
| GPU fbToScreen | 0.042 | 0.042–0.042 |
| GPU fogOverflow | 5.787 | 5.787–5.787 |
| GPU fogPerAxis | 0.022 | 0.022–0.022 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.842 | 5.842–5.842 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.138 | 0.138–0.138 |
| GPU perAxisScatter | 3.293 | 3.293–3.293 |
| GPU resolvePerAxisScreenDepth | 0.029 | 0.029–0.029 |
| GPU trixelToFb | 0.077 | 0.077–0.077 |
| GPU voxelCompact | 0.178 | 0.178–0.178 |
| GPU voxelPerAxisFinalize | 3.038 | 3.038–3.038 |
| GPU voxelPerAxisOverflow | 3.754 | 3.754–3.754 |
| GPU voxelPerAxisStore | 2.088 | 2.088–2.088 |
| GPU voxelStage1 | 2.925 | 2.925–2.925 |
| GPU voxelStage2 | 0.574 | 0.574–0.574 |
| GPU voxelSunFaces | 0.282 | 0.282–0.282 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.717 | 20.341 | 20.927 | 21.115 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 749109 / 0 (176) |
