| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.660 | 19.660–19.660 |
| frame p95 | 20.580 | 20.580–20.580 |
| frame p99 | 76.040 | 76.040–76.040 |
| steady frame avg | 18.780 | 18.780–18.780 |
| steady frame p95 | 20.290 | 20.290–20.290 |
| steady frame p99 | 20.770 | 20.770–20.770 |
| GPU frame commandBufferSpans | 14.898 | 14.898–14.898 |
| GPU frame envelope | 14.898 | 14.898–14.898 |
| GPU canvasClear | 0.014 | 0.014–0.014 |
| GPU computeLightVolume | 10.549 | 10.549–10.549 |
| GPU computeSunShadow | 0.108 | 0.108–0.108 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.775 | 8.775–8.775 |
| GPU fbToScreen | 0.037 | 0.037–0.037 |
| GPU fogOverflow | 5.811 | 5.811–5.811 |
| GPU fogPerAxis | 0.022 | 0.022–0.022 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.865 | 5.865–5.865 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.137 | 0.137–0.137 |
| GPU perAxisScatter | 3.297 | 3.297–3.297 |
| GPU resolvePerAxisScreenDepth | 0.028 | 0.028–0.028 |
| GPU trixelToFb | 0.078 | 0.078–0.078 |
| GPU voxelCompact | 0.179 | 0.179–0.179 |
| GPU voxelPerAxisFinalize | 3.065 | 3.065–3.065 |
| GPU voxelPerAxisOverflow | 3.767 | 3.767–3.767 |
| GPU voxelPerAxisStore | 2.106 | 2.106–2.106 |
| GPU voxelStage1 | 2.707 | 2.707–2.707 |
| GPU voxelStage2 | 0.813 | 0.813–0.813 |
| GPU voxelSunFaces | 0.281 | 0.281–0.281 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.781 | 20.291 | 20.773 | 20.937 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 749109 / 0 (176) |
