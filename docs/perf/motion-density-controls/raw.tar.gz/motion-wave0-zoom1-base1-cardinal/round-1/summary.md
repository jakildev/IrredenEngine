| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.870 | 8.870–8.870 |
| frame p95 | 9.960 | 9.960–9.960 |
| frame p99 | 24.950 | 24.950–24.950 |
| steady frame avg | 8.400 | 8.400–8.400 |
| steady frame p95 | 9.930 | 9.930–9.930 |
| steady frame p99 | 10.300 | 10.300–10.300 |
| GPU frame commandBufferSpans | 3.412 | 3.412–3.412 |
| GPU frame envelope | 3.412 | 3.412–3.412 |
| GPU canvasClear | 0.074 | 0.074–0.074 |
| GPU computeLightVolume | 2.385 | 2.385–2.385 |
| GPU computeSunShadow | 0.058 | 0.058–0.058 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU fbToScreen | 0.039 | 0.039–0.039 |
| GPU fogToTrixel | 0.023 | 0.023–0.023 |
| GPU lightingToTrixel | 0.060 | 0.060–0.060 |
| GPU trixelToFb | 0.174 | 0.174–0.174 |
| GPU voxelCompact | 0.050 | 0.050–0.050 |
| GPU voxelStage1 | 0.214 | 0.214–0.214 |
| GPU voxelStage2 | 0.187 | 0.187–0.187 |
| GPU voxelSunFaces | 0.075 | 0.075–0.075 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.396 | 9.933 | 10.297 | 15.381 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
