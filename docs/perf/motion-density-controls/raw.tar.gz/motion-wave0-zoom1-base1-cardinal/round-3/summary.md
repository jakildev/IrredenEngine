| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.750 | 8.750–8.750 |
| frame p95 | 10.490 | 10.490–10.490 |
| frame p99 | 13.300 | 13.300–13.300 |
| steady frame avg | 8.440 | 8.440–8.440 |
| steady frame p95 | 9.980 | 9.980–9.980 |
| steady frame p99 | 11.230 | 11.230–11.230 |
| GPU frame commandBufferSpans | 4.923 | 4.923–4.923 |
| GPU frame envelope | 4.923 | 4.923–4.923 |
| GPU canvasClear | 0.028 | 0.028–0.028 |
| GPU computeLightVolume | 4.279 | 4.279–4.279 |
| GPU computeSunShadow | 0.103 | 0.103–0.103 |
| GPU computeVoxelAO | 0.069 | 0.069–0.069 |
| GPU fbToScreen | 0.080 | 0.080–0.080 |
| GPU fogToTrixel | 0.050 | 0.050–0.050 |
| GPU lightingToTrixel | 0.074 | 0.074–0.074 |
| GPU trixelToFb | 0.144 | 0.144–0.144 |
| GPU voxelCompact | 0.051 | 0.051–0.051 |
| GPU voxelStage1 | 0.336 | 0.336–0.336 |
| GPU voxelStage2 | 0.285 | 0.285–0.285 |
| GPU voxelSunFaces | 0.109 | 0.109–0.109 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.441 | 9.975 | 11.234 | 13.301 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
