| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.820 | 8.820–8.820 |
| frame p95 | 10.380 | 10.380–10.380 |
| frame p99 | 16.410 | 16.410–16.410 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 9.540 | 9.540–9.540 |
| steady frame p99 | 10.290 | 10.290–10.290 |
| GPU frame commandBufferSpans | 5.456 | 5.456–5.456 |
| GPU frame envelope | 5.456 | 5.456–5.456 |
| GPU canvasClear | 0.033 | 0.033–0.033 |
| GPU computeLightVolume | 4.738 | 4.738–4.738 |
| GPU computeSunShadow | 0.120 | 0.120–0.120 |
| GPU computeVoxelAO | 0.073 | 0.073–0.073 |
| GPU fbToScreen | 0.093 | 0.093–0.093 |
| GPU fogToTrixel | 0.057 | 0.057–0.057 |
| GPU lightingToTrixel | 0.080 | 0.080–0.080 |
| GPU trixelToFb | 0.168 | 0.168–0.168 |
| GPU voxelCompact | 0.058 | 0.058–0.058 |
| GPU voxelStage1 | 0.386 | 0.386–0.386 |
| GPU voxelStage2 | 0.320 | 0.320–0.320 |
| GPU voxelSunFaces | 0.121 | 0.121–0.121 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.329 | 9.542 | 10.291 | 10.382 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
