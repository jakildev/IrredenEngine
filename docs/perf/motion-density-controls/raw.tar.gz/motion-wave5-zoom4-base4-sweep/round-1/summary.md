| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 20.800 | 20.800–20.800 |
| frame p95 | 21.430 | 21.430–21.430 |
| frame p99 | 94.030 | 94.030–94.030 |
| steady frame avg | 20.280 | 20.280–20.280 |
| steady frame p95 | 20.710 | 20.710–20.710 |
| steady frame p99 | 91.480 | 91.480–91.480 |
| GPU frame commandBufferSpans | 16.015 | 16.015–16.015 |
| GPU frame envelope | 16.015 | 16.015–16.015 |
| GPU canvasClear | 0.023 | 0.023–0.023 |
| GPU computeLightVolume | 10.491 | 10.491–10.491 |
| GPU computeSunShadow | 0.096 | 0.096–0.096 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.666 | 8.666–8.666 |
| GPU fbToScreen | 0.044 | 0.044–0.044 |
| GPU fogOverflow | 5.881 | 5.881–5.881 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.010 | 0.010–0.010 |
| GPU lightingOverflow | 5.881 | 5.881–5.881 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.122 | 0.122–0.122 |
| GPU perAxisScatter | 2.029 | 2.029–2.029 |
| GPU resolvePerAxisScreenDepth | 0.145 | 0.145–0.145 |
| GPU trixelToFb | 0.084 | 0.084–0.084 |
| GPU voxelCompact | 0.447 | 0.447–0.447 |
| GPU voxelPerAxisFinalize | 2.960 | 2.960–2.960 |
| GPU voxelPerAxisOverflow | 3.732 | 3.732–3.732 |
| GPU voxelPerAxisStore | 2.059 | 2.059–2.059 |
| GPU voxelStage1 | 32.006 | 32.006–32.006 |
| GPU voxelStage2 | 26.686 | 26.686–26.686 |
| GPU voxelSunFaces | 0.953 | 0.953–0.953 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 20.277 | 20.709 | 91.483 | 94.028 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 745368 / 0 (176) |
