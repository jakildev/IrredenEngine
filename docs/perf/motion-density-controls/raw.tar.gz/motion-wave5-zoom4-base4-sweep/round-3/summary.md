| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 20.870 | 20.870–20.870 |
| frame p95 | 21.110 | 21.110–21.110 |
| frame p99 | 93.890 | 93.890–93.890 |
| steady frame avg | 20.190 | 20.190–20.190 |
| steady frame p95 | 20.500 | 20.500–20.500 |
| steady frame p99 | 92.240 | 92.240–92.240 |
| GPU frame commandBufferSpans | 16.086 | 16.086–16.086 |
| GPU frame envelope | 16.086 | 16.086–16.086 |
| GPU canvasClear | 0.022 | 0.022–0.022 |
| GPU computeLightVolume | 10.691 | 10.691–10.691 |
| GPU computeSunShadow | 0.065 | 0.065–0.065 |
| GPU computeVoxelAO | 0.017 | 0.017–0.017 |
| GPU computeVoxelAoPerAxis | 8.707 | 8.707–8.707 |
| GPU fbToScreen | 0.048 | 0.048–0.048 |
| GPU fogOverflow | 5.856 | 5.856–5.856 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.845 | 5.845–5.845 |
| GPU lightingPerAxis | 0.032 | 0.032–0.032 |
| GPU lightingToTrixel | 0.016 | 0.016–0.016 |
| GPU perAxisCellCompact | 0.183 | 0.183–0.183 |
| GPU perAxisScatter | 2.032 | 2.032–2.032 |
| GPU resolvePerAxisScreenDepth | 0.147 | 0.147–0.147 |
| GPU trixelToFb | 0.089 | 0.089–0.089 |
| GPU voxelCompact | 0.438 | 0.438–0.438 |
| GPU voxelPerAxisFinalize | 2.952 | 2.952–2.952 |
| GPU voxelPerAxisOverflow | 3.754 | 3.754–3.754 |
| GPU voxelPerAxisStore | 2.070 | 2.070–2.070 |
| GPU voxelStage1 | 33.252 | 33.252–33.252 |
| GPU voxelStage2 | 26.666 | 26.666–26.666 |
| GPU voxelSunFaces | 0.972 | 0.972–0.972 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 20.191 | 20.496 | 92.236 | 93.894 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 745368 / 0 (176) |
