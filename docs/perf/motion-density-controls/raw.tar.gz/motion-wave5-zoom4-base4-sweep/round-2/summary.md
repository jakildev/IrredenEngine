| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 20.790 | 20.790–20.790 |
| frame p95 | 21.770 | 21.770–21.770 |
| frame p99 | 94.640 | 94.640–94.640 |
| steady frame avg | 20.280 | 20.280–20.280 |
| steady frame p95 | 20.200 | 20.200–20.200 |
| steady frame p99 | 91.800 | 91.800–91.800 |
| GPU frame commandBufferSpans | 16.013 | 16.013–16.013 |
| GPU frame envelope | 16.013 | 16.013–16.013 |
| GPU canvasClear | 0.022 | 0.022–0.022 |
| GPU computeLightVolume | 10.477 | 10.477–10.477 |
| GPU computeSunShadow | 0.096 | 0.096–0.096 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.649 | 8.649–8.649 |
| GPU fbToScreen | 0.044 | 0.044–0.044 |
| GPU fogOverflow | 5.850 | 5.850–5.850 |
| GPU fogPerAxis | 0.022 | 0.022–0.022 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.857 | 5.857–5.857 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.123 | 0.123–0.123 |
| GPU perAxisScatter | 2.030 | 2.030–2.030 |
| GPU resolvePerAxisScreenDepth | 0.146 | 0.146–0.146 |
| GPU trixelToFb | 0.083 | 0.083–0.083 |
| GPU voxelCompact | 0.443 | 0.443–0.443 |
| GPU voxelPerAxisFinalize | 2.956 | 2.956–2.956 |
| GPU voxelPerAxisOverflow | 3.725 | 3.725–3.725 |
| GPU voxelPerAxisStore | 2.056 | 2.056–2.056 |
| GPU voxelStage1 | 32.359 | 32.359–32.359 |
| GPU voxelStage2 | 26.685 | 26.685–26.685 |
| GPU voxelSunFaces | 0.957 | 0.957–0.957 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 20.279 | 20.197 | 91.804 | 94.638 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 745368 / 0 (176) |
