| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.240 | 9.240–9.240 |
| frame p95 | 11.510 | 11.510–11.510 |
| frame p99 | 56.400 | 56.400–56.400 |
| steady frame avg | 8.620 | 8.620–8.620 |
| steady frame p95 | 10.690 | 10.690–10.690 |
| steady frame p99 | 15.770 | 15.770–15.770 |
| GPU frame commandBufferSpans | 4.811 | 4.811–4.811 |
| GPU frame envelope | 4.811 | 4.811–4.811 |
| GPU canvasClear | 0.018 | 0.018–0.018 |
| GPU computeLightVolume | 3.532 | 3.532–3.532 |
| GPU computeSunShadow | 0.105 | 0.105–0.105 |
| GPU computeVoxelAO | 0.088 | 0.088–0.088 |
| GPU computeVoxelAoPerAxis | 0.847 | 0.847–0.847 |
| GPU fbToScreen | 0.055 | 0.055–0.055 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.024 | 0.024–0.024 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 0.008 | 0.008–0.008 |
| GPU lightingPerAxis | 0.036 | 0.036–0.036 |
| GPU lightingToTrixel | 0.018 | 0.018–0.018 |
| GPU perAxisCellCompact | 0.102 | 0.102–0.102 |
| GPU perAxisScatter | 0.088 | 0.088–0.088 |
| GPU resolvePerAxisScreenDepth | 0.130 | 0.130–0.130 |
| GPU trixelToFb | 0.084 | 0.084–0.084 |
| GPU voxelCompact | 0.077 | 0.077–0.077 |
| GPU voxelPerAxisFinalize | 0.173 | 0.173–0.173 |
| GPU voxelPerAxisOverflow | 0.121 | 0.121–0.121 |
| GPU voxelPerAxisStore | 0.712 | 0.712–0.712 |
| GPU voxelStage1 | 7.321 | 7.321–7.321 |
| GPU voxelStage2 | 2.207 | 2.207–2.207 |
| GPU voxelSunFaces | 0.130 | 0.130–0.130 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.620 | 10.686 | 15.765 | 16.787 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 0 / 0 (176) |
