| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.520 | 9.520–9.520 |
| frame p95 | 11.320 | 11.320–11.320 |
| frame p99 | 58.670 | 58.670–58.670 |
| steady frame avg | 8.840 | 8.840–8.840 |
| steady frame p95 | 11.120 | 11.120–11.120 |
| steady frame p99 | 15.370 | 15.370–15.370 |
| GPU frame commandBufferSpans | 5.524 | 5.524–5.524 |
| GPU frame envelope | 5.524 | 5.524–5.524 |
| GPU canvasClear | 0.018 | 0.018–0.018 |
| GPU computeLightVolume | 4.216 | 4.216–4.216 |
| GPU computeSunShadow | 0.120 | 0.120–0.120 |
| GPU computeVoxelAO | 0.082 | 0.082–0.082 |
| GPU computeVoxelAoPerAxis | 0.929 | 0.929–0.929 |
| GPU fbToScreen | 0.059 | 0.059–0.059 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.028 | 0.028–0.028 |
| GPU fogToTrixel | 0.013 | 0.013–0.013 |
| GPU lightingOverflow | 0.008 | 0.008–0.008 |
| GPU lightingPerAxis | 0.042 | 0.042–0.042 |
| GPU lightingToTrixel | 0.019 | 0.019–0.019 |
| GPU perAxisCellCompact | 0.103 | 0.103–0.103 |
| GPU perAxisScatter | 0.106 | 0.106–0.106 |
| GPU resolvePerAxisScreenDepth | 0.154 | 0.154–0.154 |
| GPU trixelToFb | 0.089 | 0.089–0.089 |
| GPU voxelCompact | 0.088 | 0.088–0.088 |
| GPU voxelPerAxisFinalize | 0.201 | 0.201–0.201 |
| GPU voxelPerAxisOverflow | 0.126 | 0.126–0.126 |
| GPU voxelPerAxisStore | 0.724 | 0.724–0.724 |
| GPU voxelStage1 | 6.306 | 6.306–6.306 |
| GPU voxelStage2 | 2.167 | 2.167–2.167 |
| GPU voxelSunFaces | 0.152 | 0.152–0.152 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.836 | 11.120 | 15.366 | 17.692 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 0 / 0 (176) |
