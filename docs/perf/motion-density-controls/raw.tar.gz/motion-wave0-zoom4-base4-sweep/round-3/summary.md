| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.120 | 9.120–9.120 |
| frame p95 | 10.820 | 10.820–10.820 |
| frame p99 | 55.600 | 55.600–55.600 |
| steady frame avg | 8.360 | 8.360–8.360 |
| steady frame p95 | 9.260 | 9.260–9.260 |
| steady frame p99 | 12.100 | 12.100–12.100 |
| GPU frame commandBufferSpans | 4.709 | 4.709–4.709 |
| GPU frame envelope | 4.709 | 4.709–4.709 |
| GPU canvasClear | 0.014 | 0.014–0.014 |
| GPU computeLightVolume | 3.504 | 3.504–3.504 |
| GPU computeSunShadow | 0.107 | 0.107–0.107 |
| GPU computeVoxelAO | 0.086 | 0.086–0.086 |
| GPU computeVoxelAoPerAxis | 0.852 | 0.852–0.852 |
| GPU fbToScreen | 0.056 | 0.056–0.056 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.024 | 0.024–0.024 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 0.008 | 0.008–0.008 |
| GPU lightingPerAxis | 0.037 | 0.037–0.037 |
| GPU lightingToTrixel | 0.018 | 0.018–0.018 |
| GPU perAxisCellCompact | 0.099 | 0.099–0.099 |
| GPU perAxisScatter | 0.087 | 0.087–0.087 |
| GPU resolvePerAxisScreenDepth | 0.131 | 0.131–0.131 |
| GPU trixelToFb | 0.081 | 0.081–0.081 |
| GPU voxelCompact | 0.074 | 0.074–0.074 |
| GPU voxelPerAxisFinalize | 0.173 | 0.173–0.173 |
| GPU voxelPerAxisOverflow | 0.113 | 0.113–0.113 |
| GPU voxelPerAxisStore | 0.701 | 0.701–0.701 |
| GPU voxelStage1 | 6.811 | 6.811–6.811 |
| GPU voxelStage2 | 2.142 | 2.142–2.142 |
| GPU voxelSunFaces | 0.133 | 0.133–0.133 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.359 | 9.262 | 12.098 | 14.045 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 0 / 0 (176) |
