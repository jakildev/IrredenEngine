| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 18.780 | 18.780–18.780 |
| frame p95 | 19.280 | 19.280–19.280 |
| frame p99 | 23.390 | 23.390–23.390 |
| steady frame avg | 18.290 | 18.290–18.290 |
| steady frame p95 | 19.270 | 19.270–19.270 |
| steady frame p99 | 19.640 | 19.640–19.640 |
| GPU frame commandBufferSpans | 14.168 | 14.168–14.168 |
| GPU frame envelope | 14.168 | 14.168–14.168 |
| GPU canvasClear | 0.014 | 0.014–0.014 |
| GPU computeLightVolume | 10.642 | 10.642–10.642 |
| GPU computeSunShadow | 0.063 | 0.063–0.063 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.725 | 8.725–8.725 |
| GPU fbToScreen | 0.044 | 0.044–0.044 |
| GPU fogOverflow | 5.792 | 5.792–5.792 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.823 | 5.823–5.823 |
| GPU lightingPerAxis | 0.032 | 0.032–0.032 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.169 | 0.169–0.169 |
| GPU perAxisScatter | 2.411 | 2.411–2.411 |
| GPU resolvePerAxisScreenDepth | 0.030 | 0.030–0.030 |
| GPU trixelToFb | 0.073 | 0.073–0.073 |
| GPU voxelCompact | 0.185 | 0.185–0.185 |
| GPU voxelPerAxisFinalize | 3.026 | 3.026–3.026 |
| GPU voxelPerAxisOverflow | 3.763 | 3.763–3.763 |
| GPU voxelPerAxisStore | 2.088 | 2.088–2.088 |
| GPU voxelSunFaces | 0.296 | 0.296–0.296 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.289 | 19.274 | 19.639 | 19.672 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 749109 / 0 (180) |
