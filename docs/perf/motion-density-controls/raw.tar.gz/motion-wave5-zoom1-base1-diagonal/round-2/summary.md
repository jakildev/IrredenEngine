| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 18.920 | 18.920–18.920 |
| frame p95 | 19.310 | 19.310–19.310 |
| frame p99 | 25.470 | 25.470–25.470 |
| steady frame avg | 18.240 | 18.240–18.240 |
| steady frame p95 | 18.920 | 18.920–18.920 |
| steady frame p99 | 19.470 | 19.470–19.470 |
| GPU frame commandBufferSpans | 14.202 | 14.202–14.202 |
| GPU frame envelope | 14.202 | 14.202–14.202 |
| GPU canvasClear | 0.015 | 0.015–0.015 |
| GPU computeLightVolume | 10.666 | 10.666–10.666 |
| GPU computeSunShadow | 0.146 | 0.146–0.146 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.752 | 8.752–8.752 |
| GPU fbToScreen | 0.045 | 0.045–0.045 |
| GPU fogOverflow | 5.798 | 5.798–5.798 |
| GPU fogPerAxis | 0.024 | 0.024–0.024 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.826 | 5.826–5.826 |
| GPU lightingPerAxis | 0.032 | 0.032–0.032 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.174 | 0.174–0.174 |
| GPU perAxisScatter | 2.409 | 2.409–2.409 |
| GPU resolvePerAxisScreenDepth | 0.030 | 0.030–0.030 |
| GPU trixelToFb | 0.080 | 0.080–0.080 |
| GPU voxelCompact | 0.183 | 0.183–0.183 |
| GPU voxelPerAxisFinalize | 3.031 | 3.031–3.031 |
| GPU voxelPerAxisOverflow | 3.776 | 3.776–3.776 |
| GPU voxelPerAxisStore | 2.102 | 2.102–2.102 |
| GPU voxelSunFaces | 0.295 | 0.295–0.295 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.244 | 18.917 | 19.469 | 19.547 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 7 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 749109 / 0 (180) |
