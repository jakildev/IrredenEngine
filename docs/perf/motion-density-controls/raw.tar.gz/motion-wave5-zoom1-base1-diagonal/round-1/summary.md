| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 18.840 | 18.840–18.840 |
| frame p95 | 19.190 | 19.190–19.190 |
| frame p99 | 27.750 | 27.750–27.750 |
| steady frame avg | 18.120 | 18.120–18.120 |
| steady frame p95 | 18.880 | 18.880–18.880 |
| steady frame p99 | 19.200 | 19.200–19.200 |
| GPU frame commandBufferSpans | 14.190 | 14.190–14.190 |
| GPU frame envelope | 14.190 | 14.190–14.190 |
| GPU canvasClear | 0.013 | 0.013–0.013 |
| GPU computeLightVolume | 10.667 | 10.667–10.667 |
| GPU computeSunShadow | 0.060 | 0.060–0.060 |
| GPU computeVoxelAO | 0.017 | 0.017–0.017 |
| GPU computeVoxelAoPerAxis | 8.763 | 8.763–8.763 |
| GPU fbToScreen | 0.039 | 0.039–0.039 |
| GPU fogOverflow | 5.804 | 5.804–5.804 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.835 | 5.835–5.835 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.158 | 0.158–0.158 |
| GPU perAxisScatter | 2.405 | 2.405–2.405 |
| GPU resolvePerAxisScreenDepth | 0.029 | 0.029–0.029 |
| GPU trixelToFb | 0.074 | 0.074–0.074 |
| GPU voxelCompact | 0.185 | 0.185–0.185 |
| GPU voxelPerAxisFinalize | 3.064 | 3.064–3.064 |
| GPU voxelPerAxisOverflow | 3.758 | 3.758–3.758 |
| GPU voxelPerAxisStore | 2.113 | 2.113–2.113 |
| GPU voxelSunFaces | 0.296 | 0.296–0.296 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.117 | 18.875 | 19.197 | 19.611 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 7 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 749109 / 0 (180) |
