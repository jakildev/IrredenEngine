| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.010 | 9.010–9.010 |
| frame p95 | 9.780 | 9.780–9.780 |
| frame p99 | 14.760 | 14.760–14.760 |
| steady frame avg | 8.460 | 8.460–8.460 |
| steady frame p95 | 9.720 | 9.720–9.720 |
| steady frame p99 | 12.490 | 12.490–12.490 |
| GPU frame commandBufferSpans | 3.867 | 3.867–3.867 |
| GPU frame envelope | 3.867 | 3.867–3.867 |
| GPU canvasClear | 0.013 | 0.013–0.013 |
| GPU computeLightVolume | 2.772 | 2.772–2.772 |
| GPU computeSunShadow | 0.141 | 0.141–0.141 |
| GPU computeVoxelAO | 0.088 | 0.088–0.088 |
| GPU computeVoxelAoPerAxis | 0.750 | 0.750–0.750 |
| GPU fbToScreen | 0.048 | 0.048–0.048 |
| GPU fogOverflow | 0.002 | 0.002–0.002 |
| GPU fogPerAxis | 0.022 | 0.022–0.022 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 0.005 | 0.005–0.005 |
| GPU lightingPerAxis | 0.034 | 0.034–0.034 |
| GPU lightingToTrixel | 0.017 | 0.017–0.017 |
| GPU perAxisCellCompact | 0.096 | 0.096–0.096 |
| GPU perAxisScatter | 0.061 | 0.061–0.061 |
| GPU resolvePerAxisScreenDepth | 0.030 | 0.030–0.030 |
| GPU trixelToFb | 0.076 | 0.076–0.076 |
| GPU voxelCompact | 0.055 | 0.055–0.055 |
| GPU voxelPerAxisFinalize | 0.166 | 0.166–0.166 |
| GPU voxelPerAxisOverflow | 0.115 | 0.115–0.115 |
| GPU voxelPerAxisStore | 0.674 | 0.674–0.674 |
| GPU voxelSunFaces | 0.082 | 0.082–0.082 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.465 | 9.723 | 12.488 | 13.553 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 0 / 0 (180) |
