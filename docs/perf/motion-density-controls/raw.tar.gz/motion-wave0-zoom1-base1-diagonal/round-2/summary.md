| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.710 | 9.710–9.710 |
| frame p95 | 10.950 | 10.950–10.950 |
| frame p99 | 14.300 | 14.300–14.300 |
| steady frame avg | 9.190 | 9.190–9.190 |
| steady frame p95 | 10.830 | 10.830–10.830 |
| steady frame p99 | 11.230 | 11.230–11.230 |
| GPU frame commandBufferSpans | 6.120 | 6.120–6.120 |
| GPU frame envelope | 6.120 | 6.120–6.120 |
| GPU canvasClear | 0.023 | 0.023–0.023 |
| GPU computeLightVolume | 4.830 | 4.830–4.830 |
| GPU computeSunShadow | 0.228 | 0.228–0.228 |
| GPU computeVoxelAO | 0.089 | 0.089–0.089 |
| GPU computeVoxelAoPerAxis | 0.962 | 0.962–0.962 |
| GPU fbToScreen | 0.071 | 0.071–0.071 |
| GPU fogOverflow | 0.004 | 0.004–0.004 |
| GPU fogPerAxis | 0.036 | 0.036–0.036 |
| GPU fogToTrixel | 0.015 | 0.015–0.015 |
| GPU lightingOverflow | 0.008 | 0.008–0.008 |
| GPU lightingPerAxis | 0.052 | 0.052–0.052 |
| GPU lightingToTrixel | 0.023 | 0.023–0.023 |
| GPU perAxisCellCompact | 0.110 | 0.110–0.110 |
| GPU perAxisScatter | 0.109 | 0.109–0.109 |
| GPU resolvePerAxisScreenDepth | 0.043 | 0.043–0.043 |
| GPU trixelToFb | 0.109 | 0.109–0.109 |
| GPU voxelCompact | 0.080 | 0.080–0.080 |
| GPU voxelPerAxisFinalize | 0.224 | 0.224–0.224 |
| GPU voxelPerAxisOverflow | 0.138 | 0.138–0.138 |
| GPU voxelPerAxisStore | 0.759 | 0.759–0.759 |
| GPU voxelSunFaces | 0.115 | 0.115–0.115 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 9.193 | 10.832 | 11.230 | 11.304 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 0 / 0 (180) |
