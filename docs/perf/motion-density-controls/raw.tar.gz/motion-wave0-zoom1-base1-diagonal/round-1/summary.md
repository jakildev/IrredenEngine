| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.500 | 9.500–9.500 |
| frame p95 | 10.530 | 10.530–10.530 |
| frame p99 | 46.720 | 46.720–46.720 |
| steady frame avg | 8.340 | 8.340–8.340 |
| steady frame p95 | 10.150 | 10.150–10.150 |
| steady frame p99 | 10.530 | 10.530–10.530 |
| GPU frame commandBufferSpans | 4.435 | 4.435–4.435 |
| GPU frame envelope | 4.435 | 4.435–4.435 |
| GPU canvasClear | 0.069 | 0.069–0.069 |
| GPU computeLightVolume | 2.654 | 2.654–2.654 |
| GPU computeSunShadow | 0.139 | 0.139–0.139 |
| GPU computeVoxelAO | 0.087 | 0.087–0.087 |
| GPU computeVoxelAoPerAxis | 0.744 | 0.744–0.744 |
| GPU fbToScreen | 0.044 | 0.044–0.044 |
| GPU fogOverflow | 0.006 | 0.006–0.006 |
| GPU fogPerAxis | 0.021 | 0.021–0.021 |
| GPU fogToTrixel | 0.010 | 0.010–0.010 |
| GPU lightingOverflow | 0.004 | 0.004–0.004 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.102 | 0.102–0.102 |
| GPU perAxisScatter | 0.059 | 0.059–0.059 |
| GPU resolvePerAxisScreenDepth | 0.030 | 0.030–0.030 |
| GPU trixelToFb | 0.136 | 0.136–0.136 |
| GPU voxelCompact | 0.086 | 0.086–0.086 |
| GPU voxelPerAxisFinalize | 0.177 | 0.177–0.177 |
| GPU voxelPerAxisOverflow | 0.098 | 0.098–0.098 |
| GPU voxelPerAxisStore | 0.893 | 0.893–0.893 |
| GPU voxelSunFaces | 0.084 | 0.084–0.084 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.340 | 10.151 | 10.527 | 10.741 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 0 / 0 (180) |
