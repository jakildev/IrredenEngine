| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 10.490 | 10.490–10.490 |
| frame p95 | 11.460 | 11.460–11.460 |
| frame p99 | 15.260 | 15.260–15.260 |
| steady frame avg | 10.040 | 10.040–10.040 |
| steady frame p95 | 11.190 | 11.190–11.190 |
| steady frame p99 | 11.480 | 11.480–11.480 |
| GPU frame commandBufferSpans | 7.444 | 7.444–7.444 |
| GPU frame envelope | 7.444 | 7.444–7.444 |
| GPU canvasClear | 0.034 | 0.034–0.034 |
| GPU computeLightVolume | 3.307 | 3.307–3.307 |
| GPU computeSunShadow | 0.029 | 0.029–0.029 |
| GPU computeVoxelAO | 0.045 | 0.045–0.045 |
| GPU fbToScreen | 0.047 | 0.047–0.047 |
| GPU fogToTrixel | 0.014 | 0.014–0.014 |
| GPU lightingToTrixel | 0.032 | 0.032–0.032 |
| GPU trixelToFb | 0.070 | 0.070–0.070 |
| GPU voxelCompact | 0.058 | 0.058–0.058 |
| GPU voxelStage1 | 3.089 | 3.089–3.089 |
| GPU voxelStage2 | 1.723 | 1.723–1.723 |
| GPU voxelSunFaces | 0.252 | 0.252–0.252 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 10.040 | 11.193 | 11.482 | 12.330 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
