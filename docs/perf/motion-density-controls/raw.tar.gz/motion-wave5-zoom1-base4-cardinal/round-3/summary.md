| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 10.480 | 10.480–10.480 |
| frame p95 | 11.450 | 11.450–11.450 |
| frame p99 | 16.030 | 16.030–16.030 |
| steady frame avg | 10.040 | 10.040–10.040 |
| steady frame p95 | 11.300 | 11.300–11.300 |
| steady frame p99 | 11.590 | 11.590–11.590 |
| GPU frame commandBufferSpans | 7.435 | 7.435–7.435 |
| GPU frame envelope | 7.435 | 7.435–7.435 |
| GPU canvasClear | 0.034 | 0.034–0.034 |
| GPU computeLightVolume | 3.313 | 3.313–3.313 |
| GPU computeSunShadow | 0.030 | 0.030–0.030 |
| GPU computeVoxelAO | 0.047 | 0.047–0.047 |
| GPU fbToScreen | 0.046 | 0.046–0.046 |
| GPU fogToTrixel | 0.014 | 0.014–0.014 |
| GPU lightingToTrixel | 0.032 | 0.032–0.032 |
| GPU trixelToFb | 0.062 | 0.062–0.062 |
| GPU voxelCompact | 0.063 | 0.063–0.063 |
| GPU voxelStage1 | 3.064 | 3.064–3.064 |
| GPU voxelStage2 | 1.726 | 1.726–1.726 |
| GPU voxelSunFaces | 0.255 | 0.255–0.255 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 10.043 | 11.299 | 11.590 | 11.740 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
