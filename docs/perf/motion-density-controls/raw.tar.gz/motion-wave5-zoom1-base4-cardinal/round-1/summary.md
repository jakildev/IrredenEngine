| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.370 | 11.370–11.370 |
| frame p95 | 13.440 | 13.440–13.440 |
| frame p99 | 25.640 | 25.640–25.640 |
| steady frame avg | 11.120 | 11.120–11.120 |
| steady frame p95 | 13.380 | 13.380–13.380 |
| steady frame p99 | 13.790 | 13.790–13.790 |
| GPU frame commandBufferSpans | 8.048 | 8.048–8.048 |
| GPU frame envelope | 8.048 | 8.048–8.048 |
| GPU canvasClear | 0.045 | 0.045–0.045 |
| GPU computeLightVolume | 3.664 | 3.664–3.664 |
| GPU computeSunShadow | 0.033 | 0.033–0.033 |
| GPU computeVoxelAO | 0.045 | 0.045–0.045 |
| GPU fbToScreen | 0.053 | 0.053–0.053 |
| GPU fogToTrixel | 0.015 | 0.015–0.015 |
| GPU lightingToTrixel | 0.035 | 0.035–0.035 |
| GPU trixelToFb | 0.085 | 0.085–0.085 |
| GPU voxelCompact | 0.071 | 0.071–0.071 |
| GPU voxelStage1 | 3.201 | 3.201–3.201 |
| GPU voxelStage2 | 1.891 | 1.891–1.891 |
| GPU voxelSunFaces | 0.263 | 0.263–0.263 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 11.124 | 13.382 | 13.788 | 25.637 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
