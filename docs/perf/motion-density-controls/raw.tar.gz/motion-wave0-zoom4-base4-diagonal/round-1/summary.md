| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.710 | 9.710–9.710 |
| frame p95 | 11.260 | 11.260–11.260 |
| frame p99 | 15.510 | 15.510–15.510 |
| steady frame avg | 9.130 | 9.130–9.130 |
| steady frame p95 | 11.120 | 11.120–11.120 |
| steady frame p99 | 11.530 | 11.530–11.530 |
| GPU frame commandBufferSpans | 5.869 | 5.869–5.869 |
| GPU frame envelope | 5.869 | 5.869–5.869 |
| GPU canvasClear | 0.021 | 0.021–0.021 |
| GPU computeLightVolume | 4.590 | 4.590–4.590 |
| GPU computeSunShadow | 0.144 | 0.144–0.144 |
| GPU computeVoxelAO | 0.089 | 0.089–0.089 |
| GPU computeVoxelAoPerAxis | 0.981 | 0.981–0.981 |
| GPU fbToScreen | 0.068 | 0.068–0.068 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.033 | 0.033–0.033 |
| GPU fogToTrixel | 0.014 | 0.014–0.014 |
| GPU lightingOverflow | 0.009 | 0.009–0.009 |
| GPU lightingPerAxis | 0.049 | 0.049–0.049 |
| GPU lightingToTrixel | 0.022 | 0.022–0.022 |
| GPU perAxisCellCompact | 0.108 | 0.108–0.108 |
| GPU perAxisScatter | 0.101 | 0.101–0.101 |
| GPU resolvePerAxisScreenDepth | 0.175 | 0.175–0.175 |
| GPU trixelToFb | 0.100 | 0.100–0.100 |
| GPU voxelCompact | 0.090 | 0.090–0.090 |
| GPU voxelPerAxisFinalize | 0.215 | 0.215–0.215 |
| GPU voxelPerAxisOverflow | 0.130 | 0.130–0.130 |
| GPU voxelPerAxisStore | 0.729 | 0.729–0.729 |
| GPU voxelSunFaces | 0.162 | 0.162–0.162 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 9.131 | 11.122 | 11.530 | 15.513 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 0 / 0 (180) |
