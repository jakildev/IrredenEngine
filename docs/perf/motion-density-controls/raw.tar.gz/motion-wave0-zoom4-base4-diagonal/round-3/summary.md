| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.560 | 9.560–9.560 |
| frame p95 | 11.250 | 11.250–11.250 |
| frame p99 | 19.600 | 19.600–19.600 |
| steady frame avg | 9.160 | 9.160–9.160 |
| steady frame p95 | 11.140 | 11.140–11.140 |
| steady frame p99 | 12.310 | 12.310–12.310 |
| GPU frame commandBufferSpans | 5.434 | 5.434–5.434 |
| GPU frame envelope | 5.434 | 5.434–5.434 |
| GPU canvasClear | 0.019 | 0.019–0.019 |
| GPU computeLightVolume | 4.178 | 4.178–4.178 |
| GPU computeSunShadow | 0.135 | 0.135–0.135 |
| GPU computeVoxelAO | 0.095 | 0.095–0.095 |
| GPU computeVoxelAoPerAxis | 0.926 | 0.926–0.926 |
| GPU fbToScreen | 0.074 | 0.074–0.074 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.032 | 0.032–0.032 |
| GPU fogToTrixel | 0.014 | 0.014–0.014 |
| GPU lightingOverflow | 0.007 | 0.007–0.007 |
| GPU lightingPerAxis | 0.048 | 0.048–0.048 |
| GPU lightingToTrixel | 0.023 | 0.023–0.023 |
| GPU perAxisCellCompact | 0.107 | 0.107–0.107 |
| GPU perAxisScatter | 0.094 | 0.094–0.094 |
| GPU resolvePerAxisScreenDepth | 0.156 | 0.156–0.156 |
| GPU trixelToFb | 0.087 | 0.087–0.087 |
| GPU voxelCompact | 0.086 | 0.086–0.086 |
| GPU voxelPerAxisFinalize | 0.205 | 0.205–0.205 |
| GPU voxelPerAxisOverflow | 0.131 | 0.131–0.131 |
| GPU voxelPerAxisStore | 0.725 | 0.725–0.725 |
| GPU voxelSunFaces | 0.145 | 0.145–0.145 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 9.162 | 11.141 | 12.312 | 13.562 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 0 / 0 (180) |
