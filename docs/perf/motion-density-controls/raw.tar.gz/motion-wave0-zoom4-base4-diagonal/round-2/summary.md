| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.590 | 9.590–9.590 |
| frame p95 | 11.080 | 11.080–11.080 |
| frame p99 | 19.060 | 19.060–19.060 |
| steady frame avg | 8.950 | 8.950–8.950 |
| steady frame p95 | 10.930 | 10.930–10.930 |
| steady frame p99 | 11.440 | 11.440–11.440 |
| GPU frame commandBufferSpans | 5.461 | 5.461–5.461 |
| GPU frame envelope | 5.461 | 5.461–5.461 |
| GPU canvasClear | 0.020 | 0.020–0.020 |
| GPU computeLightVolume | 4.229 | 4.229–4.229 |
| GPU computeSunShadow | 0.132 | 0.132–0.132 |
| GPU computeVoxelAO | 0.090 | 0.090–0.090 |
| GPU computeVoxelAoPerAxis | 0.928 | 0.928–0.928 |
| GPU fbToScreen | 0.065 | 0.065–0.065 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.033 | 0.033–0.033 |
| GPU fogToTrixel | 0.014 | 0.014–0.014 |
| GPU lightingOverflow | 0.008 | 0.008–0.008 |
| GPU lightingPerAxis | 0.045 | 0.045–0.045 |
| GPU lightingToTrixel | 0.020 | 0.020–0.020 |
| GPU perAxisCellCompact | 0.104 | 0.104–0.104 |
| GPU perAxisScatter | 0.095 | 0.095–0.095 |
| GPU resolvePerAxisScreenDepth | 0.159 | 0.159–0.159 |
| GPU trixelToFb | 0.084 | 0.084–0.084 |
| GPU voxelCompact | 0.080 | 0.080–0.080 |
| GPU voxelPerAxisFinalize | 0.203 | 0.203–0.203 |
| GPU voxelPerAxisOverflow | 0.125 | 0.125–0.125 |
| GPU voxelPerAxisStore | 0.726 | 0.726–0.726 |
| GPU voxelSunFaces | 0.146 | 0.146–0.146 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.950 | 10.930 | 11.443 | 11.530 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 0 / 0 (180) |
