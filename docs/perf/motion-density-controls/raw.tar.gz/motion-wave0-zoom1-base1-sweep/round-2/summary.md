| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.160 | 9.160–9.160 |
| frame p95 | 10.930 | 10.930–10.930 |
| frame p99 | 57.400 | 57.400–57.400 |
| steady frame avg | 8.340 | 8.340–8.340 |
| steady frame p95 | 9.640 | 9.640–9.640 |
| steady frame p99 | 10.020 | 10.020–10.020 |
| GPU frame commandBufferSpans | 4.023 | 4.023–4.023 |
| GPU frame envelope | 4.023 | 4.023–4.023 |
| GPU canvasClear | 0.013 | 0.013–0.013 |
| GPU computeLightVolume | 2.955 | 2.955–2.955 |
| GPU computeSunShadow | 0.141 | 0.141–0.141 |
| GPU computeVoxelAO | 0.089 | 0.089–0.089 |
| GPU computeVoxelAoPerAxis | 0.780 | 0.780–0.780 |
| GPU fbToScreen | 0.045 | 0.045–0.045 |
| GPU fogOverflow | 0.002 | 0.002–0.002 |
| GPU fogPerAxis | 0.021 | 0.021–0.021 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 0.005 | 0.005–0.005 |
| GPU lightingPerAxis | 0.033 | 0.033–0.033 |
| GPU lightingToTrixel | 0.018 | 0.018–0.018 |
| GPU perAxisCellCompact | 0.095 | 0.095–0.095 |
| GPU perAxisScatter | 0.073 | 0.073–0.073 |
| GPU resolvePerAxisScreenDepth | 0.030 | 0.030–0.030 |
| GPU trixelToFb | 0.073 | 0.073–0.073 |
| GPU voxelCompact | 0.056 | 0.056–0.056 |
| GPU voxelPerAxisFinalize | 0.178 | 0.178–0.178 |
| GPU voxelPerAxisOverflow | 0.111 | 0.111–0.111 |
| GPU voxelPerAxisStore | 0.689 | 0.689–0.689 |
| GPU voxelStage1 | 0.219 | 0.219–0.219 |
| GPU voxelStage2 | 0.161 | 0.161–0.161 |
| GPU voxelSunFaces | 0.081 | 0.081–0.081 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.343 | 9.639 | 10.022 | 10.066 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 0 / 0 (176) |
