| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.200 | 9.200–9.200 |
| frame p95 | 11.190 | 11.190–11.190 |
| frame p99 | 53.770 | 53.770–53.770 |
| steady frame avg | 8.580 | 8.580–8.580 |
| steady frame p95 | 10.840 | 10.840–10.840 |
| steady frame p99 | 11.250 | 11.250–11.250 |
| GPU frame commandBufferSpans | 4.454 | 4.454–4.454 |
| GPU frame envelope | 4.454 | 4.454–4.454 |
| GPU canvasClear | 0.015 | 0.015–0.015 |
| GPU computeLightVolume | 3.363 | 3.363–3.363 |
| GPU computeSunShadow | 0.157 | 0.157–0.157 |
| GPU computeVoxelAO | 0.086 | 0.086–0.086 |
| GPU computeVoxelAoPerAxis | 0.811 | 0.811–0.811 |
| GPU fbToScreen | 0.051 | 0.051–0.051 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.025 | 0.025–0.025 |
| GPU fogToTrixel | 0.012 | 0.012–0.012 |
| GPU lightingOverflow | 0.006 | 0.006–0.006 |
| GPU lightingPerAxis | 0.038 | 0.038–0.038 |
| GPU lightingToTrixel | 0.019 | 0.019–0.019 |
| GPU perAxisCellCompact | 0.097 | 0.097–0.097 |
| GPU perAxisScatter | 0.087 | 0.087–0.087 |
| GPU resolvePerAxisScreenDepth | 0.033 | 0.033–0.033 |
| GPU trixelToFb | 0.077 | 0.077–0.077 |
| GPU voxelCompact | 0.061 | 0.061–0.061 |
| GPU voxelPerAxisFinalize | 0.181 | 0.181–0.181 |
| GPU voxelPerAxisOverflow | 0.121 | 0.121–0.121 |
| GPU voxelPerAxisStore | 0.691 | 0.691–0.691 |
| GPU voxelStage1 | 0.178 | 0.178–0.178 |
| GPU voxelStage2 | 0.143 | 0.143–0.143 |
| GPU voxelSunFaces | 0.087 | 0.087–0.087 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.584 | 10.841 | 11.251 | 11.415 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 0 / 0 (176) |
