| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.260 | 9.260–9.260 |
| frame p95 | 11.630 | 11.630–11.630 |
| frame p99 | 66.190 | 66.190–66.190 |
| steady frame avg | 8.530 | 8.530–8.530 |
| steady frame p95 | 10.940 | 10.940–10.940 |
| steady frame p99 | 12.470 | 12.470–12.470 |
| GPU frame commandBufferSpans | 4.379 | 4.379–4.379 |
| GPU frame envelope | 4.379 | 4.379–4.379 |
| GPU canvasClear | 0.073 | 0.073–0.073 |
| GPU computeLightVolume | 2.841 | 2.841–2.841 |
| GPU computeSunShadow | 0.132 | 0.132–0.132 |
| GPU computeVoxelAO | 0.097 | 0.097–0.097 |
| GPU computeVoxelAoPerAxis | 0.768 | 0.768–0.768 |
| GPU fbToScreen | 0.045 | 0.045–0.045 |
| GPU fogOverflow | 0.004 | 0.004–0.004 |
| GPU fogPerAxis | 0.021 | 0.021–0.021 |
| GPU fogToTrixel | 0.013 | 0.013–0.013 |
| GPU lightingOverflow | 0.005 | 0.005–0.005 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.016 | 0.016–0.016 |
| GPU perAxisCellCompact | 0.100 | 0.100–0.100 |
| GPU perAxisScatter | 0.069 | 0.069–0.069 |
| GPU resolvePerAxisScreenDepth | 0.029 | 0.029–0.029 |
| GPU trixelToFb | 0.129 | 0.129–0.129 |
| GPU voxelCompact | 0.085 | 0.085–0.085 |
| GPU voxelPerAxisFinalize | 0.176 | 0.176–0.176 |
| GPU voxelPerAxisOverflow | 0.096 | 0.096–0.096 |
| GPU voxelPerAxisStore | 0.858 | 0.858–0.858 |
| GPU voxelStage1 | 0.237 | 0.237–0.237 |
| GPU voxelStage2 | 0.163 | 0.163–0.163 |
| GPU voxelSunFaces | 0.080 | 0.080–0.080 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.533 | 10.941 | 12.474 | 12.540 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 0 / 0 (176) |
