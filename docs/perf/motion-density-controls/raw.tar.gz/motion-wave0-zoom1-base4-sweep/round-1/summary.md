| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.470 | 9.470–9.470 |
| frame p95 | 12.080 | 12.080–12.080 |
| frame p99 | 68.180 | 68.180–68.180 |
| steady frame avg | 8.520 | 8.520–8.520 |
| steady frame p95 | 11.110 | 11.110–11.110 |
| steady frame p99 | 12.130 | 12.130–12.130 |
| GPU frame commandBufferSpans | 4.334 | 4.334–4.334 |
| GPU frame envelope | 4.334 | 4.334–4.334 |
| GPU canvasClear | 0.061 | 0.061–0.061 |
| GPU computeLightVolume | 2.753 | 2.753–2.753 |
| GPU computeSunShadow | 0.142 | 0.142–0.142 |
| GPU computeVoxelAO | 0.083 | 0.083–0.083 |
| GPU computeVoxelAoPerAxis | 0.776 | 0.776–0.776 |
| GPU fbToScreen | 0.059 | 0.059–0.059 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.020 | 0.020–0.020 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 0.004 | 0.004–0.004 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.017 | 0.017–0.017 |
| GPU perAxisCellCompact | 0.108 | 0.108–0.108 |
| GPU perAxisScatter | 0.069 | 0.069–0.069 |
| GPU resolvePerAxisScreenDepth | 0.033 | 0.033–0.033 |
| GPU trixelToFb | 0.100 | 0.100–0.100 |
| GPU voxelCompact | 0.094 | 0.094–0.094 |
| GPU voxelPerAxisFinalize | 0.174 | 0.174–0.174 |
| GPU voxelPerAxisOverflow | 0.098 | 0.098–0.098 |
| GPU voxelPerAxisStore | 0.856 | 0.856–0.856 |
| GPU voxelStage1 | 1.266 | 1.266–1.266 |
| GPU voxelStage2 | 0.502 | 0.502–0.502 |
| GPU voxelSunFaces | 0.098 | 0.098–0.098 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.516 | 11.108 | 12.127 | 12.563 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 0 / 0 (176) |
