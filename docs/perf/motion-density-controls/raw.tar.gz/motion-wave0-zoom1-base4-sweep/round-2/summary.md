| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.440 | 9.440–9.440 |
| frame p95 | 11.220 | 11.220–11.220 |
| frame p99 | 62.640 | 62.640–62.640 |
| steady frame avg | 8.660 | 8.660–8.660 |
| steady frame p95 | 11.000 | 11.000–11.000 |
| steady frame p99 | 11.480 | 11.480–11.480 |
| GPU frame commandBufferSpans | 5.346 | 5.346–5.346 |
| GPU frame envelope | 5.346 | 5.346–5.346 |
| GPU canvasClear | 0.017 | 0.017–0.017 |
| GPU computeLightVolume | 4.163 | 4.163–4.163 |
| GPU computeSunShadow | 0.193 | 0.193–0.193 |
| GPU computeVoxelAO | 0.089 | 0.089–0.089 |
| GPU computeVoxelAoPerAxis | 0.883 | 0.883–0.883 |
| GPU fbToScreen | 0.073 | 0.073–0.073 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.029 | 0.029–0.029 |
| GPU fogToTrixel | 0.014 | 0.014–0.014 |
| GPU lightingOverflow | 0.008 | 0.008–0.008 |
| GPU lightingPerAxis | 0.044 | 0.044–0.044 |
| GPU lightingToTrixel | 0.022 | 0.022–0.022 |
| GPU perAxisCellCompact | 0.104 | 0.104–0.104 |
| GPU perAxisScatter | 0.107 | 0.107–0.107 |
| GPU resolvePerAxisScreenDepth | 0.044 | 0.044–0.044 |
| GPU trixelToFb | 0.085 | 0.085–0.085 |
| GPU voxelCompact | 0.071 | 0.071–0.071 |
| GPU voxelPerAxisFinalize | 0.201 | 0.201–0.201 |
| GPU voxelPerAxisOverflow | 0.134 | 0.134–0.134 |
| GPU voxelPerAxisStore | 0.718 | 0.718–0.718 |
| GPU voxelStage1 | 0.469 | 0.469–0.469 |
| GPU voxelStage2 | 0.479 | 0.479–0.479 |
| GPU voxelSunFaces | 0.101 | 0.101–0.101 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.660 | 10.998 | 11.480 | 11.487 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 0 / 0 (176) |
