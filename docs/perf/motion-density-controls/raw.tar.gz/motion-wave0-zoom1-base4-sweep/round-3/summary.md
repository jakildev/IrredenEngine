| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.330 | 9.330–9.330 |
| frame p95 | 11.240 | 11.240–11.240 |
| frame p99 | 57.200 | 57.200–57.200 |
| steady frame avg | 8.510 | 8.510–8.510 |
| steady frame p95 | 10.300 | 10.300–10.300 |
| steady frame p99 | 11.960 | 11.960–11.960 |
| GPU frame commandBufferSpans | 5.644 | 5.644–5.644 |
| GPU frame envelope | 5.644 | 5.644–5.644 |
| GPU canvasClear | 0.017 | 0.017–0.017 |
| GPU computeLightVolume | 4.433 | 4.433–4.433 |
| GPU computeSunShadow | 0.204 | 0.204–0.204 |
| GPU computeVoxelAO | 0.092 | 0.092–0.092 |
| GPU computeVoxelAoPerAxis | 0.913 | 0.913–0.913 |
| GPU fbToScreen | 0.075 | 0.075–0.075 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.030 | 0.030–0.030 |
| GPU fogToTrixel | 0.014 | 0.014–0.014 |
| GPU lightingOverflow | 0.007 | 0.007–0.007 |
| GPU lightingPerAxis | 0.046 | 0.046–0.046 |
| GPU lightingToTrixel | 0.023 | 0.023–0.023 |
| GPU perAxisCellCompact | 0.105 | 0.105–0.105 |
| GPU perAxisScatter | 0.111 | 0.111–0.111 |
| GPU resolvePerAxisScreenDepth | 0.045 | 0.045–0.045 |
| GPU trixelToFb | 0.090 | 0.090–0.090 |
| GPU voxelCompact | 0.072 | 0.072–0.072 |
| GPU voxelPerAxisFinalize | 0.204 | 0.204–0.204 |
| GPU voxelPerAxisOverflow | 0.138 | 0.138–0.138 |
| GPU voxelPerAxisStore | 0.727 | 0.727–0.727 |
| GPU voxelStage1 | 0.530 | 0.530–0.530 |
| GPU voxelStage2 | 0.432 | 0.432–0.432 |
| GPU voxelSunFaces | 0.100 | 0.100–0.100 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.508 | 10.299 | 11.956 | 12.067 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 0 / 0 (176) |
