| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.160 | 19.160–19.160 |
| frame p95 | 19.370 | 19.370–19.370 |
| frame p99 | 55.730 | 55.730–55.730 |
| steady frame avg | 18.600 | 18.600–18.600 |
| steady frame p95 | 19.320 | 19.320–19.320 |
| steady frame p99 | 20.090 | 20.090–20.090 |
| GPU frame commandBufferSpans | 14.244 | 14.244–14.244 |
| GPU frame envelope | 14.244 | 14.244–14.244 |
| GPU canvasClear | 0.013 | 0.013–0.013 |
| GPU computeLightVolume | 10.719 | 10.719–10.719 |
| GPU computeSunShadow | 0.141 | 0.141–0.141 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.796 | 8.796–8.796 |
| GPU fbToScreen | 0.060 | 0.060–0.060 |
| GPU fogOverflow | 5.830 | 5.830–5.830 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.858 | 5.858–5.858 |
| GPU lightingPerAxis | 0.032 | 0.032–0.032 |
| GPU lightingToTrixel | 0.016 | 0.016–0.016 |
| GPU perAxisCellCompact | 0.169 | 0.169–0.169 |
| GPU perAxisScatter | 2.399 | 2.399–2.399 |
| GPU resolvePerAxisScreenDepth | 0.038 | 0.038–0.038 |
| GPU trixelToFb | 0.070 | 0.070–0.070 |
| GPU voxelCompact | 0.186 | 0.186–0.186 |
| GPU voxelPerAxisFinalize | 3.065 | 3.065–3.065 |
| GPU voxelPerAxisOverflow | 3.768 | 3.768–3.768 |
| GPU voxelPerAxisStore | 2.125 | 2.125–2.125 |
| GPU voxelSunFaces | 0.297 | 0.297–0.297 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.597 | 19.319 | 20.093 | 55.730 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 7 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 749109 / 0 (180) |
