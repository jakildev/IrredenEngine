| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.510 | 19.510–19.510 |
| frame p95 | 21.730 | 21.730–21.730 |
| frame p99 | 30.410 | 30.410–30.410 |
| steady frame avg | 19.050 | 19.050–19.050 |
| steady frame p95 | 21.620 | 21.620–21.620 |
| steady frame p99 | 22.080 | 22.080–22.080 |
| GPU frame commandBufferSpans | 14.756 | 14.756–14.756 |
| GPU frame envelope | 14.756 | 14.756–14.756 |
| GPU canvasClear | 0.026 | 0.026–0.026 |
| GPU computeLightVolume | 11.125 | 11.125–11.125 |
| GPU computeSunShadow | 0.124 | 0.124–0.124 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 9.134 | 9.134–9.134 |
| GPU fbToScreen | 0.081 | 0.081–0.081 |
| GPU fogOverflow | 6.039 | 6.039–6.039 |
| GPU fogPerAxis | 0.025 | 0.025–0.025 |
| GPU fogToTrixel | 0.012 | 0.012–0.012 |
| GPU lightingOverflow | 6.074 | 6.074–6.074 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.016 | 0.016–0.016 |
| GPU perAxisCellCompact | 0.141 | 0.141–0.141 |
| GPU perAxisScatter | 2.416 | 2.416–2.416 |
| GPU resolvePerAxisScreenDepth | 0.037 | 0.037–0.037 |
| GPU trixelToFb | 0.093 | 0.093–0.093 |
| GPU voxelCompact | 0.194 | 0.194–0.194 |
| GPU voxelPerAxisFinalize | 3.214 | 3.214–3.214 |
| GPU voxelPerAxisOverflow | 3.906 | 3.906–3.906 |
| GPU voxelPerAxisStore | 2.204 | 2.204–2.204 |
| GPU voxelSunFaces | 0.296 | 0.296–0.296 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 19.054 | 21.620 | 22.085 | 22.602 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 749109 / 0 (180) |
