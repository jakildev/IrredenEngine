| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 18.840 | 18.840–18.840 |
| frame p95 | 19.390 | 19.390–19.390 |
| frame p99 | 24.460 | 24.460–24.460 |
| steady frame avg | 18.300 | 18.300–18.300 |
| steady frame p95 | 19.310 | 19.310–19.310 |
| steady frame p99 | 19.610 | 19.610–19.610 |
| GPU frame commandBufferSpans | 14.193 | 14.193–14.193 |
| GPU frame envelope | 14.193 | 14.193–14.193 |
| GPU canvasClear | 0.012 | 0.012–0.012 |
| GPU computeLightVolume | 10.673 | 10.673–10.673 |
| GPU computeSunShadow | 0.062 | 0.062–0.062 |
| GPU computeVoxelAO | 0.017 | 0.017–0.017 |
| GPU computeVoxelAoPerAxis | 8.761 | 8.761–8.761 |
| GPU fbToScreen | 0.061 | 0.061–0.061 |
| GPU fogOverflow | 5.808 | 5.808–5.808 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.837 | 5.837–5.837 |
| GPU lightingPerAxis | 0.032 | 0.032–0.032 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.177 | 0.177–0.177 |
| GPU perAxisScatter | 2.403 | 2.403–2.403 |
| GPU resolvePerAxisScreenDepth | 0.038 | 0.038–0.038 |
| GPU trixelToFb | 0.070 | 0.070–0.070 |
| GPU voxelCompact | 0.184 | 0.184–0.184 |
| GPU voxelPerAxisFinalize | 3.043 | 3.043–3.043 |
| GPU voxelPerAxisOverflow | 3.772 | 3.772–3.772 |
| GPU voxelPerAxisStore | 2.106 | 2.106–2.106 |
| GPU voxelSunFaces | 0.297 | 0.297–0.297 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.296 | 19.310 | 19.612 | 19.780 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 749109 / 0 (180) |
