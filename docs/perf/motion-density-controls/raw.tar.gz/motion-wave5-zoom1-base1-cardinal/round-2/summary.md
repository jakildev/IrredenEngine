| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.760 | 8.760–8.760 |
| frame p95 | 9.880 | 9.880–9.880 |
| frame p99 | 14.980 | 14.980–14.980 |
| steady frame avg | 8.400 | 8.400–8.400 |
| steady frame p95 | 9.610 | 9.610–9.610 |
| steady frame p99 | 10.840 | 10.840–10.840 |
| GPU frame commandBufferSpans | 4.741 | 4.741–4.741 |
| GPU frame envelope | 4.741 | 4.741–4.741 |
| GPU canvasClear | 0.050 | 0.050–0.050 |
| GPU computeLightVolume | 3.049 | 3.049–3.049 |
| GPU computeSunShadow | 0.020 | 0.020–0.020 |
| GPU computeVoxelAO | 0.026 | 0.026–0.026 |
| GPU fbToScreen | 0.046 | 0.046–0.046 |
| GPU fogToTrixel | 0.012 | 0.012–0.012 |
| GPU lightingToTrixel | 0.021 | 0.021–0.021 |
| GPU trixelToFb | 0.126 | 0.126–0.126 |
| GPU voxelCompact | 0.070 | 0.070–0.070 |
| GPU voxelStage1 | 1.900 | 1.900–1.900 |
| GPU voxelStage2 | 0.639 | 0.639–0.639 |
| GPU voxelSunFaces | 0.325 | 0.325–0.325 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.398 | 9.611 | 10.844 | 11.382 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
