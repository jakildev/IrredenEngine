| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.760 | 8.760–8.760 |
| frame p95 | 9.650 | 9.650–9.650 |
| frame p99 | 12.940 | 12.940–12.940 |
| steady frame avg | 8.340 | 8.340–8.340 |
| steady frame p95 | 9.210 | 9.210–9.210 |
| steady frame p99 | 9.550 | 9.550–9.550 |
| GPU frame commandBufferSpans | 5.307 | 5.307–5.307 |
| GPU frame envelope | 5.307 | 5.307–5.307 |
| GPU canvasClear | 0.058 | 0.058–0.058 |
| GPU computeLightVolume | 3.475 | 3.475–3.475 |
| GPU computeSunShadow | 0.021 | 0.021–0.021 |
| GPU computeVoxelAO | 0.026 | 0.026–0.026 |
| GPU fbToScreen | 0.050 | 0.050–0.050 |
| GPU fogToTrixel | 0.012 | 0.012–0.012 |
| GPU lightingToTrixel | 0.022 | 0.022–0.022 |
| GPU trixelToFb | 0.159 | 0.159–0.159 |
| GPU voxelCompact | 0.080 | 0.080–0.080 |
| GPU voxelStage1 | 2.109 | 2.109–2.109 |
| GPU voxelStage2 | 0.718 | 0.718–0.718 |
| GPU voxelSunFaces | 0.373 | 0.373–0.373 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.338 | 9.214 | 9.554 | 9.654 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
