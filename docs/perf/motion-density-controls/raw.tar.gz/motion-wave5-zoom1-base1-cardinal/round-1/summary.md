| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.650 | 8.650–8.650 |
| frame p95 | 9.560 | 9.560–9.560 |
| frame p99 | 12.760 | 12.760–12.760 |
| steady frame avg | 8.340 | 8.340–8.340 |
| steady frame p95 | 9.450 | 9.450–9.450 |
| steady frame p99 | 9.950 | 9.950–9.950 |
| GPU frame commandBufferSpans | 4.847 | 4.847–4.847 |
| GPU frame envelope | 4.847 | 4.847–4.847 |
| GPU canvasClear | 0.060 | 0.060–0.060 |
| GPU computeLightVolume | 3.136 | 3.136–3.136 |
| GPU computeSunShadow | 0.021 | 0.021–0.021 |
| GPU computeVoxelAO | 0.028 | 0.028–0.028 |
| GPU fbToScreen | 0.047 | 0.047–0.047 |
| GPU fogToTrixel | 0.012 | 0.012–0.012 |
| GPU lightingToTrixel | 0.023 | 0.023–0.023 |
| GPU trixelToFb | 0.144 | 0.144–0.144 |
| GPU voxelCompact | 0.062 | 0.062–0.062 |
| GPU voxelStage1 | 1.908 | 1.908–1.908 |
| GPU voxelStage2 | 0.645 | 0.645–0.645 |
| GPU voxelSunFaces | 0.340 | 0.340–0.340 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.341 | 9.449 | 9.945 | 9.973 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
