| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 89.220 | 89.220–89.220 |
| frame p95 | 90.520 | 90.520–90.520 |
| frame p99 | 93.870 | 93.870–93.870 |
| steady frame avg | 88.760 | 88.760–88.760 |
| steady frame p95 | 89.720 | 89.720–89.720 |
| steady frame p99 | 91.010 | 91.010–91.010 |
| GPU frame commandBufferSpans | 81.944 | 81.944–81.944 |
| GPU frame envelope | 81.944 | 81.944–81.944 |
| GPU canvasClear | 0.047 | 0.047–0.047 |
| GPU computeLightVolume | 3.650 | 3.650–3.650 |
| GPU computeSunShadow | 0.030 | 0.030–0.030 |
| GPU computeVoxelAO | 0.049 | 0.049–0.049 |
| GPU fbToScreen | 0.047 | 0.047–0.047 |
| GPU fogToTrixel | 0.015 | 0.015–0.015 |
| GPU lightingToTrixel | 0.038 | 0.038–0.038 |
| GPU trixelToFb | 0.151 | 0.151–0.151 |
| GPU voxelCompact | 0.187 | 0.187–0.187 |
| GPU voxelStage1 | 28.494 | 28.494–28.494 |
| GPU voxelStage2 | 25.476 | 25.476–25.476 |
| GPU voxelSunFaces | 0.822 | 0.822–0.822 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 88.755 | 89.722 | 91.007 | 92.251 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 5.30 | 5.30–5.30 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
