| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 89.260 | 89.260–89.260 |
| frame p95 | 90.640 | 90.640–90.640 |
| frame p99 | 93.850 | 93.850–93.850 |
| steady frame avg | 88.840 | 88.840–88.840 |
| steady frame p95 | 90.170 | 90.170–90.170 |
| steady frame p99 | 90.790 | 90.790–90.790 |
| GPU frame commandBufferSpans | 81.953 | 81.953–81.953 |
| GPU frame envelope | 81.953 | 81.953–81.953 |
| GPU canvasClear | 0.061 | 0.061–0.061 |
| GPU computeLightVolume | 4.271 | 4.271–4.271 |
| GPU computeSunShadow | 0.030 | 0.030–0.030 |
| GPU computeVoxelAO | 0.049 | 0.049–0.049 |
| GPU fbToScreen | 0.049 | 0.049–0.049 |
| GPU fogToTrixel | 0.016 | 0.016–0.016 |
| GPU lightingToTrixel | 0.038 | 0.038–0.038 |
| GPU trixelToFb | 0.150 | 0.150–0.150 |
| GPU voxelCompact | 0.183 | 0.183–0.183 |
| GPU voxelStage1 | 28.508 | 28.508–28.508 |
| GPU voxelStage2 | 25.454 | 25.454–25.454 |
| GPU voxelSunFaces | 0.821 | 0.821–0.821 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 88.838 | 90.174 | 90.789 | 91.540 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 5.30 | 5.30–5.30 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
