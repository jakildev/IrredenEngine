| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 89.080 | 89.080–89.080 |
| frame p95 | 89.850 | 89.850–89.850 |
| frame p99 | 95.200 | 95.200–95.200 |
| steady frame avg | 88.600 | 88.600–88.600 |
| steady frame p95 | 89.690 | 89.690–89.690 |
| steady frame p99 | 90.060 | 90.060–90.060 |
| GPU frame commandBufferSpans | 81.981 | 81.981–81.981 |
| GPU frame envelope | 81.981 | 81.981–81.981 |
| GPU canvasClear | 0.055 | 0.055–0.055 |
| GPU computeLightVolume | 3.871 | 3.871–3.871 |
| GPU computeSunShadow | 0.030 | 0.030–0.030 |
| GPU computeVoxelAO | 0.049 | 0.049–0.049 |
| GPU fbToScreen | 0.049 | 0.049–0.049 |
| GPU fogToTrixel | 0.015 | 0.015–0.015 |
| GPU lightingToTrixel | 0.038 | 0.038–0.038 |
| GPU trixelToFb | 0.151 | 0.151–0.151 |
| GPU voxelCompact | 0.192 | 0.192–0.192 |
| GPU voxelStage1 | 28.513 | 28.513–28.513 |
| GPU voxelStage2 | 25.483 | 25.483–25.483 |
| GPU voxelSunFaces | 0.823 | 0.823–0.823 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 88.604 | 89.685 | 90.064 | 90.902 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 5.30 | 5.30–5.30 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (0.000) | 0 / 0 (0) |
