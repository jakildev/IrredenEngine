| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.730 | 19.730–19.730 |
| frame p95 | 20.620 | 20.620–20.620 |
| frame p99 | 77.970 | 77.970–77.970 |
| steady frame avg | 18.830 | 18.830–18.830 |
| steady frame p95 | 20.180 | 20.180–20.180 |
| steady frame p99 | 20.730 | 20.730–20.730 |
| GPU frame commandBufferSpans | 15.032 | 15.032–15.032 |
| GPU frame envelope | 15.032 | 15.032–15.032 |
| GPU canvasClear | 0.017 | 0.017–0.017 |
| GPU computeLightVolume | 10.594 | 10.594–10.594 |
| GPU computeSunShadow | 0.146 | 0.146–0.146 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.778 | 8.778–8.778 |
| GPU fbToScreen | 0.059 | 0.059–0.059 |
| GPU fogOverflow | 5.825 | 5.825–5.825 |
| GPU fogPerAxis | 0.022 | 0.022–0.022 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.846 | 5.846–5.846 |
| GPU lightingPerAxis | 0.032 | 0.032–0.032 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.178 | 0.178–0.178 |
| GPU perAxisScatter | 3.281 | 3.281–3.281 |
| GPU resolvePerAxisScreenDepth | 0.037 | 0.037–0.037 |
| GPU trixelToFb | 0.070 | 0.070–0.070 |
| GPU voxelCompact | 0.170 | 0.170–0.170 |
| GPU voxelPerAxisFinalize | 3.065 | 3.065–3.065 |
| GPU voxelPerAxisOverflow | 3.771 | 3.771–3.771 |
| GPU voxelPerAxisStore | 2.108 | 2.108–2.108 |
| GPU voxelStage1 | 6.422 | 6.422–6.422 |
| GPU voxelStage2 | 2.083 | 2.083–2.083 |
| GPU voxelSunFaces | 0.282 | 0.282–0.282 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.826 | 20.176 | 20.729 | 20.873 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 749109 / 0 (176) |
