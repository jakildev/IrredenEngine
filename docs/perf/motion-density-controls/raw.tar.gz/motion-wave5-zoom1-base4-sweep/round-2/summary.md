| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.870 | 19.870–19.870 |
| frame p95 | 21.040 | 21.040–21.040 |
| frame p99 | 79.520 | 79.520–79.520 |
| steady frame avg | 18.990 | 18.990–18.990 |
| steady frame p95 | 20.750 | 20.750–20.750 |
| steady frame p99 | 21.480 | 21.480–21.480 |
| GPU frame commandBufferSpans | 15.023 | 15.023–15.023 |
| GPU frame envelope | 15.023 | 15.023–15.023 |
| GPU canvasClear | 0.015 | 0.015–0.015 |
| GPU computeLightVolume | 10.529 | 10.529–10.529 |
| GPU computeSunShadow | 0.084 | 0.084–0.084 |
| GPU computeVoxelAO | 0.017 | 0.017–0.017 |
| GPU computeVoxelAoPerAxis | 8.724 | 8.724–8.724 |
| GPU fbToScreen | 0.057 | 0.057–0.057 |
| GPU fogOverflow | 5.836 | 5.836–5.836 |
| GPU fogPerAxis | 0.023 | 0.023–0.023 |
| GPU fogToTrixel | 0.011 | 0.011–0.011 |
| GPU lightingOverflow | 5.852 | 5.852–5.852 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.016 | 0.016–0.016 |
| GPU perAxisCellCompact | 0.124 | 0.124–0.124 |
| GPU perAxisScatter | 3.282 | 3.282–3.282 |
| GPU resolvePerAxisScreenDepth | 0.037 | 0.037–0.037 |
| GPU trixelToFb | 0.072 | 0.072–0.072 |
| GPU voxelCompact | 0.169 | 0.169–0.169 |
| GPU voxelPerAxisFinalize | 3.054 | 3.054–3.054 |
| GPU voxelPerAxisOverflow | 3.735 | 3.735–3.735 |
| GPU voxelPerAxisStore | 2.141 | 2.141–2.141 |
| GPU voxelStage1 | 5.361 | 5.361–5.361 |
| GPU voxelStage2 | 2.085 | 2.085–2.085 |
| GPU voxelSunFaces | 0.280 | 0.280–0.280 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.989 | 20.750 | 21.480 | 21.557 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 749109 / 0 (176) |
