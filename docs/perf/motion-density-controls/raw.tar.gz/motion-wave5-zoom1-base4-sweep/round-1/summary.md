| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.580 | 19.580–19.580 |
| frame p95 | 20.730 | 20.730–20.730 |
| frame p99 | 65.490 | 65.490–65.490 |
| steady frame avg | 18.850 | 18.850–18.850 |
| steady frame p95 | 20.350 | 20.350–20.350 |
| steady frame p99 | 21.390 | 21.390–21.390 |
| GPU frame commandBufferSpans | 14.909 | 14.909–14.909 |
| GPU frame envelope | 14.909 | 14.909–14.909 |
| GPU canvasClear | 0.012 | 0.012–0.012 |
| GPU computeLightVolume | 10.514 | 10.514–10.514 |
| GPU computeSunShadow | 0.094 | 0.094–0.094 |
| GPU computeVoxelAO | 0.016 | 0.016–0.016 |
| GPU computeVoxelAoPerAxis | 8.739 | 8.739–8.739 |
| GPU fbToScreen | 0.053 | 0.053–0.053 |
| GPU fogOverflow | 5.799 | 5.799–5.799 |
| GPU fogPerAxis | 0.022 | 0.022–0.022 |
| GPU fogToTrixel | 0.010 | 0.010–0.010 |
| GPU lightingOverflow | 5.833 | 5.833–5.833 |
| GPU lightingPerAxis | 0.031 | 0.031–0.031 |
| GPU lightingToTrixel | 0.015 | 0.015–0.015 |
| GPU perAxisCellCompact | 0.122 | 0.122–0.122 |
| GPU perAxisScatter | 3.279 | 3.279–3.279 |
| GPU resolvePerAxisScreenDepth | 0.036 | 0.036–0.036 |
| GPU trixelToFb | 0.069 | 0.069–0.069 |
| GPU voxelCompact | 0.179 | 0.179–0.179 |
| GPU voxelPerAxisFinalize | 3.063 | 3.063–3.063 |
| GPU voxelPerAxisOverflow | 3.736 | 3.736–3.736 |
| GPU voxelPerAxisStore | 2.104 | 2.104–2.104 |
| GPU voxelStage1 | 5.733 | 5.733–5.733 |
| GPU voxelStage2 | 2.062 | 2.062–2.062 |
| GPU voxelSunFaces | 0.280 | 0.280–0.280 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 18.848 | 20.353 | 21.394 | 21.420 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 0.000 (358.000) | 749109 / 0 (176) |
