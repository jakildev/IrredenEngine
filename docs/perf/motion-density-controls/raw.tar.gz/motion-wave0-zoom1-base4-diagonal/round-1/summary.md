| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.980 | 9.980–9.980 |
| frame p95 | 11.640 | 11.640–11.640 |
| frame p99 | 61.680 | 61.680–61.680 |
| steady frame avg | 8.580 | 8.580–8.580 |
| steady frame p95 | 11.290 | 11.290–11.290 |
| steady frame p99 | 12.010 | 12.010–12.010 |
| GPU frame commandBufferSpans | 4.758 | 4.758–4.758 |
| GPU frame envelope | 4.758 | 4.758–4.758 |
| GPU canvasClear | 0.050 | 0.050–0.050 |
| GPU computeLightVolume | 2.934 | 2.934–2.934 |
| GPU computeSunShadow | 0.143 | 0.143–0.143 |
| GPU computeVoxelAO | 0.086 | 0.086–0.086 |
| GPU computeVoxelAoPerAxis | 0.822 | 0.822–0.822 |
| GPU fbToScreen | 0.067 | 0.067–0.067 |
| GPU fogOverflow | 0.005 | 0.005–0.005 |
| GPU fogPerAxis | 0.022 | 0.022–0.022 |
| GPU fogToTrixel | 0.010 | 0.010–0.010 |
| GPU lightingOverflow | 0.004 | 0.004–0.004 |
| GPU lightingPerAxis | 0.032 | 0.032–0.032 |
| GPU lightingToTrixel | 0.017 | 0.017–0.017 |
| GPU perAxisCellCompact | 0.129 | 0.129–0.129 |
| GPU perAxisScatter | 0.063 | 0.063–0.063 |
| GPU resolvePerAxisScreenDepth | 0.035 | 0.035–0.035 |
| GPU trixelToFb | 0.087 | 0.087–0.087 |
| GPU voxelCompact | 0.063 | 0.063–0.063 |
| GPU voxelPerAxisFinalize | 0.242 | 0.242–0.242 |
| GPU voxelPerAxisOverflow | 0.104 | 0.104–0.104 |
| GPU voxelPerAxisStore | 0.840 | 0.840–0.840 |
| GPU voxelSunFaces | 0.076 | 0.076–0.076 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 8.578 | 11.291 | 12.008 | 12.590 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 0 / 0 (180) |
