| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 10.000 | 10.000–10.000 |
| frame p95 | 11.270 | 11.270–11.270 |
| frame p99 | 15.530 | 15.530–15.530 |
| steady frame avg | 9.550 | 9.550–9.550 |
| steady frame p95 | 11.090 | 11.090–11.090 |
| steady frame p99 | 11.520 | 11.520–11.520 |
| GPU frame commandBufferSpans | 6.424 | 6.424–6.424 |
| GPU frame envelope | 6.424 | 6.424–6.424 |
| GPU canvasClear | 0.023 | 0.023–0.023 |
| GPU computeLightVolume | 5.077 | 5.077–5.077 |
| GPU computeSunShadow | 0.240 | 0.240–0.240 |
| GPU computeVoxelAO | 0.093 | 0.093–0.093 |
| GPU computeVoxelAoPerAxis | 0.989 | 0.989–0.989 |
| GPU fbToScreen | 0.083 | 0.083–0.083 |
| GPU fogOverflow | 0.004 | 0.004–0.004 |
| GPU fogPerAxis | 0.038 | 0.038–0.038 |
| GPU fogToTrixel | 0.016 | 0.016–0.016 |
| GPU lightingOverflow | 0.009 | 0.009–0.009 |
| GPU lightingPerAxis | 0.053 | 0.053–0.053 |
| GPU lightingToTrixel | 0.023 | 0.023–0.023 |
| GPU perAxisCellCompact | 0.110 | 0.110–0.110 |
| GPU perAxisScatter | 0.116 | 0.116–0.116 |
| GPU resolvePerAxisScreenDepth | 0.052 | 0.052–0.052 |
| GPU trixelToFb | 0.096 | 0.096–0.096 |
| GPU voxelCompact | 0.081 | 0.081–0.081 |
| GPU voxelPerAxisFinalize | 0.234 | 0.234–0.234 |
| GPU voxelPerAxisOverflow | 0.146 | 0.146–0.146 |
| GPU voxelPerAxisStore | 0.760 | 0.760–0.760 |
| GPU voxelSunFaces | 0.120 | 0.120–0.120 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 9.555 | 11.091 | 11.518 | 11.617 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 0 / 0 (180) |
