| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.700 | 9.700–9.700 |
| frame p95 | 11.200 | 11.200–11.200 |
| frame p99 | 19.030 | 19.030–19.030 |
| steady frame avg | 9.370 | 9.370–9.370 |
| steady frame p95 | 11.200 | 11.200–11.200 |
| steady frame p99 | 11.950 | 11.950–11.950 |
| GPU frame commandBufferSpans | 5.551 | 5.551–5.551 |
| GPU frame envelope | 5.551 | 5.551–5.551 |
| GPU canvasClear | 0.021 | 0.021–0.021 |
| GPU computeLightVolume | 4.315 | 4.315–4.315 |
| GPU computeSunShadow | 0.203 | 0.203–0.203 |
| GPU computeVoxelAO | 0.090 | 0.090–0.090 |
| GPU computeVoxelAoPerAxis | 0.899 | 0.899–0.899 |
| GPU fbToScreen | 0.073 | 0.073–0.073 |
| GPU fogOverflow | 0.003 | 0.003–0.003 |
| GPU fogPerAxis | 0.033 | 0.033–0.033 |
| GPU fogToTrixel | 0.014 | 0.014–0.014 |
| GPU lightingOverflow | 0.007 | 0.007–0.007 |
| GPU lightingPerAxis | 0.046 | 0.046–0.046 |
| GPU lightingToTrixel | 0.020 | 0.020–0.020 |
| GPU perAxisCellCompact | 0.104 | 0.104–0.104 |
| GPU perAxisScatter | 0.098 | 0.098–0.098 |
| GPU resolvePerAxisScreenDepth | 0.047 | 0.047–0.047 |
| GPU trixelToFb | 0.085 | 0.085–0.085 |
| GPU voxelCompact | 0.073 | 0.073–0.073 |
| GPU voxelPerAxisFinalize | 0.211 | 0.211–0.211 |
| GPU voxelPerAxisOverflow | 0.136 | 0.136–0.136 |
| GPU voxelPerAxisStore | 0.728 | 0.728–0.728 |
| GPU voxelSunFaces | 0.106 | 0.106–0.106 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 45 of each run excluded | 135 | 9.370 | 11.200 | 11.948 | 12.162 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 180 / 180 | 0 | 180 | 45.000 (0.000) | 0 / 0 (180) |
