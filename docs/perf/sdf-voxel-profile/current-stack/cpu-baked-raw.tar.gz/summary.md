| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.280 | 12.280–12.280 |
| frame p95 | 20.420 | 20.420–20.420 |
| frame p99 | 21.150 | 21.150–21.150 |
| steady frame avg | 13.210 | 13.210–13.210 |
| steady frame p95 | 20.510 | 20.510–20.510 |
| steady frame p99 | 21.190 | 21.190–21.190 |
| GPU frame commandBufferSpans | 5.040 | 5.040–5.040 |
| GPU frame envelope | 5.040 | 5.040–5.040 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 300 of each run excluded | 900 | 13.205 | 20.508 | 21.193 | 21.841 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 1200 / 1200 | 0 | 1200 | 45.000 (0.000) | 403 / 0 (1200) |
