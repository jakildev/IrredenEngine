| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.610 | 12.610–12.610 |
| frame p95 | 21.050 | 21.050–21.050 |
| frame p99 | 24.610 | 24.610–24.610 |
| steady frame avg | 11.110 | 11.110–11.110 |
| steady frame p95 | 20.530 | 20.530–20.530 |
| steady frame p99 | 21.380 | 21.380–21.380 |
| GPU frame commandBufferSpans | 5.316 | 5.316–5.316 |
| GPU frame envelope | 5.316 | 5.316–5.316 |
| GPU canvasClear | 0.065 | 0.065–0.065 |
| GPU computeLightVolume | 3.688 | 3.688–3.688 |
| GPU computeSunShadow | 0.092 | 0.092–0.092 |
| GPU computeVoxelAO | 0.039 | 0.039–0.039 |
| GPU computeVoxelAoPerAxis | 2.124 | 2.124–2.124 |
| GPU fbToScreen | 0.111 | 0.111–0.111 |
| GPU lightingOverflow | 3.218 | 3.218–3.218 |
| GPU lightingPerAxis | 0.098 | 0.098–0.098 |
| GPU lightingToTrixel | 0.046 | 0.046–0.046 |
| GPU perAxisCellCompact | 0.259 | 0.259–0.259 |
| GPU perAxisScatter | 0.147 | 0.147–0.147 |
| GPU resolvePerAxisScreenDepth | 2.275 | 2.275–2.275 |
| GPU shapeDepth | 0.268 | 0.268–0.268 |
| GPU shapeOwnerClear | 0.018 | 0.018–0.018 |
| GPU shapeOwnerElect | 0.262 | 0.262–0.262 |
| GPU shapePublish | 0.262 | 0.262–0.262 |
| GPU trixelToFb | 0.225 | 0.225–0.225 |
| GPU voxelCompact | 0.114 | 0.114–0.114 |
| GPU voxelPerAxisFinalize | 0.242 | 0.242–0.242 |
| GPU voxelPerAxisOverflow | 0.332 | 0.332–0.332 |
| GPU voxelPerAxisStore | 1.321 | 1.321–1.321 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.111 | 20.530 | 21.385 | 24.606 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
