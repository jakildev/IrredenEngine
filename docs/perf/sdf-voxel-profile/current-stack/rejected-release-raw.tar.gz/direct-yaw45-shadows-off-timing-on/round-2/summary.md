| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.060 | 15.060–15.060 |
| frame p95 | 19.990 | 19.990–19.990 |
| frame p99 | 28.530 | 28.530–28.530 |
| steady frame avg | 15.580 | 15.580–15.580 |
| steady frame p95 | 19.990 | 19.990–19.990 |
| steady frame p99 | 20.500 | 20.500–20.500 |
| GPU frame commandBufferSpans | 5.712 | 5.712–5.712 |
| GPU frame envelope | 5.712 | 5.712–5.712 |
| GPU canvasClear | 0.065 | 0.065–0.065 |
| GPU computeLightVolume | 4.007 | 4.007–4.007 |
| GPU computeSunShadow | 0.102 | 0.102–0.102 |
| GPU computeVoxelAO | 0.043 | 0.043–0.043 |
| GPU computeVoxelAoPerAxis | 2.270 | 2.270–2.270 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingOverflow | 3.509 | 3.509–3.509 |
| GPU lightingPerAxis | 0.107 | 0.107–0.107 |
| GPU lightingToTrixel | 0.051 | 0.051–0.051 |
| GPU perAxisCellCompact | 0.274 | 0.274–0.274 |
| GPU perAxisScatter | 0.158 | 0.158–0.158 |
| GPU resolvePerAxisScreenDepth | 2.444 | 2.444–2.444 |
| GPU shapeDepth | 0.294 | 0.294–0.294 |
| GPU shapeOwnerClear | 0.018 | 0.018–0.018 |
| GPU shapeOwnerElect | 0.287 | 0.287–0.287 |
| GPU shapePublish | 0.289 | 0.289–0.289 |
| GPU trixelToFb | 0.218 | 0.218–0.218 |
| GPU voxelCompact | 0.124 | 0.124–0.124 |
| GPU voxelPerAxisFinalize | 0.252 | 0.252–0.252 |
| GPU voxelPerAxisOverflow | 0.347 | 0.347–0.347 |
| GPU voxelPerAxisStore | 1.378 | 1.378–1.378 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.585 | 19.990 | 20.502 | 28.525 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
