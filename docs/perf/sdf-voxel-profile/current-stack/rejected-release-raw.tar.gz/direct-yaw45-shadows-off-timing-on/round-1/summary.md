| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.230 | 15.230–15.230 |
| frame p95 | 19.940 | 19.940–19.940 |
| frame p99 | 20.490 | 20.490–20.490 |
| steady frame avg | 16.780 | 16.780–16.780 |
| steady frame p95 | 19.990 | 19.990–19.990 |
| steady frame p99 | 20.440 | 20.440–20.440 |
| GPU frame commandBufferSpans | 5.711 | 5.711–5.711 |
| GPU frame envelope | 5.711 | 5.711–5.711 |
| GPU canvasClear | 0.067 | 0.067–0.067 |
| GPU computeLightVolume | 3.968 | 3.968–3.968 |
| GPU computeSunShadow | 0.100 | 0.100–0.100 |
| GPU computeVoxelAO | 0.043 | 0.043–0.043 |
| GPU computeVoxelAoPerAxis | 2.253 | 2.253–2.253 |
| GPU fbToScreen | 0.117 | 0.117–0.117 |
| GPU lightingOverflow | 3.484 | 3.484–3.484 |
| GPU lightingPerAxis | 0.105 | 0.105–0.105 |
| GPU lightingToTrixel | 0.049 | 0.049–0.049 |
| GPU perAxisCellCompact | 0.275 | 0.275–0.275 |
| GPU perAxisScatter | 0.156 | 0.156–0.156 |
| GPU resolvePerAxisScreenDepth | 2.430 | 2.430–2.430 |
| GPU shapeDepth | 0.288 | 0.288–0.288 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.282 | 0.282–0.282 |
| GPU shapePublish | 0.286 | 0.286–0.286 |
| GPU trixelToFb | 0.215 | 0.215–0.215 |
| GPU voxelCompact | 0.130 | 0.130–0.130 |
| GPU voxelPerAxisFinalize | 0.251 | 0.251–0.251 |
| GPU voxelPerAxisOverflow | 0.346 | 0.346–0.346 |
| GPU voxelPerAxisStore | 1.380 | 1.380–1.380 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 16.777 | 19.993 | 20.442 | 20.891 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
