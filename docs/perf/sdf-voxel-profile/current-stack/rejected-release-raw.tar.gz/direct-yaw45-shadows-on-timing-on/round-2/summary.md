| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.290 | 16.290–16.290 |
| frame p95 | 20.400 | 20.400–20.400 |
| frame p99 | 21.370 | 21.370–21.370 |
| steady frame avg | 16.180 | 16.180–16.180 |
| steady frame p95 | 20.420 | 20.420–20.420 |
| steady frame p99 | 20.810 | 20.810–20.810 |
| GPU frame commandBufferSpans | 5.699 | 5.699–5.699 |
| GPU frame envelope | 5.699 | 5.699–5.699 |
| GPU canvasClear | 0.057 | 0.057–0.057 |
| GPU computeLightVolume | 3.228 | 3.228–3.228 |
| GPU computeSunShadow | 0.346 | 0.346–0.346 |
| GPU computeVoxelAO | 0.037 | 0.037–0.037 |
| GPU computeVoxelAoPerAxis | 0.737 | 0.737–0.737 |
| GPU fbToScreen | 0.107 | 0.107–0.107 |
| GPU lightingOverflow | 2.286 | 2.286–2.286 |
| GPU lightingPerAxis | 0.098 | 0.098–0.098 |
| GPU lightingToTrixel | 0.045 | 0.045–0.045 |
| GPU perAxisCellCompact | 0.403 | 0.403–0.403 |
| GPU perAxisScatter | 0.162 | 0.162–0.162 |
| GPU resolvePerAxisScreenDepth | 0.938 | 0.938–0.938 |
| GPU shapeCastBake | 1.938 | 1.938–1.938 |
| GPU shapeCastBoxes | 2.116 | 2.116–2.116 |
| GPU shapeCastClear | 0.046 | 0.046–0.046 |
| GPU shapeCastFallback | 0.028 | 0.028–0.028 |
| GPU shapeCastResolve | 0.035 | 0.035–0.035 |
| GPU shapeDepth | 0.273 | 0.273–0.273 |
| GPU shapeOwnerClear | 0.017 | 0.017–0.017 |
| GPU shapeOwnerElect | 0.263 | 0.263–0.263 |
| GPU shapePublish | 0.278 | 0.278–0.278 |
| GPU trixelToFb | 0.214 | 0.214–0.214 |
| GPU voxelCompact | 0.096 | 0.096–0.096 |
| GPU voxelPerAxisFinalize | 0.295 | 0.295–0.295 |
| GPU voxelPerAxisOverflow | 0.466 | 0.466–0.466 |
| GPU voxelPerAxisStore | 1.464 | 1.464–1.464 |
| GPU voxelSunFaces | 0.229 | 0.229–0.229 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 16.179 | 20.418 | 20.808 | 21.371 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
