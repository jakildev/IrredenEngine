| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.950 | 15.950–15.950 |
| frame p95 | 20.480 | 20.480–20.480 |
| frame p99 | 22.710 | 22.710–22.710 |
| steady frame avg | 17.950 | 17.950–17.950 |
| steady frame p95 | 20.480 | 20.480–20.480 |
| steady frame p99 | 21.030 | 21.030–21.030 |
| GPU frame commandBufferSpans | 5.721 | 5.721–5.721 |
| GPU frame envelope | 5.721 | 5.721–5.721 |
| GPU canvasClear | 0.056 | 0.056–0.056 |
| GPU computeLightVolume | 3.283 | 3.283–3.283 |
| GPU computeSunShadow | 0.361 | 0.361–0.361 |
| GPU computeVoxelAO | 0.036 | 0.036–0.036 |
| GPU computeVoxelAoPerAxis | 0.731 | 0.731–0.731 |
| GPU fbToScreen | 0.111 | 0.111–0.111 |
| GPU lightingOverflow | 2.350 | 2.350–2.350 |
| GPU lightingPerAxis | 0.102 | 0.102–0.102 |
| GPU lightingToTrixel | 0.047 | 0.047–0.047 |
| GPU perAxisCellCompact | 0.393 | 0.393–0.393 |
| GPU perAxisScatter | 0.169 | 0.169–0.169 |
| GPU resolvePerAxisScreenDepth | 0.942 | 0.942–0.942 |
| GPU shapeCastBake | 1.915 | 1.915–1.915 |
| GPU shapeCastBoxes | 2.096 | 2.096–2.096 |
| GPU shapeCastClear | 0.046 | 0.046–0.046 |
| GPU shapeCastFallback | 0.028 | 0.028–0.028 |
| GPU shapeCastResolve | 0.037 | 0.037–0.037 |
| GPU shapeDepth | 0.282 | 0.282–0.282 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.273 | 0.273–0.273 |
| GPU shapePublish | 0.286 | 0.286–0.286 |
| GPU trixelToFb | 0.208 | 0.208–0.208 |
| GPU voxelCompact | 0.085 | 0.085–0.085 |
| GPU voxelPerAxisFinalize | 0.303 | 0.303–0.303 |
| GPU voxelPerAxisOverflow | 0.479 | 0.479–0.479 |
| GPU voxelPerAxisStore | 1.396 | 1.396–1.396 |
| GPU voxelSunFaces | 0.224 | 0.224–0.224 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 17.953 | 20.482 | 21.031 | 21.167 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
