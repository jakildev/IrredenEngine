| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.620 | 12.620–12.620 |
| frame p95 | 20.240 | 20.240–20.240 |
| frame p99 | 29.850 | 29.850–29.850 |
| steady frame avg | 11.380 | 11.380–11.380 |
| steady frame p95 | 19.910 | 19.910–19.910 |
| steady frame p99 | 20.240 | 20.240–20.240 |
| GPU frame commandBufferSpans | 5.755 | 5.755–5.755 |
| GPU frame envelope | 5.755 | 5.755–5.755 |
| GPU canvasClear | 0.055 | 0.055–0.055 |
| GPU computeLightVolume | 3.333 | 3.333–3.333 |
| GPU computeSunShadow | 0.372 | 0.372–0.372 |
| GPU computeVoxelAO | 0.036 | 0.036–0.036 |
| GPU computeVoxelAoPerAxis | 0.720 | 0.720–0.720 |
| GPU fbToScreen | 0.113 | 0.113–0.113 |
| GPU lightingOverflow | 2.388 | 2.388–2.388 |
| GPU lightingPerAxis | 0.102 | 0.102–0.102 |
| GPU lightingToTrixel | 0.047 | 0.047–0.047 |
| GPU perAxisCellCompact | 0.406 | 0.406–0.406 |
| GPU perAxisScatter | 0.173 | 0.173–0.173 |
| GPU resolvePerAxisScreenDepth | 0.929 | 0.929–0.929 |
| GPU shapeCastBake | 1.980 | 1.980–1.980 |
| GPU shapeCastBoxes | 2.149 | 2.149–2.149 |
| GPU shapeCastClear | 0.048 | 0.048–0.048 |
| GPU shapeCastFallback | 0.030 | 0.030–0.030 |
| GPU shapeCastResolve | 0.039 | 0.039–0.039 |
| GPU shapeDepth | 0.295 | 0.295–0.295 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.286 | 0.286–0.286 |
| GPU shapePublish | 0.301 | 0.301–0.301 |
| GPU trixelToFb | 0.235 | 0.235–0.235 |
| GPU voxelCompact | 0.077 | 0.077–0.077 |
| GPU voxelPerAxisFinalize | 0.310 | 0.310–0.310 |
| GPU voxelPerAxisOverflow | 0.511 | 0.511–0.511 |
| GPU voxelPerAxisStore | 1.366 | 1.366–1.366 |
| GPU voxelSunFaces | 0.217 | 0.217–0.217 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.382 | 19.915 | 20.243 | 20.715 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
