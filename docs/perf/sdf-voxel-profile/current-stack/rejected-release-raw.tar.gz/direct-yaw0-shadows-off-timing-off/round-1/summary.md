| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.470 | 8.470–8.470 |
| frame p95 | 8.540 | 8.540–8.540 |
| frame p99 | 8.850 | 8.850–8.850 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.540 | 8.540–8.540 |
| steady frame p99 | 8.620 | 8.620–8.620 |
| GPU frame commandBufferSpans | 3.004 | 3.004–3.004 |
| GPU frame envelope | 3.004 | 3.004–3.004 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.334 | 8.542 | 8.616 | 8.685 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
