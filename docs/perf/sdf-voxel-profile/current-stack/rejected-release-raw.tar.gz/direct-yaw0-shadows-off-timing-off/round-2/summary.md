| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.580 | 8.580–8.580 |
| frame p95 | 8.540 | 8.540–8.540 |
| frame p99 | 8.680 | 8.680–8.680 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.530 | 8.530–8.530 |
| steady frame p99 | 8.670 | 8.670–8.670 |
| GPU frame commandBufferSpans | 3.334 | 3.334–3.334 |
| GPU frame envelope | 3.334 | 3.334–3.334 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.377 | 8.534 | 8.672 | 18.701 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
