| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.570 | 11.570–11.570 |
| frame p95 | 19.160 | 19.160–19.160 |
| frame p99 | 21.410 | 21.410–21.410 |
| steady frame avg | 11.720 | 11.720–11.720 |
| steady frame p95 | 19.130 | 19.130–19.130 |
| steady frame p99 | 19.660 | 19.660–19.660 |
| GPU frame commandBufferSpans | 4.725 | 4.725–4.725 |
| GPU frame envelope | 4.725 | 4.725–4.725 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.721 | 19.129 | 19.661 | 21.408 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
