| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 14.340 | 14.340–14.340 |
| frame p95 | 19.370 | 19.370–19.370 |
| frame p99 | 21.410 | 21.410–21.410 |
| steady frame avg | 14.660 | 14.660–14.660 |
| steady frame p95 | 19.280 | 19.280–19.280 |
| steady frame p99 | 20.020 | 20.020–20.020 |
| GPU frame commandBufferSpans | 4.970 | 4.970–4.970 |
| GPU frame envelope | 4.970 | 4.970–4.970 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 14.662 | 19.281 | 20.015 | 20.321 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
