| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.680 | 8.680–8.680 |
| frame p95 | 8.590 | 8.590–8.590 |
| frame p99 | 27.750 | 27.750–27.750 |
| steady frame avg | 8.370 | 8.370–8.370 |
| steady frame p95 | 8.590 | 8.590–8.590 |
| steady frame p99 | 8.760 | 8.760–8.760 |
| GPU frame commandBufferSpans | 3.406 | 3.406–3.406 |
| GPU frame envelope | 3.406 | 3.406–3.406 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.370 | 8.591 | 8.758 | 16.855 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
