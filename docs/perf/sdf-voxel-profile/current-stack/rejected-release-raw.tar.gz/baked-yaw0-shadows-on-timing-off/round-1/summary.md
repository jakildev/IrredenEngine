| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.540 | 8.540–8.540 |
| frame p95 | 8.660 | 8.660–8.660 |
| frame p99 | 18.260 | 18.260–18.260 |
| steady frame avg | 8.370 | 8.370–8.370 |
| steady frame p95 | 8.640 | 8.640–8.640 |
| steady frame p99 | 8.700 | 8.700–8.700 |
| GPU frame commandBufferSpans | 3.423 | 3.423–3.423 |
| GPU frame envelope | 3.423 | 3.423–3.423 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.373 | 8.637 | 8.696 | 18.256 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
