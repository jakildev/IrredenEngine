| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.540 | 8.540–8.540 |
| frame p95 | 8.590 | 8.590–8.590 |
| frame p99 | 16.680 | 16.680–16.680 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.560 | 8.560–8.560 |
| steady frame p99 | 8.740 | 8.740–8.740 |
| GPU frame commandBufferSpans | 3.322 | 3.322–3.322 |
| GPU frame envelope | 3.322 | 3.322–3.322 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.332 | 8.556 | 8.739 | 8.748 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
