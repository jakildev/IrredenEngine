| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.580 | 8.580–8.580 |
| frame p95 | 8.600 | 8.600–8.600 |
| frame p99 | 17.700 | 17.700–17.700 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.590 | 8.590–8.590 |
| steady frame p99 | 8.700 | 8.700–8.700 |
| GPU frame commandBufferSpans | 4.030 | 4.030–4.030 |
| GPU frame envelope | 4.030 | 4.030–4.030 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.375 | 8.590 | 8.699 | 17.701 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
