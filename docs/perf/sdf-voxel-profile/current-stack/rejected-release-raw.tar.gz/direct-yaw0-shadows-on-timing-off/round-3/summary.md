| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.540 | 8.540–8.540 |
| frame p95 | 8.560 | 8.560–8.560 |
| frame p99 | 18.480 | 18.480–18.480 |
| steady frame avg | 8.410 | 8.410–8.410 |
| steady frame p95 | 8.550 | 8.550–8.550 |
| steady frame p99 | 8.630 | 8.630–8.630 |
| GPU frame commandBufferSpans | 3.929 | 3.929–3.929 |
| GPU frame envelope | 3.929 | 3.929–3.929 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.411 | 8.554 | 8.631 | 18.482 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
