| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.630 | 8.630–8.630 |
| frame p95 | 8.570 | 8.570–8.570 |
| frame p99 | 33.720 | 33.720–33.720 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.540 | 8.540–8.540 |
| steady frame p99 | 8.650 | 8.650–8.650 |
| GPU frame commandBufferSpans | 3.878 | 3.878–3.878 |
| GPU frame envelope | 3.878 | 3.878–3.878 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.333 | 8.543 | 8.647 | 8.723 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
