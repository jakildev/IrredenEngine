| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.830 | 8.830–8.830 |
| frame p95 | 8.640 | 8.640–8.640 |
| frame p99 | 36.050 | 36.050–36.050 |
| steady frame avg | 8.410 | 8.410–8.410 |
| steady frame p95 | 8.620 | 8.620–8.620 |
| steady frame p99 | 8.710 | 8.710–8.710 |
| GPU frame commandBufferSpans | 3.611 | 3.611–3.611 |
| GPU frame envelope | 3.611 | 3.611–3.611 |
| GPU canvasClear | 0.050 | 0.050–0.050 |
| GPU computeLightVolume | 2.151 | 2.151–2.151 |
| GPU computeSunShadow | 0.316 | 0.316–0.316 |
| GPU computeVoxelAO | 0.036 | 0.036–0.036 |
| GPU fbToScreen | 0.126 | 0.126–0.126 |
| GPU lightingToTrixel | 0.064 | 0.064–0.064 |
| GPU trixelToFb | 0.201 | 0.201–0.201 |
| GPU voxelCardinalElect | 0.110 | 0.110–0.110 |
| GPU voxelCompact | 0.068 | 0.068–0.068 |
| GPU voxelStage1 | 0.169 | 0.169–0.169 |
| GPU voxelStage2 | 0.125 | 0.125–0.125 |
| GPU voxelSunFaces | 0.131 | 0.131–0.131 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.409 | 8.618 | 8.712 | 17.555 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
