| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.590 | 8.590–8.590 |
| frame p95 | 8.670 | 8.670–8.670 |
| frame p99 | 19.690 | 19.690–19.690 |
| steady frame avg | 8.430 | 8.430–8.430 |
| steady frame p95 | 8.660 | 8.660–8.660 |
| steady frame p99 | 8.740 | 8.740–8.740 |
| GPU frame commandBufferSpans | 3.468 | 3.468–3.468 |
| GPU frame envelope | 3.468 | 3.468–3.468 |
| GPU canvasClear | 0.048 | 0.048–0.048 |
| GPU computeLightVolume | 2.076 | 2.076–2.076 |
| GPU computeSunShadow | 0.305 | 0.305–0.305 |
| GPU computeVoxelAO | 0.034 | 0.034–0.034 |
| GPU fbToScreen | 0.122 | 0.122–0.122 |
| GPU lightingToTrixel | 0.060 | 0.060–0.060 |
| GPU trixelToFb | 0.206 | 0.206–0.206 |
| GPU voxelCardinalElect | 0.104 | 0.104–0.104 |
| GPU voxelCompact | 0.071 | 0.071–0.071 |
| GPU voxelStage1 | 0.155 | 0.155–0.155 |
| GPU voxelStage2 | 0.116 | 0.116–0.116 |
| GPU voxelSunFaces | 0.132 | 0.132–0.132 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.426 | 8.657 | 8.737 | 19.692 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
