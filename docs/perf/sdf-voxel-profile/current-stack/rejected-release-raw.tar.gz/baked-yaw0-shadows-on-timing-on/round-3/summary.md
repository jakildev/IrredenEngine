| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.490 | 8.490–8.490 |
| frame p95 | 8.620 | 8.620–8.620 |
| frame p99 | 9.600 | 9.600–9.600 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.620 | 8.620–8.620 |
| steady frame p99 | 8.660 | 8.660–8.660 |
| GPU frame commandBufferSpans | 3.455 | 3.455–3.455 |
| GPU frame envelope | 3.455 | 3.455–3.455 |
| GPU canvasClear | 0.053 | 0.053–0.053 |
| GPU computeLightVolume | 2.097 | 2.097–2.097 |
| GPU computeSunShadow | 0.308 | 0.308–0.308 |
| GPU computeVoxelAO | 0.037 | 0.037–0.037 |
| GPU fbToScreen | 0.125 | 0.125–0.125 |
| GPU lightingToTrixel | 0.064 | 0.064–0.064 |
| GPU trixelToFb | 0.201 | 0.201–0.201 |
| GPU voxelCardinalElect | 0.108 | 0.108–0.108 |
| GPU voxelCompact | 0.070 | 0.070–0.070 |
| GPU voxelStage1 | 0.163 | 0.163–0.163 |
| GPU voxelStage2 | 0.120 | 0.120–0.120 |
| GPU voxelSunFaces | 0.130 | 0.130–0.130 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.333 | 8.623 | 8.661 | 8.800 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
