| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.910 | 8.910–8.910 |
| frame p95 | 8.540 | 8.540–8.540 |
| frame p99 | 19.500 | 19.500–19.500 |
| steady frame avg | 8.670 | 8.670–8.670 |
| steady frame p95 | 8.520 | 8.520–8.520 |
| steady frame p99 | 18.530 | 18.530–18.530 |
| GPU frame commandBufferSpans | 4.795 | 4.795–4.795 |
| GPU frame envelope | 4.795 | 4.795–4.795 |
| GPU canvasClear | 0.063 | 0.063–0.063 |
| GPU computeLightVolume | 3.133 | 3.133–3.133 |
| GPU computeSunShadow | 0.088 | 0.088–0.088 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU computeVoxelAoPerAxis | 1.385 | 1.385–1.385 |
| GPU fbToScreen | 0.114 | 0.114–0.114 |
| GPU lightingOverflow | 2.609 | 2.609–2.609 |
| GPU lightingPerAxis | 0.099 | 0.099–0.099 |
| GPU lightingToTrixel | 0.040 | 0.040–0.040 |
| GPU perAxisCellCompact | 0.270 | 0.270–0.270 |
| GPU perAxisScatter | 0.163 | 0.163–0.163 |
| GPU resolvePerAxisScreenDepth | 1.605 | 1.605–1.605 |
| GPU trixelToFb | 0.253 | 0.253–0.253 |
| GPU voxelCompact | 0.139 | 0.139–0.139 |
| GPU voxelPerAxisFinalize | 0.251 | 0.251–0.251 |
| GPU voxelPerAxisOverflow | 0.338 | 0.338–0.338 |
| GPU voxelPerAxisStore | 1.391 | 1.391–1.391 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.671 | 8.517 | 18.527 | 19.501 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
