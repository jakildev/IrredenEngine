| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.430 | 9.430–9.430 |
| frame p95 | 18.380 | 18.380–18.380 |
| frame p99 | 20.550 | 20.550–20.550 |
| steady frame avg | 9.260 | 9.260–9.260 |
| steady frame p95 | 18.220 | 18.220–18.220 |
| steady frame p99 | 19.140 | 19.140–19.140 |
| GPU frame commandBufferSpans | 4.925 | 4.925–4.925 |
| GPU frame envelope | 4.925 | 4.925–4.925 |
| GPU canvasClear | 0.064 | 0.064–0.064 |
| GPU computeLightVolume | 3.225 | 3.225–3.225 |
| GPU computeSunShadow | 0.091 | 0.091–0.091 |
| GPU computeVoxelAO | 0.044 | 0.044–0.044 |
| GPU computeVoxelAoPerAxis | 1.415 | 1.415–1.415 |
| GPU fbToScreen | 0.118 | 0.118–0.118 |
| GPU lightingOverflow | 2.709 | 2.709–2.709 |
| GPU lightingPerAxis | 0.103 | 0.103–0.103 |
| GPU lightingToTrixel | 0.041 | 0.041–0.041 |
| GPU perAxisCellCompact | 0.281 | 0.281–0.281 |
| GPU perAxisScatter | 0.173 | 0.173–0.173 |
| GPU resolvePerAxisScreenDepth | 1.649 | 1.649–1.649 |
| GPU trixelToFb | 0.251 | 0.251–0.251 |
| GPU voxelCompact | 0.137 | 0.137–0.137 |
| GPU voxelPerAxisFinalize | 0.255 | 0.255–0.255 |
| GPU voxelPerAxisOverflow | 0.352 | 0.352–0.352 |
| GPU voxelPerAxisStore | 1.383 | 1.383–1.383 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 9.265 | 18.225 | 19.135 | 19.809 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
