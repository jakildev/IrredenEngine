| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 13.870 | 13.870–13.870 |
| frame p95 | 19.650 | 19.650–19.650 |
| frame p99 | 23.300 | 23.300–23.300 |
| steady frame avg | 15.180 | 15.180–15.180 |
| steady frame p95 | 19.650 | 19.650–19.650 |
| steady frame p99 | 20.120 | 20.120–20.120 |
| GPU frame commandBufferSpans | 5.635 | 5.635–5.635 |
| GPU frame envelope | 5.635 | 5.635–5.635 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.184 | 19.653 | 20.120 | 22.493 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
