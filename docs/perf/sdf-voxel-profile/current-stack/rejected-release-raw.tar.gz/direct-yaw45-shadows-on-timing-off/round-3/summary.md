| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 17.120 | 17.120–17.120 |
| frame p95 | 20.940 | 20.940–20.940 |
| frame p99 | 38.130 | 38.130–38.130 |
| steady frame avg | 18.170 | 18.170–18.170 |
| steady frame p95 | 20.890 | 20.890–20.890 |
| steady frame p99 | 21.740 | 21.740–21.740 |
| GPU frame commandBufferSpans | 5.764 | 5.764–5.764 |
| GPU frame envelope | 5.764 | 5.764–5.764 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 18.173 | 20.887 | 21.744 | 27.909 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
