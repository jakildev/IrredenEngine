| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.680 | 12.680–12.680 |
| frame p95 | 19.730 | 19.730–19.730 |
| frame p99 | 20.850 | 20.850–20.850 |
| steady frame avg | 13.120 | 13.120–13.120 |
| steady frame p95 | 19.720 | 19.720–19.720 |
| steady frame p99 | 20.230 | 20.230–20.230 |
| GPU frame commandBufferSpans | 5.567 | 5.567–5.567 |
| GPU frame envelope | 5.567 | 5.567–5.567 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 13.119 | 19.721 | 20.230 | 20.849 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
