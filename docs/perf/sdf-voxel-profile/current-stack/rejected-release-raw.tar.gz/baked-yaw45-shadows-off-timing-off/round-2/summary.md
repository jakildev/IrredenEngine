| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 10.960 | 10.960–10.960 |
| frame p95 | 18.910 | 18.910–18.910 |
| frame p99 | 20.040 | 20.040–20.040 |
| steady frame avg | 11.110 | 11.110–11.110 |
| steady frame p95 | 18.970 | 18.970–18.970 |
| steady frame p99 | 19.580 | 19.580–19.580 |
| GPU frame commandBufferSpans | 4.519 | 4.519–4.519 |
| GPU frame envelope | 4.519 | 4.519–4.519 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.109 | 18.969 | 19.582 | 20.038 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
