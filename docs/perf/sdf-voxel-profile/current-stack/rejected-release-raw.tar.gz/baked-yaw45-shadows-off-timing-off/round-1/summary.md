| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 13.820 | 13.820–13.820 |
| frame p95 | 18.600 | 18.600–18.600 |
| frame p99 | 21.810 | 21.810–21.810 |
| steady frame avg | 14.610 | 14.610–14.610 |
| steady frame p95 | 18.600 | 18.600–18.600 |
| steady frame p99 | 19.050 | 19.050–19.050 |
| GPU frame commandBufferSpans | 4.699 | 4.699–4.699 |
| GPU frame envelope | 4.699 | 4.699–4.699 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 14.614 | 18.600 | 19.046 | 21.807 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
