| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.230 | 11.230–11.230 |
| frame p95 | 19.330 | 19.330–19.330 |
| frame p99 | 28.200 | 28.200–28.200 |
| steady frame avg | 11.690 | 11.690–11.690 |
| steady frame p95 | 19.330 | 19.330–19.330 |
| steady frame p99 | 20.200 | 20.200–20.200 |
| GPU frame commandBufferSpans | 5.434 | 5.434–5.434 |
| GPU frame envelope | 5.434 | 5.434–5.434 |
| GPU canvasClear | 0.055 | 0.055–0.055 |
| GPU computeLightVolume | 3.440 | 3.440–3.440 |
| GPU computeSunShadow | 0.334 | 0.334–0.334 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU computeVoxelAoPerAxis | 1.178 | 1.178–1.178 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingOverflow | 2.963 | 2.963–2.963 |
| GPU lightingPerAxis | 0.103 | 0.103–0.103 |
| GPU lightingToTrixel | 0.040 | 0.040–0.040 |
| GPU perAxisCellCompact | 0.285 | 0.285–0.285 |
| GPU perAxisScatter | 0.258 | 0.258–0.258 |
| GPU resolvePerAxisScreenDepth | 1.423 | 1.423–1.423 |
| GPU trixelToFb | 0.269 | 0.269–0.269 |
| GPU voxelCompact | 0.075 | 0.075–0.075 |
| GPU voxelPerAxisFinalize | 0.254 | 0.254–0.254 |
| GPU voxelPerAxisOverflow | 0.417 | 0.417–0.417 |
| GPU voxelPerAxisStore | 1.210 | 1.210–1.210 |
| GPU voxelSunFaces | 0.212 | 0.212–0.212 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.686 | 19.328 | 20.196 | 24.277 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
