| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 13.980 | 13.980–13.980 |
| frame p95 | 20.970 | 20.970–20.970 |
| frame p99 | 21.590 | 21.590–21.590 |
| steady frame avg | 15.290 | 15.290–15.290 |
| steady frame p95 | 21.030 | 21.030–21.030 |
| steady frame p99 | 21.310 | 21.310–21.310 |
| GPU frame commandBufferSpans | 5.615 | 5.615–5.615 |
| GPU frame envelope | 5.615 | 5.615–5.615 |
| GPU canvasClear | 0.057 | 0.057–0.057 |
| GPU computeLightVolume | 3.529 | 3.529–3.529 |
| GPU computeSunShadow | 0.341 | 0.341–0.341 |
| GPU computeVoxelAO | 0.044 | 0.044–0.044 |
| GPU computeVoxelAoPerAxis | 1.217 | 1.217–1.217 |
| GPU fbToScreen | 0.121 | 0.121–0.121 |
| GPU lightingOverflow | 3.021 | 3.021–3.021 |
| GPU lightingPerAxis | 0.105 | 0.105–0.105 |
| GPU lightingToTrixel | 0.040 | 0.040–0.040 |
| GPU perAxisCellCompact | 0.312 | 0.312–0.312 |
| GPU perAxisScatter | 0.259 | 0.259–0.259 |
| GPU resolvePerAxisScreenDepth | 1.466 | 1.466–1.466 |
| GPU trixelToFb | 0.289 | 0.289–0.289 |
| GPU voxelCompact | 0.085 | 0.085–0.085 |
| GPU voxelPerAxisFinalize | 0.266 | 0.266–0.266 |
| GPU voxelPerAxisOverflow | 0.419 | 0.419–0.419 |
| GPU voxelPerAxisStore | 1.272 | 1.272–1.272 |
| GPU voxelSunFaces | 0.220 | 0.220–0.220 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.294 | 21.025 | 21.315 | 21.587 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
