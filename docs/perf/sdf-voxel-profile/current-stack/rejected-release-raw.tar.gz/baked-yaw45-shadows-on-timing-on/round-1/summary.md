| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.240 | 12.240–12.240 |
| frame p95 | 19.720 | 19.720–19.720 |
| frame p99 | 26.260 | 26.260–26.260 |
| steady frame avg | 13.090 | 13.090–13.090 |
| steady frame p95 | 19.740 | 19.740–19.740 |
| steady frame p99 | 20.170 | 20.170–20.170 |
| GPU frame commandBufferSpans | 5.313 | 5.313–5.313 |
| GPU frame envelope | 5.313 | 5.313–5.313 |
| GPU canvasClear | 0.054 | 0.054–0.054 |
| GPU computeLightVolume | 3.389 | 3.389–3.389 |
| GPU computeSunShadow | 0.327 | 0.327–0.327 |
| GPU computeVoxelAO | 0.041 | 0.041–0.041 |
| GPU computeVoxelAoPerAxis | 1.170 | 1.170–1.170 |
| GPU fbToScreen | 0.116 | 0.116–0.116 |
| GPU lightingOverflow | 2.902 | 2.902–2.902 |
| GPU lightingPerAxis | 0.100 | 0.100–0.100 |
| GPU lightingToTrixel | 0.038 | 0.038–0.038 |
| GPU perAxisCellCompact | 0.285 | 0.285–0.285 |
| GPU perAxisScatter | 0.248 | 0.248–0.248 |
| GPU resolvePerAxisScreenDepth | 1.407 | 1.407–1.407 |
| GPU trixelToFb | 0.265 | 0.265–0.265 |
| GPU voxelCompact | 0.075 | 0.075–0.075 |
| GPU voxelPerAxisFinalize | 0.253 | 0.253–0.253 |
| GPU voxelPerAxisOverflow | 0.411 | 0.411–0.411 |
| GPU voxelPerAxisStore | 1.210 | 1.210–1.210 |
| GPU voxelSunFaces | 0.211 | 0.211–0.211 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 13.094 | 19.737 | 20.166 | 26.255 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
