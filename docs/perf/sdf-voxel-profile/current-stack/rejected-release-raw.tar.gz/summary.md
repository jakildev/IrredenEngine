| Case | Frame mean ms | Run min–max ms | Steady mean ms | GPU envelope mean ms | Retained mean | Axis entries mean |
|---|---:|---:|---:|---:|---:|---:|
| direct-yaw0-shadows-on-timing-on | 8.525 | 8.460–8.590 | 8.330 | 3.976 | 2328.0 | 0.0 |
| baked-yaw0-shadows-on-timing-on | 8.710 | 8.590–8.830 | 8.420 | 3.540 | 3134.0 | 0.0 |
| direct-yaw0-shadows-on-timing-off | 8.605 | 8.580–8.630 | 8.355 | 3.954 | 0.0 | — |
| baked-yaw0-shadows-on-timing-off | 8.540 | 8.540–8.540 | 8.350 | 3.373 | 0.0 | — |
| direct-yaw0-shadows-off-timing-on | 8.570 | 8.530–8.610 | 8.405 | 3.068 | 2328.0 | 0.0 |
| baked-yaw0-shadows-off-timing-on | 8.500 | 8.490–8.510 | 8.330 | 2.649 | 3134.0 | 0.0 |
| direct-yaw0-shadows-off-timing-off | 8.525 | 8.470–8.580 | 8.355 | 3.169 | 0.0 | — |
| baked-yaw0-shadows-off-timing-off | 8.575 | 8.530–8.620 | 8.350 | 2.718 | 0.0 | — |
| direct-yaw45-shadows-on-timing-on | 16.120 | 15.950–16.290 | 17.065 | 5.710 | 2328.0 | 2560.0 |
| baked-yaw45-shadows-on-timing-on | 11.735 | 11.230–12.240 | 12.390 | 5.373 | 3134.0 | 4008.0 |
| direct-yaw45-shadows-on-timing-off | 13.275 | 12.680–13.870 | 14.150 | 5.601 | 0.0 | — |
| baked-yaw45-shadows-on-timing-off | 10.155 | 9.270–11.040 | 9.710 | 4.978 | 0.0 | — |
| direct-yaw45-shadows-off-timing-on | 15.145 | 15.060–15.230 | 16.180 | 5.712 | 2328.0 | 2560.0 |
| baked-yaw45-shadows-off-timing-on | 9.170 | 8.910–9.430 | 8.965 | 4.860 | 3134.0 | 4008.0 |
| direct-yaw45-shadows-off-timing-off | 12.955 | 11.570–14.340 | 13.190 | 4.848 | 0.0 | — |
| baked-yaw45-shadows-off-timing-off | 12.390 | 10.960–13.820 | 12.860 | 4.609 | 0.0 | — |
