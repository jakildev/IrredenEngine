| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.510 | 8.510–8.510 |
| frame p95 | 8.620 | 8.620–8.620 |
| frame p99 | 17.710 | 17.710–17.710 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.590 | 8.590–8.590 |
| steady frame p99 | 8.650 | 8.650–8.650 |
| GPU frame commandBufferSpans | 2.623 | 2.623–2.623 |
| GPU frame envelope | 2.623 | 2.623–2.623 |
| GPU canvasClear | 0.059 | 0.059–0.059 |
| GPU computeLightVolume | 1.474 | 1.474–1.474 |
| GPU computeSunShadow | 0.031 | 0.031–0.031 |
| GPU computeVoxelAO | 0.143 | 0.143–0.143 |
| GPU fbToScreen | 0.118 | 0.118–0.118 |
| GPU lightingToTrixel | 0.058 | 0.058–0.058 |
| GPU trixelToFb | 0.181 | 0.181–0.181 |
| GPU voxelCardinalElect | 0.114 | 0.114–0.114 |
| GPU voxelCompact | 0.126 | 0.126–0.126 |
| GPU voxelStage1 | 0.202 | 0.202–0.202 |
| GPU voxelStage2 | 0.124 | 0.124–0.124 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.333 | 8.595 | 8.649 | 8.707 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
