| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.490 | 8.490–8.490 |
| frame p95 | 8.640 | 8.640–8.640 |
| frame p99 | 18.680 | 18.680–18.680 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.570 | 8.570–8.570 |
| steady frame p99 | 8.730 | 8.730–8.730 |
| GPU frame commandBufferSpans | 2.601 | 2.601–2.601 |
| GPU frame envelope | 2.601 | 2.601–2.601 |
| GPU canvasClear | 0.053 | 0.053–0.053 |
| GPU computeLightVolume | 1.464 | 1.464–1.464 |
| GPU computeSunShadow | 0.032 | 0.032–0.032 |
| GPU computeVoxelAO | 0.127 | 0.127–0.127 |
| GPU fbToScreen | 0.120 | 0.120–0.120 |
| GPU lightingToTrixel | 0.063 | 0.063–0.063 |
| GPU trixelToFb | 0.182 | 0.182–0.182 |
| GPU voxelCardinalElect | 0.108 | 0.108–0.108 |
| GPU voxelCompact | 0.102 | 0.102–0.102 |
| GPU voxelStage1 | 0.206 | 0.206–0.206 |
| GPU voxelStage2 | 0.121 | 0.121–0.121 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.375 | 8.569 | 8.732 | 18.677 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
