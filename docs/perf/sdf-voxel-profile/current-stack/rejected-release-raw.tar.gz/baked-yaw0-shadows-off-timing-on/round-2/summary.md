| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.490 | 8.490–8.490 |
| frame p95 | 8.630 | 8.630–8.630 |
| frame p99 | 8.990 | 8.990–8.990 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.610 | 8.610–8.610 |
| steady frame p99 | 8.730 | 8.730–8.730 |
| GPU frame commandBufferSpans | 2.674 | 2.674–2.674 |
| GPU frame envelope | 2.674 | 2.674–2.674 |
| GPU canvasClear | 0.058 | 0.058–0.058 |
| GPU computeLightVolume | 1.497 | 1.497–1.497 |
| GPU computeSunShadow | 0.032 | 0.032–0.032 |
| GPU computeVoxelAO | 0.146 | 0.146–0.146 |
| GPU fbToScreen | 0.120 | 0.120–0.120 |
| GPU lightingToTrixel | 0.060 | 0.060–0.060 |
| GPU trixelToFb | 0.223 | 0.223–0.223 |
| GPU voxelCardinalElect | 0.110 | 0.110–0.110 |
| GPU voxelCompact | 0.133 | 0.133–0.133 |
| GPU voxelStage1 | 0.203 | 0.203–0.203 |
| GPU voxelStage2 | 0.121 | 0.121–0.121 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.332 | 8.612 | 8.734 | 8.769 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
