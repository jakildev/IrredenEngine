| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.520 | 8.520–8.520 |
| frame p95 | 8.640 | 8.640–8.640 |
| frame p99 | 20.710 | 20.710–20.710 |
| steady frame avg | 8.390 | 8.390–8.390 |
| steady frame p95 | 8.620 | 8.620–8.620 |
| steady frame p99 | 8.760 | 8.760–8.760 |
| GPU frame commandBufferSpans | 2.719 | 2.719–2.719 |
| GPU frame envelope | 2.719 | 2.719–2.719 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.385 | 8.616 | 8.761 | 20.708 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
