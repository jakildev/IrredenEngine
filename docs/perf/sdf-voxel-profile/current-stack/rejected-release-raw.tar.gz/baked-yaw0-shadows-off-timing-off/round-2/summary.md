| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.530 | 8.530–8.530 |
| frame p95 | 8.600 | 8.600–8.600 |
| frame p99 | 8.980 | 8.980–8.980 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.600 | 8.600–8.600 |
| steady frame p99 | 8.690 | 8.690–8.690 |
| GPU frame commandBufferSpans | 2.688 | 2.688–2.688 |
| GPU frame envelope | 2.688 | 2.688–2.688 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.332 | 8.601 | 8.691 | 8.982 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
