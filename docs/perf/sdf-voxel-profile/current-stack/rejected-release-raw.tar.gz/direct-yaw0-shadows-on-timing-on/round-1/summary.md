| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.590 | 8.590–8.590 |
| frame p95 | 8.630 | 8.630–8.630 |
| frame p99 | 17.350 | 17.350–17.350 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.570 | 8.570–8.570 |
| steady frame p99 | 8.680 | 8.680–8.680 |
| GPU frame commandBufferSpans | 4.076 | 4.076–4.076 |
| GPU frame envelope | 4.076 | 4.076–4.076 |
| GPU canvasClear | 0.107 | 0.107–0.107 |
| GPU computeLightVolume | 2.510 | 2.510–2.510 |
| GPU computeSunShadow | 0.292 | 0.292–0.292 |
| GPU computeVoxelAO | 0.032 | 0.032–0.032 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingToTrixel | 0.067 | 0.067–0.067 |
| GPU shapeCastBake | 1.256 | 1.256–1.256 |
| GPU shapeCastBoxes | 1.163 | 1.163–1.163 |
| GPU shapeCastClear | 0.034 | 0.034–0.034 |
| GPU shapeCastFallback | 0.035 | 0.035–0.035 |
| GPU shapeCastResolve | 0.047 | 0.047–0.047 |
| GPU shapeDepth | 0.143 | 0.143–0.143 |
| GPU shapeOwnerClear | 0.017 | 0.017–0.017 |
| GPU shapeOwnerElect | 0.146 | 0.146–0.146 |
| GPU shapePublish | 0.154 | 0.154–0.154 |
| GPU trixelToFb | 0.199 | 0.199–0.199 |
| GPU voxelCardinalElect | 0.099 | 0.099–0.099 |
| GPU voxelCompact | 0.067 | 0.067–0.067 |
| GPU voxelStage1 | 0.254 | 0.254–0.254 |
| GPU voxelStage2 | 0.108 | 0.108–0.108 |
| GPU voxelSunFaces | 0.126 | 0.126–0.126 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.333 | 8.571 | 8.677 | 8.694 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
