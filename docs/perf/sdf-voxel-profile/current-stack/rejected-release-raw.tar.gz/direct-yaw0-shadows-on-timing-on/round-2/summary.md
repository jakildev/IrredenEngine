| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.460 | 8.460–8.460 |
| frame p95 | 8.620 | 8.620–8.620 |
| frame p99 | 8.840 | 8.840–8.840 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.630 | 8.630–8.630 |
| steady frame p99 | 8.810 | 8.810–8.810 |
| GPU frame commandBufferSpans | 3.877 | 3.877–3.877 |
| GPU frame envelope | 3.877 | 3.877–3.877 |
| GPU canvasClear | 0.093 | 0.093–0.093 |
| GPU computeLightVolume | 2.457 | 2.457–2.457 |
| GPU computeSunShadow | 0.295 | 0.295–0.295 |
| GPU computeVoxelAO | 0.031 | 0.031–0.031 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingToTrixel | 0.066 | 0.066–0.066 |
| GPU shapeCastBake | 1.193 | 1.193–1.193 |
| GPU shapeCastBoxes | 1.102 | 1.102–1.102 |
| GPU shapeCastClear | 0.033 | 0.033–0.033 |
| GPU shapeCastFallback | 0.029 | 0.029–0.029 |
| GPU shapeCastResolve | 0.048 | 0.048–0.048 |
| GPU shapeDepth | 0.142 | 0.142–0.142 |
| GPU shapeOwnerClear | 0.018 | 0.018–0.018 |
| GPU shapeOwnerElect | 0.146 | 0.146–0.146 |
| GPU shapePublish | 0.155 | 0.155–0.155 |
| GPU trixelToFb | 0.169 | 0.169–0.169 |
| GPU voxelCardinalElect | 0.093 | 0.093–0.093 |
| GPU voxelCompact | 0.062 | 0.062–0.062 |
| GPU voxelStage1 | 0.214 | 0.214–0.214 |
| GPU voxelStage2 | 0.104 | 0.104–0.104 |
| GPU voxelSunFaces | 0.121 | 0.121–0.121 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.333 | 8.626 | 8.808 | 8.921 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
