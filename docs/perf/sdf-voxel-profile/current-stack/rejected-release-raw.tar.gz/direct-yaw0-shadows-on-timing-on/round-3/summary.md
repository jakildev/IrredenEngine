| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.650 | 8.650–8.650 |
| frame p95 | 8.630 | 8.630–8.630 |
| frame p99 | 18.390 | 18.390–18.390 |
| steady frame avg | 8.530 | 8.530–8.530 |
| steady frame p95 | 8.590 | 8.590–8.590 |
| steady frame p99 | 17.780 | 17.780–17.780 |
| GPU frame commandBufferSpans | 4.166 | 4.166–4.166 |
| GPU frame envelope | 4.166 | 4.166–4.166 |
| GPU canvasClear | 0.095 | 0.095–0.095 |
| GPU computeLightVolume | 2.625 | 2.625–2.625 |
| GPU computeSunShadow | 0.307 | 0.307–0.307 |
| GPU computeVoxelAO | 0.035 | 0.035–0.035 |
| GPU fbToScreen | 0.125 | 0.125–0.125 |
| GPU lightingToTrixel | 0.069 | 0.069–0.069 |
| GPU shapeCastBake | 1.277 | 1.277–1.277 |
| GPU shapeCastBoxes | 1.198 | 1.198–1.198 |
| GPU shapeCastClear | 0.033 | 0.033–0.033 |
| GPU shapeCastFallback | 0.033 | 0.033–0.033 |
| GPU shapeCastResolve | 0.048 | 0.048–0.048 |
| GPU shapeDepth | 0.152 | 0.152–0.152 |
| GPU shapeOwnerClear | 0.017 | 0.017–0.017 |
| GPU shapeOwnerElect | 0.154 | 0.154–0.154 |
| GPU shapePublish | 0.162 | 0.162–0.162 |
| GPU trixelToFb | 0.194 | 0.194–0.194 |
| GPU voxelCardinalElect | 0.107 | 0.107–0.107 |
| GPU voxelCompact | 0.063 | 0.063–0.063 |
| GPU voxelStage1 | 0.250 | 0.250–0.250 |
| GPU voxelStage2 | 0.117 | 0.117–0.117 |
| GPU voxelSunFaces | 0.130 | 0.130–0.130 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.535 | 8.595 | 17.776 | 18.394 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
