Steady samples exclude each report's warmup. The 60 Hz budget is 1000/60 ms; these are measured frames, not a throughput guarantee.

| Case | Runs | Steady p95 / p99 ms | Frames over 60 Hz budget | Overflow max entries / dropped |
|---|---:|---:|---:|---:|
| direct-yaw0-shadows-on-timing-on | 2 | 8.594 / 8.694 | 0 / 450 | 0 / 0 |
| baked-yaw0-shadows-on-timing-on | 2 | 8.645 / 8.737 | 4 / 450 | 0 / 0 |
| direct-yaw0-shadows-on-timing-off | 2 | 8.579 / 8.663 | 1 / 450 | 0 / 0 |
| baked-yaw0-shadows-on-timing-off | 2 | 8.611 / 8.739 | 1 / 450 | 0 / 0 |
| direct-yaw0-shadows-off-timing-on | 2 | 8.565 / 8.792 | 3 / 450 | 0 / 0 |
| baked-yaw0-shadows-off-timing-on | 2 | 8.605 / 8.707 | 0 / 450 | 0 / 0 |
| direct-yaw0-shadows-off-timing-off | 2 | 8.540 / 8.657 | 1 / 450 | 0 / 0 |
| baked-yaw0-shadows-off-timing-off | 2 | 8.609 / 8.691 | 1 / 450 | 0 / 0 |
| direct-yaw45-shadows-on-timing-on | 2 | 20.453 / 20.902 | 363 / 450 | 12 / 0 |
| baked-yaw45-shadows-on-timing-on | 2 | 19.708 / 20.181 | 180 / 450 | 403 / 0 |
| direct-yaw45-shadows-on-timing-off | 2 | 19.677 / 20.137 | 251 / 450 | 12 / 0 |
| baked-yaw45-shadows-on-timing-off | 2 | 18.742 / 19.640 | 61 / 450 | 403 / 0 |
| direct-yaw45-shadows-off-timing-on | 2 | 19.993 / 20.494 | 330 / 450 | 12 / 0 |
| baked-yaw45-shadows-off-timing-on | 2 | 17.922 / 19.047 | 29 / 450 | 403 / 0 |
| direct-yaw45-shadows-off-timing-off | 2 | 19.195 / 19.964 | 217 / 450 | 12 / 0 |
| baked-yaw45-shadows-off-timing-off | 2 | 18.842 / 19.498 | 207 / 450 | 403 / 0 |
