| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.530 | 8.530–8.530 |
| frame p95 | 8.560 | 8.560–8.560 |
| frame p99 | 17.910 | 17.910–17.910 |
| steady frame avg | 8.370 | 8.370–8.370 |
| steady frame p95 | 8.560 | 8.560–8.560 |
| steady frame p99 | 8.640 | 8.640–8.640 |
| GPU frame commandBufferSpans | 3.089 | 3.089–3.089 |
| GPU frame envelope | 3.089 | 3.089–3.089 |
| GPU canvasClear | 0.054 | 0.054–0.054 |
| GPU computeLightVolume | 1.890 | 1.890–1.890 |
| GPU computeSunShadow | 0.049 | 0.049–0.049 |
| GPU computeVoxelAO | 0.044 | 0.044–0.044 |
| GPU fbToScreen | 0.122 | 0.122–0.122 |
| GPU lightingToTrixel | 0.067 | 0.067–0.067 |
| GPU shapeDepth | 0.192 | 0.192–0.192 |
| GPU shapeOwnerClear | 0.014 | 0.014–0.014 |
| GPU shapeOwnerElect | 0.150 | 0.150–0.150 |
| GPU shapePublish | 0.161 | 0.161–0.161 |
| GPU trixelToFb | 0.190 | 0.190–0.190 |
| GPU voxelCardinalElect | 0.109 | 0.109–0.109 |
| GPU voxelCompact | 0.122 | 0.122–0.122 |
| GPU voxelStage1 | 0.191 | 0.191–0.191 |
| GPU voxelStage2 | 0.114 | 0.114–0.114 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.371 | 8.558 | 8.643 | 17.912 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
