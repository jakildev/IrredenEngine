| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.610 | 8.610–8.610 |
| frame p95 | 8.590 | 8.590–8.590 |
| frame p99 | 20.930 | 20.930–20.930 |
| steady frame avg | 8.440 | 8.440–8.440 |
| steady frame p95 | 8.580 | 8.580–8.580 |
| steady frame p99 | 9.060 | 9.060–9.060 |
| GPU frame commandBufferSpans | 3.047 | 3.047–3.047 |
| GPU frame envelope | 3.047 | 3.047–3.047 |
| GPU canvasClear | 0.051 | 0.051–0.051 |
| GPU computeLightVolume | 1.860 | 1.860–1.860 |
| GPU computeSunShadow | 0.047 | 0.047–0.047 |
| GPU computeVoxelAO | 0.043 | 0.043–0.043 |
| GPU fbToScreen | 0.123 | 0.123–0.123 |
| GPU lightingToTrixel | 0.067 | 0.067–0.067 |
| GPU shapeDepth | 0.194 | 0.194–0.194 |
| GPU shapeOwnerClear | 0.016 | 0.016–0.016 |
| GPU shapeOwnerElect | 0.148 | 0.148–0.148 |
| GPU shapePublish | 0.156 | 0.156–0.156 |
| GPU trixelToFb | 0.187 | 0.187–0.187 |
| GPU voxelCardinalElect | 0.109 | 0.109–0.109 |
| GPU voxelCompact | 0.109 | 0.109–0.109 |
| GPU voxelStage1 | 0.171 | 0.171–0.171 |
| GPU voxelStage2 | 0.119 | 0.119–0.119 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.435 | 8.578 | 9.063 | 20.934 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
