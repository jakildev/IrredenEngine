| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.510 | 8.510–8.510 |
| frame p95 | 8.600 | 8.600–8.600 |
| frame p99 | 8.900 | 8.900–8.900 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.560 | 8.560–8.560 |
| steady frame p99 | 8.690 | 8.690–8.690 |
| GPU frame commandBufferSpans | 3.055 | 3.055–3.055 |
| GPU frame envelope | 3.055 | 3.055–3.055 |
| GPU canvasClear | 0.056 | 0.056–0.056 |
| GPU computeLightVolume | 1.859 | 1.859–1.859 |
| GPU computeSunShadow | 0.052 | 0.052–0.052 |
| GPU computeVoxelAO | 0.045 | 0.045–0.045 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingToTrixel | 0.066 | 0.066–0.066 |
| GPU shapeDepth | 0.196 | 0.196–0.196 |
| GPU shapeOwnerClear | 0.015 | 0.015–0.015 |
| GPU shapeOwnerElect | 0.147 | 0.147–0.147 |
| GPU shapePublish | 0.156 | 0.156–0.156 |
| GPU trixelToFb | 0.186 | 0.186–0.186 |
| GPU voxelCardinalElect | 0.110 | 0.110–0.110 |
| GPU voxelCompact | 0.137 | 0.137–0.137 |
| GPU voxelStage1 | 0.182 | 0.182–0.182 |
| GPU voxelStage2 | 0.113 | 0.113–0.113 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.333 | 8.556 | 8.695 | 8.896 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
