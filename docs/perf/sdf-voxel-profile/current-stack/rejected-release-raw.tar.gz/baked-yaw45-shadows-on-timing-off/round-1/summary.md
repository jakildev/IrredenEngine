| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.270 | 9.270–9.270 |
| frame p95 | 18.290 | 18.290–18.290 |
| frame p99 | 19.570 | 19.570–19.570 |
| steady frame avg | 8.680 | 8.680–8.680 |
| steady frame p95 | 8.550 | 8.550–8.550 |
| steady frame p99 | 18.610 | 18.610–18.610 |
| GPU frame commandBufferSpans | 4.735 | 4.735–4.735 |
| GPU frame envelope | 4.735 | 4.735–4.735 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.681 | 8.546 | 18.607 | 19.566 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
