| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.060 | 15.060–15.060 |
| frame p95 | 20.430 | 20.430–20.430 |
| frame p99 | 21.500 | 21.500–21.500 |
| steady frame avg | 15.420 | 15.420–15.420 |
| steady frame p95 | 20.430 | 20.430–20.430 |
| steady frame p99 | 21.400 | 21.400–21.400 |
| GPU frame commandBufferSpans | 5.296 | 5.296–5.296 |
| GPU frame envelope | 5.296 | 5.296–5.296 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.416 | 20.431 | 21.399 | 21.497 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
