| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.040 | 11.040–11.040 |
| frame p95 | 19.490 | 19.490–19.490 |
| frame p99 | 20.800 | 20.800–20.800 |
| steady frame avg | 10.740 | 10.740–10.740 |
| steady frame p95 | 19.170 | 19.170–19.170 |
| steady frame p99 | 19.980 | 19.980–19.980 |
| GPU frame commandBufferSpans | 5.220 | 5.220–5.220 |
| GPU frame envelope | 5.220 | 5.220–5.220 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 10.736 | 19.173 | 19.980 | 20.704 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
