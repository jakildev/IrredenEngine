| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.630 | 8.630–8.630 |
| frame p95 | 8.430 | 8.430–8.430 |
| frame p99 | 17.520 | 17.520–17.520 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.420 | 8.420–8.420 |
| steady frame p99 | 8.500 | 8.500–8.500 |
| GPU frame commandBufferSpans | 4.983 | 4.983–4.983 |
| GPU frame envelope | 4.983 | 4.983–4.983 |
| GPU canvasClear | 0.063 | 0.063–0.063 |
| GPU computeLightVolume | 3.284 | 3.284–3.284 |
| GPU computeSunShadow | 0.092 | 0.092–0.092 |
| GPU computeVoxelAO | 0.045 | 0.045–0.045 |
| GPU computeVoxelAoPerAxis | 1.438 | 1.438–1.438 |
| GPU fbToScreen | 0.120 | 0.120–0.120 |
| GPU lightingOverflow | 2.766 | 2.766–2.766 |
| GPU lightingPerAxis | 0.104 | 0.104–0.104 |
| GPU lightingToTrixel | 0.042 | 0.042–0.042 |
| GPU perAxisCellCompact | 0.285 | 0.285–0.285 |
| GPU perAxisScatter | 0.173 | 0.173–0.173 |
| GPU resolvePerAxisScreenDepth | 1.681 | 1.681–1.681 |
| GPU trixelToFb | 0.235 | 0.235–0.235 |
| GPU voxelCompact | 0.139 | 0.139–0.139 |
| GPU voxelPerAxisFinalize | 0.266 | 0.266–0.266 |
| GPU voxelPerAxisOverflow | 0.353 | 0.353–0.353 |
| GPU voxelPerAxisStore | 1.386 | 1.386–1.386 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.332 | 8.424 | 8.499 | 8.636 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
