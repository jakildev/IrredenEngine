| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.120 | 12.120–12.120 |
| frame p95 | 20.330 | 20.330–20.330 |
| frame p99 | 22.820 | 22.820–22.820 |
| steady frame avg | 10.870 | 10.870–10.870 |
| steady frame p95 | 20.050 | 20.050–20.050 |
| steady frame p99 | 20.650 | 20.650–20.650 |
| GPU frame commandBufferSpans | 4.816 | 4.816–4.816 |
| GPU frame envelope | 4.816 | 4.816–4.816 |
| GPU canvasClear | 0.067 | 0.067–0.067 |
| GPU computeLightVolume | 3.117 | 3.117–3.117 |
| GPU computeSunShadow | 0.090 | 0.090–0.090 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU computeVoxelAoPerAxis | 1.365 | 1.365–1.365 |
| GPU fbToScreen | 0.113 | 0.113–0.113 |
| GPU lightingOverflow | 2.605 | 2.605–2.605 |
| GPU lightingPerAxis | 0.097 | 0.097–0.097 |
| GPU lightingToTrixel | 0.040 | 0.040–0.040 |
| GPU perAxisCellCompact | 0.266 | 0.266–0.266 |
| GPU perAxisScatter | 0.163 | 0.163–0.163 |
| GPU resolvePerAxisScreenDepth | 1.588 | 1.588–1.588 |
| GPU trixelToFb | 0.227 | 0.227–0.227 |
| GPU voxelCompact | 0.146 | 0.146–0.146 |
| GPU voxelPerAxisFinalize | 0.241 | 0.241–0.241 |
| GPU voxelPerAxisOverflow | 0.332 | 0.332–0.332 |
| GPU voxelPerAxisStore | 1.412 | 1.412–1.412 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 10.871 | 20.048 | 20.653 | 22.817 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
