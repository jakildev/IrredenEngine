| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.690 | 8.690–8.690 |
| frame p95 | 8.440 | 8.440–8.440 |
| frame p99 | 18.780 | 18.780–18.780 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.420 | 8.420–8.420 |
| steady frame p99 | 8.540 | 8.540–8.540 |
| GPU frame commandBufferSpans | 4.891 | 4.891–4.891 |
| GPU frame envelope | 4.891 | 4.891–4.891 |
| GPU canvasClear | 0.064 | 0.064–0.064 |
| GPU computeLightVolume | 3.221 | 3.221–3.221 |
| GPU computeSunShadow | 0.092 | 0.092–0.092 |
| GPU computeVoxelAO | 0.044 | 0.044–0.044 |
| GPU computeVoxelAoPerAxis | 1.396 | 1.396–1.396 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingOverflow | 2.715 | 2.715–2.715 |
| GPU lightingPerAxis | 0.104 | 0.104–0.104 |
| GPU lightingToTrixel | 0.042 | 0.042–0.042 |
| GPU perAxisCellCompact | 0.273 | 0.273–0.273 |
| GPU perAxisScatter | 0.174 | 0.174–0.174 |
| GPU resolvePerAxisScreenDepth | 1.634 | 1.634–1.634 |
| GPU trixelToFb | 0.255 | 0.255–0.255 |
| GPU voxelCompact | 0.131 | 0.131–0.131 |
| GPU voxelPerAxisFinalize | 0.257 | 0.257–0.257 |
| GPU voxelPerAxisOverflow | 0.353 | 0.353–0.353 |
| GPU voxelPerAxisStore | 1.349 | 1.349–1.349 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.334 | 8.418 | 8.543 | 8.579 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
