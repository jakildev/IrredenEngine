| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 17.180 | 17.180–17.180 |
| frame p95 | 20.700 | 20.700–20.700 |
| frame p99 | 23.730 | 23.730–23.730 |
| steady frame avg | 18.090 | 18.090–18.090 |
| steady frame p95 | 20.700 | 20.700–20.700 |
| steady frame p99 | 21.420 | 21.420–21.420 |
| GPU frame commandBufferSpans | 4.638 | 4.638–4.638 |
| GPU frame envelope | 4.638 | 4.638–4.638 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 18.091 | 20.701 | 21.418 | 24.867 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
