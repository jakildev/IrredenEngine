| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.270 | 15.270–15.270 |
| frame p95 | 19.250 | 19.250–19.250 |
| frame p99 | 20.770 | 20.770–20.770 |
| steady frame avg | 15.330 | 15.330–15.330 |
| steady frame p95 | 19.170 | 19.170–19.170 |
| steady frame p99 | 19.630 | 19.630–19.630 |
| GPU frame commandBufferSpans | 4.910 | 4.910–4.910 |
| GPU frame envelope | 4.910 | 4.910–4.910 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.335 | 19.172 | 19.626 | 20.765 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
