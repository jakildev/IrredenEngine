| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.950 | 11.950–11.950 |
| frame p95 | 19.040 | 19.040–19.040 |
| frame p99 | 20.300 | 20.300–20.300 |
| steady frame avg | 11.430 | 11.430–11.430 |
| steady frame p95 | 19.030 | 19.030–19.030 |
| steady frame p99 | 19.640 | 19.640–19.640 |
| GPU frame commandBufferSpans | 4.350 | 4.350–4.350 |
| GPU frame envelope | 4.350 | 4.350–4.350 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.432 | 19.028 | 19.640 | 21.855 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
