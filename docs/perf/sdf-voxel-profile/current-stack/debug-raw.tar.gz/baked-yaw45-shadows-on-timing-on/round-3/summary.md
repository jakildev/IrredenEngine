| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.780 | 12.780–12.780 |
| frame p95 | 20.710 | 20.710–20.710 |
| frame p99 | 21.570 | 21.570–21.570 |
| steady frame avg | 13.670 | 13.670–13.670 |
| steady frame p95 | 20.850 | 20.850–20.850 |
| steady frame p99 | 21.440 | 21.440–21.440 |
| GPU frame commandBufferSpans | 5.377 | 5.377–5.377 |
| GPU frame envelope | 5.377 | 5.377–5.377 |
| GPU canvasClear | 0.056 | 0.056–0.056 |
| GPU computeLightVolume | 3.479 | 3.479–3.479 |
| GPU computeSunShadow | 0.333 | 0.333–0.333 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU computeVoxelAoPerAxis | 1.161 | 1.161–1.161 |
| GPU fbToScreen | 0.118 | 0.118–0.118 |
| GPU lightingOverflow | 2.919 | 2.919–2.919 |
| GPU lightingPerAxis | 0.102 | 0.102–0.102 |
| GPU lightingToTrixel | 0.039 | 0.039–0.039 |
| GPU perAxisCellCompact | 0.291 | 0.291–0.291 |
| GPU perAxisScatter | 0.251 | 0.251–0.251 |
| GPU resolvePerAxisScreenDepth | 1.401 | 1.401–1.401 |
| GPU trixelToFb | 0.282 | 0.282–0.282 |
| GPU voxelCompact | 0.075 | 0.075–0.075 |
| GPU voxelPerAxisFinalize | 0.256 | 0.256–0.256 |
| GPU voxelPerAxisOverflow | 0.418 | 0.418–0.418 |
| GPU voxelPerAxisStore | 1.266 | 1.266–1.266 |
| GPU voxelSunFaces | 0.217 | 0.217–0.217 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 13.670 | 20.850 | 21.436 | 21.602 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
