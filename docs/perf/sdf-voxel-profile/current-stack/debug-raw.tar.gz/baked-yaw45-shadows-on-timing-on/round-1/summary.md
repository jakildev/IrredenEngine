| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.260 | 15.260–15.260 |
| frame p95 | 20.020 | 20.020–20.020 |
| frame p99 | 22.440 | 22.440–22.440 |
| steady frame avg | 15.770 | 15.770–15.770 |
| steady frame p95 | 20.020 | 20.020–20.020 |
| steady frame p99 | 20.450 | 20.450–20.450 |
| GPU frame commandBufferSpans | 5.289 | 5.289–5.289 |
| GPU frame envelope | 5.289 | 5.289–5.289 |
| GPU canvasClear | 0.054 | 0.054–0.054 |
| GPU computeLightVolume | 3.292 | 3.292–3.292 |
| GPU computeSunShadow | 0.318 | 0.318–0.318 |
| GPU computeVoxelAO | 0.041 | 0.041–0.041 |
| GPU computeVoxelAoPerAxis | 1.157 | 1.157–1.157 |
| GPU fbToScreen | 0.112 | 0.112–0.112 |
| GPU lightingOverflow | 2.820 | 2.820–2.820 |
| GPU lightingPerAxis | 0.098 | 0.098–0.098 |
| GPU lightingToTrixel | 0.038 | 0.038–0.038 |
| GPU perAxisCellCompact | 0.284 | 0.284–0.284 |
| GPU perAxisScatter | 0.244 | 0.244–0.244 |
| GPU resolvePerAxisScreenDepth | 1.384 | 1.384–1.384 |
| GPU trixelToFb | 0.250 | 0.250–0.250 |
| GPU voxelCompact | 0.084 | 0.084–0.084 |
| GPU voxelPerAxisFinalize | 0.247 | 0.247–0.247 |
| GPU voxelPerAxisOverflow | 0.397 | 0.397–0.397 |
| GPU voxelPerAxisStore | 1.242 | 1.242–1.242 |
| GPU voxelSunFaces | 0.208 | 0.208–0.208 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.773 | 20.023 | 20.445 | 22.444 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
