| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.080 | 9.080–9.080 |
| frame p95 | 17.360 | 17.360–17.360 |
| frame p99 | 20.750 | 20.750–20.750 |
| steady frame avg | 8.910 | 8.910–8.910 |
| steady frame p95 | 17.360 | 17.360–17.360 |
| steady frame p99 | 17.790 | 17.790–17.790 |
| GPU frame commandBufferSpans | 5.055 | 5.055–5.055 |
| GPU frame envelope | 5.055 | 5.055–5.055 |
| GPU canvasClear | 0.052 | 0.052–0.052 |
| GPU computeLightVolume | 3.313 | 3.313–3.313 |
| GPU computeSunShadow | 0.312 | 0.312–0.312 |
| GPU computeVoxelAO | 0.039 | 0.039–0.039 |
| GPU computeVoxelAoPerAxis | 1.103 | 1.103–1.103 |
| GPU fbToScreen | 0.111 | 0.111–0.111 |
| GPU lightingOverflow | 2.750 | 2.750–2.750 |
| GPU lightingPerAxis | 0.095 | 0.095–0.095 |
| GPU lightingToTrixel | 0.037 | 0.037–0.037 |
| GPU perAxisCellCompact | 0.278 | 0.278–0.278 |
| GPU perAxisScatter | 0.238 | 0.238–0.238 |
| GPU resolvePerAxisScreenDepth | 1.322 | 1.322–1.322 |
| GPU trixelToFb | 0.294 | 0.294–0.294 |
| GPU voxelCompact | 0.072 | 0.072–0.072 |
| GPU voxelPerAxisFinalize | 0.241 | 0.241–0.241 |
| GPU voxelPerAxisOverflow | 0.398 | 0.398–0.398 |
| GPU voxelPerAxisStore | 1.187 | 1.187–1.187 |
| GPU voxelSunFaces | 0.203 | 0.203–0.203 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.911 | 17.356 | 17.787 | 20.749 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
