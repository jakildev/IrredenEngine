| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.210 | 9.210–9.210 |
| frame p95 | 17.930 | 17.930–17.930 |
| frame p99 | 23.440 | 23.440–23.440 |
| steady frame avg | 9.220 | 9.220–9.220 |
| steady frame p95 | 17.990 | 17.990–17.990 |
| steady frame p99 | 22.090 | 22.090–22.090 |
| GPU frame commandBufferSpans | 3.354 | 3.354–3.354 |
| GPU frame envelope | 3.354 | 3.354–3.354 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 9.222 | 17.995 | 22.090 | 23.437 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
