| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.170 | 9.170–9.170 |
| frame p95 | 17.750 | 17.750–17.750 |
| frame p99 | 22.570 | 22.570–22.570 |
| steady frame avg | 9.010 | 9.010–9.010 |
| steady frame p95 | 17.360 | 17.360–17.360 |
| steady frame p99 | 18.310 | 18.310–18.310 |
| GPU frame commandBufferSpans | 3.179 | 3.179–3.179 |
| GPU frame envelope | 3.179 | 3.179–3.179 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 9.008 | 17.364 | 18.309 | 22.566 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
