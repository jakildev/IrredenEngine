| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.500 | 8.500–8.500 |
| frame p95 | 8.700 | 8.700–8.700 |
| frame p99 | 19.150 | 19.150–19.150 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.680 | 8.680–8.680 |
| steady frame p99 | 8.830 | 8.830–8.830 |
| GPU frame commandBufferSpans | 3.267 | 3.267–3.267 |
| GPU frame envelope | 3.267 | 3.267–3.267 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.380 | 8.683 | 8.828 | 19.154 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
