| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.190 | 16.190–16.190 |
| frame p95 | 20.350 | 20.350–20.350 |
| frame p99 | 21.240 | 21.240–21.240 |
| steady frame avg | 17.300 | 17.300–17.300 |
| steady frame p95 | 20.400 | 20.400–20.400 |
| steady frame p99 | 21.090 | 21.090–21.090 |
| GPU frame commandBufferSpans | 5.636 | 5.636–5.636 |
| GPU frame envelope | 5.636 | 5.636–5.636 |
| GPU canvasClear | 0.063 | 0.063–0.063 |
| GPU computeLightVolume | 3.903 | 3.903–3.903 |
| GPU computeSunShadow | 0.098 | 0.098–0.098 |
| GPU computeVoxelAO | 0.048 | 0.048–0.048 |
| GPU computeVoxelAoPerAxis | 2.239 | 2.239–2.239 |
| GPU fbToScreen | 0.115 | 0.115–0.115 |
| GPU lightingOverflow | 3.378 | 3.378–3.378 |
| GPU lightingPerAxis | 0.105 | 0.105–0.105 |
| GPU lightingToTrixel | 0.049 | 0.049–0.049 |
| GPU perAxisCellCompact | 0.278 | 0.278–0.278 |
| GPU perAxisScatter | 0.153 | 0.153–0.153 |
| GPU resolvePerAxisScreenDepth | 2.399 | 2.399–2.399 |
| GPU shapeDepth | 0.278 | 0.278–0.278 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.273 | 0.273–0.273 |
| GPU shapePublish | 0.275 | 0.275–0.275 |
| GPU trixelToFb | 0.207 | 0.207–0.207 |
| GPU voxelCompact | 0.136 | 0.136–0.136 |
| GPU voxelPerAxisFinalize | 0.250 | 0.250–0.250 |
| GPU voxelPerAxisOverflow | 0.340 | 0.340–0.340 |
| GPU voxelPerAxisStore | 1.429 | 1.429–1.429 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 17.297 | 20.397 | 21.090 | 21.331 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
