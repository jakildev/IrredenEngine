| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 18.200 | 18.200–18.200 |
| frame p95 | 21.600 | 21.600–21.600 |
| frame p99 | 22.380 | 22.380–22.380 |
| steady frame avg | 17.360 | 17.360–17.360 |
| steady frame p95 | 21.600 | 21.600–21.600 |
| steady frame p99 | 22.160 | 22.160–22.160 |
| GPU frame commandBufferSpans | 5.683 | 5.683–5.683 |
| GPU frame envelope | 5.683 | 5.683–5.683 |
| GPU canvasClear | 0.067 | 0.067–0.067 |
| GPU computeLightVolume | 4.001 | 4.001–4.001 |
| GPU computeSunShadow | 0.102 | 0.102–0.102 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU computeVoxelAoPerAxis | 2.248 | 2.248–2.248 |
| GPU fbToScreen | 0.120 | 0.120–0.120 |
| GPU lightingOverflow | 3.503 | 3.503–3.503 |
| GPU lightingPerAxis | 0.107 | 0.107–0.107 |
| GPU lightingToTrixel | 0.051 | 0.051–0.051 |
| GPU perAxisCellCompact | 0.267 | 0.267–0.267 |
| GPU perAxisScatter | 0.159 | 0.159–0.159 |
| GPU resolvePerAxisScreenDepth | 2.420 | 2.420–2.420 |
| GPU shapeDepth | 0.289 | 0.289–0.289 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.286 | 0.286–0.286 |
| GPU shapePublish | 0.289 | 0.289–0.289 |
| GPU trixelToFb | 0.206 | 0.206–0.206 |
| GPU voxelCompact | 0.116 | 0.116–0.116 |
| GPU voxelPerAxisFinalize | 0.252 | 0.252–0.252 |
| GPU voxelPerAxisOverflow | 0.349 | 0.349–0.349 |
| GPU voxelPerAxisStore | 1.366 | 1.366–1.366 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 17.361 | 21.598 | 22.157 | 22.376 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
