| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 10.330 | 10.330–10.330 |
| frame p95 | 19.600 | 19.600–19.600 |
| frame p99 | 20.480 | 20.480–20.480 |
| steady frame avg | 10.310 | 10.310–10.310 |
| steady frame p95 | 19.600 | 19.600–19.600 |
| steady frame p99 | 20.240 | 20.240–20.240 |
| GPU frame commandBufferSpans | 5.703 | 5.703–5.703 |
| GPU frame envelope | 5.703 | 5.703–5.703 |
| GPU canvasClear | 0.068 | 0.068–0.068 |
| GPU computeLightVolume | 3.999 | 3.999–3.999 |
| GPU computeSunShadow | 0.103 | 0.103–0.103 |
| GPU computeVoxelAO | 0.041 | 0.041–0.041 |
| GPU computeVoxelAoPerAxis | 2.233 | 2.233–2.233 |
| GPU fbToScreen | 0.120 | 0.120–0.120 |
| GPU lightingOverflow | 3.523 | 3.523–3.523 |
| GPU lightingPerAxis | 0.108 | 0.108–0.108 |
| GPU lightingToTrixel | 0.052 | 0.052–0.052 |
| GPU perAxisCellCompact | 0.263 | 0.263–0.263 |
| GPU perAxisScatter | 0.159 | 0.159–0.159 |
| GPU resolvePerAxisScreenDepth | 2.403 | 2.403–2.403 |
| GPU shapeDepth | 0.292 | 0.292–0.292 |
| GPU shapeOwnerClear | 0.018 | 0.018–0.018 |
| GPU shapeOwnerElect | 0.286 | 0.286–0.286 |
| GPU shapePublish | 0.291 | 0.291–0.291 |
| GPU trixelToFb | 0.223 | 0.223–0.223 |
| GPU voxelCompact | 0.097 | 0.097–0.097 |
| GPU voxelPerAxisFinalize | 0.253 | 0.253–0.253 |
| GPU voxelPerAxisOverflow | 0.350 | 0.350–0.350 |
| GPU voxelPerAxisStore | 1.287 | 1.287–1.287 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 10.307 | 19.596 | 20.237 | 20.480 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
