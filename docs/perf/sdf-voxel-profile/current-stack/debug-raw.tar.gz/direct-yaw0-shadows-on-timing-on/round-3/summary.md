| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.650 | 9.650–9.650 |
| frame p95 | 18.290 | 18.290–18.290 |
| frame p99 | 19.760 | 19.760–19.760 |
| steady frame avg | 9.830 | 9.830–9.830 |
| steady frame p95 | 18.290 | 18.290–18.290 |
| steady frame p99 | 18.780 | 18.780–18.780 |
| GPU frame commandBufferSpans | 4.073 | 4.073–4.073 |
| GPU frame envelope | 4.073 | 4.073–4.073 |
| GPU canvasClear | 0.098 | 0.098–0.098 |
| GPU computeLightVolume | 2.534 | 2.534–2.534 |
| GPU computeSunShadow | 0.296 | 0.296–0.296 |
| GPU computeVoxelAO | 0.033 | 0.033–0.033 |
| GPU fbToScreen | 0.121 | 0.121–0.121 |
| GPU lightingToTrixel | 0.069 | 0.069–0.069 |
| GPU shapeCastBake | 1.241 | 1.241–1.241 |
| GPU shapeCastBoxes | 1.165 | 1.165–1.165 |
| GPU shapeCastClear | 0.036 | 0.036–0.036 |
| GPU shapeCastFallback | 0.034 | 0.034–0.034 |
| GPU shapeCastResolve | 0.051 | 0.051–0.051 |
| GPU shapeDepth | 0.149 | 0.149–0.149 |
| GPU shapeOwnerClear | 0.017 | 0.017–0.017 |
| GPU shapeOwnerElect | 0.150 | 0.150–0.150 |
| GPU shapePublish | 0.157 | 0.157–0.157 |
| GPU trixelToFb | 0.179 | 0.179–0.179 |
| GPU voxelCardinalElect | 0.100 | 0.100–0.100 |
| GPU voxelCompact | 0.065 | 0.065–0.065 |
| GPU voxelStage1 | 0.244 | 0.244–0.244 |
| GPU voxelStage2 | 0.110 | 0.110–0.110 |
| GPU voxelSunFaces | 0.124 | 0.124–0.124 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 9.834 | 18.286 | 18.780 | 19.667 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
