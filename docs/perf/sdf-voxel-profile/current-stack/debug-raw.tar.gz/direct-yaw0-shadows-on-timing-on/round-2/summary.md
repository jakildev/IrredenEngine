| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.920 | 9.920–9.920 |
| frame p95 | 18.450 | 18.450–18.450 |
| frame p99 | 18.780 | 18.780–18.780 |
| steady frame avg | 9.580 | 9.580–9.580 |
| steady frame p95 | 18.390 | 18.390–18.390 |
| steady frame p99 | 18.710 | 18.710–18.710 |
| GPU frame commandBufferSpans | 4.072 | 4.072–4.072 |
| GPU frame envelope | 4.072 | 4.072–4.072 |
| GPU canvasClear | 0.091 | 0.091–0.091 |
| GPU computeLightVolume | 2.576 | 2.576–2.576 |
| GPU computeSunShadow | 0.306 | 0.306–0.306 |
| GPU computeVoxelAO | 0.034 | 0.034–0.034 |
| GPU fbToScreen | 0.124 | 0.124–0.124 |
| GPU lightingToTrixel | 0.068 | 0.068–0.068 |
| GPU shapeCastBake | 1.238 | 1.238–1.238 |
| GPU shapeCastBoxes | 1.165 | 1.165–1.165 |
| GPU shapeCastClear | 0.038 | 0.038–0.038 |
| GPU shapeCastFallback | 0.032 | 0.032–0.032 |
| GPU shapeCastResolve | 0.048 | 0.048–0.048 |
| GPU shapeDepth | 0.157 | 0.157–0.157 |
| GPU shapeOwnerClear | 0.018 | 0.018–0.018 |
| GPU shapeOwnerElect | 0.156 | 0.156–0.156 |
| GPU shapePublish | 0.161 | 0.161–0.161 |
| GPU trixelToFb | 0.187 | 0.187–0.187 |
| GPU voxelCardinalElect | 0.101 | 0.101–0.101 |
| GPU voxelCompact | 0.061 | 0.061–0.061 |
| GPU voxelStage1 | 0.225 | 0.225–0.225 |
| GPU voxelStage2 | 0.112 | 0.112–0.112 |
| GPU voxelSunFaces | 0.126 | 0.126–0.126 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 9.577 | 18.391 | 18.709 | 19.120 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
