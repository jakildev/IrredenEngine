| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.790 | 8.790–8.790 |
| frame p95 | 8.650 | 8.650–8.650 |
| frame p99 | 20.100 | 20.100–20.100 |
| steady frame avg | 8.490 | 8.490–8.490 |
| steady frame p95 | 8.650 | 8.650–8.650 |
| steady frame p99 | 17.330 | 17.330–17.330 |
| GPU frame commandBufferSpans | 4.226 | 4.226–4.226 |
| GPU frame envelope | 4.226 | 4.226–4.226 |
| GPU canvasClear | 0.103 | 0.103–0.103 |
| GPU computeLightVolume | 2.587 | 2.587–2.587 |
| GPU computeSunShadow | 0.297 | 0.297–0.297 |
| GPU computeVoxelAO | 0.033 | 0.033–0.033 |
| GPU fbToScreen | 0.126 | 0.126–0.126 |
| GPU lightingToTrixel | 0.070 | 0.070–0.070 |
| GPU shapeCastBake | 1.264 | 1.264–1.264 |
| GPU shapeCastBoxes | 1.185 | 1.185–1.185 |
| GPU shapeCastClear | 0.032 | 0.032–0.032 |
| GPU shapeCastFallback | 0.036 | 0.036–0.036 |
| GPU shapeCastResolve | 0.047 | 0.047–0.047 |
| GPU shapeDepth | 0.145 | 0.145–0.145 |
| GPU shapeOwnerClear | 0.016 | 0.016–0.016 |
| GPU shapeOwnerElect | 0.147 | 0.147–0.147 |
| GPU shapePublish | 0.156 | 0.156–0.156 |
| GPU trixelToFb | 0.202 | 0.202–0.202 |
| GPU voxelCardinalElect | 0.100 | 0.100–0.100 |
| GPU voxelCompact | 0.067 | 0.067–0.067 |
| GPU voxelStage1 | 0.267 | 0.267–0.267 |
| GPU voxelStage2 | 0.109 | 0.109–0.109 |
| GPU voxelSunFaces | 0.125 | 0.125–0.125 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.489 | 8.652 | 17.326 | 17.790 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
