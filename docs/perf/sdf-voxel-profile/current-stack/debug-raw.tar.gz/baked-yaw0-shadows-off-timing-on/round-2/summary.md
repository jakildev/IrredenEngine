| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.520 | 8.520–8.520 |
| frame p95 | 8.630 | 8.630–8.630 |
| frame p99 | 8.780 | 8.780–8.780 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.620 | 8.620–8.620 |
| steady frame p99 | 8.660 | 8.660–8.660 |
| GPU frame commandBufferSpans | 2.724 | 2.724–2.724 |
| GPU frame envelope | 2.724 | 2.724–2.724 |
| GPU canvasClear | 0.056 | 0.056–0.056 |
| GPU computeLightVolume | 1.510 | 1.510–1.510 |
| GPU computeSunShadow | 0.031 | 0.031–0.031 |
| GPU computeVoxelAO | 0.135 | 0.135–0.135 |
| GPU fbToScreen | 0.122 | 0.122–0.122 |
| GPU lightingToTrixel | 0.059 | 0.059–0.059 |
| GPU trixelToFb | 0.179 | 0.179–0.179 |
| GPU voxelCardinalElect | 0.110 | 0.110–0.110 |
| GPU voxelCompact | 0.109 | 0.109–0.109 |
| GPU voxelStage1 | 0.203 | 0.203–0.203 |
| GPU voxelStage2 | 0.125 | 0.125–0.125 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.330 | 8.624 | 8.663 | 8.779 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
