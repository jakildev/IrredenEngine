| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.490 | 8.490–8.490 |
| frame p95 | 8.600 | 8.600–8.600 |
| frame p99 | 19.580 | 19.580–19.580 |
| steady frame avg | 8.430 | 8.430–8.430 |
| steady frame p95 | 8.600 | 8.600–8.600 |
| steady frame p99 | 8.760 | 8.760–8.760 |
| GPU frame commandBufferSpans | 2.715 | 2.715–2.715 |
| GPU frame envelope | 2.715 | 2.715–2.715 |
| GPU canvasClear | 0.058 | 0.058–0.058 |
| GPU computeLightVolume | 1.515 | 1.515–1.515 |
| GPU computeSunShadow | 0.033 | 0.033–0.033 |
| GPU computeVoxelAO | 0.153 | 0.153–0.153 |
| GPU fbToScreen | 0.121 | 0.121–0.121 |
| GPU lightingToTrixel | 0.061 | 0.061–0.061 |
| GPU trixelToFb | 0.217 | 0.217–0.217 |
| GPU voxelCardinalElect | 0.114 | 0.114–0.114 |
| GPU voxelCompact | 0.143 | 0.143–0.143 |
| GPU voxelStage1 | 0.208 | 0.208–0.208 |
| GPU voxelStage2 | 0.121 | 0.121–0.121 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.427 | 8.603 | 8.762 | 20.030 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
