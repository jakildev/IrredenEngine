| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.860 | 8.860–8.860 |
| frame p95 | 9.180 | 9.180–9.180 |
| frame p99 | 19.110 | 19.110–19.110 |
| steady frame avg | 8.790 | 8.790–8.790 |
| steady frame p95 | 9.180 | 9.180–9.180 |
| steady frame p99 | 18.680 | 18.680–18.680 |
| GPU frame commandBufferSpans | 3.888 | 3.888–3.888 |
| GPU frame envelope | 3.888 | 3.888–3.888 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.789 | 9.183 | 18.677 | 19.110 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
