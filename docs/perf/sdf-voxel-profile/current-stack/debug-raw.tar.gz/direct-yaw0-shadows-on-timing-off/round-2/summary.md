| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.780 | 9.780–9.780 |
| frame p95 | 17.910 | 17.910–17.910 |
| frame p99 | 19.720 | 19.720–19.720 |
| steady frame avg | 9.980 | 9.980–9.980 |
| steady frame p95 | 17.990 | 17.990–17.990 |
| steady frame p99 | 18.900 | 18.900–18.900 |
| GPU frame commandBufferSpans | 4.112 | 4.112–4.112 |
| GPU frame envelope | 4.112 | 4.112–4.112 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 9.977 | 17.986 | 18.898 | 20.159 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
