| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.550 | 8.550–8.550 |
| frame p95 | 8.600 | 8.600–8.600 |
| frame p99 | 21.320 | 21.320–21.320 |
| steady frame avg | 8.390 | 8.390–8.390 |
| steady frame p95 | 8.550 | 8.550–8.550 |
| steady frame p99 | 8.720 | 8.720–8.720 |
| GPU frame commandBufferSpans | 3.872 | 3.872–3.872 |
| GPU frame envelope | 3.872 | 3.872–3.872 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.387 | 8.554 | 8.723 | 21.318 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
