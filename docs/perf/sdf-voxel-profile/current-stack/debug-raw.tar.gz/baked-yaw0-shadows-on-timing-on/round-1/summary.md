| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.540 | 8.540–8.540 |
| frame p95 | 8.660 | 8.660–8.660 |
| frame p99 | 20.060 | 20.060–20.060 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.640 | 8.640–8.640 |
| steady frame p99 | 8.810 | 8.810–8.810 |
| GPU frame commandBufferSpans | 3.382 | 3.382–3.382 |
| GPU frame envelope | 3.382 | 3.382–3.382 |
| GPU canvasClear | 0.047 | 0.047–0.047 |
| GPU computeLightVolume | 2.074 | 2.074–2.074 |
| GPU computeSunShadow | 0.306 | 0.306–0.306 |
| GPU computeVoxelAO | 0.034 | 0.034–0.034 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingToTrixel | 0.061 | 0.061–0.061 |
| GPU trixelToFb | 0.208 | 0.208–0.208 |
| GPU voxelCardinalElect | 0.101 | 0.101–0.101 |
| GPU voxelCompact | 0.067 | 0.067–0.067 |
| GPU voxelStage1 | 0.155 | 0.155–0.155 |
| GPU voxelStage2 | 0.115 | 0.115–0.115 |
| GPU voxelSunFaces | 0.130 | 0.130–0.130 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.381 | 8.645 | 8.811 | 20.063 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
