| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.570 | 9.570–9.570 |
| frame p95 | 17.820 | 17.820–17.820 |
| frame p99 | 22.440 | 22.440–22.440 |
| steady frame avg | 9.250 | 9.250–9.250 |
| steady frame p95 | 17.790 | 17.790–17.790 |
| steady frame p99 | 18.160 | 18.160–18.160 |
| GPU frame commandBufferSpans | 3.491 | 3.491–3.491 |
| GPU frame envelope | 3.491 | 3.491–3.491 |
| GPU canvasClear | 0.050 | 0.050–0.050 |
| GPU computeLightVolume | 2.120 | 2.120–2.120 |
| GPU computeSunShadow | 0.310 | 0.310–0.310 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU fbToScreen | 0.123 | 0.123–0.123 |
| GPU lightingToTrixel | 0.062 | 0.062–0.062 |
| GPU trixelToFb | 0.201 | 0.201–0.201 |
| GPU voxelCardinalElect | 0.110 | 0.110–0.110 |
| GPU voxelCompact | 0.065 | 0.065–0.065 |
| GPU voxelStage1 | 0.166 | 0.166–0.166 |
| GPU voxelStage2 | 0.126 | 0.126–0.126 |
| GPU voxelSunFaces | 0.130 | 0.130–0.130 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 9.248 | 17.794 | 18.161 | 22.436 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
