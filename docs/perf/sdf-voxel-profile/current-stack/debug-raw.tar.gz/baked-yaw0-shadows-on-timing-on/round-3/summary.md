| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.540 | 8.540–8.540 |
| frame p95 | 9.070 | 9.070–9.070 |
| frame p99 | 17.970 | 17.970–17.970 |
| steady frame avg | 8.490 | 8.490–8.490 |
| steady frame p95 | 9.100 | 9.100–9.100 |
| steady frame p99 | 17.620 | 17.620–17.620 |
| GPU frame commandBufferSpans | 3.494 | 3.494–3.494 |
| GPU frame envelope | 3.494 | 3.494–3.494 |
| GPU canvasClear | 0.052 | 0.052–0.052 |
| GPU computeLightVolume | 2.138 | 2.138–2.138 |
| GPU computeSunShadow | 0.317 | 0.317–0.317 |
| GPU computeVoxelAO | 0.035 | 0.035–0.035 |
| GPU fbToScreen | 0.126 | 0.126–0.126 |
| GPU lightingToTrixel | 0.063 | 0.063–0.063 |
| GPU trixelToFb | 0.210 | 0.210–0.210 |
| GPU voxelCardinalElect | 0.110 | 0.110–0.110 |
| GPU voxelCompact | 0.068 | 0.068–0.068 |
| GPU voxelStage1 | 0.162 | 0.162–0.162 |
| GPU voxelStage2 | 0.122 | 0.122–0.122 |
| GPU voxelSunFaces | 0.133 | 0.133–0.133 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.494 | 9.096 | 17.615 | 18.798 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
