| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.590 | 8.590–8.590 |
| frame p95 | 8.570 | 8.570–8.570 |
| frame p99 | 16.340 | 16.340–16.340 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.550 | 8.550–8.550 |
| steady frame p99 | 8.650 | 8.650–8.650 |
| GPU frame commandBufferSpans | 3.135 | 3.135–3.135 |
| GPU frame envelope | 3.135 | 3.135–3.135 |
| GPU canvasClear | 0.054 | 0.054–0.054 |
| GPU computeLightVolume | 1.840 | 1.840–1.840 |
| GPU computeSunShadow | 0.047 | 0.047–0.047 |
| GPU computeVoxelAO | 0.046 | 0.046–0.046 |
| GPU fbToScreen | 0.117 | 0.117–0.117 |
| GPU lightingToTrixel | 0.066 | 0.066–0.066 |
| GPU shapeDepth | 0.194 | 0.194–0.194 |
| GPU shapeOwnerClear | 0.014 | 0.014–0.014 |
| GPU shapeOwnerElect | 0.145 | 0.145–0.145 |
| GPU shapePublish | 0.153 | 0.153–0.153 |
| GPU trixelToFb | 0.183 | 0.183–0.183 |
| GPU voxelCardinalElect | 0.110 | 0.110–0.110 |
| GPU voxelCompact | 0.136 | 0.136–0.136 |
| GPU voxelStage1 | 0.187 | 0.187–0.187 |
| GPU voxelStage2 | 0.111 | 0.111–0.111 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.333 | 8.552 | 8.652 | 8.723 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
