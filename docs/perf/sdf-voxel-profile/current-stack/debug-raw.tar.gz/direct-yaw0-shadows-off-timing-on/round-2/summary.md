| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.520 | 8.520–8.520 |
| frame p95 | 8.800 | 8.800–8.800 |
| frame p99 | 18.070 | 18.070–18.070 |
| steady frame avg | 8.370 | 8.370–8.370 |
| steady frame p95 | 8.790 | 8.790–8.790 |
| steady frame p99 | 9.040 | 9.040–9.040 |
| GPU frame commandBufferSpans | 3.143 | 3.143–3.143 |
| GPU frame envelope | 3.143 | 3.143–3.143 |
| GPU canvasClear | 0.062 | 0.062–0.062 |
| GPU computeLightVolume | 1.915 | 1.915–1.915 |
| GPU computeSunShadow | 0.050 | 0.050–0.050 |
| GPU computeVoxelAO | 0.046 | 0.046–0.046 |
| GPU fbToScreen | 0.123 | 0.123–0.123 |
| GPU lightingToTrixel | 0.068 | 0.068–0.068 |
| GPU shapeDepth | 0.200 | 0.200–0.200 |
| GPU shapeOwnerClear | 0.016 | 0.016–0.016 |
| GPU shapeOwnerElect | 0.152 | 0.152–0.152 |
| GPU shapePublish | 0.162 | 0.162–0.162 |
| GPU trixelToFb | 0.194 | 0.194–0.194 |
| GPU voxelCardinalElect | 0.118 | 0.118–0.118 |
| GPU voxelCompact | 0.124 | 0.124–0.124 |
| GPU voxelStage1 | 0.199 | 0.199–0.199 |
| GPU voxelStage2 | 0.118 | 0.118–0.118 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.373 | 8.794 | 9.044 | 18.071 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
