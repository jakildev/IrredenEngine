| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.410 | 8.410–8.410 |
| frame p95 | 8.780 | 8.780–8.780 |
| frame p99 | 9.110 | 9.110–9.110 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.780 | 8.780–8.780 |
| steady frame p99 | 8.980 | 8.980–8.980 |
| GPU frame commandBufferSpans | 3.068 | 3.068–3.068 |
| GPU frame envelope | 3.068 | 3.068–3.068 |
| GPU canvasClear | 0.055 | 0.055–0.055 |
| GPU computeLightVolume | 1.866 | 1.866–1.866 |
| GPU computeSunShadow | 0.053 | 0.053–0.053 |
| GPU computeVoxelAO | 0.046 | 0.046–0.046 |
| GPU fbToScreen | 0.120 | 0.120–0.120 |
| GPU lightingToTrixel | 0.067 | 0.067–0.067 |
| GPU shapeDepth | 0.192 | 0.192–0.192 |
| GPU shapeOwnerClear | 0.014 | 0.014–0.014 |
| GPU shapeOwnerElect | 0.148 | 0.148–0.148 |
| GPU shapePublish | 0.157 | 0.157–0.157 |
| GPU trixelToFb | 0.202 | 0.202–0.202 |
| GPU voxelCardinalElect | 0.107 | 0.107–0.107 |
| GPU voxelCompact | 0.137 | 0.137–0.137 |
| GPU voxelStage1 | 0.193 | 0.193–0.193 |
| GPU voxelStage2 | 0.111 | 0.111–0.111 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.334 | 8.784 | 8.977 | 9.293 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
