| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.780 | 19.780–19.780 |
| frame p95 | 21.170 | 21.170–21.170 |
| frame p99 | 25.650 | 25.650–25.650 |
| steady frame avg | 19.610 | 19.610–19.610 |
| steady frame p95 | 21.120 | 21.120–21.120 |
| steady frame p99 | 21.450 | 21.450–21.450 |
| GPU frame commandBufferSpans | 5.935 | 5.935–5.935 |
| GPU frame envelope | 5.935 | 5.935–5.935 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 19.610 | 21.118 | 21.450 | 22.548 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
