| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.530 | 15.530–15.530 |
| frame p95 | 19.950 | 19.950–19.950 |
| frame p99 | 21.300 | 21.300–21.300 |
| steady frame avg | 15.440 | 15.440–15.440 |
| steady frame p95 | 19.940 | 19.940–19.940 |
| steady frame p99 | 20.550 | 20.550–20.550 |
| GPU frame commandBufferSpans | 5.615 | 5.615–5.615 |
| GPU frame envelope | 5.615 | 5.615–5.615 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.443 | 19.942 | 20.550 | 21.305 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
