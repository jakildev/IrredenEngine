| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.150 | 11.150–11.150 |
| frame p95 | 19.590 | 19.590–19.590 |
| frame p99 | 20.420 | 20.420–20.420 |
| steady frame avg | 11.460 | 11.460–11.460 |
| steady frame p95 | 19.590 | 19.590–19.590 |
| steady frame p99 | 20.030 | 20.030–20.030 |
| GPU frame commandBufferSpans | 5.574 | 5.574–5.574 |
| GPU frame envelope | 5.574 | 5.574–5.574 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.465 | 19.592 | 20.029 | 20.550 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
