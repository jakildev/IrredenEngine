| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 13.950 | 13.950–13.950 |
| frame p95 | 19.220 | 19.220–19.220 |
| frame p99 | 21.910 | 21.910–21.910 |
| steady frame avg | 14.160 | 14.160–14.160 |
| steady frame p95 | 19.170 | 19.170–19.170 |
| steady frame p99 | 19.580 | 19.580–19.580 |
| GPU frame commandBufferSpans | 4.728 | 4.728–4.728 |
| GPU frame envelope | 4.728 | 4.728–4.728 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 14.158 | 19.173 | 19.585 | 21.909 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
