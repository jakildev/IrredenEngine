| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 14.210 | 14.210–14.210 |
| frame p95 | 19.110 | 19.110–19.110 |
| frame p99 | 19.590 | 19.590–19.590 |
| steady frame avg | 15.550 | 15.550–15.550 |
| steady frame p95 | 19.140 | 19.140–19.140 |
| steady frame p99 | 19.390 | 19.390–19.390 |
| GPU frame commandBufferSpans | 4.951 | 4.951–4.951 |
| GPU frame envelope | 4.951 | 4.951–4.951 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.552 | 19.144 | 19.390 | 19.644 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
