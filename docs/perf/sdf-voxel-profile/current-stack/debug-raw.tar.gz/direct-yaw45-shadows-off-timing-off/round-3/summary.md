| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.810 | 12.810–12.810 |
| frame p95 | 20.160 | 20.160–20.160 |
| frame p99 | 21.240 | 21.240–21.240 |
| steady frame avg | 11.580 | 11.580–11.580 |
| steady frame p95 | 20.010 | 20.010–20.010 |
| steady frame p99 | 20.480 | 20.480–20.480 |
| GPU frame commandBufferSpans | 4.805 | 4.805–4.805 |
| GPU frame envelope | 4.805 | 4.805–4.805 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.580 | 20.015 | 20.478 | 21.240 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
