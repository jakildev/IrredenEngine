| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.520 | 8.520–8.520 |
| frame p95 | 8.640 | 8.640–8.640 |
| frame p99 | 18.570 | 18.570–18.570 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.630 | 8.630–8.630 |
| steady frame p99 | 8.720 | 8.720–8.720 |
| GPU frame commandBufferSpans | 2.748 | 2.748–2.748 |
| GPU frame envelope | 2.748 | 2.748–2.748 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.375 | 8.632 | 8.724 | 18.575 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
