| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.410 | 8.410–8.410 |
| frame p95 | 8.600 | 8.600–8.600 |
| frame p99 | 8.720 | 8.720–8.720 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.590 | 8.590–8.590 |
| steady frame p99 | 8.690 | 8.690–8.690 |
| GPU frame commandBufferSpans | 2.792 | 2.792–2.792 |
| GPU frame envelope | 2.792 | 2.792–2.792 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.333 | 8.594 | 8.695 | 8.751 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
