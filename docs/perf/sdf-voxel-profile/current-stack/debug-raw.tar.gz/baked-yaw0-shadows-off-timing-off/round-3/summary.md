| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.500 | 8.500–8.500 |
| frame p95 | 9.010 | 9.010–9.010 |
| frame p99 | 19.180 | 19.180–19.180 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.970 | 8.970–8.970 |
| steady frame p99 | 9.180 | 9.180–9.180 |
| GPU frame commandBufferSpans | 2.584 | 2.584–2.584 |
| GPU frame envelope | 2.584 | 2.584–2.584 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.380 | 8.968 | 9.183 | 19.177 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
