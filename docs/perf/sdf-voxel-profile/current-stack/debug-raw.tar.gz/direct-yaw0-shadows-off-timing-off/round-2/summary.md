| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.470 | 8.470–8.470 |
| frame p95 | 8.580 | 8.580–8.580 |
| frame p99 | 8.840 | 8.840–8.840 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.570 | 8.570–8.570 |
| steady frame p99 | 8.750 | 8.750–8.750 |
| GPU frame commandBufferSpans | 2.917 | 2.917–2.917 |
| GPU frame envelope | 2.917 | 2.917–2.917 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.331 | 8.569 | 8.750 | 8.842 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
