| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.480 | 8.480–8.480 |
| frame p95 | 8.590 | 8.590–8.590 |
| frame p99 | 19.520 | 19.520–19.520 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.580 | 8.580–8.580 |
| steady frame p99 | 8.720 | 8.720–8.720 |
| GPU frame commandBufferSpans | 3.070 | 3.070–3.070 |
| GPU frame envelope | 3.070 | 3.070–3.070 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.380 | 8.582 | 8.724 | 19.776 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
