| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.490 | 8.490–8.490 |
| frame p95 | 8.970 | 8.970–8.970 |
| frame p99 | 16.430 | 16.430–16.430 |
| steady frame avg | 8.450 | 8.450–8.450 |
| steady frame p95 | 8.970 | 8.970–8.970 |
| steady frame p99 | 15.110 | 15.110–15.110 |
| GPU frame commandBufferSpans | 3.146 | 3.146–3.146 |
| GPU frame envelope | 3.146 | 3.146–3.146 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.446 | 8.973 | 15.115 | 17.334 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
