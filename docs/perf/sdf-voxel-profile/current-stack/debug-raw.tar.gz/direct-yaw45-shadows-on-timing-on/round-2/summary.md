| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 17.250 | 17.250–17.250 |
| frame p95 | 20.730 | 20.730–20.730 |
| frame p99 | 21.420 | 21.420–21.420 |
| steady frame avg | 18.320 | 18.320–18.320 |
| steady frame p95 | 20.810 | 20.810–20.810 |
| steady frame p99 | 21.380 | 21.380–21.380 |
| GPU frame commandBufferSpans | 5.960 | 5.960–5.960 |
| GPU frame envelope | 5.960 | 5.960–5.960 |
| GPU canvasClear | 0.054 | 0.054–0.054 |
| GPU computeLightVolume | 3.398 | 3.398–3.398 |
| GPU computeSunShadow | 0.369 | 0.369–0.369 |
| GPU computeVoxelAO | 0.038 | 0.038–0.038 |
| GPU computeVoxelAoPerAxis | 0.776 | 0.776–0.776 |
| GPU fbToScreen | 0.115 | 0.115–0.115 |
| GPU lightingOverflow | 2.438 | 2.438–2.438 |
| GPU lightingPerAxis | 0.102 | 0.102–0.102 |
| GPU lightingToTrixel | 0.048 | 0.048–0.048 |
| GPU perAxisCellCompact | 0.419 | 0.419–0.419 |
| GPU perAxisScatter | 0.175 | 0.175–0.175 |
| GPU resolvePerAxisScreenDepth | 0.991 | 0.991–0.991 |
| GPU shapeCastBake | 1.994 | 1.994–1.994 |
| GPU shapeCastBoxes | 2.171 | 2.171–2.171 |
| GPU shapeCastClear | 0.049 | 0.049–0.049 |
| GPU shapeCastFallback | 0.029 | 0.029–0.029 |
| GPU shapeCastResolve | 0.038 | 0.038–0.038 |
| GPU shapeDepth | 0.290 | 0.290–0.290 |
| GPU shapeOwnerClear | 0.018 | 0.018–0.018 |
| GPU shapeOwnerElect | 0.280 | 0.280–0.280 |
| GPU shapePublish | 0.301 | 0.301–0.301 |
| GPU trixelToFb | 0.221 | 0.221–0.221 |
| GPU voxelCompact | 0.093 | 0.093–0.093 |
| GPU voxelPerAxisFinalize | 0.312 | 0.312–0.312 |
| GPU voxelPerAxisOverflow | 0.494 | 0.494–0.494 |
| GPU voxelPerAxisStore | 1.450 | 1.450–1.450 |
| GPU voxelSunFaces | 0.227 | 0.227–0.227 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 18.320 | 20.813 | 21.380 | 21.600 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
