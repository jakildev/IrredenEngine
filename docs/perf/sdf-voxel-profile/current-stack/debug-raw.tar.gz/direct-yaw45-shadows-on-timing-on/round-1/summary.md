| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 17.780 | 17.780–17.780 |
| frame p95 | 20.940 | 20.940–20.940 |
| frame p99 | 22.180 | 22.180–22.180 |
| steady frame avg | 17.040 | 17.040–17.040 |
| steady frame p95 | 20.800 | 20.800–20.800 |
| steady frame p99 | 21.380 | 21.380–21.380 |
| GPU frame commandBufferSpans | 6.094 | 6.094–6.094 |
| GPU frame envelope | 6.094 | 6.094–6.094 |
| GPU canvasClear | 0.058 | 0.058–0.058 |
| GPU computeLightVolume | 3.479 | 3.479–3.479 |
| GPU computeSunShadow | 0.377 | 0.377–0.377 |
| GPU computeVoxelAO | 0.040 | 0.040–0.040 |
| GPU computeVoxelAoPerAxis | 0.805 | 0.805–0.805 |
| GPU fbToScreen | 0.117 | 0.117–0.117 |
| GPU lightingOverflow | 2.513 | 2.513–2.513 |
| GPU lightingPerAxis | 0.107 | 0.107–0.107 |
| GPU lightingToTrixel | 0.051 | 0.051–0.051 |
| GPU perAxisCellCompact | 0.418 | 0.418–0.418 |
| GPU perAxisScatter | 0.178 | 0.178–0.178 |
| GPU resolvePerAxisScreenDepth | 1.026 | 1.026–1.026 |
| GPU shapeCastBake | 2.030 | 2.030–2.030 |
| GPU shapeCastBoxes | 2.220 | 2.220–2.220 |
| GPU shapeCastClear | 0.047 | 0.047–0.047 |
| GPU shapeCastFallback | 0.032 | 0.032–0.032 |
| GPU shapeCastResolve | 0.037 | 0.037–0.037 |
| GPU shapeDepth | 0.293 | 0.293–0.293 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.285 | 0.285–0.285 |
| GPU shapePublish | 0.299 | 0.299–0.299 |
| GPU trixelToFb | 0.225 | 0.225–0.225 |
| GPU voxelCompact | 0.096 | 0.096–0.096 |
| GPU voxelPerAxisFinalize | 0.325 | 0.325–0.325 |
| GPU voxelPerAxisOverflow | 0.501 | 0.501–0.501 |
| GPU voxelPerAxisStore | 1.502 | 1.502–1.502 |
| GPU voxelSunFaces | 0.232 | 0.232–0.232 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 17.037 | 20.799 | 21.385 | 22.183 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
