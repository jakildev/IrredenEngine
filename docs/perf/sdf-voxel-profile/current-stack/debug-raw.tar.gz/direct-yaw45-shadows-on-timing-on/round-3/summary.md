| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.440 | 19.440–19.440 |
| frame p95 | 21.860 | 21.860–21.860 |
| frame p99 | 22.350 | 22.350–22.350 |
| steady frame avg | 20.080 | 20.080–20.080 |
| steady frame p95 | 21.860 | 21.860–21.860 |
| steady frame p99 | 22.140 | 22.140–22.140 |
| GPU frame commandBufferSpans | 6.089 | 6.089–6.089 |
| GPU frame envelope | 6.089 | 6.089–6.089 |
| GPU canvasClear | 0.056 | 0.056–0.056 |
| GPU computeLightVolume | 3.480 | 3.480–3.480 |
| GPU computeSunShadow | 0.377 | 0.377–0.377 |
| GPU computeVoxelAO | 0.039 | 0.039–0.039 |
| GPU computeVoxelAoPerAxis | 0.798 | 0.798–0.798 |
| GPU fbToScreen | 0.116 | 0.116–0.116 |
| GPU lightingOverflow | 2.479 | 2.479–2.479 |
| GPU lightingPerAxis | 0.105 | 0.105–0.105 |
| GPU lightingToTrixel | 0.049 | 0.049–0.049 |
| GPU perAxisCellCompact | 0.424 | 0.424–0.424 |
| GPU perAxisScatter | 0.176 | 0.176–0.176 |
| GPU resolvePerAxisScreenDepth | 1.015 | 1.015–1.015 |
| GPU shapeCastBake | 2.006 | 2.006–2.006 |
| GPU shapeCastBoxes | 2.190 | 2.190–2.190 |
| GPU shapeCastClear | 0.048 | 0.048–0.048 |
| GPU shapeCastFallback | 0.030 | 0.030–0.030 |
| GPU shapeCastResolve | 0.038 | 0.038–0.038 |
| GPU shapeDepth | 0.295 | 0.295–0.295 |
| GPU shapeOwnerClear | 0.020 | 0.020–0.020 |
| GPU shapeOwnerElect | 0.287 | 0.287–0.287 |
| GPU shapePublish | 0.303 | 0.303–0.303 |
| GPU trixelToFb | 0.228 | 0.228–0.228 |
| GPU voxelCompact | 0.095 | 0.095–0.095 |
| GPU voxelPerAxisFinalize | 0.318 | 0.318–0.318 |
| GPU voxelPerAxisOverflow | 0.503 | 0.503–0.503 |
| GPU voxelPerAxisStore | 1.456 | 1.456–1.456 |
| GPU voxelSunFaces | 0.231 | 0.231–0.231 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 20.082 | 21.864 | 22.138 | 22.335 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.20 | 1.20–1.20 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
