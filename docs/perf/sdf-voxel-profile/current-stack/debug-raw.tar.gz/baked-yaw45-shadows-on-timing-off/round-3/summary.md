| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.990 | 15.990–15.990 |
| frame p95 | 20.790 | 20.790–20.790 |
| frame p99 | 21.790 | 21.790–21.790 |
| steady frame avg | 15.570 | 15.570–15.570 |
| steady frame p95 | 20.630 | 20.630–20.630 |
| steady frame p99 | 21.280 | 21.280–21.280 |
| GPU frame commandBufferSpans | 5.087 | 5.087–5.087 |
| GPU frame envelope | 5.087 | 5.087–5.087 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.573 | 20.633 | 21.275 | 21.357 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
