| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.290 | 11.290–11.290 |
| frame p95 | 19.360 | 19.360–19.360 |
| frame p99 | 20.320 | 20.320–20.320 |
| steady frame avg | 11.750 | 11.750–11.750 |
| steady frame p95 | 19.300 | 19.300–19.300 |
| steady frame p99 | 19.910 | 19.910–19.910 |
| GPU frame commandBufferSpans | 4.979 | 4.979–4.979 |
| GPU frame envelope | 4.979 | 4.979–4.979 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.747 | 19.304 | 19.907 | 20.316 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
