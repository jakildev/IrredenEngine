| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.820 | 12.820–12.820 |
| frame p95 | 19.680 | 19.680–19.680 |
| frame p99 | 20.870 | 20.870–20.870 |
| steady frame avg | 12.740 | 12.740–12.740 |
| steady frame p95 | 19.620 | 19.620–19.620 |
| steady frame p99 | 20.360 | 20.360–20.360 |
| GPU frame commandBufferSpans | 5.500 | 5.500–5.500 |
| GPU frame envelope | 5.500 | 5.500–5.500 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 12.740 | 19.622 | 20.355 | 20.867 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 7 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
