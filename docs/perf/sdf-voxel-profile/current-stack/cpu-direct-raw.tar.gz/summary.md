| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 14.290 | 14.290–14.290 |
| frame p95 | 21.120 | 21.120–21.120 |
| frame p99 | 21.780 | 21.780–21.780 |
| steady frame avg | 16.150 | 16.150–16.150 |
| steady frame p95 | 21.250 | 21.250–21.250 |
| steady frame p99 | 21.930 | 21.930–21.930 |
| GPU frame commandBufferSpans | 5.378 | 5.378–5.378 |
| GPU frame envelope | 5.378 | 5.378–5.378 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 300 of each run excluded | 900 | 16.150 | 21.251 | 21.928 | 30.788 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 1200 / 1200 | 0 | 1200 | 45.000 (0.000) | 12 / 0 (1200) |
