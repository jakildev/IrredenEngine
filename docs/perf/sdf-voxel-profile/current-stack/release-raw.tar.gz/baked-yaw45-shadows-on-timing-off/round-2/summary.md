| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.720 | 16.720–16.720 |
| frame p95 | 20.910 | 20.910–20.910 |
| frame p99 | 30.010 | 30.010–30.010 |
| steady frame avg | 18.340 | 18.340–18.340 |
| steady frame p95 | 20.830 | 20.830–20.830 |
| steady frame p99 | 21.150 | 21.150–21.150 |
| GPU frame commandBufferSpans | 5.011 | 5.011–5.011 |
| GPU frame envelope | 5.011 | 5.011–5.011 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 18.338 | 20.835 | 21.149 | 21.421 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
