| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 17.030 | 17.030–17.030 |
| frame p95 | 20.700 | 20.700–20.700 |
| frame p99 | 22.480 | 22.480–22.480 |
| steady frame avg | 16.910 | 16.910–16.910 |
| steady frame p95 | 20.690 | 20.690–20.690 |
| steady frame p99 | 21.330 | 21.330–21.330 |
| GPU frame commandBufferSpans | 5.171 | 5.171–5.171 |
| GPU frame envelope | 5.171 | 5.171–5.171 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 16.909 | 20.685 | 21.325 | 21.686 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
