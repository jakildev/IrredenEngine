| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.080 | 19.080–19.080 |
| frame p95 | 21.830 | 21.830–21.830 |
| frame p99 | 26.680 | 26.680–26.680 |
| steady frame avg | 18.990 | 18.990–18.990 |
| steady frame p95 | 21.710 | 21.710–21.710 |
| steady frame p99 | 22.060 | 22.060–22.060 |
| GPU frame commandBufferSpans | 6.345 | 6.345–6.345 |
| GPU frame envelope | 6.345 | 6.345–6.345 |
| GPU canvasClear | 0.057 | 0.057–0.057 |
| GPU computeLightVolume | 3.559 | 3.559–3.559 |
| GPU computeSunShadow | 0.391 | 0.391–0.391 |
| GPU computeVoxelAO | 0.040 | 0.040–0.040 |
| GPU computeVoxelAoPerAxis | 0.815 | 0.815–0.815 |
| GPU fbToScreen | 0.122 | 0.122–0.122 |
| GPU lightingOverflow | 2.578 | 2.578–2.578 |
| GPU lightingPerAxis | 0.110 | 0.110–0.110 |
| GPU lightingToTrixel | 0.051 | 0.051–0.051 |
| GPU perAxisCellCompact | 0.445 | 0.445–0.445 |
| GPU perAxisScatter | 0.184 | 0.184–0.184 |
| GPU resolvePerAxisScreenDepth | 1.042 | 1.042–1.042 |
| GPU shapeCastBake | 2.039 | 2.039–2.039 |
| GPU shapeCastBoxes | 2.220 | 2.220–2.220 |
| GPU shapeCastClear | 0.051 | 0.051–0.051 |
| GPU shapeCastFallback | 0.032 | 0.032–0.032 |
| GPU shapeCastResolve | 0.039 | 0.039–0.039 |
| GPU shapeDepth | 0.299 | 0.299–0.299 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.296 | 0.296–0.296 |
| GPU shapePublish | 0.312 | 0.312–0.312 |
| GPU trixelToFb | 0.224 | 0.224–0.224 |
| GPU voxelCompact | 0.092 | 0.092–0.092 |
| GPU voxelPerAxisFinalize | 0.327 | 0.327–0.327 |
| GPU voxelPerAxisOverflow | 0.513 | 0.513–0.513 |
| GPU voxelPerAxisStore | 1.459 | 1.459–1.459 |
| GPU voxelSunFaces | 0.236 | 0.236–0.236 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 18.992 | 21.713 | 22.056 | 22.905 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
