| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 13.320 | 13.320–13.320 |
| frame p95 | 21.180 | 21.180–21.180 |
| frame p99 | 21.940 | 21.940–21.940 |
| steady frame avg | 12.760 | 12.760–12.760 |
| steady frame p95 | 21.150 | 21.150–21.150 |
| steady frame p99 | 21.750 | 21.750–21.750 |
| GPU frame commandBufferSpans | 5.637 | 5.637–5.637 |
| GPU frame envelope | 5.637 | 5.637–5.637 |
| GPU canvasClear | 0.055 | 0.055–0.055 |
| GPU computeLightVolume | 3.331 | 3.331–3.331 |
| GPU computeSunShadow | 0.375 | 0.375–0.375 |
| GPU computeVoxelAO | 0.034 | 0.034–0.034 |
| GPU computeVoxelAoPerAxis | 0.677 | 0.677–0.677 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingOverflow | 2.380 | 2.380–2.380 |
| GPU lightingPerAxis | 0.103 | 0.103–0.103 |
| GPU lightingToTrixel | 0.047 | 0.047–0.047 |
| GPU perAxisCellCompact | 0.375 | 0.375–0.375 |
| GPU perAxisScatter | 0.177 | 0.177–0.177 |
| GPU resolvePerAxisScreenDepth | 0.888 | 0.888–0.888 |
| GPU shapeCastBake | 1.941 | 1.941–1.941 |
| GPU shapeCastBoxes | 2.098 | 2.098–2.098 |
| GPU shapeCastClear | 0.046 | 0.046–0.046 |
| GPU shapeCastFallback | 0.030 | 0.030–0.030 |
| GPU shapeCastResolve | 0.040 | 0.040–0.040 |
| GPU shapeDepth | 0.297 | 0.297–0.297 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.292 | 0.292–0.292 |
| GPU shapePublish | 0.307 | 0.307–0.307 |
| GPU trixelToFb | 0.229 | 0.229–0.229 |
| GPU voxelCompact | 0.067 | 0.067–0.067 |
| GPU voxelPerAxisFinalize | 0.316 | 0.316–0.316 |
| GPU voxelPerAxisOverflow | 0.513 | 0.513–0.513 |
| GPU voxelPerAxisStore | 1.307 | 1.307–1.307 |
| GPU voxelSunFaces | 0.209 | 0.209–0.209 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 12.758 | 21.154 | 21.754 | 21.937 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
