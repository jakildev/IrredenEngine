| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 18.060 | 18.060–18.060 |
| frame p95 | 21.590 | 21.590–21.590 |
| frame p99 | 22.180 | 22.180–22.180 |
| steady frame avg | 18.420 | 18.420–18.420 |
| steady frame p95 | 21.680 | 21.680–21.680 |
| steady frame p99 | 22.060 | 22.060–22.060 |
| GPU frame commandBufferSpans | 6.000 | 6.000–6.000 |
| GPU frame envelope | 6.000 | 6.000–6.000 |
| GPU canvasClear | 0.055 | 0.055–0.055 |
| GPU computeLightVolume | 3.456 | 3.456–3.456 |
| GPU computeSunShadow | 0.376 | 0.376–0.376 |
| GPU computeVoxelAO | 0.039 | 0.039–0.039 |
| GPU computeVoxelAoPerAxis | 0.792 | 0.792–0.792 |
| GPU fbToScreen | 0.116 | 0.116–0.116 |
| GPU lightingOverflow | 2.492 | 2.492–2.492 |
| GPU lightingPerAxis | 0.105 | 0.105–0.105 |
| GPU lightingToTrixel | 0.048 | 0.048–0.048 |
| GPU perAxisCellCompact | 0.417 | 0.417–0.417 |
| GPU perAxisScatter | 0.176 | 0.176–0.176 |
| GPU resolvePerAxisScreenDepth | 1.009 | 1.009–1.009 |
| GPU shapeCastBake | 2.020 | 2.020–2.020 |
| GPU shapeCastBoxes | 2.193 | 2.193–2.193 |
| GPU shapeCastClear | 0.047 | 0.047–0.047 |
| GPU shapeCastFallback | 0.030 | 0.030–0.030 |
| GPU shapeCastResolve | 0.038 | 0.038–0.038 |
| GPU shapeDepth | 0.294 | 0.294–0.294 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.289 | 0.289–0.289 |
| GPU shapePublish | 0.301 | 0.301–0.301 |
| GPU trixelToFb | 0.230 | 0.230–0.230 |
| GPU voxelCompact | 0.088 | 0.088–0.088 |
| GPU voxelPerAxisFinalize | 0.319 | 0.319–0.319 |
| GPU voxelPerAxisOverflow | 0.502 | 0.502–0.502 |
| GPU voxelPerAxisStore | 1.462 | 1.462–1.462 |
| GPU voxelSunFaces | 0.229 | 0.229–0.229 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 18.423 | 21.681 | 22.061 | 22.185 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
