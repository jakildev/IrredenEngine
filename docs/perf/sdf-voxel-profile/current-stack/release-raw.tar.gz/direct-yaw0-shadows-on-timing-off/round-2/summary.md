| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.620 | 8.620–8.620 |
| frame p95 | 8.920 | 8.920–8.920 |
| frame p99 | 18.670 | 18.670–18.670 |
| steady frame avg | 8.540 | 8.540–8.540 |
| steady frame p95 | 8.890 | 8.890–8.890 |
| steady frame p99 | 18.240 | 18.240–18.240 |
| GPU frame commandBufferSpans | 3.914 | 3.914–3.914 |
| GPU frame envelope | 3.914 | 3.914–3.914 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.544 | 8.895 | 18.240 | 18.671 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
