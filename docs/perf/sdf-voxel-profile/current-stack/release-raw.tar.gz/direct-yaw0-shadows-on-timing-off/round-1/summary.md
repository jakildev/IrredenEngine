| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.870 | 8.870–8.870 |
| frame p95 | 9.600 | 9.600–9.600 |
| frame p99 | 20.420 | 20.420–20.420 |
| steady frame avg | 8.840 | 8.840–8.840 |
| steady frame p95 | 17.240 | 17.240–17.240 |
| steady frame p99 | 18.580 | 18.580–18.580 |
| GPU frame commandBufferSpans | 3.935 | 3.935–3.935 |
| GPU frame envelope | 3.935 | 3.935–3.935 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.845 | 17.239 | 18.583 | 20.421 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
