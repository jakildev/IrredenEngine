| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.800 | 8.800–8.800 |
| frame p95 | 9.060 | 9.060–9.060 |
| frame p99 | 22.320 | 22.320–22.320 |
| steady frame avg | 8.710 | 8.710–8.710 |
| steady frame p95 | 9.040 | 9.040–9.040 |
| steady frame p99 | 20.810 | 20.810–20.810 |
| GPU frame commandBufferSpans | 3.864 | 3.864–3.864 |
| GPU frame envelope | 3.864 | 3.864–3.864 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.709 | 9.040 | 20.814 | 22.324 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
