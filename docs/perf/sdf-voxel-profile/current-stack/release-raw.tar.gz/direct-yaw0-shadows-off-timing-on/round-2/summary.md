| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.750 | 8.750–8.750 |
| frame p95 | 8.820 | 8.820–8.820 |
| frame p99 | 18.520 | 18.520–18.520 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.730 | 8.730–8.730 |
| steady frame p99 | 8.970 | 8.970–8.970 |
| GPU frame commandBufferSpans | 3.272 | 3.272–3.272 |
| GPU frame envelope | 3.272 | 3.272–3.272 |
| GPU canvasClear | 0.052 | 0.052–0.052 |
| GPU computeLightVolume | 1.842 | 1.842–1.842 |
| GPU computeSunShadow | 0.048 | 0.048–0.048 |
| GPU computeVoxelAO | 0.041 | 0.041–0.041 |
| GPU fbToScreen | 0.124 | 0.124–0.124 |
| GPU lightingToTrixel | 0.066 | 0.066–0.066 |
| GPU shapeDepth | 0.186 | 0.186–0.186 |
| GPU shapeOwnerClear | 0.015 | 0.015–0.015 |
| GPU shapeOwnerElect | 0.148 | 0.148–0.148 |
| GPU shapePublish | 0.157 | 0.157–0.157 |
| GPU trixelToFb | 0.168 | 0.168–0.168 |
| GPU voxelCardinalElect | 0.105 | 0.105–0.105 |
| GPU voxelCompact | 0.100 | 0.100–0.100 |
| GPU voxelStage1 | 0.182 | 0.182–0.182 |
| GPU voxelStage2 | 0.113 | 0.113–0.113 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.330 | 8.734 | 8.966 | 9.279 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
