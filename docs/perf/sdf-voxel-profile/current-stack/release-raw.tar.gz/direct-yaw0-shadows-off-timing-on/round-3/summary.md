| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.500 | 8.500–8.500 |
| frame p95 | 8.670 | 8.670–8.670 |
| frame p99 | 21.050 | 21.050–21.050 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.670 | 8.670–8.670 |
| steady frame p99 | 8.980 | 8.980–8.980 |
| GPU frame commandBufferSpans | 3.007 | 3.007–3.007 |
| GPU frame envelope | 3.007 | 3.007–3.007 |
| GPU canvasClear | 0.054 | 0.054–0.054 |
| GPU computeLightVolume | 1.848 | 1.848–1.848 |
| GPU computeSunShadow | 0.048 | 0.048–0.048 |
| GPU computeVoxelAO | 0.043 | 0.043–0.043 |
| GPU fbToScreen | 0.120 | 0.120–0.120 |
| GPU lightingToTrixel | 0.065 | 0.065–0.065 |
| GPU shapeDepth | 0.188 | 0.188–0.188 |
| GPU shapeOwnerClear | 0.014 | 0.014–0.014 |
| GPU shapeOwnerElect | 0.148 | 0.148–0.148 |
| GPU shapePublish | 0.156 | 0.156–0.156 |
| GPU trixelToFb | 0.179 | 0.179–0.179 |
| GPU voxelCardinalElect | 0.105 | 0.105–0.105 |
| GPU voxelCompact | 0.113 | 0.113–0.113 |
| GPU voxelStage1 | 0.185 | 0.185–0.185 |
| GPU voxelStage2 | 0.112 | 0.112–0.112 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.384 | 8.667 | 8.983 | 21.046 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
