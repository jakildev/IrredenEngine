| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.480 | 8.480–8.480 |
| frame p95 | 8.790 | 8.790–8.790 |
| frame p99 | 9.090 | 9.090–9.090 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.750 | 8.750–8.750 |
| steady frame p99 | 8.890 | 8.890–8.890 |
| GPU frame commandBufferSpans | 3.164 | 3.164–3.164 |
| GPU frame envelope | 3.164 | 3.164–3.164 |
| GPU canvasClear | 0.058 | 0.058–0.058 |
| GPU computeLightVolume | 1.924 | 1.924–1.924 |
| GPU computeSunShadow | 0.052 | 0.052–0.052 |
| GPU computeVoxelAO | 0.047 | 0.047–0.047 |
| GPU fbToScreen | 0.124 | 0.124–0.124 |
| GPU lightingToTrixel | 0.070 | 0.070–0.070 |
| GPU shapeDepth | 0.197 | 0.197–0.197 |
| GPU shapeOwnerClear | 0.014 | 0.014–0.014 |
| GPU shapeOwnerElect | 0.153 | 0.153–0.153 |
| GPU shapePublish | 0.162 | 0.162–0.162 |
| GPU trixelToFb | 0.205 | 0.205–0.205 |
| GPU voxelCardinalElect | 0.110 | 0.110–0.110 |
| GPU voxelCompact | 0.132 | 0.132–0.132 |
| GPU voxelStage1 | 0.195 | 0.195–0.195 |
| GPU voxelStage2 | 0.115 | 0.115–0.115 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.330 | 8.747 | 8.890 | 9.088 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
