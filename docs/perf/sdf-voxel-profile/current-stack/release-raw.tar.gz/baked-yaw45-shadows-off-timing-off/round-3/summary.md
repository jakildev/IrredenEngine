| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.700 | 12.700–12.700 |
| frame p95 | 20.120 | 20.120–20.120 |
| frame p99 | 20.910 | 20.910–20.910 |
| steady frame avg | 13.390 | 13.390–13.390 |
| steady frame p95 | 20.220 | 20.220–20.220 |
| steady frame p99 | 20.680 | 20.680–20.680 |
| GPU frame commandBufferSpans | 4.500 | 4.500–4.500 |
| GPU frame envelope | 4.500 | 4.500–4.500 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 13.389 | 20.222 | 20.677 | 21.432 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
