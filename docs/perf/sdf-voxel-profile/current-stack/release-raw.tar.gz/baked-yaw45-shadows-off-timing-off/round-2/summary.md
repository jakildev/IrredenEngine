| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 13.360 | 13.360–13.360 |
| frame p95 | 19.710 | 19.710–19.710 |
| frame p99 | 20.420 | 20.420–20.420 |
| steady frame avg | 13.500 | 13.500–13.500 |
| steady frame p95 | 19.620 | 19.620–19.620 |
| steady frame p99 | 20.330 | 20.330–20.330 |
| GPU frame commandBufferSpans | 4.690 | 4.690–4.690 |
| GPU frame envelope | 4.690 | 4.690–4.690 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 13.498 | 19.621 | 20.329 | 20.416 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
