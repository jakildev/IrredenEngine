| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.940 | 11.940–11.940 |
| frame p95 | 19.580 | 19.580–19.580 |
| frame p99 | 20.700 | 20.700–20.700 |
| steady frame avg | 11.140 | 11.140–11.140 |
| steady frame p95 | 19.400 | 19.400–19.400 |
| steady frame p99 | 19.960 | 19.960–19.960 |
| GPU frame commandBufferSpans | 4.565 | 4.565–4.565 |
| GPU frame envelope | 4.565 | 4.565–4.565 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.140 | 19.401 | 19.963 | 20.177 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
