| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 12.500 | 12.500–12.500 |
| frame p95 | 20.050 | 20.050–20.050 |
| frame p99 | 22.380 | 22.380–22.380 |
| steady frame avg | 11.630 | 11.630–11.630 |
| steady frame p95 | 19.990 | 19.990–19.990 |
| steady frame p99 | 21.030 | 21.030–21.030 |
| GPU frame commandBufferSpans | 4.787 | 4.787–4.787 |
| GPU frame envelope | 4.787 | 4.787–4.787 |
| GPU canvasClear | 0.063 | 0.063–0.063 |
| GPU computeLightVolume | 3.101 | 3.101–3.101 |
| GPU computeSunShadow | 0.089 | 0.089–0.089 |
| GPU computeVoxelAO | 0.043 | 0.043–0.043 |
| GPU computeVoxelAoPerAxis | 1.384 | 1.384–1.384 |
| GPU fbToScreen | 0.113 | 0.113–0.113 |
| GPU lightingOverflow | 2.624 | 2.624–2.624 |
| GPU lightingPerAxis | 0.104 | 0.104–0.104 |
| GPU lightingToTrixel | 0.040 | 0.040–0.040 |
| GPU perAxisCellCompact | 0.265 | 0.265–0.265 |
| GPU perAxisScatter | 0.169 | 0.169–0.169 |
| GPU resolvePerAxisScreenDepth | 1.609 | 1.609–1.609 |
| GPU trixelToFb | 0.228 | 0.228–0.228 |
| GPU voxelCompact | 0.143 | 0.143–0.143 |
| GPU voxelPerAxisFinalize | 0.243 | 0.243–0.243 |
| GPU voxelPerAxisOverflow | 0.331 | 0.331–0.331 |
| GPU voxelPerAxisStore | 1.409 | 1.409–1.409 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 11.635 | 19.992 | 21.033 | 22.379 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
