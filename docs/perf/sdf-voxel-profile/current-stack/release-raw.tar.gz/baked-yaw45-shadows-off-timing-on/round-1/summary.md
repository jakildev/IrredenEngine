| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.000 | 15.000–15.000 |
| frame p95 | 20.260 | 20.260–20.260 |
| frame p99 | 21.340 | 21.340–21.340 |
| steady frame avg | 15.110 | 15.110–15.110 |
| steady frame p95 | 20.260 | 20.260–20.260 |
| steady frame p99 | 21.000 | 21.000–21.000 |
| GPU frame commandBufferSpans | 4.765 | 4.765–4.765 |
| GPU frame envelope | 4.765 | 4.765–4.765 |
| GPU canvasClear | 0.067 | 0.067–0.067 |
| GPU computeLightVolume | 3.131 | 3.131–3.131 |
| GPU computeSunShadow | 0.088 | 0.088–0.088 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU computeVoxelAoPerAxis | 1.397 | 1.397–1.397 |
| GPU fbToScreen | 0.114 | 0.114–0.114 |
| GPU lightingOverflow | 2.649 | 2.649–2.649 |
| GPU lightingPerAxis | 0.099 | 0.099–0.099 |
| GPU lightingToTrixel | 0.039 | 0.039–0.039 |
| GPU perAxisCellCompact | 0.262 | 0.262–0.262 |
| GPU perAxisScatter | 0.167 | 0.167–0.167 |
| GPU resolvePerAxisScreenDepth | 1.626 | 1.626–1.626 |
| GPU trixelToFb | 0.221 | 0.221–0.221 |
| GPU voxelCompact | 0.125 | 0.125–0.125 |
| GPU voxelPerAxisFinalize | 0.246 | 0.246–0.246 |
| GPU voxelPerAxisOverflow | 0.338 | 0.338–0.338 |
| GPU voxelPerAxisStore | 1.372 | 1.372–1.372 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.108 | 20.262 | 21.004 | 21.340 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
