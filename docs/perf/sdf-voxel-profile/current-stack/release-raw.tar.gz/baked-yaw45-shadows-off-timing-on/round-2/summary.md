| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 11.010 | 11.010–11.010 |
| frame p95 | 20.130 | 20.130–20.130 |
| frame p99 | 21.480 | 21.480–21.480 |
| steady frame avg | 10.830 | 10.830–10.830 |
| steady frame p95 | 20.070 | 20.070–20.070 |
| steady frame p99 | 21.080 | 21.080–21.080 |
| GPU frame commandBufferSpans | 4.600 | 4.600–4.600 |
| GPU frame envelope | 4.600 | 4.600–4.600 |
| GPU canvasClear | 0.064 | 0.064–0.064 |
| GPU computeLightVolume | 3.045 | 3.045–3.045 |
| GPU computeSunShadow | 0.086 | 0.086–0.086 |
| GPU computeVoxelAO | 0.039 | 0.039–0.039 |
| GPU computeVoxelAoPerAxis | 1.328 | 1.328–1.328 |
| GPU fbToScreen | 0.114 | 0.114–0.114 |
| GPU lightingOverflow | 2.579 | 2.579–2.579 |
| GPU lightingPerAxis | 0.096 | 0.096–0.096 |
| GPU lightingToTrixel | 0.038 | 0.038–0.038 |
| GPU perAxisCellCompact | 0.242 | 0.242–0.242 |
| GPU perAxisScatter | 0.167 | 0.167–0.167 |
| GPU resolvePerAxisScreenDepth | 1.549 | 1.549–1.549 |
| GPU trixelToFb | 0.233 | 0.233–0.233 |
| GPU voxelCompact | 0.108 | 0.108–0.108 |
| GPU voxelPerAxisFinalize | 0.236 | 0.236–0.236 |
| GPU voxelPerAxisOverflow | 0.345 | 0.345–0.345 |
| GPU voxelPerAxisStore | 1.274 | 1.274–1.274 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 10.827 | 20.069 | 21.085 | 21.479 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.70 | 0.70–0.70 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
