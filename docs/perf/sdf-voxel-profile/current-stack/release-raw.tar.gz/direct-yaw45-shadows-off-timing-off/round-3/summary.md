| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 10.480 | 10.480–10.480 |
| frame p95 | 19.720 | 19.720–19.720 |
| frame p99 | 20.820 | 20.820–20.820 |
| steady frame avg | 10.090 | 10.090–10.090 |
| steady frame p95 | 19.710 | 19.710–19.710 |
| steady frame p99 | 20.710 | 20.710–20.710 |
| GPU frame commandBufferSpans | 4.284 | 4.284–4.284 |
| GPU frame envelope | 4.284 | 4.284–4.284 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 10.091 | 19.706 | 20.710 | 20.819 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
