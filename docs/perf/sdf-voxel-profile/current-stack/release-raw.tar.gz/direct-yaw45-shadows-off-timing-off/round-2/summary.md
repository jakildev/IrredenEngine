| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 13.880 | 13.880–13.880 |
| frame p95 | 19.940 | 19.940–19.940 |
| frame p99 | 24.230 | 24.230–24.230 |
| steady frame avg | 13.690 | 13.690–13.690 |
| steady frame p95 | 19.890 | 19.890–19.890 |
| steady frame p99 | 20.290 | 20.290–20.290 |
| GPU frame commandBufferSpans | 4.887 | 4.887–4.887 |
| GPU frame envelope | 4.887 | 4.887–4.887 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 13.685 | 19.886 | 20.285 | 24.227 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 5 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
