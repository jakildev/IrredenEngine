| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 14.440 | 14.440–14.440 |
| frame p95 | 20.120 | 20.120–20.120 |
| frame p99 | 20.940 | 20.940–20.940 |
| steady frame avg | 13.370 | 13.370–13.370 |
| steady frame p95 | 19.850 | 19.850–19.850 |
| steady frame p99 | 20.390 | 20.390–20.390 |
| GPU frame commandBufferSpans | 4.928 | 4.928–4.928 |
| GPU frame envelope | 4.928 | 4.928–4.928 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 13.373 | 19.852 | 20.389 | 20.813 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
