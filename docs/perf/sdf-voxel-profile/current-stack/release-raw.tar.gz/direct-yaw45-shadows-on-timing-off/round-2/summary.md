| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 15.430 | 15.430–15.430 |
| frame p95 | 21.000 | 21.000–21.000 |
| frame p99 | 21.980 | 21.980–21.980 |
| steady frame avg | 17.410 | 17.410–17.410 |
| steady frame p95 | 21.020 | 21.020–21.020 |
| steady frame p99 | 21.430 | 21.430–21.430 |
| GPU frame commandBufferSpans | 5.680 | 5.680–5.680 |
| GPU frame envelope | 5.680 | 5.680–5.680 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 17.407 | 21.024 | 21.430 | 22.243 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
