| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 13.710 | 13.710–13.710 |
| frame p95 | 20.730 | 20.730–20.730 |
| frame p99 | 27.790 | 27.790–27.790 |
| steady frame avg | 12.290 | 12.290–12.290 |
| steady frame p95 | 20.680 | 20.680–20.680 |
| steady frame p99 | 21.220 | 21.220–21.220 |
| GPU frame commandBufferSpans | 5.793 | 5.793–5.793 |
| GPU frame envelope | 5.793 | 5.793–5.793 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 12.286 | 20.679 | 21.217 | 23.386 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
