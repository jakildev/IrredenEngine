| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.230 | 16.230–16.230 |
| frame p95 | 20.790 | 20.790–20.790 |
| frame p99 | 21.980 | 21.980–21.980 |
| steady frame avg | 15.940 | 15.940–15.940 |
| steady frame p95 | 20.670 | 20.670–20.670 |
| steady frame p99 | 21.150 | 21.150–21.150 |
| GPU frame commandBufferSpans | 5.413 | 5.413–5.413 |
| GPU frame envelope | 5.413 | 5.413–5.413 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.940 | 20.671 | 21.149 | 21.980 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
