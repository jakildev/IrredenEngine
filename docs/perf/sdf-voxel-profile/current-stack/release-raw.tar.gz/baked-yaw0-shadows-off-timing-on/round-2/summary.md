| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.890 | 8.890–8.890 |
| frame p95 | 8.930 | 8.930–8.930 |
| frame p99 | 22.930 | 22.930–22.930 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.840 | 8.840–8.840 |
| steady frame p99 | 9.040 | 9.040–9.040 |
| GPU frame commandBufferSpans | 2.947 | 2.947–2.947 |
| GPU frame envelope | 2.947 | 2.947–2.947 |
| GPU canvasClear | 0.061 | 0.061–0.061 |
| GPU computeLightVolume | 1.529 | 1.529–1.529 |
| GPU computeSunShadow | 0.033 | 0.033–0.033 |
| GPU computeVoxelAO | 0.154 | 0.154–0.154 |
| GPU fbToScreen | 0.121 | 0.121–0.121 |
| GPU lightingToTrixel | 0.061 | 0.061–0.061 |
| GPU trixelToFb | 0.224 | 0.224–0.224 |
| GPU voxelCardinalElect | 0.109 | 0.109–0.109 |
| GPU voxelCompact | 0.142 | 0.142–0.142 |
| GPU voxelStage1 | 0.213 | 0.213–0.213 |
| GPU voxelStage2 | 0.121 | 0.121–0.121 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.334 | 8.837 | 9.042 | 9.153 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 6 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
