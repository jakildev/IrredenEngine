| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.560 | 8.560–8.560 |
| frame p95 | 9.090 | 9.090–9.090 |
| frame p99 | 20.310 | 20.310–20.310 |
| steady frame avg | 8.370 | 8.370–8.370 |
| steady frame p95 | 9.000 | 9.000–9.000 |
| steady frame p99 | 9.250 | 9.250–9.250 |
| GPU frame commandBufferSpans | 2.744 | 2.744–2.744 |
| GPU frame envelope | 2.744 | 2.744–2.744 |
| GPU canvasClear | 0.061 | 0.061–0.061 |
| GPU computeLightVolume | 1.537 | 1.537–1.537 |
| GPU computeSunShadow | 0.033 | 0.033–0.033 |
| GPU computeVoxelAO | 0.142 | 0.142–0.142 |
| GPU fbToScreen | 0.124 | 0.124–0.124 |
| GPU lightingToTrixel | 0.061 | 0.061–0.061 |
| GPU trixelToFb | 0.198 | 0.198–0.198 |
| GPU voxelCardinalElect | 0.115 | 0.115–0.115 |
| GPU voxelCompact | 0.122 | 0.122–0.122 |
| GPU voxelStage1 | 0.217 | 0.217–0.217 |
| GPU voxelStage2 | 0.124 | 0.124–0.124 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.374 | 8.997 | 9.246 | 17.403 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
