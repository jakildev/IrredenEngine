| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.490 | 8.490–8.490 |
| frame p95 | 8.940 | 8.940–8.940 |
| frame p99 | 18.880 | 18.880–18.880 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.920 | 8.920–8.920 |
| steady frame p99 | 9.180 | 9.180–9.180 |
| GPU frame commandBufferSpans | 2.766 | 2.766–2.766 |
| GPU frame envelope | 2.766 | 2.766–2.766 |
| GPU canvasClear | 0.060 | 0.060–0.060 |
| GPU computeLightVolume | 1.537 | 1.537–1.537 |
| GPU computeSunShadow | 0.032 | 0.032–0.032 |
| GPU computeVoxelAO | 0.143 | 0.143–0.143 |
| GPU fbToScreen | 0.124 | 0.124–0.124 |
| GPU lightingToTrixel | 0.062 | 0.062–0.062 |
| GPU trixelToFb | 0.214 | 0.214–0.214 |
| GPU voxelCardinalElect | 0.113 | 0.113–0.113 |
| GPU voxelCompact | 0.139 | 0.139–0.139 |
| GPU voxelStage1 | 0.216 | 0.216–0.216 |
| GPU voxelStage2 | 0.126 | 0.126–0.126 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.378 | 8.921 | 9.177 | 19.256 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
