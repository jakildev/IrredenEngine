| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.950 | 16.950–16.950 |
| frame p95 | 20.970 | 20.970–20.970 |
| frame p99 | 23.520 | 23.520–23.520 |
| steady frame avg | 16.650 | 16.650–16.650 |
| steady frame p95 | 20.920 | 20.920–20.920 |
| steady frame p99 | 21.460 | 21.460–21.460 |
| GPU frame commandBufferSpans | 5.556 | 5.556–5.556 |
| GPU frame envelope | 5.556 | 5.556–5.556 |
| GPU canvasClear | 0.056 | 0.056–0.056 |
| GPU computeLightVolume | 3.462 | 3.462–3.462 |
| GPU computeSunShadow | 0.339 | 0.339–0.339 |
| GPU computeVoxelAO | 0.043 | 0.043–0.043 |
| GPU computeVoxelAoPerAxis | 1.228 | 1.228–1.228 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingOverflow | 3.006 | 3.006–3.006 |
| GPU lightingPerAxis | 0.104 | 0.104–0.104 |
| GPU lightingToTrixel | 0.040 | 0.040–0.040 |
| GPU perAxisCellCompact | 0.303 | 0.303–0.303 |
| GPU perAxisScatter | 0.256 | 0.256–0.256 |
| GPU resolvePerAxisScreenDepth | 1.476 | 1.476–1.476 |
| GPU trixelToFb | 0.259 | 0.259–0.259 |
| GPU voxelCompact | 0.084 | 0.084–0.084 |
| GPU voxelPerAxisFinalize | 0.264 | 0.264–0.264 |
| GPU voxelPerAxisOverflow | 0.423 | 0.423–0.423 |
| GPU voxelPerAxisStore | 1.244 | 1.244–1.244 |
| GPU voxelSunFaces | 0.222 | 0.222–0.222 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 16.653 | 20.925 | 21.461 | 21.636 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
