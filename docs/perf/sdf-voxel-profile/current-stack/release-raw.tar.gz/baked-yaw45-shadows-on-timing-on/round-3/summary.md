| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 14.530 | 14.530–14.530 |
| frame p95 | 20.840 | 20.840–20.840 |
| frame p99 | 23.450 | 23.450–23.450 |
| steady frame avg | 12.900 | 12.900–12.900 |
| steady frame p95 | 20.470 | 20.470–20.470 |
| steady frame p99 | 20.880 | 20.880–20.880 |
| GPU frame commandBufferSpans | 5.582 | 5.582–5.582 |
| GPU frame envelope | 5.582 | 5.582–5.582 |
| GPU canvasClear | 0.060 | 0.060–0.060 |
| GPU computeLightVolume | 3.537 | 3.537–3.537 |
| GPU computeSunShadow | 0.344 | 0.344–0.344 |
| GPU computeVoxelAO | 0.043 | 0.043–0.043 |
| GPU computeVoxelAoPerAxis | 1.198 | 1.198–1.198 |
| GPU fbToScreen | 0.123 | 0.123–0.123 |
| GPU lightingOverflow | 3.036 | 3.036–3.036 |
| GPU lightingPerAxis | 0.105 | 0.105–0.105 |
| GPU lightingToTrixel | 0.041 | 0.041–0.041 |
| GPU perAxisCellCompact | 0.293 | 0.293–0.293 |
| GPU perAxisScatter | 0.259 | 0.259–0.259 |
| GPU resolvePerAxisScreenDepth | 1.450 | 1.450–1.450 |
| GPU trixelToFb | 0.261 | 0.261–0.261 |
| GPU voxelCompact | 0.075 | 0.075–0.075 |
| GPU voxelPerAxisFinalize | 0.260 | 0.260–0.260 |
| GPU voxelPerAxisOverflow | 0.422 | 0.422–0.422 |
| GPU voxelPerAxisStore | 1.219 | 1.219–1.219 |
| GPU voxelSunFaces | 0.209 | 0.209–0.209 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 12.900 | 20.475 | 20.884 | 21.190 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.90 | 0.90–0.90 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
