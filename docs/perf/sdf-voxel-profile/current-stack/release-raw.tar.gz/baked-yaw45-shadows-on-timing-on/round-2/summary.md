| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.890 | 16.890–16.890 |
| frame p95 | 20.990 | 20.990–20.990 |
| frame p99 | 24.210 | 24.210–24.210 |
| steady frame avg | 15.700 | 15.700–15.700 |
| steady frame p95 | 20.850 | 20.850–20.850 |
| steady frame p99 | 21.250 | 21.250–21.250 |
| GPU frame commandBufferSpans | 5.538 | 5.538–5.538 |
| GPU frame envelope | 5.538 | 5.538–5.538 |
| GPU canvasClear | 0.058 | 0.058–0.058 |
| GPU computeLightVolume | 3.428 | 3.428–3.428 |
| GPU computeSunShadow | 0.339 | 0.339–0.339 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU computeVoxelAoPerAxis | 1.209 | 1.209–1.209 |
| GPU fbToScreen | 0.122 | 0.122–0.122 |
| GPU lightingOverflow | 2.991 | 2.991–2.991 |
| GPU lightingPerAxis | 0.103 | 0.103–0.103 |
| GPU lightingToTrixel | 0.040 | 0.040–0.040 |
| GPU perAxisCellCompact | 0.290 | 0.290–0.290 |
| GPU perAxisScatter | 0.258 | 0.258–0.258 |
| GPU resolvePerAxisScreenDepth | 1.457 | 1.457–1.457 |
| GPU trixelToFb | 0.245 | 0.245–0.245 |
| GPU voxelCompact | 0.082 | 0.082–0.082 |
| GPU voxelPerAxisFinalize | 0.260 | 0.260–0.260 |
| GPU voxelPerAxisOverflow | 0.415 | 0.415–0.415 |
| GPU voxelPerAxisStore | 1.238 | 1.238–1.238 |
| GPU voxelSunFaces | 0.214 | 0.214–0.214 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.697 | 20.850 | 21.247 | 24.207 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 403 / 0 (300) |
