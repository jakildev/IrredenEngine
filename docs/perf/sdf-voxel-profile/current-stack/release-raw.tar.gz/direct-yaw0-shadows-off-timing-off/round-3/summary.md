| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.520 | 8.520–8.520 |
| frame p95 | 8.920 | 8.920–8.920 |
| frame p99 | 19.250 | 19.250–19.250 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.830 | 8.830–8.830 |
| steady frame p99 | 9.180 | 9.180–9.180 |
| GPU frame commandBufferSpans | 3.102 | 3.102–3.102 |
| GPU frame envelope | 3.102 | 3.102–3.102 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.381 | 8.830 | 9.176 | 19.253 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
