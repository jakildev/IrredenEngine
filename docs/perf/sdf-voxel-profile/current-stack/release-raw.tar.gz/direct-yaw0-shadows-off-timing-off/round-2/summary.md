| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.430 | 8.430–8.430 |
| frame p95 | 8.730 | 8.730–8.730 |
| frame p99 | 9.470 | 9.470–9.470 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.730 | 8.730–8.730 |
| steady frame p99 | 8.910 | 8.910–8.910 |
| GPU frame commandBufferSpans | 3.067 | 3.067–3.067 |
| GPU frame envelope | 3.067 | 3.067–3.067 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.330 | 8.732 | 8.907 | 9.467 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 1 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
