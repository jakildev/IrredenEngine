| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 14.160 | 14.160–14.160 |
| frame p95 | 20.880 | 20.880–20.880 |
| frame p99 | 22.140 | 22.140–22.140 |
| steady frame avg | 14.100 | 14.100–14.100 |
| steady frame p95 | 20.850 | 20.850–20.850 |
| steady frame p99 | 21.180 | 21.180–21.180 |
| GPU frame commandBufferSpans | 5.568 | 5.568–5.568 |
| GPU frame envelope | 5.568 | 5.568–5.568 |
| GPU canvasClear | 0.063 | 0.063–0.063 |
| GPU computeLightVolume | 3.790 | 3.790–3.790 |
| GPU computeSunShadow | 0.097 | 0.097–0.097 |
| GPU computeVoxelAO | 0.039 | 0.039–0.039 |
| GPU computeVoxelAoPerAxis | 2.136 | 2.136–2.136 |
| GPU fbToScreen | 0.113 | 0.113–0.113 |
| GPU lightingOverflow | 3.314 | 3.314–3.314 |
| GPU lightingPerAxis | 0.102 | 0.102–0.102 |
| GPU lightingToTrixel | 0.048 | 0.048–0.048 |
| GPU perAxisCellCompact | 0.249 | 0.249–0.249 |
| GPU perAxisScatter | 0.151 | 0.151–0.151 |
| GPU resolvePerAxisScreenDepth | 2.296 | 2.296–2.296 |
| GPU shapeDepth | 0.271 | 0.271–0.271 |
| GPU shapeOwnerClear | 0.017 | 0.017–0.017 |
| GPU shapeOwnerElect | 0.268 | 0.268–0.268 |
| GPU shapePublish | 0.271 | 0.271–0.271 |
| GPU trixelToFb | 0.203 | 0.203–0.203 |
| GPU voxelCompact | 0.110 | 0.110–0.110 |
| GPU voxelPerAxisFinalize | 0.239 | 0.239–0.239 |
| GPU voxelPerAxisOverflow | 0.328 | 0.328–0.328 |
| GPU voxelPerAxisStore | 1.325 | 1.325–1.325 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 14.103 | 20.850 | 21.177 | 21.815 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.80 | 0.80–0.80 | 7 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
