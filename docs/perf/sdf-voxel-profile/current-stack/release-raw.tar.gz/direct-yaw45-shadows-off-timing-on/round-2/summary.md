| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 16.470 | 16.470–16.470 |
| frame p95 | 21.250 | 21.250–21.250 |
| frame p99 | 23.700 | 23.700–23.700 |
| steady frame avg | 15.450 | 15.450–15.450 |
| steady frame p95 | 21.170 | 21.170–21.170 |
| steady frame p99 | 21.550 | 21.550–21.550 |
| GPU frame commandBufferSpans | 5.810 | 5.810–5.810 |
| GPU frame envelope | 5.810 | 5.810–5.810 |
| GPU canvasClear | 0.066 | 0.066–0.066 |
| GPU computeLightVolume | 3.909 | 3.909–3.909 |
| GPU computeSunShadow | 0.097 | 0.097–0.097 |
| GPU computeVoxelAO | 0.042 | 0.042–0.042 |
| GPU computeVoxelAoPerAxis | 2.240 | 2.240–2.240 |
| GPU fbToScreen | 0.116 | 0.116–0.116 |
| GPU lightingOverflow | 3.427 | 3.427–3.427 |
| GPU lightingPerAxis | 0.103 | 0.103–0.103 |
| GPU lightingToTrixel | 0.049 | 0.049–0.049 |
| GPU perAxisCellCompact | 0.271 | 0.271–0.271 |
| GPU perAxisScatter | 0.153 | 0.153–0.153 |
| GPU resolvePerAxisScreenDepth | 2.408 | 2.408–2.408 |
| GPU shapeDepth | 0.284 | 0.284–0.284 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.279 | 0.279–0.279 |
| GPU shapePublish | 0.280 | 0.280–0.280 |
| GPU trixelToFb | 0.211 | 0.211–0.211 |
| GPU voxelCompact | 0.127 | 0.127–0.127 |
| GPU voxelPerAxisFinalize | 0.247 | 0.247–0.247 |
| GPU voxelPerAxisOverflow | 0.340 | 0.340–0.340 |
| GPU voxelPerAxisStore | 1.418 | 1.418–1.418 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 15.448 | 21.167 | 21.551 | 21.728 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.00 | 1.00–1.00 | 7 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
