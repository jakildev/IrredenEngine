| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 19.130 | 19.130–19.130 |
| frame p95 | 21.360 | 21.360–21.360 |
| frame p99 | 24.710 | 24.710–24.710 |
| steady frame avg | 18.890 | 18.890–18.890 |
| steady frame p95 | 21.280 | 21.280–21.280 |
| steady frame p99 | 21.680 | 21.680–21.680 |
| GPU frame commandBufferSpans | 5.859 | 5.859–5.859 |
| GPU frame envelope | 5.859 | 5.859–5.859 |
| GPU canvasClear | 0.066 | 0.066–0.066 |
| GPU computeLightVolume | 4.054 | 4.054–4.054 |
| GPU computeSunShadow | 0.102 | 0.102–0.102 |
| GPU computeVoxelAO | 0.044 | 0.044–0.044 |
| GPU computeVoxelAoPerAxis | 2.312 | 2.312–2.312 |
| GPU fbToScreen | 0.118 | 0.118–0.118 |
| GPU lightingOverflow | 3.541 | 3.541–3.541 |
| GPU lightingPerAxis | 0.107 | 0.107–0.107 |
| GPU lightingToTrixel | 0.051 | 0.051–0.051 |
| GPU perAxisCellCompact | 0.288 | 0.288–0.288 |
| GPU perAxisScatter | 0.159 | 0.159–0.159 |
| GPU resolvePerAxisScreenDepth | 2.485 | 2.485–2.485 |
| GPU shapeDepth | 0.289 | 0.289–0.289 |
| GPU shapeOwnerClear | 0.019 | 0.019–0.019 |
| GPU shapeOwnerElect | 0.286 | 0.286–0.286 |
| GPU shapePublish | 0.288 | 0.288–0.288 |
| GPU trixelToFb | 0.205 | 0.205–0.205 |
| GPU voxelCompact | 0.140 | 0.140–0.140 |
| GPU voxelPerAxisFinalize | 0.252 | 0.252–0.252 |
| GPU voxelPerAxisOverflow | 0.349 | 0.349–0.349 |
| GPU voxelPerAxisStore | 1.472 | 1.472–1.472 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 18.887 | 21.278 | 21.678 | 23.030 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 1.10 | 1.10–1.10 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 45.000 (0.000) | 12 / 0 (300) |
