| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.460 | 8.460–8.460 |
| frame p95 | 8.930 | 8.930–8.930 |
| frame p99 | 9.500 | 9.500–9.500 |
| steady frame avg | 8.370 | 8.370–8.370 |
| steady frame p95 | 8.930 | 8.930–8.930 |
| steady frame p99 | 9.210 | 9.210–9.210 |
| GPU frame commandBufferSpans | 2.729 | 2.729–2.729 |
| GPU frame envelope | 2.729 | 2.729–2.729 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.371 | 8.928 | 9.211 | 17.930 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
