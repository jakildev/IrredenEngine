| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.520 | 8.520–8.520 |
| frame p95 | 8.960 | 8.960–8.960 |
| frame p99 | 9.860 | 9.860–9.860 |
| steady frame avg | 8.370 | 8.370–8.370 |
| steady frame p95 | 8.830 | 8.830–8.830 |
| steady frame p99 | 9.540 | 9.540–9.540 |
| GPU frame commandBufferSpans | 3.254 | 3.254–3.254 |
| GPU frame envelope | 3.254 | 3.254–3.254 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.371 | 8.825 | 9.541 | 16.179 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
