| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.550 | 8.550–8.550 |
| frame p95 | 9.000 | 9.000–9.000 |
| frame p99 | 18.140 | 18.140–18.140 |
| steady frame avg | 8.410 | 8.410–8.410 |
| steady frame p95 | 8.970 | 8.970–8.970 |
| steady frame p99 | 9.330 | 9.330–9.330 |
| GPU frame commandBufferSpans | 3.340 | 3.340–3.340 |
| GPU frame envelope | 3.340 | 3.340–3.340 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.415 | 8.966 | 9.335 | 18.135 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
