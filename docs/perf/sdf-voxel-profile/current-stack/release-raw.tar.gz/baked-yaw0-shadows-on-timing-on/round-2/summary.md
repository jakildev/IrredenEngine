| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.540 | 8.540–8.540 |
| frame p95 | 9.020 | 9.020–9.020 |
| frame p99 | 19.290 | 19.290–19.290 |
| steady frame avg | 8.380 | 8.380–8.380 |
| steady frame p95 | 8.990 | 8.990–8.990 |
| steady frame p99 | 9.120 | 9.120–9.120 |
| GPU frame commandBufferSpans | 3.471 | 3.471–3.471 |
| GPU frame envelope | 3.471 | 3.471–3.471 |
| GPU canvasClear | 0.056 | 0.056–0.056 |
| GPU computeLightVolume | 2.113 | 2.113–2.113 |
| GPU computeSunShadow | 0.307 | 0.307–0.307 |
| GPU computeVoxelAO | 0.043 | 0.043–0.043 |
| GPU fbToScreen | 0.121 | 0.121–0.121 |
| GPU lightingToTrixel | 0.062 | 0.062–0.062 |
| GPU trixelToFb | 0.206 | 0.206–0.206 |
| GPU voxelCardinalElect | 0.110 | 0.110–0.110 |
| GPU voxelCompact | 0.068 | 0.068–0.068 |
| GPU voxelStage1 | 0.170 | 0.170–0.170 |
| GPU voxelStage2 | 0.125 | 0.125–0.125 |
| GPU voxelSunFaces | 0.130 | 0.130–0.130 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.378 | 8.993 | 9.119 | 19.174 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
