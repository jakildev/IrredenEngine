| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.580 | 8.580–8.580 |
| frame p95 | 8.990 | 8.990–8.990 |
| frame p99 | 17.270 | 17.270–17.270 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 8.970 | 8.970–8.970 |
| steady frame p99 | 9.160 | 9.160–9.160 |
| GPU frame commandBufferSpans | 3.597 | 3.597–3.597 |
| GPU frame envelope | 3.597 | 3.597–3.597 |
| GPU canvasClear | 0.056 | 0.056–0.056 |
| GPU computeLightVolume | 2.128 | 2.128–2.128 |
| GPU computeSunShadow | 0.308 | 0.308–0.308 |
| GPU computeVoxelAO | 0.037 | 0.037–0.037 |
| GPU fbToScreen | 0.122 | 0.122–0.122 |
| GPU lightingToTrixel | 0.062 | 0.062–0.062 |
| GPU trixelToFb | 0.210 | 0.210–0.210 |
| GPU voxelCardinalElect | 0.113 | 0.113–0.113 |
| GPU voxelCompact | 0.071 | 0.071–0.071 |
| GPU voxelStage1 | 0.175 | 0.175–0.175 |
| GPU voxelStage2 | 0.123 | 0.123–0.123 |
| GPU voxelSunFaces | 0.130 | 0.130–0.130 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.329 | 8.965 | 9.163 | 9.256 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
