| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 8.590 | 8.590–8.590 |
| frame p95 | 9.090 | 9.090–9.090 |
| frame p99 | 14.490 | 14.490–14.490 |
| steady frame avg | 8.330 | 8.330–8.330 |
| steady frame p95 | 9.080 | 9.080–9.080 |
| steady frame p99 | 9.170 | 9.170–9.170 |
| GPU frame commandBufferSpans | 3.450 | 3.450–3.450 |
| GPU frame envelope | 3.450 | 3.450–3.450 |
| GPU canvasClear | 0.050 | 0.050–0.050 |
| GPU computeLightVolume | 2.086 | 2.086–2.086 |
| GPU computeSunShadow | 0.308 | 0.308–0.308 |
| GPU computeVoxelAO | 0.035 | 0.035–0.035 |
| GPU fbToScreen | 0.120 | 0.120–0.120 |
| GPU lightingToTrixel | 0.061 | 0.061–0.061 |
| GPU trixelToFb | 0.197 | 0.197–0.197 |
| GPU voxelCardinalElect | 0.108 | 0.108–0.108 |
| GPU voxelCompact | 0.068 | 0.068–0.068 |
| GPU voxelStage1 | 0.165 | 0.165–0.165 |
| GPU voxelStage2 | 0.120 | 0.120–0.120 |
| GPU voxelSunFaces | 0.129 | 0.129–0.129 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 8.333 | 9.085 | 9.173 | 9.317 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.50 | 0.50–0.50 | 3 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
