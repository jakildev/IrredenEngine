| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.270 | 9.270–9.270 |
| frame p95 | 17.870 | 17.870–17.870 |
| frame p99 | 18.800 | 18.800–18.800 |
| steady frame avg | 9.220 | 9.220–9.220 |
| steady frame p95 | 17.970 | 17.970–17.970 |
| steady frame p99 | 18.490 | 18.490–18.490 |
| GPU frame commandBufferSpans | 4.202 | 4.202–4.202 |
| GPU frame envelope | 4.202 | 4.202–4.202 |
| GPU canvasClear | 0.090 | 0.090–0.090 |
| GPU computeLightVolume | 2.545 | 2.545–2.545 |
| GPU computeSunShadow | 0.304 | 0.304–0.304 |
| GPU computeVoxelAO | 0.034 | 0.034–0.034 |
| GPU fbToScreen | 0.120 | 0.120–0.120 |
| GPU lightingToTrixel | 0.068 | 0.068–0.068 |
| GPU shapeCastBake | 1.231 | 1.231–1.231 |
| GPU shapeCastBoxes | 1.160 | 1.160–1.160 |
| GPU shapeCastClear | 0.035 | 0.035–0.035 |
| GPU shapeCastFallback | 0.034 | 0.034–0.034 |
| GPU shapeCastResolve | 0.048 | 0.048–0.048 |
| GPU shapeDepth | 0.153 | 0.153–0.153 |
| GPU shapeOwnerClear | 0.017 | 0.017–0.017 |
| GPU shapeOwnerElect | 0.151 | 0.151–0.151 |
| GPU shapePublish | 0.158 | 0.158–0.158 |
| GPU trixelToFb | 0.194 | 0.194–0.194 |
| GPU voxelCardinalElect | 0.100 | 0.100–0.100 |
| GPU voxelCompact | 0.059 | 0.059–0.059 |
| GPU voxelStage1 | 0.238 | 0.238–0.238 |
| GPU voxelStage2 | 0.112 | 0.112–0.112 |
| GPU voxelSunFaces | 0.124 | 0.124–0.124 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 9.216 | 17.965 | 18.491 | 18.799 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 4 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
