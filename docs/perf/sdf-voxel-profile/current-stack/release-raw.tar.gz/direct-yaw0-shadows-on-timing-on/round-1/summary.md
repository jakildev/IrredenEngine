| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 10.590 | 10.590–10.590 |
| frame p95 | 18.780 | 18.780–18.780 |
| frame p99 | 19.840 | 19.840–19.840 |
| steady frame avg | 10.230 | 10.230–10.230 |
| steady frame p95 | 18.690 | 18.690–18.690 |
| steady frame p99 | 19.080 | 19.080–19.080 |
| GPU frame commandBufferSpans | 4.212 | 4.212–4.212 |
| GPU frame envelope | 4.212 | 4.212–4.212 |
| GPU canvasClear | 0.085 | 0.085–0.085 |
| GPU computeLightVolume | 2.505 | 2.505–2.505 |
| GPU computeSunShadow | 0.294 | 0.294–0.294 |
| GPU computeVoxelAO | 0.033 | 0.033–0.033 |
| GPU fbToScreen | 0.119 | 0.119–0.119 |
| GPU lightingToTrixel | 0.065 | 0.065–0.065 |
| GPU shapeCastBake | 1.211 | 1.211–1.211 |
| GPU shapeCastBoxes | 1.142 | 1.142–1.142 |
| GPU shapeCastClear | 0.037 | 0.037–0.037 |
| GPU shapeCastFallback | 0.031 | 0.031–0.031 |
| GPU shapeCastResolve | 0.048 | 0.048–0.048 |
| GPU shapeDepth | 0.147 | 0.147–0.147 |
| GPU shapeOwnerClear | 0.017 | 0.017–0.017 |
| GPU shapeOwnerElect | 0.152 | 0.152–0.152 |
| GPU shapePublish | 0.156 | 0.156–0.156 |
| GPU trixelToFb | 0.182 | 0.182–0.182 |
| GPU voxelCardinalElect | 0.096 | 0.096–0.096 |
| GPU voxelCompact | 0.063 | 0.063–0.063 |
| GPU voxelStage1 | 0.241 | 0.241–0.241 |
| GPU voxelStage2 | 0.108 | 0.108–0.108 |
| GPU voxelSunFaces | 0.121 | 0.121–0.121 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 10.227 | 18.690 | 19.084 | 19.546 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 8 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
