| Measurement | Mean ms | Run min–max ms |
|---|---:|---:|
| frame avg | 9.510 | 9.510–9.510 |
| frame p95 | 18.120 | 18.120–18.120 |
| frame p99 | 21.860 | 21.860–21.860 |
| steady frame avg | 9.630 | 9.630–9.630 |
| steady frame p95 | 18.120 | 18.120–18.120 |
| steady frame p99 | 19.060 | 19.060–19.060 |
| GPU frame commandBufferSpans | 4.111 | 4.111–4.111 |
| GPU frame envelope | 4.111 | 4.111–4.111 |
| GPU canvasClear | 0.092 | 0.092–0.092 |
| GPU computeLightVolume | 2.556 | 2.556–2.556 |
| GPU computeSunShadow | 0.299 | 0.299–0.299 |
| GPU computeVoxelAO | 0.034 | 0.034–0.034 |
| GPU fbToScreen | 0.121 | 0.121–0.121 |
| GPU lightingToTrixel | 0.072 | 0.072–0.072 |
| GPU shapeCastBake | 1.237 | 1.237–1.237 |
| GPU shapeCastBoxes | 1.169 | 1.169–1.169 |
| GPU shapeCastClear | 0.036 | 0.036–0.036 |
| GPU shapeCastFallback | 0.036 | 0.036–0.036 |
| GPU shapeCastResolve | 0.050 | 0.050–0.050 |
| GPU shapeDepth | 0.150 | 0.150–0.150 |
| GPU shapeOwnerClear | 0.017 | 0.017–0.017 |
| GPU shapeOwnerElect | 0.151 | 0.151–0.151 |
| GPU shapePublish | 0.157 | 0.157–0.157 |
| GPU trixelToFb | 0.191 | 0.191–0.191 |
| GPU voxelCardinalElect | 0.099 | 0.099–0.099 |
| GPU voxelCompact | 0.061 | 0.061–0.061 |
| GPU voxelStage1 | 0.249 | 0.249–0.249 |
| GPU voxelStage2 | 0.111 | 0.111–0.111 |
| GPU voxelSunFaces | 0.126 | 0.126–0.126 |

| Steady frames pooled over runs | Frames | Mean ms | p95 ms | p99 ms | Max ms |
|---|---:|---:|---:|---:|---:|
| first 75 of each run excluded | 225 | 9.631 | 18.116 | 19.059 | 21.235 |

| Fixed updates per rendered frame | Mean | Run min–max | Max in a frame |
|---|---:|---:|---:|
| update ticks | 0.60 | 0.60–0.60 | 2 |

| Run | Frame GPU supported | Valid / attempted | Invalid | Command buffers | Yaw deg (travel) | Overflow max entries / dropped (frames sampled) |
|---|---|---:|---:|---:|---:|---:|
| 1 | True | 300 / 300 | 0 | 300 | 0.000 (0.000) | 0 / 0 (0) |
