#define IR_SUN_QUERY_STATS 1
#include <metal_stdlib>
using namespace metal;
#ifndef IR_SUN_QUERY_STATS_INCLUDED
#define IR_SUN_QUERY_STATS_INCLUDED

constant uint kSunQueryCascades = 0u;
constant uint kSunQueryIndexed = 1u;
constant uint kSunQueryCandidates = 2u;
constant uint kSunQueryFaceMisses = 3u;
constant uint kSunQueryShapeCandidates = 4u;
constant uint kSunQueryBlocked = 5u;
constant uint kSunQueryFirstBlockerVisits = 6u;
constant uint kSunQueryExhausted = 7u;
constant uint kSunQueryIncomplete = 8u;
constant uint kSunQueryOutside = 9u;
constant uint kSunQueryCounterCount = 10u;

struct SunQueryStats {
    uint counts[kSunQueryCounterCount];
};

#endif

// Mirrors shaders/ir_iso_common.glsl; keep the two in lockstep.
#ifndef IR_ISO_COMMON_METAL_INCLUDED
#define IR_ISO_COMMON_METAL_INCLUDED

#include <metal_stdlib>
using namespace metal;
#ifndef IR_PROJECTED_FACE_INCLUDED
#define IR_PROJECTED_FACE_INCLUDED

inline float projectedFaceDeterminant(float2 edgeU, float2 edgeV) {
    return edgeU.x * edgeV.y - edgeU.y * edgeV.x;
}

// The caller rejects degenerate bases before dividing. Coverage ownership is
// separate: display faces are half-open; finite shadow footprints are closed.
inline float2 projectedFaceCoordinates(float2 delta, float2 edgeU, float2 edgeV, float determinant) {
    return float2((delta.x * edgeV.y - delta.y * edgeV.x) / determinant,
                (edgeU.x * delta.y - edgeU.y * delta.x) / determinant);
}

// The sun-query envelope preserves exact represented faces at every orientation.
// Its arithmetic margin and the producer enclosure in sourceFaceIndexBounds
// are coupled; the derivation is in docs/design/sun-face-index-coverage.md.
inline bool sourceFaceWithinProjectedBounds(float point, float corner, float edgeU, float edgeV) {
    const float relativeMargin = 0.00000095367431640625;
    const float absoluteMargin = 3.7615819226313200255e-37;
    const float padding = relativeMargin * (abs(corner) + abs(edgeU) + abs(edgeV)) + absoluteMargin;
    const float low = corner + (edgeU < 0.0 ? edgeU : 0.0) + (edgeV < 0.0 ? edgeV : 0.0) - padding;
    const float high = corner + (edgeU > 0.0 ? edgeU : 0.0) + (edgeV > 0.0 ? edgeV : 0.0) + padding;
    return !(point < low || point > high);
}

// Conservative closed-edge predicates for independently rounded projected
// inputs and finite normal binary32 arithmetic. gamma(7) bounds input rounding,
// subtraction and two-product edge functions, not upstream projection error.
// The caller rejects degenerate bases and keeps uncertain-hit depth on the face.
inline bool projectedFaceContainsClosed(float2 point, float2 corner, float2 edgeU, float2 edgeV,
                                       float determinant, float2 uv) {
    if (uv.x >= 0.0 && uv.y >= 0.0 && uv.x <= 1.0 && uv.y <= 1.0) return true;
    const float unitRoundoff = 0.000000059604644775390625;
    const float gamma7 = (7.0 * unitRoundoff) / (1.0 - 7.0 * unitRoundoff);
    const float dx = abs(point.x) + abs(corner.x);
    const float dy = abs(point.y) + abs(corner.y);
    const float detMagnitude = abs(edgeU.x * edgeV.y) + abs(edgeU.y * edgeV.x);
    const float errorU = gamma7 * (dx * abs(edgeV.y) + dy * abs(edgeV.x) + detMagnitude);
    const float errorV = gamma7 * (dx * abs(edgeU.y) + dy * abs(edgeU.x) + detMagnitude);
    const float deltaX = point.x - corner.x;
    const float deltaY = point.y - corner.y;
    const float numeratorU = deltaX * edgeV.y - deltaY * edgeV.x;
    const float numeratorV = edgeU.x * deltaY - edgeU.y * deltaX;
    const float orientation = determinant > 0.0 ? 1.0 : -1.0;
    return orientation * numeratorU >= -errorU &&
           orientation * (determinant - numeratorU) >= -errorU &&
           orientation * numeratorV >= -errorV &&
           orientation * (determinant - numeratorV) >= -errorV;
}

#endif


// Axis-only face indices (X / Y / Z axis, polarity-blind). The 3-face
// helpers take these; the six-face FaceId constants are the polarity-aware
// set visible-triplet rasterization uses.
constant int kXFace = 0;
constant int kYFace = 1;
constant int kZFace = 2;

// Polarity-aware six-face IDs (mirrors `kFaceXNeg`/... in the GLSL
// `ir_iso_common.glsl` and `IRMath::FaceId` in C++). Bit positions line
// up with `IRComponents::VoxelFlags::kFaceOccluded*`:
//   bit(faceId) = 2 + faceId
constant int kFaceXNeg = 0;
constant int kFaceXPos = 1;
constant int kFaceYNeg = 2;
constant int kFaceYPos = 3;
constant int kFaceZNeg = 4;
constant int kFaceZPos = 5;

inline int2 pos3DtoPos2DIso(int3 position) {
    return int2(
        -position.x + position.y,
        -position.x - position.y + 2 * position.z
    );
}

inline float pos3DtoDistance(float3 position) {
    return position.x + position.y + position.z;
}

inline int pos3DtoDistance(int3 position) {
    return position.x + position.y + position.z;
}

// The isometric depth axis (1,1,1) is perpendicular to the screen, so given
// (isoX, isoY) and depth d = x + y + z, (x, y, z) is uniquely determined.
inline float3 isoPositionToPos3D(float2 iso, float depth) {
    const float x = (2.0 * depth - 3.0 * iso.x - iso.y) / 6.0;
    return float3(x, x + iso.x, (iso.y + 2.0 * x + iso.x) / 2.0);
}

inline float3 isoPixelToPos3D(int isoX, int isoY, float depth) {
    return isoPositionToPos3D(float2(isoX, isoY), depth);
}

inline float3 isoToLocal3D(int2 isoRel, float depth) {
    return isoPixelToPos3D(isoRel.x, isoRel.y, depth);
}

inline float4 unpackColor(uint packedColor) {
    return float4(
        float(packedColor & 0xFFu) / 255.0,
        float((packedColor >> 8) & 0xFFu) / 255.0,
        float((packedColor >> 16) & 0xFFu) / 255.0,
        float((packedColor >> 24) & 0xFFu) / 255.0
    );
}

// Exact inverse of unpackColor: clamp to [0,1] and round-to-nearest so a
// round-trip of a stored 8-bit channel is a fixed point (the overflow-face
// relight rewrites an entry's colorPacked in place through this).
inline uint packColor(float4 c) {
    uint4 q = uint4(clamp(c, 0.0, 1.0) * 255.0 + 0.5);
    return q.r | (q.g << 8) | (q.b << 16) | (q.a << 24);
}

// PCG-flavored integer hash (low-collision, no FP precision loss). Cheap
// enough for per-thread shader use; quality is sufficient for visual jitter
// on the stateless particle path. Mirrors the GLSL implementation
// in ir_iso_common.glsl line-for-line so deterministic seeds reproduce on
// both backends.
inline uint hash3(uint a, uint b, uint c) {
    uint h = a * 0x9E3779B1u;
    h = (h ^ b) * 0x85EBCA77u;
    h = (h ^ c) * 0xC2B2AE3Du;
    h ^= h >> 16;
    h *= 0x85EBCA77u;
    h ^= h >> 13;
    h *= 0xC2B2AE3Du;
    h ^= h >> 16;
    return h;
}

inline float3 randomUnitVec(uint seed) {
    const float kInvU32 = 1.0f / 4294967295.0f;
    uint rx = hash3(seed, 0x9E3779B1u, 0u);
    uint ry = hash3(seed, 0x85EBCA77u, 1u);
    uint rz = hash3(seed, 0xC2B2AE3Du, 2u);
    return float3(
        float(rx) * kInvU32 * 2.0f - 1.0f,
        float(ry) * kInvU32 * 2.0f - 1.0f,
        float(rz) * kInvU32 * 2.0f - 1.0f
    );
}

// Map local invocation ID within a (2, 3, 1) workgroup to a face type.
//   (0,0),(1,0) -> Z_FACE
//   (1,1),(1,2) -> X_FACE
//   (0,1),(0,2) -> Y_FACE
inline int localIDToFace_2x3(uint2 localId) {
    if (localId.y == 0u) return kZFace;
    if (localId.x == 1u) return kXFace;
    return kYFace;
}

// Face offset within the 2x3 trixel diamond for a given face and sub-pixel
// index (0 or 1).  Matches the layout used by localIDToFace_2x3():
//   Z -> (0,0),(1,0)   X -> (1,1),(1,2)   Y -> (0,1),(0,2)
inline int2 faceOffset_2x3(int face, int subPixel) {
    if (face == kZFace) return int2(subPixel, 0);
    if (face == kXFace) return int2(1, 1 + subPixel);
    return int2(0, 1 + subPixel);
}

// Single-canvas distance-encoding scale: one depth unit spans 8 codes —
// [31:3] depth | [2] flip | [1:0] slot. Mirrors IRRender::kDepthEncodeShift
// (ir_render_types.hpp) and the GLSL twin (ir_iso_common.glsl).
constant int kDepthEncodeShift = 8;

// Encode depth with face priority for deterministic depth-test resolution.
// The *8 spacing keeps flip + slot below every depth boundary, so raw-int
// atomicMin still orders by depth first (a flipped-but-farther cell can
// never win the min) and the Hi-Z max stays a faithful max-depth pyramid.
// `flip` marks a silhouette-riser face emitted with the OPPOSITE polarity of
// its slot's triplet face (faceId = visibleFaceIds[slot] ^ 1): lighting/AO/
// shadow decode it to negate the slot-derived outward normal instead of
// shading the riser with an inverted Lambert.
inline int encodeDepthWithFace(int rawDepth, int face, int flip) {
    return rawDepth * kDepthEncodeShift + (flip << 2) + face;
}

inline int encodeDepthWithFace(int rawDepth, int face) {
    return encodeDepthWithFace(rawDepth, face, 0);
}

// Shared decode helpers — the ONLY places the two distance-encoding bit
// layouts live; twin of ir_iso_common.glsl. Single-canvas:
// [31:3] depth | [2] flip | [1:0] slot. Per-axis: [31:15] depth |
// [14:11] wFrac4 | [10] flip | [9:6] uFrac4 | [5:2] vFrac4 | [1:0] slot.
// Depth decodes by arithmetic right shift (floor), so negative depths recover
// exactly. wFrac sits directly below depth so atomicMin still orders by true
// plane depth (a same-cell nearer plane wins) before flip/frac/slot. Route
// every consumer through these — an open-coded shift silently mis-decodes
// when a layout changes.
inline int decodeSlot(int encoded) { return encoded & 3; }
inline int decodeFlipSingle(int encoded) { return (encoded >> 2) & 1; }
inline int decodeDepthSingle(int encoded) { return encoded >> 3; }
inline int decodeFlipPerAxis(int encoded) { return (encoded >> 10) & 1; }
inline int decodeDepthPerAxis(int encoded) { return encoded >> 15; }
// 4-bit sub-cell fracs (0..15, 8 = cell centre): u/v span the face's two
// in-plane axes; w is the OUT-OF-PLANE fraction along the face axis — the
// coordinate the integer cell lattice cannot carry. Dropping w displaces a
// fractionally-positioned face along its own normal by up to half a voxel.
inline int decodeUFrac4PerAxis(int encoded) { return (encoded >> 6) & 15; }
inline int decodeVFrac4PerAxis(int encoded) { return (encoded >> 2) & 15; }
inline int decodeWFrac4PerAxis(int encoded) { return (encoded >> 11) & 15; }
// Route-aware forms for the shared lighting/AO/shadow/bake consumers that
// read either encoding behind the perAxisRoute selector.
inline int decodeDepthRoute(int encoded, int perAxisRoute) {
    return perAxisRoute != 0 ? decodeDepthPerAxis(encoded) : decodeDepthSingle(encoded);
}
inline int decodeFlipRoute(int encoded, int perAxisRoute) {
    return perAxisRoute != 0 ? decodeFlipPerAxis(encoded) : decodeFlipSingle(encoded);
}

// Framebuffer composite key of a single-canvas stored distance — mirror of
// compositeCanvasDistance in ir_iso_common.glsl. While the per-axis scatter
// co-renders, its continuous key carries no face bits, so a gather drawn
// beside it drops the stored (flip << 2) | slot too. Cardinal composites keep
// the bits.
inline int compositeCanvasDistance(int rawDist, bool faceFree) {
    return faceFree ? decodeDepthSingle(rawDist) * kDepthEncodeShift : rawDist;
}

// Two-tier composite depth partition. The most-negative
// kDepthForegroundBandWidth codes of [kMinTriangleDistance, kMaxTriangleDistance]
// are reserved for foreground-priority detached solids: trixel_to_framebuffer
// clamps WORLD content out of the band and pins FOREGROUND content into it, so a
// priority solid is unconditionally nearer than any world fragment regardless of
// world extent. Mirrors IRRender::kDepthForegroundBandWidth (ir_render_types.hpp)
// and the GLSL twin (ir_iso_common.glsl).
constant int kDepthForegroundBandWidth = 16384;

// Per-trixel priority tiers — twin of ir_iso_common.glsl. Subdivide the
// reserved foreground band into N-1 disjoint equal-width tiers; tier 0 = world
// (out of band). MORE-negative = higher priority (tier N-1 at the near band edge).
// trixel_to_framebuffer selects tier = max(perEntityTier, perTrixelTier).
// Mirror IRRender::kDepthForegroundTier* + the GLSL twin.
constant int kDepthForegroundTierCount = 3;
constant int kDepthForegroundTierWidth = kDepthForegroundBandWidth / (kDepthForegroundTierCount - 1);
inline int depthForegroundTierLo(int kMin, int tier) {
    return kMin + (kDepthForegroundTierCount - 1 - tier) * kDepthForegroundTierWidth;
}
inline int depthForegroundTierHi(int kMin, int tier) {
    return depthForegroundTierLo(kMin, tier) + kDepthForegroundTierWidth - 1;
}
inline int depthForegroundTierCenter(int kMin, int tier) {
    return depthForegroundTierLo(kMin, tier) + kDepthForegroundTierWidth / 2;
}

// Per-trixel priority carrier — twin of ir_iso_common.glsl. The per-trixel
// tier rides the top K=2 bits of the 64-bit entity id stored in triangleEntityIds
// (uint2: .x = low word, .y = high word; carrier = bits 30..31 of the high word).
// THE chokepoint: every reader masks via decodeEntityId, the stage-2 writer packs
// via encodeEntityIdWithPriority. Priority 0 ⇒ id unchanged.
constant uint kEntityIdPriorityShiftInHighWord = 30u;
constant uint kEntityIdPriorityMaskInHighWord = 0x3u << kEntityIdPriorityShiftInHighWord;
// Fog cut-face carrier — GLSL twin's kEntityIdCutFaceMaskInHighWord. Bit 29
// flags a fog cross-section CUT face so LIGHTING_TO_TRIXEL forces it fully lit
// (no self-shadow / crease AO). Rides the same masking chokepoint; a non-cut
// face leaves the id unchanged.
constant uint kEntityIdCutFaceMaskInHighWord = 0x1u << 29u;
// Fog BODY carrier — GLSL twin's kEntityIdFogBody* constants. Bit 28 flags a
// BODY-classed pixel and bits 27:20 carry its 8-bit reveal factor, so
// FOG_TO_TRIXEL paints the pixel at factor / 255 with no field lookup. Rides
// the same masking chokepoint.
constant uint kEntityIdFogBodyMaskInHighWord = 0x1u << 28u;
constant uint kEntityIdFogWholeBodyMaskInHighWord = kEntityIdFogBodyMaskInHighWord;
constant uint kEntityIdFogBodyFactorShiftInHighWord = 20u;
constant uint kEntityIdFogBodyFactorMaskInHighWord = 0xFFu << kEntityIdFogBodyFactorShiftInHighWord;
// Analytic-surface carrier — GLSL twin's kEntityIdAnalyticSurfaceMaskInHighWord.
// Bit 19 flags a pixel the shape raster wrote (an exact world surface point)
// as opposed to a voxel raster point on the lower-corner cell lattice. Rides
// the same masking chokepoint.
constant uint kEntityIdAnalyticSurfaceMaskInHighWord = 0x1u << 19u;
// Positive provenance of a settled non-detached voxel raster sample.
constant uint kEntityIdCardinalVoxelMaskInHighWord = 0x1u << 18u;
constant uint kEntityIdHighWordMask =
    ~(kEntityIdPriorityMaskInHighWord | kEntityIdCutFaceMaskInHighWord |
      kEntityIdFogBodyMaskInHighWord | kEntityIdFogBodyFactorMaskInHighWord |
      kEntityIdAnalyticSurfaceMaskInHighWord | kEntityIdCardinalVoxelMaskInHighWord);
inline uint decodePriority(uint2 rawId) {
    return (rawId.y >> kEntityIdPriorityShiftInHighWord) & 0x3u;
}
inline bool decodeCutFace(uint2 rawId) {
    return (rawId.y & kEntityIdCutFaceMaskInHighWord) != 0u;
}
inline bool decodeFogBody(uint2 rawId) {
    return (rawId.y & kEntityIdFogBodyMaskInHighWord) != 0u;
}
inline bool decodeFogWholeBody(uint2 rawId) {
    return decodeFogBody(rawId);
}
// The BODY reveal factor in 0..255; meaningful only when decodeFogBody.
inline uint decodeFogBodyFactor(uint2 rawId) {
    return (rawId.y >> kEntityIdFogBodyFactorShiftInHighWord) & 0xFFu;
}
inline bool decodeAnalyticSurface(uint2 rawId) {
    return (rawId.y & kEntityIdAnalyticSurfaceMaskInHighWord) != 0u;
}
inline bool decodeEntityIdCardinalVoxel(uint2 rawId) {
    return (rawId.y & kEntityIdCardinalVoxelMaskInHighWord) != 0u;
}
inline uint2 decodeEntityId(uint2 rawId) {
    return uint2(rawId.x, rawId.y & kEntityIdHighWordMask);
}
inline uint2 encodeEntityIdWithPriority(uint2 id, uint priority) {
    return uint2(id.x, (id.y & kEntityIdHighWordMask) |
                           ((priority & 0x3u) << kEntityIdPriorityShiftInHighWord));
}
// Set the fog cut-face flag on an ALREADY priority-encoded id — GLSL twin.
// `packedId` mirrors the GLSL side, where `packed` is a reserved keyword
// (NVIDIA rejects it as an identifier); keep the twins in lockstep.
inline uint2 encodeEntityIdCutFace(uint2 packedId, bool isCutFace) {
    return isCutFace ? uint2(packedId.x, packedId.y | kEntityIdCutFaceMaskInHighWord)
                     : packedId;
}
// Fold the fog BODY class bit and its 8-bit reveal factor into an ALREADY
// priority-encoded id — GLSL twin. A non-BODY leaves the id unchanged.
inline uint2 encodeEntityIdFogBody(uint2 packedId, bool isFogBody, uint factor) {
    return isFogBody
        ? uint2(packedId.x, packedId.y | kEntityIdFogBodyMaskInHighWord |
                                ((factor & 0xFFu) << kEntityIdFogBodyFactorShiftInHighWord))
        : packedId;
}
inline uint2 encodeEntityIdCardinalVoxel(uint2 packedId) {
    return uint2(packedId.x, packedId.y | kEntityIdCardinalVoxelMaskInHighWord);
}

// Set the analytic-surface flag on an ALREADY priority-encoded id — GLSL twin.
inline uint2 encodeEntityIdAnalyticSurface(uint2 packedId) {
    return uint2(packedId.x, packedId.y | kEntityIdAnalyticSurfaceMaskInHighWord);
}
// A subject whose raster route carries no factor of its own (a flagged SDF
// shape) renders whole: the class bit with the factor pinned at 255.
inline uint2 encodeEntityIdFogWholeBody(uint2 packedId, bool isFogWholeBody) {
    return encodeEntityIdFogBody(packedId, isFogWholeBody, 255u);
}
// Overflow word 0: x in bits 15:0, y in 30:16, cut-face provenance in 31.
// PerAxisCanvasStore::allocate bounds the canvas height below 32768 cells.
constant uint kOverflowCutFaceBit = 0x80000000u;
inline uint packOverflowEntryCell(int2 cell, bool isCutFace) {
    return uint(cell.x) | (uint(cell.y) << 16u) |
           (isCutFace ? kOverflowCutFaceBit : 0u);
}
inline uint overflowEntryCell(uint word) {
    return word & ~kOverflowCutFaceBit;
}
inline bool overflowEntryIsCutFace(uint word) {
    return (word & kOverflowCutFaceBit) != 0u;
}

// Overflow-entry fog class byte — GLSL twin: 255 FIELD, a BODY factor rescaled
// onto 0..254.
constant uint kFogOverflowFieldByte = 255u;
inline uint encodeFogOverflowClassByte(bool isFogBody, uint factor) {
    return isFogBody ? ((factor & 0xFFu) * 254u + 127u) / 255u : kFogOverflowFieldByte;
}

// Per-axis fractional encoding:
// (depth << 15) | (wFrac4 << 11) | (flip << 10) | (uFrac4 << 6)
// | (vFrac4 << 2) | slot. Frac fields in 0..15 where 8 = cell centre
// (fracInCell = 0): u/v are the face's in-plane sub-cell offsets, w the
// out-of-plane offset along the face axis. atomicMin orders by depth first,
// then wFrac (the true-plane-depth remainder — a same-cell nearer plane
// wins), then flip — the same relative invariant as the single-canvas
// encode. Per-axis canvases clear to INT_MAX (0x7FFFFFFF) so any valid
// encoding overwrites the sentinel. rawDepth must be in world units; the
// depth field is 17 bits so rawDepth must stay < 2^16.
inline int encodeDepthWithFaceFrac(
    int rawDepth, int slot, int uFrac4, int vFrac4, int wFrac4, int flip
) {
    return (rawDepth << 15) | (wFrac4 << 11) | (flip << 10) | (uFrac4 << 6) |
           (vFrac4 << 2) | slot;
}

// Maps fracInCell to the three 4-bit sub-cell offsets (0..15, 8 = cell
// centre) for the given axis: u/v follow the uv assignment of
// faceInPlaneUnitAxes; w is the fracInCell component along the face axis.
inline void fracToFrac4(
    int axis, float3 fracInCell, thread int& uFrac4, thread int& vFrac4, thread int& wFrac4
) {
    if (axis == 0) {
        uFrac4 = clamp(int(fracInCell.y * 16.0) + 8, 0, 15);
        vFrac4 = clamp(int(fracInCell.z * 16.0) + 8, 0, 15);
        wFrac4 = clamp(int(fracInCell.x * 16.0) + 8, 0, 15);
    } else if (axis == 1) {
        uFrac4 = clamp(int(fracInCell.x * 16.0) + 8, 0, 15);
        vFrac4 = clamp(int(fracInCell.z * 16.0) + 8, 0, 15);
        wFrac4 = clamp(int(fracInCell.y * 16.0) + 8, 0, 15);
    } else {
        uFrac4 = clamp(int(fracInCell.x * 16.0) + 8, 0, 15);
        vFrac4 = clamp(int(fracInCell.y * 16.0) + 8, 0, 15);
        wFrac4 = clamp(int(fracInCell.z * 16.0) + 8, 0, 15);
    }
}

inline int encodeDepthWithFaceFrac(int rawDepth, int slot, int axis, float3 fracInCell, int flip) {
    int uFrac4, vFrac4, wFrac4;
    fracToFrac4(axis, fracInCell, uFrac4, vFrac4, wFrac4);
    return encodeDepthWithFaceFrac(rawDepth, slot, uFrac4, vFrac4, wFrac4, flip);
}

// Unit vector of a face's out-of-plane axis — the direction the wFrac
// offset moves the reconstructed plane. Companion to faceInPlaneUnitAxes.
inline float3 faceOutOfPlaneUnitAxis(int axis) {
    return float3(axis == 0 ? 1.0 : 0.0, axis == 1 ? 1.0 : 0.0, axis == 2 ? 1.0 : 0.0);
}

// Outward unit normal for the visible side of each iso-rendered face. The
// iso projection has view direction (1,1,1), so a camera at
// (-large,-large,-large) sees the faces whose outward normals point
// AGAINST the view direction — -X, -Y, -Z (+Z is down, so -Z is up = the
// top face). Used by AO sampling (step out of the surface) and lighting
// lambert (dot with sun direction); both consumers MUST share this so
// they agree on "out". GLSL mirror lives in ir_iso_common.glsl.
inline float3 faceOutwardNormal(int face) {
    if (face == kXFace) return float3(-1.0, 0.0, 0.0);
    if (face == kYFace) return float3(0.0, -1.0, 0.0);
    return float3(0.0, 0.0, -1.0);
}

inline int3 faceOutwardNormalI(int face) {
    if (face == kXFace) return int3(-1, 0, 0);
    if (face == kYFace) return int3(0, -1, 0);
    return int3(0, 0, -1);
}

// Six-face polarity-aware outward unit normal. `faceId` must be one of
// `kFaceXNeg`/.../`kFaceZPos` (0..5) — typically read from
// `visibleFaceIds[slot]`. Mirrors `faceOutwardNormal6` in
// shaders/ir_iso_common.glsl and `IRMath::faceOutwardNormal(FaceId)`.
inline float3 faceOutwardNormal6(int faceId) {
    if (faceId == kFaceXNeg) return float3(-1.0, 0.0, 0.0);
    if (faceId == kFaceXPos) return float3( 1.0, 0.0, 0.0);
    if (faceId == kFaceYNeg) return float3(0.0, -1.0, 0.0);
    if (faceId == kFaceYPos) return float3(0.0,  1.0, 0.0);
    if (faceId == kFaceZNeg) return float3(0.0, 0.0, -1.0);
    return float3(0.0, 0.0, 1.0);  // kFaceZPos
}

inline int3 faceOutwardNormal6I(int faceId) {
    if (faceId == kFaceXNeg) return int3(-1, 0, 0);
    if (faceId == kFaceXPos) return int3( 1, 0, 0);
    if (faceId == kFaceYNeg) return int3(0, -1, 0);
    if (faceId == kFaceYPos) return int3(0,  1, 0);
    if (faceId == kFaceZNeg) return int3(0, 0, -1);
    return int3(0, 0, 1);  // kFaceZPos
}

// True when face `faceId` is exposed (neighbor cell empty). Encoding
// mirrors `IRComponents::VoxelFlags::kFaceOccluded*`: bit `(2 + faceId)`
// set ⟺ neighbor exists ⟺ face occluded ⟺ skip emit.
inline bool faceIsExposed(uint flagsByte, int faceId) {
    return ((flagsByte >> uint(2 + faceId)) & 1u) == 0u;
}

inline int3 faceMicroPositionFixed(
    int face,
    int3 voxelPositionFixed,
    int u,
    int v
) {
    if (face == kXFace) {
        return int3(
            voxelPositionFixed.x,
            voxelPositionFixed.y + u,
            voxelPositionFixed.z + v
        );
    }
    if (face == kYFace) {
        return int3(
            voxelPositionFixed.x + u,
            voxelPositionFixed.y,
            voxelPositionFixed.z + v
        );
    }
    return int3(
        voxelPositionFixed.x + u,
        voxelPositionFixed.y + v,
        voxelPositionFixed.z
    );
}

// Six-face polarity-aware micro position. For POS faces the fixed-axis
// coordinate sits at `voxelPositionFixed.<axis> + subdivisions`; for NEG
// faces it sits at `voxelPositionFixed.<axis>` (identical to the 3-face
// overload). Mirrors `faceMicroPositionFixed6` in shaders/ir_iso_common.glsl.
inline int3 faceMicroPositionFixed6(
    int faceId,
    int3 voxelPositionFixed,
    int u,
    int v,
    int subdivisions
) {
    if (faceId == kFaceXNeg) {
        return int3(
            voxelPositionFixed.x,
            voxelPositionFixed.y + u,
            voxelPositionFixed.z + v
        );
    }
    if (faceId == kFaceXPos) {
        return int3(
            voxelPositionFixed.x + subdivisions,
            voxelPositionFixed.y + u,
            voxelPositionFixed.z + v
        );
    }
    if (faceId == kFaceYNeg) {
        return int3(
            voxelPositionFixed.x + u,
            voxelPositionFixed.y,
            voxelPositionFixed.z + v
        );
    }
    if (faceId == kFaceYPos) {
        return int3(
            voxelPositionFixed.x + u,
            voxelPositionFixed.y + subdivisions,
            voxelPositionFixed.z + v
        );
    }
    if (faceId == kFaceZNeg) {
        return int3(
            voxelPositionFixed.x + u,
            voxelPositionFixed.y + v,
            voxelPositionFixed.z
        );
    }
    // kFaceZPos
    return int3(
        voxelPositionFixed.x + u,
        voxelPositionFixed.y + v,
        voxelPositionFixed.z + subdivisions
    );
}

inline bool isInsideCanvas(int2 pixel, int2 canvasSize) {
    return pixel.x >= 0 && pixel.x < canvasSize.x &&
           pixel.y >= 0 && pixel.y < canvasSize.y;
}

// Shadow-feeder classification: on the cardinal single-canvas world route, a
// voxel whose cardinal iso position lies outside the UN-widened visible
// viewport but inside the shadow-feeder-widened cull exists only to cast sun
// shadows onto on-screen pixels through stage 1's distance bake — it is never
// displayed, lit, or picked.
//
// Two kernels ask this same question and must agree: c_voxel_visibility_compact
// partitions survivors into the visible list vs the strided off-screen feeder
// list, and c_voxel_to_trixel_stage_2 skips a feeder's colour + entity-id taps.
// A voxel the compact calls VISIBLE while stage 2 skips it drops an on-screen
// pixel's colour, so over-classifying VISIBLE is the only safe failure
// direction.
//
// The route terms are part of the predicate, not a caller-side gate: the
// widened cull only exists on the cardinal (residualYaw == 0) world
// (isDetachedCanvas < 0.5) route, so both terms must hold before an
// out-of-bounds iso means "feeder". When sun shadows are off,
// visibleIsoBounds == cullIsoMin/Max and this never fires.
inline bool isShadowFeederIso(
    int2 isoPos,
    int4 visibleIsoBounds,
    float residualYaw,
    float isDetachedCanvas
) {
    return residualYaw == 0.0f && isDetachedCanvas < 0.5f &&
        (isoPos.x < visibleIsoBounds.x || isoPos.x > visibleIsoBounds.z ||
         isoPos.y < visibleIsoBounds.y || isoPos.y > visibleIsoBounds.w);
}

// Hardware round() is safe here: the 1e-4 near-grid gate excludes
// half-integer inputs, so the tie direction — the only point where
// round() can differ from the GLSL twin — is unobservable.
inline float3 snapNearIntegerVoxelPosition(float3 voxelPosition) {
    float3 voxelRounded = round(voxelPosition);
    bool3 nearGrid = abs(voxelPosition - voxelRounded) <= float3(0.0001);
    return select(voxelPosition, voxelRounded, nearGrid);
}

// Round-half-up: rounds to the nearest integer, ties go UP. Mirrors
// `IRMath::roundHalfUp` (engine/math/include/irreden/ir_math.hpp) so any
// CPU↔GPU coordinate handshake (occupancy grid build, ray-march cell sampling)
// resolves half-integer voxel positions to the same cell on both sides.
// Hardware `round()` is implementation-defined at half-integers and cannot be
// trusted for that handshake.
inline int3 roundHalfUp(float3 v) {
    return int3(floor(v + float3(0.5)));
}

// Per-axis faces encode translation in signed sixteenths, independent of
// subdivisions. Axis 2 maps the packed u/v/w fractions to world x/y/z.
inline float3 perAxisRenderedVoxelCenter(float3 voxelPosition) {
    const float3 aligned = snapNearIntegerVoxelPosition(voxelPosition);
    const int3 cell = roundHalfUp(aligned);
    int u, v, w;
    fracToFrac4(2, aligned - float3(cell), u, v, w);
    return float3(cell) + (float3(u, v, w) / 16.0 - float3(0.5));
}

inline int roundHalfUp(float v) {
    return int(floor(v + 0.5f));
}

inline int2 roundHalfUp(float2 v) {
    return int2(floor(v + float2(0.5)));
}

// Unit-vector components as exact UNORM8 codes: -1 → 0, 0 → 128, +1 → 255.
// A bare `v * 0.5 + 0.5` leaves the 0.5 midpoint to the store's float-to-unorm
// conversion, which is implementation-defined at that tie (127 or 128), so
// debug colours read back exactly only when the shader rounds them itself.
inline float3 encodeUnitVectorUnorm8(float3 v) {
    return float3(roundHalfUp(v * 127.5f + 127.5f)) / 255.0f;
}

// Raw canvas position of the gather fragment at raster-target pixel
// `fragmentPixel` (fragment position.xy; the vertex stage's clip-Y negation
// makes it equal OpenGL's gl_FragCoord.xy). `canvasFromPixel` holds the quad
// centre in raster-target pixels (.xy) and canvas texels per raster pixel (.zw);
// canvas Y runs down the screen. Evaluated per fragment, never interpolated:
// with a power-of-two scale and a centre on the half-pixel lattice every term is
// exact, so a pixel centre on a texel boundary selects the same texel on every GPU.
inline float2 canvasPositionFromPixel(float2 fragmentPixel, float4 canvasFromPixel,
                                      float2 textureOffset, float2 textureSize) {
    return (fragmentPixel - canvasFromPixel.xy) * float2(1.0f, -1.0f) * canvasFromPixel.zw +
           textureOffset + 0.5f * textureSize;
}

// Per-voxel iso occlusion depth of model position `pos` projected onto a
// (possibly entity-rotated) iso depth `axis` — the SO(3) generalization of
// pos3DtoDistance (identical to it when axis == (1,1,1)). For a rotated
// DETACHED canvas `axis` is `R⁻¹·(1,1,1)` (uploaded in
// FrameDataVoxelToTrixel.voxelDepthAxis); the world canvas keeps (1,1,1).
// CPU twin: IRMath::isoDepthAlongAxis — roundHalfUp keeps the half-integer
// rounding bit-identical across the CPU/GPU boundary.
inline int isoDepthAlongAxis(int3 pos, float3 axis) {
    return roundHalfUp(dot(float3(pos), axis));
}

inline int2 trixelOriginOffsetX1(int2 trixelCanvasSize) {
    return trixelCanvasSize / int2(2);
}

inline int2 trixelOriginOffsetZ1(int2 trixelCanvasSize) {
    return trixelOriginOffsetX1(trixelCanvasSize) + int2(-1, -1);
}

inline int trixelOriginModifier(int2 trixelCanvasOffsetZ1, float2 frameCanvasOffset) {
    const float2 canvasOffsetFloored = floor(frameCanvasOffset);
    return (
        trixelCanvasOffsetZ1.x + trixelCanvasOffsetZ1.y +
        int(canvasOffsetFloored.x) + int(canvasOffsetFloored.y)
    ) & 1;
}

// Clamp a float canvas-pixel position into a valid `texture.read()` index;
// `texture.read()` has no edge handling of its own. The GLSL twin
// (`trixelCanvasReadCoord` in `ir_iso_common.glsl`) applies the same explicit
// clamp before its `texelFetch()`, so both backends pick the same texel.
inline uint2 trixelCanvasReadCoord(float2 origin, float2 textureSize) {
    return uint2(clamp(origin, float2(0.0f), textureSize - float2(1.0f)));
}

// Mirror of `trixelFramebufferSamplePosition` in `ir_iso_common.glsl` — the
// parity bit + fract sub-pixel test pick which of the iso cell's two trixels
// a canvas position maps to, byte-identical to GLSL/CPU `pos2DIsoToTriangleIndex`.
//
// The trixel->framebuffer gather does not use it in RECTANGULAR display:
// every texture read — color, depth, tier and the hover entity id — and the
// hover compare sample the raw texel (the cell it selects straddles two raw
// texel rows, so it cannot name one stored texel). LOCAL_TRIANGLES supplies
// canvas-local parity and a row-corrected query through
// localTrixelFramebufferSamplePosition; its caller rejects out-of-bounds
// results before texture reads.
// Shifting the RECTANGULAR color/depth reads produces a 1px sawtooth on every
// iso-diagonal and vertical silhouette plus a garbage top-canvas-row line
// (`origin.y - 1` underflow at row 0). Derivation:
// docs/design/trixel-parity-shift-442-investigation.md.
inline float2 trixelFramebufferSamplePosition(float2 origin, int originModifier) {
    const float2 originFloored = floor(origin);
    const float2 fractComp = fract(origin);
    const int parity = (int(originFloored.x) + int(originFloored.y) + originModifier) & 1;
    if (parity != 0) {
        if (fractComp.y < fractComp.x) {
            origin.y -= 1.0f;
        }
    } else if (fractComp.y < 1.0f - fractComp.x) {
        origin.y -= 1.0f;
    }
    return origin;
}

// Private storage parity excludes the world placement of the canvas quad.
inline int localTrixelOriginParity(int2 originZ1) {
    return (originZ1.x + originZ1.y) & 1;
}

inline float2 localTrixelCellCentroid(int2 cell, int originParity) {
    const bool odd = ((cell.x + cell.y + originParity) & 1) != 0;
    return float2(cell) + float2(odd ? 1.0 / 3.0 : 2.0 / 3.0, 0.0);
}

// A local display triangle is centered one row below its stored index.
inline float2 localTrixelFramebufferSamplePosition(float2 origin, int2 originZ1) {
    return trixelFramebufferSamplePosition(
        origin + float2(0.0, 1.0), localTrixelOriginParity(originZ1));
}

inline int effectiveTrixelSubdivisionScale(int2 voxelRenderOptions) {
    return voxelRenderOptions.x != 0 ? max(voxelRenderOptions.y, 1) : 1;
}

inline int2 trixelFrameOffset(
    int2 trixelCanvasOffsetZ1,
    float2 frameCanvasOffset,
    int2 voxelRenderOptions
) {
    const int scale = effectiveTrixelSubdivisionScale(voxelRenderOptions);
    return trixelCanvasOffsetZ1 + int2(floor(frameCanvasOffset * float(scale)));
}

// The per-axis store origin is the frame data's `perAxisStoreFrame.xy` —
// whole-iso, NOT density-scaled (per-axis canvases are base-resolution, so a
// scaled origin jitters under pan) — and each per-axis site reads it directly,
// not through a helper centralised here, so this shared header gains no symbol
// that would perturb FP scheduling and drift the cardinal SDF/voxel fast path.

inline int2 trixelCanvasPixelToIsoRel(
    int2 pixel,
    int2 trixelCanvasOffsetZ1,
    float2 frameCanvasOffset,
    int2 voxelRenderOptions
) {
    return pixel - trixelFrameOffset(trixelCanvasOffsetZ1, frameCanvasOffset, voxelRenderOptions);
}

// Cardinal Z-yaw helpers; bodies match shaders/ir_iso_common.glsl line-for-line.
// rotateCardinalZ is world->view = R_z(-rasterYaw), the same convention as the
// continuous-yaw shape projection; voxels and shapes MUST share it or they
// desync at non-zero yaw.

inline int rasterYawCardinalIndex(float rasterYaw) {
    // CPU snaps visualYaw to a multiple of pi/2 (Camera::computeYawSplit) so
    // this index pick is exact at floats that survived the UBO upload. The
    // round() defends against bit-wise drift only; it is not the cardinal-snap
    // policy itself. Negative inputs (yaw=-pi/2 -> q=-1) fold via the (mod 4 +
    // 4) mod 4 clamp.
    constexpr float kHalfPi = 1.5707963267948966f;
    int q = int(round(rasterYaw / kHalfPi));
    return ((q % 4) + 4) % 4;
}

// (cos, sin) of the cardinal angle named by cardinalIndex — exact ±1/0, the
// snapped Z-yaw the GRID rasterizer projects at. Mirrors
// IRMath::cardinalYawCosSin and ir_iso_common.glsl.
inline float2 cardinalYawCosSin(int cardinalIndex) {
    if (cardinalIndex == 1) return float2( 0.0,  1.0);
    if (cardinalIndex == 2) return float2(-1.0,  0.0);
    if (cardinalIndex == 3) return float2( 0.0, -1.0);
    return float2(1.0, 0.0);
}

inline int3 rotateCardinalZ(int3 v, int cardinalIndex) {
    if (cardinalIndex == 1) return int3( v.y, -v.x, v.z);   // R_z(-pi/2)
    if (cardinalIndex == 2) return int3(-v.x, -v.y, v.z);   // R_z(+/-pi)
    if (cardinalIndex == 3) return int3(-v.y,  v.x, v.z);   // R_z(+pi/2)
    return v;
}

// Mirror of `cardinalLowerCornerShift` in shaders/ir_iso_common.glsl: the
// view-space lower-corner displacement of the rotated unit voxel. The raster
// store and its inverses do NOT apply it — they use the plain rotated position;
// adding the shift rotates the voxel mass about `position + (0.5,0.5,0.5)`
// instead of the exact position the SDF path and CPU picking rotate about.
inline int3 cardinalLowerCornerShift(int cardinalIndex) {
    if (cardinalIndex == 1) return int3(0, -1, 0);
    if (cardinalIndex == 2) return int3(-1, -1, 0);
    if (cardinalIndex == 3) return int3(-1, 0, 0);
    return int3(0, 0, 0);
}

// Image of a six-face FaceId's outward normal under rotateCardinalZ (world ->
// view) — mirror of rotateFaceIdCardinalZ in ir_iso_common.glsl. Face
// micro-positions are computed natively in view space on the rotated cell: a
// cell index and a face plane map differently under axis negation, so rotating
// a world-frame POS-face plane opens a background seam along shared edges at
// cardinals 1/2/3.
inline int rotateFaceIdCardinalZ(int faceId, int cardinalIndex) {
    if (cardinalIndex == 0 || faceId >= kFaceZNeg) return faceId;
    if (cardinalIndex == 2) return faceId ^ 1;             // +/-x -> -/+x, +/-y -> -/+y
    if (cardinalIndex == 1) {
        // world +x -> view -y, world +y -> view +x
        if (faceId == kFaceXNeg) return kFaceYPos;
        if (faceId == kFaceXPos) return kFaceYNeg;
        if (faceId == kFaceYNeg) return kFaceXNeg;
        return kFaceXPos;                                  // kFaceYPos
    }
    // cardinalIndex == 3: world +x -> view +y, world +y -> view -x
    if (faceId == kFaceXNeg) return kFaceYNeg;
    if (faceId == kFaceXPos) return kFaceYPos;
    if (faceId == kFaceYNeg) return kFaceXPos;
    return kFaceXNeg;                                      // kFaceYPos
}

inline float3 rotateCardinalZInv(float3 v, int cardinalIndex) {
    if (cardinalIndex == 1) return float3(-v.y,  v.x, v.z); // R_z(+pi/2)
    if (cardinalIndex == 2) return float3(-v.x, -v.y, v.z); // R_z(+/-pi)
    if (cardinalIndex == 3) return float3( v.y, -v.x, v.z); // R_z(-pi/2)
    return v;
}

inline int3 rotateCardinalZInvI(int3 v, int cardinalIndex) {
    if (cardinalIndex == 1) return int3(-v.y,  v.x, v.z);   // R_z(+pi/2)
    if (cardinalIndex == 2) return int3(-v.x, -v.y, v.z);   // R_z(+/-pi)
    if (cardinalIndex == 3) return int3( v.y, -v.x, v.z);   // R_z(-pi/2)
    return v;
}

inline float3 isoPixelToWorld3D(int isoX, int isoY, float depth, int cardinalIndex) {
    return rotateCardinalZInv(isoPixelToPos3D(isoX, isoY, depth), cardinalIndex);
}

inline float3 trixelCanvasPixelToWorld3D(
    int2 pixel,
    int rawDepth,
    int2 trixelCanvasOffsetZ1,
    float2 frameCanvasOffset,
    int2 voxelRenderOptions,
    int cardinalIndex
) {
    const int scale = effectiveTrixelSubdivisionScale(voxelRenderOptions);
    const int2 isoRel =
        trixelCanvasPixelToIsoRel(pixel, trixelCanvasOffsetZ1, frameCanvasOffset, voxelRenderOptions);
    float3 pos3D = isoPixelToPos3D(isoRel.x, isoRel.y, float(rawDepth));
    if (scale > 1) {
        pos3D /= float(scale);
    }
    if (cardinalIndex != 0) {
        // The rasterizer stores the plain rotated position (no lower-corner
        // shift), so the inverse is the plain cardinal rotation back to world.
        pos3D = rotateCardinalZInv(pos3D, cardinalIndex);
    }
    return pos3D;
}

inline float3 trixelCanvasPixelToWorld3D(
    int2 pixel,
    int rawDepth,
    int2 trixelCanvasOffsetZ1,
    float2 frameCanvasOffset,
    int2 voxelRenderOptions,
    float rasterYaw
) {
    return trixelCanvasPixelToWorld3D(
        pixel, rawDepth, trixelCanvasOffsetZ1, frameCanvasOffset, voxelRenderOptions,
        rasterYawCardinalIndex(rasterYaw)
    );
}

// View frame -> world frame under a continuous camera Z-yaw: R_z(+yaw)·v, the
// smooth companion to rotateCardinalZInv (pos3DtoPos2DIsoYawed projects the
// view point R_z(-yaw)·world, so this is its rotation inverse).
inline float3 rotateYawZInv(float3 v, float yaw) {
    const float c = cos(yaw);
    const float s = sin(yaw);
    return float3(c * v.x - s * v.y, s * v.x + c * v.y, v.z);
}

// Smooth-camera-yaw inverse of the smooth-yaw SDF store: those pixels are
// placed at roundHalfUp(pos3DtoPos2DIsoYawed(world, visualYaw)) with the
// VIEW-frame iso depth, so recover the view-frame point with the
// cardinal-frame solver and rotate back by the full +visualYaw. No
// lower-corner shift — the smooth store never applies one. Identical to
// trixelCanvasPixelToWorld3D at visualYaw == 0 (cos=1/sin=0, cardinal 0 takes
// the same shift-free path).
inline float3 trixelCanvasPixelToWorld3DSmoothYaw(
    int2 pixel,
    int rawDepth,
    int2 trixelCanvasOffsetZ1,
    float2 frameCanvasOffset,
    int2 voxelRenderOptions,
    float visualYaw
) {
    const int scale = effectiveTrixelSubdivisionScale(voxelRenderOptions);
    const int2 isoRel =
        trixelCanvasPixelToIsoRel(pixel, trixelCanvasOffsetZ1, frameCanvasOffset, voxelRenderOptions);
    float3 viewPos = isoPixelToPos3D(isoRel.x, isoRel.y, float(rawDepth));
    if (scale > 1) {
        viewPos /= float(scale);
    }
    return rotateYawZInv(viewPos, visualYaw);
}

// Continuous-yaw + per-face deformation math. Mirrors shaders/ir_iso_common.glsl
// and IRMath::pos3DtoPos2DIsoYawed / faceDeformationMatrix /
// deformedTrixelIsoPixel / sqtToMat4 / matrixApplyToVoxelGrid in
// engine/math/include/irreden/ir_math.hpp.

inline float2 pos3DtoPos2DIsoYawed(float3 worldPos, float visualYaw) {
    const float c = cos(visualYaw);
    const float s = sin(visualYaw);
    const float vx = worldPos.x * c + worldPos.y * s;
    const float vy = -worldPos.x * s + worldPos.y * c;
    return float2(-vx + vy, -vx - vy + 2.0f * worldPos.z);
}

// Rotation anchor for VOXEL-RASTER cell positions — mirror of
// ir_iso_common.glsl: the raster's lower-corner cell lattice renders displaced
// by -h so the mass rotates about the authored position (exact no-op at yaw 0 —
// iso(0.5,0.5,0.5) == (0,0)). Placement uses pos3DtoPos2DIsoYawedCellAnchor;
// depth keys use yawedIsoDistanceCellAnchor. Exact world positions (SDF
// centers, entity translations) use the un-anchored forms. The correction is
// CONTINUOUS in yaw — do not quantize it: a whole-cell or whole-pixel
// quantization steps the whole layer at rounding crossings during a yaw sweep.
constant float3 kVoxelRasterCellAnchor = float3(0.5f);

// Mirror of cardinalRasterLatticeDepthOffset in ir_iso_common.glsl.
inline int cardinalRasterLatticeDepthOffset(int subdivisions) {
    return (3 * subdivisions + 1) / 2;
}

inline float2 pos3DtoPos2DIsoYawedCellAnchor(float3 rasterPos, float visualYaw) {
    return pos3DtoPos2DIsoYawed(rasterPos - kVoxelRasterCellAnchor, visualYaw);
}

// Continuous-yaw iso depth — mirror of yawedIsoDistance in ir_iso_common.glsl.
// pos3DtoDistance(R_z(-visualYaw) * worldPos) = x(cos-sin) + y(sin+cos) + z, the
// one shared composite depth metric for SDF + per-axis voxels + the detached
// composite (CPU twin IRMath::pos3DtoDistanceYawed) so all three co-sort at
// every yaw; collapses to un-yawed x+y+z at cardinals.
inline float yawedIsoDistance(float3 worldPos, float visualYaw) {
    const float c = cos(visualYaw);
    const float s = sin(visualYaw);
    return worldPos.x * (c - s) + worldPos.y * (s + c) + worldPos.z;
}

// Cell-anchor twin of yawedIsoDistance — mirror of
// yawedIsoDistanceCellAnchor in ir_iso_common.glsl: composite depth of a
// raster cell/face position measured at its authored-lattice world point so
// voxel and SDF surfaces co-sort exactly at every residual.
inline float yawedIsoDistanceCellAnchor(float3 rasterPos, float visualYaw) {
    return yawedIsoDistance(rasterPos - kVoxelRasterCellAnchor, visualYaw);
}

// Exact (unquantized) composite depth key for a forward-scattered face corner —
// mirror of scatterCompositeDepthKey in ir_iso_common.glsl. encScale
// (kDepthEncodeShift × the effective subdivision) keeps the encodeDepthWithFace
// scale the SDF smooth-yaw gather is composited in (compositeCanvasDistance
// strips its face bits while this key is live); the face priority rides the
// tie band (scatterFinalDepth), never this key. Do not round it: a rounded key
// ties adjacent micro-cells on a foreshortened axis and lets draw order pick
// the farther quad on the sign-flip side of a bracket (wrong-voxel-color
// bands). Shared by every forward-scatter composite writer.
inline float scatterCompositeDepthKey(float3 rasterPos, float visualYaw, float encScale) {
    return yawedIsoDistanceCellAnchor(rasterPos, visualYaw) * encScale;
}

// Conservative XY growth of an axis-aligned half-extent swept under a Z-yaw of
// (cosYaw, sinYaw): each in-plane axis grows to |c|*hX + |s|*hY, Z unchanged.
// CPU mirror: IRMath::yawGrownIsoHalfExtent; GLSL mirror in ir_iso_common.glsl.
inline float3 yawGrownIsoHalfExtent(float3 halfExtent, float cosYaw, float sinYaw) {
    const float absC = abs(cosYaw);
    const float absS = abs(sinYaw);
    return float3(halfExtent.x * absC + halfExtent.y * absS,
                  halfExtent.x * absS + halfExtent.y * absC,
                  halfExtent.z);
}

// 2x2 deformation matrix per face for residual yaw. At residualYaw == 0 all
// three return identity. `face` uses the kXFace / kYFace / kZFace convention;
// other values return identity. CPU mirror: IRMath::faceDeformationMatrix.
inline float2x2 faceDeformationMatrix(int face, float residualYaw) {
    const float c = cos(residualYaw);
    const float s = sin(residualYaw);
    if (face == kXFace) {
        return float2x2(float2(c - s, 1.0f - (c + s)), float2(0.0f, 1.0f));
    }
    if (face == kYFace) {
        return float2x2(float2(c + s, c - s - 1.0f), float2(0.0f, 1.0f));
    }
    if (face == kZFace) {
        return float2x2(float2(c, -s), float2(s, c));
    }
    return float2x2(float2(1.0f, 0.0f), float2(0.0f, 1.0f));
}

inline int2 deformedTrixelIsoPixel(int face, int subPixel, float residualYaw) {
    const int2 unyawed = faceOffset_2x3(face, subPixel);
    const float2x2 D = faceDeformationMatrix(face, residualYaw);
    const float2 deformed = D * float2(unyawed);
    return int2(roundHalfUp(deformed.x), roundHalfUp(deformed.y));
}

// Rotates vector v by unit quaternion q = (qx, qy, qz, qw).
// CPU mirror: IRMath::rotateVectorByQuat.
inline float3 rotateByQuat(float3 v, float4 q) {
    float3 u = q.xyz;
    float w = q.w;
    float3 t = 2.0f * cross(u, v);
    return v + w * t + cross(u, t);
}

inline float3 rotateByInverseQuat(float3 v, float4 q) {
    return rotateByQuat(v, float4(-q.xyz, q.w));
}

// The two in-plane unit model axes (e_u, e_v) a face's scatter quad spans, by
// axis = faceId >> 1 (0=X spans y,z; 1=Y spans x,z; 2=Z spans x,y) — matching
// faceSpanCorner's cornerSel.x -> e_u, cornerSel.y -> e_v ordering. Mirror of
// the GLSL twin in ir_iso_common.glsl.
inline void faceInPlaneUnitAxes(int axis, thread float3& eu, thread float3& ev) {
    eu = (axis == 0) ? float3(0.0, 1.0, 0.0) : float3(1.0, 0.0, 0.0);
    ev = (axis == 2) ? float3(0.0, 1.0, 0.0) : float3(0.0, 0.0, 1.0);
}

// In-plane iso-pixel unit steps (su, sv) for a face's two in-plane world axes —
// the iso directions along which a re-voxelized cell's in-plane neighbour cells
// sit on screen. Mirror of the GLSL twin in ir_iso_common.glsl: the
// detached re-voxelize raster dilates each surface face's footprint by ±su / ±sv
// so the sub-cell gaps round-to-cell leaves between adjacent rotated cells fill
// with the nearest (occlusion-winning, correct-colour) surface face. Normalised
// to ~1px so the silhouette grows by at most a pixel along the surface, never
// across a concave notch.
inline void faceInPlaneIsoSteps(int faceId, thread int2& su, thread int2& sv) {
    float3 eu, ev;
    faceInPlaneUnitAxes(faceId >> 1, eu, ev);
    su = roundHalfUp(normalize(float2(pos3DtoPos2DIso(int3(eu)))));
    sv = roundHalfUp(normalize(float2(pos3DtoPos2DIso(int3(ev)))));
}

// Per-axis scatter quantizes final depth to a 16-step band and injects a
// priority-major face/cell code (rank2 << 2 | cell2) into that band. The code
// spans 0..15, so the band width and tie step must match the CPU assertion in
// ir_render_types.hpp and the final-depth helper in ir_scatter_depth.metal.
constant float kScatterCellTieStep = 1.0f / 8388608.0f;
constant float kScatterCellTieBand = 16.0f * kScatterCellTieStep;

// A face that recedes behind a surface it shares an edge with ties that
// surface at pixel centers on the edge. A fragment within this in-plane
// distance of its face's edge, in face units, yields one tie band when the
// face's depth grows toward its own interior across that edge; the face that
// advances toward its interior keeps the pixel.
constant float kScatterEdgeTieWidth = 1.0f / 32.0f;

// Builds the local->world matrix from an SQT triple (scale, quaternion
// rotation, translation). Composition is T * R * S; quaternion layout matches
// the engine canon: float4(qx, qy, qz, qw) with .w the scalar; identity is
// (0, 0, 0, 1). CPU mirror: IRMath::sqtToMat4.
inline float4x4 sqtToMat4(float3 scaleVec, float4 rotationQuat, float3 translation) {
    const float x = rotationQuat.x;
    const float y = rotationQuat.y;
    const float z = rotationQuat.z;
    const float w = rotationQuat.w;
    const float3 col0 = float3(1.0f - 2.0f * (y * y + z * z),
                               2.0f * (x * y + w * z),
                               2.0f * (x * z - w * y)) * scaleVec.x;
    const float3 col1 = float3(2.0f * (x * y - w * z),
                               1.0f - 2.0f * (x * x + z * z),
                               2.0f * (y * z + w * x)) * scaleVec.y;
    const float3 col2 = float3(2.0f * (x * z + w * y),
                               2.0f * (y * z - w * x),
                               1.0f - 2.0f * (x * x + y * y)) * scaleVec.z;
    return float4x4(
        float4(col0, 0.0f),
        float4(col1, 0.0f),
        float4(col2, 0.0f),
        float4(translation, 1.0f)
    );
}

inline int3 matrixApplyToVoxelGrid(float4x4 transformMat, int3 cell) {
    const float4 worldPos = transformMat * float4(float3(cell), 1.0f);
    return roundHalfUp(float3(worldPos.x, worldPos.y, worldPos.z));
}

// Frame data layout used by all voxel→trixel compute kernels.  Mirrors the
// FrameDataVoxelToTrixel UBO in the GLSL pipeline.  std140 padding rules from
// GLSL collapse cleanly into Metal's natural packing here.
struct FrameDataVoxelToTrixel {
    float2 frameCanvasOffset;
    int2 trixelCanvasOffsetZ1;
    int2 voxelRenderOptions;
    int2 voxelDispatchGrid;
    int voxelCount;
    // Smooth-camera-Z-yaw per-axis route selector (mirrors
    // FrameDataVoxelToCanvas::perAxisRoute_). 0 = single-canvas raster;
    // 1/2/3 = the X/Y/Z per-axis canvas pass.
    int perAxisRoute;
    int2 canvasSizePixels;
    int2 cullIsoMin;
    int2 cullIsoMax;
    float visualYaw;
    float rasterYaw;    // cardinal-snap basis selection
    // Residual yaw beyond rasterYaw; its per-face deformation is baked into
    // faceDeform[] CPU-side.
    float residualYaw;
    // 1.0 for a detached entity canvas, 0.0 for the world canvas. Gates
    // emitDeformedFace super-sampling to the detached path only.
    float isDetachedCanvas;
    // Per-slot deformation matrix packed column-major: .xy = col0, .zw =
    // col1 of `IRMath::faceDeformationMatrix(axis(visibleFaceIds[slot]),
    // residualYaw)`. **Indexed by visible-triplet SLOT (0/1/2)**, not by
    // axis — at non-zero cardinal the world face whose matrix lives at
    // slot s changes per `visibleFaceIds[s]`. Identity when residualYaw==0.
    // Mirrors the GLSL `vec4 faceDeform[3]`.
    float4 faceDeform[3];
    // Per-slot world FaceId (0..5) — the three camera-visible faces
    // resolved on the CPU via `IRMath::visibleFaceTripletCardinal`.
    // .w is std140 padding. Mirrors `ivec4 visibleFaceIds` in the GLSL
    // UBO declarations.
    int4 visibleFaceIds;
    // Model-frame iso depth axis `R⁻¹·(1,1,1)` for the per-voxel occlusion
    // metric. (1,1,1) for the world canvas / identity entity →
    // isoDepthAlongAxis collapses to x+y+z; a rotated DETACHED canvas uploads
    // IRMath::isoDepthAxisModel(rotation). .w is padding. Mirrors
    // `vec4 voxelDepthAxis` in the GLSL stage-1 UBO
    // and FrameDataVoxelToCanvas::voxelDepthAxis_. Other kernels that bind
    // this struct never read it.
    float4 voxelDepthAxis;
    // World-receive offset for an opt-in world-placed detached re-voxelize solid.
    // .xyz = the entity world cell origin (roundVec3HalfUp(translation)); .w =
    // 1.0 when worldPlaced_, else 0.0. c_lighting_to_trixel recovers world pos
    // as modelPos + .xyz and samples the shared world sun-shadow map + light
    // volume there; .w == 0 is the default screen-locked path. Mirrors
    // FrameDataVoxelToCanvas::detachedWorldReceive_. Also read by
    // c_voxel_to_trixel_stage_{1,2} to recover the world column for the fog
    // cut-face cross-section on a world-placed detached re-voxelize canvas.
    float4 detachedWorldReceive;
    // Un-widened (no shadow-feeder sweep) iso cull viewport for the depth-only
    // shadow-feeder path. .xy = floor(min), .zw = ceil(max). A voxel
    // inside [cullIsoMin, cullIsoMax] but OUTSIDE this box is an off-screen
    // shadow feeder — c_voxel_to_trixel_stage_2 skips its colour/entity-id taps
    // (stage 1 still wrote its full-res depth, all the bake + AO read). Mirrors
    // FrameDataVoxelToCanvas::visibleIsoBounds_. Other kernels never read it.
    int4 visibleIsoBounds;
    // Per-axis deterministic-winner resolve mode. 0 = the normal
    // distance store. 1 = the winner-resolve dispatch between the stage-1
    // store and stage 2: re-run the identical per-axis geometry and, for each
    // face whose encoded distance matches the settled per-cell atomic-min
    // winner, atomic-min the face's run-stable voxel pool index into the
    // per-cell winner scratch (buffer 28 = kBufferIndex_PerAxisResolveScratch,
    // transiently reused) — so stage 2's color/entity-id tap admits exactly
    // one of the equal-key faces. Mirrors FrameDataVoxelToCanvas::resolveMode_
    // (offset 192). Read only by c_voxel_to_trixel_stage_1.
    int resolveMode;
    // Per-voxel Hi-Z occlusion-cull gate. 0 = the compact's per-voxel test is
    // skipped; non-zero = the Hi-Z chain level count, so
    // c_voxel_visibility_compact samples level 0 at each surviving voxel and
    // drops globally-occluded ones. Mirrors
    // FrameDataVoxelToCanvas::occlusionCullMipCount_ (offset 196). Read only by
    // c_voxel_visibility_compact.
    int occlusionCullMipCount;
    // Shadow-feeder dispatch partition, mirroring
    // FrameDataVoxelToCanvas::feederSubCap_ / feederPassTailBase_ (offsets
    // 200/204). The compact tail-appends off-screen shadow feeders into a
    // second indirect struct; stage 1 rasters them in a second dispatch at a
    // strided micro-grid capped to feederSubCap per face edge. Read by the
    // compact + stage 1. WHICH pass a stage-1 kernel is (visible vs feeder) is
    // the COMPILE-TIME IR_FEEDER_PASS specialization, not a runtime flag lane —
    // the two lanes pack the 192..208 std140 row exactly.
    int feederSubCap;
    int feederPassTailBase;
    // Overflow scratch layout: region base offsets (in uints) into the
    // unified buffer-28 scratch + entry cap. .x = reserved, .y = ctrl block,
    // .z = overflow entries, .w = entry cap. Region 0 holds winner ids.
    // Mirrors FrameDataVoxelToCanvas::overflowScratchLayout_ (offset 208).
    int4 overflowScratchLayout;
    // Overflow-entry canonical-sort step descriptor, read only by
    // c_per_axis_overflow_sort between the mode-3 append and the overflow
    // draw: .x = pass mode (0 sentinel-fill, 1 fused local sort, 2 fused
    // strided slab), .y = stage size k, .z/.w = the mode-2 inclusive stride
    // bit-position window [pLo, pHi].
    // Mirrors FrameDataVoxelToCanvas::overflowSortStep_ (offset 224).
    int4 overflowSortStep;
    float4 detachedViewToWorld;
    // Frame the per-axis store is keyed in: .xy = store cell of the frame's iso
    // origin, .z = cardinal index of the view the key positions are rotated
    // into. Mirrors FrameDataVoxelToCanvas::perAxisStoreFrame_.
    int4 perAxisStoreFrame;
    // .x non-zero while the bound fog window has a ceiling-enabled source
    // live; face selection's one-uniform ceiling gate. Mirrors
    // FrameDataVoxelToCanvas::fogCeilingEnabled_ (offset 272).
    int4 fogCeilingEnabled;
};

// Smooth analytic vision-circle reveal for one fog disc at `worldXY`.
// `circle` = (centerX, centerY, radius, edgeSoftness) in world units; `aa` is
// an extra half-width the band is widened to. Pass `aa > 0`: with a hard disc
// (edgeSoftness 0) and `aa == 0` the band has zero width and smoothstep is
// undefined — a binary per-column disc test goes through
// fogDiscRevealAtDistance (ir_voxel_face_select.metal) instead. Returns 1.0
// fully revealed, 0.0 fully hidden.
inline float fogVisionCircleReveal(float2 worldXY, float4 circle, float aa) {
    const float dist = length(worldXY - circle.xy);
    const float a = max(circle.w, aa);
    return 1.0f - smoothstep(circle.z - a, circle.z + a, dist);
}

// A source's ceiling factor at dzUp world units above its observer. GLSL
// twin: fogCeilingVisibility in ../ir_iso_common.glsl.
inline float fogCeilingVisibility(float4 ceiling, float dzUp) {
    if (ceiling.x < 0.0f) {
        return 1.0f;
    }
    if (ceiling.y <= 0.0f) {
        return dzUp <= ceiling.x ? 1.0f : 0.0f;
    }
    return 1.0f - smoothstep(ceiling.x, ceiling.x + ceiling.y, dzUp);
}

// The fog window is RG32UI: .r is the cell state integer (0 unexplored, 128
// explored, 255 visible), .g the cell's channel mask. GLSL twin:
// fogTexelState in ../ir_iso_common.glsl.
constant uint kFogChannelDefault = 1u;
inline float fogTexelState(uint state) {
    return float(state) / 255.0f;
}

inline float fogRevealSurfaceHash01(int3 voxel) {
    uint hash = uint(voxel.x) * 0x8DA6B343u ^ uint(voxel.y) * 0xD8163841u ^
        uint(voxel.z) * 0xCB1AB31Fu;
    hash ^= hash >> 16u;
    hash *= 0x7FEB352Du;
    hash ^= hash >> 15u;
    hash *= 0x846CA68Bu;
    hash ^= hash >> 16u;
    return float(hash & 0xFFFFFFu) / 16777216.0f;
}

inline int2 fogWindowTexel(int2 col, int2 origin, int2 fogSize) {
    const int2 rel = col - origin;
    if (rel.x < 0 || rel.x >= fogSize.x || rel.y < 0 || rel.y >= fogSize.y) {
        return int2(-1);
    }
    int2 base;
    base.x = origin.x >= 0 ? origin.x % fogSize.x : fogSize.x - 1 - (-(origin.x + 1)) % fogSize.x;
    base.y = origin.y >= 0 ? origin.y % fogSize.y : fogSize.y - 1 - (-(origin.y + 1)) % fogSize.y;
    int2 texel = rel + base;
    if (texel.x >= fogSize.x) {
        texel.x -= fogSize.x;
    }
    if (texel.y >= fogSize.y) {
        texel.y -= fogSize.y;
    }
    return texel;
}

constant int kMaxFogVisionCircles = 8;
constant float kFogCeilingAdmitAa = 0.75f;
constant float kFogCeilingFlickerSpan = 2.0f;

inline float fogCeilingPhaseHeight(int3 voxel, float phase) {
    if (phase == 0.0f) return 0.0f;
    uint hash = uint(voxel.x) * 0xA24BAED5u ^ uint(voxel.y) * 0x9FB21C65u ^
        uint(voxel.z) * 0xC13FA9A9u;
    hash ^= hash >> 16u;
    hash *= 0x7FEB352Du;
    hash ^= hash >> 15u;
    const float rate = 0.125f + 0.875f * (float(hash & 0xFFFFFFu) / 16777216.0f);
    return kFogCeilingFlickerSpan * (1.0f - 4.0f * abs(fract(rate * phase + 0.25f) - 0.5f));
}

// Admission is independent of height and phase; Z neighbours reuse this mask.
inline uint fogCeilingSourceMask(
    int2 column, uint2 cell, constant float4* circles,
    constant uint4* channels, int count
) {
    if (cell.x == 255u) return 0u;
    uint admitted = 0u;
    for (int source = 0; source < count; ++source) {
        if ((channels[source / 4][source % 4] & cell.y) == 0u) continue;
        const float4 circle = circles[source];
        const float2 nearest = clamp(circle.xy, float2(column) - 0.5f, float2(column) + 0.5f);
        if (fogVisionCircleReveal(nearest, circle, kFogCeilingAdmitAa) > 0.0f) {
            admitted |= 1u << uint(source);
        }
    }
    return admitted;
}

inline float fogCeilingPresenceFromMask(
    int voxelZ, uint admitted, constant float4* heights,
    constant float4* ceilings, int count, float heightOffset
) {
    if (admitted == 0u) return 1.0f;
    float presence = 0.0f;
    for (int source = 0; source < count; ++source) {
        if ((admitted & (1u << uint(source))) == 0u) continue;
        const float dzUp = max(heights[source].x - float(voxelZ), 0.0f);
        presence = max(presence, fogCeilingVisibility(ceilings[source], dzUp + heightOffset));
        if (presence == 1.0f) return 1.0f;
    }
    return presence;
}

inline float fogCeilingPresence(
    int3 voxel, uint2 cell, constant float4* circles,
    constant float4* heights, constant float4* ceilings,
    constant uint4* channels, int count, float heightOffset
) {
    return fogCeilingPresenceFromMask(
        voxel.z, fogCeilingSourceMask(voxel.xy, cell, circles, channels, count),
        heights, ceilings, count, heightOffset);
}

inline bool fogCeilingRetained(
    int3 voxel, uint2 cell, constant float4* circles,
    constant float4* heights, constant float4* ceilings,
    constant uint4* channels, int count, float4 treatment, float phase
) {
    const bool treated = treatment.x != 0.0f;
    const float presence = fogCeilingPresence(
        voxel, cell, circles, heights, ceilings, channels, count,
        treated ? fogCeilingPhaseHeight(voxel, phase) : 0.0f);
    if (presence <= 0.0f) return false;
    if (presence >= 1.0f || !treated || treatment.y == 0.0f) return true;
    return fogRevealSurfaceHash01(voxel) <= mix(1.0f, presence, treatment.y);
}

constant int kDetachedFaceMissDepth = 2147483647;

constant uint kSourceLightingBaked = 0u;
constant uint kSourceLightingLinear = 1u;
constant uint kSourceLightingHDR = 2u;
constant uint kSourceLightingShadow = 3u;
constant uint kSourceLightingAOShadow = 4u;

// owner.z selects color interpretation; owner.xy retain packed entity identity.
struct SourceVoxelFace {
    float4 centerAndFace;
    float4 color;
    uint4 owner;
    float4 directSunAndExposure;
    float4 worldCenterAndAO;
};
struct SourceVoxelFaces {
    uint indexCount;
    atomic_uint count;
    uint padding[6];
    SourceVoxelFace faces[1];
};

struct DetachedFaceFootprint {
    float2 origin;
    float2 planeOrigin;
    float2 uvOrigin;
    float2 edgeU;
    float2 edgeV;
    float3 depth;
    int2 lo;
    int2 hi;
};

inline DetachedFaceFootprint detachedFaceFootprint(
    float3 position, int faceId, int subdivisions, int microIndex,
    float2x2 deformX, float2x2 deformY, float3 depthAxis, int2 frameOffset
) {
    const float2 basisX = deformY * float2(-1.0, -1.0);
    const float2 basisY = deformX * float2(1.0, -1.0);
    const float2 basisZ = deformX * float2(0.0, 2.0);
    const int axis = faceId >> 1;
    const int axisU = axis == 0 ? 1 : 0;
    const int axisV = axis == 2 ? 1 : 2;
    float3 source = position * float(subdivisions) - float3(0.5 * float(subdivisions));
    source[axis] += float((faceId & 1) * subdivisions);
    source[axisU] += float(microIndex / subdivisions);
    source[axisV] += float(microIndex % subdivisions);
    DetachedFaceFootprint face;
    face.origin = float2(frameOffset) + float2(float(subdivisions)) +
        source.x * basisX + source.y * basisY + source.z * basisZ;
    face.edgeU = axisU == 0 ? basisX : basisY;
    face.edgeV = axisV == 1 ? basisY : basisZ;
    const float2 basisAxis = axis == 0 ? basisX : (axis == 1 ? basisY : basisZ);
    face.planeOrigin = float2(frameOffset) + float2(float(subdivisions)) + source[axis] * basisAxis;
    face.uvOrigin = float2(source[axisU], source[axisV]);
    face.depth = float3(source[axis] * depthAxis[axis],
                      depthAxis[axisU], depthAxis[axisV]);
    face.lo = int2(floor(face.origin + min(face.edgeU, float2(0.0)) +
                        min(face.edgeV, float2(0.0)))) - int2(1);
    face.hi = int2(ceil(face.origin + max(face.edgeU, float2(0.0)) +
                        max(face.edgeV, float2(0.0)))) + int2(1);
    return face;
}

// Samples are centroids of the local triangles reconstructed by the fragment
// gather. Half-open face coordinates give adjacent micro-faces one shared edge.
inline int detachedFaceSampleDepth(DetachedFaceFootprint face, int2 pixel, int parity, int slot) {
    const float determinant = projectedFaceDeterminant(face.edgeU, face.edgeV);
    if (abs(determinant) < 1e-6) return kDetachedFaceMissDepth;
    const float2 delta = localTrixelCellCentroid(pixel, parity) - face.planeOrigin;
    const float2 uv = projectedFaceCoordinates(delta, face.edgeU, face.edgeV, determinant);
    if (any(uv < face.uvOrigin) || any(uv >= face.uvOrigin + float2(1.0)))
        return kDetachedFaceMissDepth;
    return encodeDepthWithFace(int(floor(face.depth.x + dot(uv, face.depth.yz) + 0.5)), slot);
}

inline float3 detachedFaceViewNormal(int faceId, float2x2 deformX, float2x2 deformY, float3 depthAxis) {
    const int axis = faceId >> 1;
    const float2 projected = axis == 0 ? deformY * float2(-1.0, -1.0) :
        (axis == 1 ? deformX * float2(1.0, -1.0) : deformX * float2(0.0, 2.0));
    const float depth = depthAxis[axis];
    return normalize(isoPositionToPos3D(projected, depth)) * ((faceId & 1) == 0 ? -1.0 : 1.0);
}
#endif // IR_ISO_COMMON_METAL_INCLUDED

#ifndef IR_PROJECTED_FACE_INCLUDED
#define IR_PROJECTED_FACE_INCLUDED

inline float projectedFaceDeterminant(float2 edgeU, float2 edgeV) {
    return edgeU.x * edgeV.y - edgeU.y * edgeV.x;
}

// The caller rejects degenerate bases before dividing. Coverage ownership is
// separate: display faces are half-open; finite shadow footprints are closed.
inline float2 projectedFaceCoordinates(float2 delta, float2 edgeU, float2 edgeV, float determinant) {
    return float2((delta.x * edgeV.y - delta.y * edgeV.x) / determinant,
                (edgeU.x * delta.y - edgeU.y * delta.x) / determinant);
}

// The sun-query envelope preserves exact represented faces at every orientation.
// Its arithmetic margin and the producer enclosure in sourceFaceIndexBounds
// are coupled; the derivation is in docs/design/sun-face-index-coverage.md.
inline bool sourceFaceWithinProjectedBounds(float point, float corner, float edgeU, float edgeV) {
    const float relativeMargin = 0.00000095367431640625;
    const float absoluteMargin = 3.7615819226313200255e-37;
    const float padding = relativeMargin * (abs(corner) + abs(edgeU) + abs(edgeV)) + absoluteMargin;
    const float low = corner + (edgeU < 0.0 ? edgeU : 0.0) + (edgeV < 0.0 ? edgeV : 0.0) - padding;
    const float high = corner + (edgeU > 0.0 ? edgeU : 0.0) + (edgeV > 0.0 ? edgeV : 0.0) + padding;
    return !(point < low || point > high);
}

// Conservative closed-edge predicates for independently rounded projected
// inputs and finite normal binary32 arithmetic. gamma(7) bounds input rounding,
// subtraction and two-product edge functions, not upstream projection error.
// The caller rejects degenerate bases and keeps uncertain-hit depth on the face.
inline bool projectedFaceContainsClosed(float2 point, float2 corner, float2 edgeU, float2 edgeV,
                                       float determinant, float2 uv) {
    if (uv.x >= 0.0 && uv.y >= 0.0 && uv.x <= 1.0 && uv.y <= 1.0) return true;
    const float unitRoundoff = 0.000000059604644775390625;
    const float gamma7 = (7.0 * unitRoundoff) / (1.0 - 7.0 * unitRoundoff);
    const float dx = abs(point.x) + abs(corner.x);
    const float dy = abs(point.y) + abs(corner.y);
    const float detMagnitude = abs(edgeU.x * edgeV.y) + abs(edgeU.y * edgeV.x);
    const float errorU = gamma7 * (dx * abs(edgeV.y) + dy * abs(edgeV.x) + detMagnitude);
    const float errorV = gamma7 * (dx * abs(edgeU.y) + dy * abs(edgeU.x) + detMagnitude);
    const float deltaX = point.x - corner.x;
    const float deltaY = point.y - corner.y;
    const float numeratorU = deltaX * edgeV.y - deltaY * edgeV.x;
    const float numeratorV = edgeU.x * deltaY - edgeU.y * deltaX;
    const float orientation = determinant > 0.0 ? 1.0 : -1.0;
    return orientation * numeratorU >= -errorU &&
           orientation * (determinant - numeratorU) >= -errorU &&
           orientation * numeratorV >= -errorV &&
           orientation * (determinant - numeratorV) >= -errorV;
}

#endif

#ifndef IR_SUN_FACE_QUERY_LAYOUT_INCLUDED
#define IR_SUN_FACE_QUERY_LAYOUT_INCLUDED

// SunShadowDepthMap holds depth layers, primary tile lists, geometry and bounded spill lists.
constant uint kSourceFaceMapDimension = 1024u;
constant uint kSourceFaceCascadeCount = 2u;
constant uint kSourceFaceTileEdge = 8u;
constant uint kSourceFaceTilesPerAxis = kSourceFaceMapDimension / kSourceFaceTileEdge;
constant uint kSourceFaceTileCount = kSourceFaceCascadeCount * kSourceFaceTilesPerAxis * kSourceFaceTilesPerAxis;
constant uint kSourceFaceTileCapacity = 64u;
constant uint kSourceFaceTileQueryCapacity = 256u;
constant uint kSourceFaceSpillCapacity = 262144u;
constant uint kSourceFaceSpillNodeWords = 2u;
constant uint kSourceFaceCapacity = 65536u;
constant uint kSourceFaceRecordWords = 10u;
constant uint kSourceFaceFallbackOffset = kSourceFaceCascadeCount * kSourceFaceMapDimension * kSourceFaceMapDimension;
constant uint kSourceFaceHeaderOffset = 2u * kSourceFaceFallbackOffset;
constant uint kSourceFaceTileOffset = kSourceFaceHeaderOffset + 1u;
constant uint kSourceFaceRecordOffset = kSourceFaceTileOffset + kSourceFaceTileCount * (kSourceFaceTileCapacity + 1u);
constant uint kSourceFaceSpillCounterOffset = kSourceFaceRecordOffset + kSourceFaceCapacity * kSourceFaceRecordWords;
constant uint kSourceFaceSpillHeadOffset = kSourceFaceSpillCounterOffset + 1u;
constant uint kSourceFaceSpillNodeOffset = kSourceFaceSpillHeadOffset + kSourceFaceTileCount;
constant uint kSourceFaceBufferWords = kSourceFaceSpillNodeOffset + kSourceFaceSpillCapacity * kSourceFaceSpillNodeWords;

inline uint sourceFaceTileBase(uint tileIndex) {
    return kSourceFaceTileOffset + tileIndex * (kSourceFaceTileCapacity + 1u);
}

inline bool sourceFaceQueryComplete(uint count) {
    return count <= kSourceFaceTileQueryCapacity;
}

// Positive separation is a front hit, including conservative rounded boundaries.
inline float sourceFaceRaySeparation(float2 sunUV, float sunZ, float3 corner, float3 edgeU, float3 edgeV
#if IR_SUN_QUERY_STATS
    , thread SunQueryStats &sunQueryStats
#endif
) {
    const float determinant = projectedFaceDeterminant(float2(edgeU.x, edgeU.y), float2(edgeV.x, edgeV.y));
    if (abs(determinant) < 0.000001 ||
        !sourceFaceWithinProjectedBounds(sunUV.x, corner.x, edgeU.x, edgeV.x) ||
        !sourceFaceWithinProjectedBounds(sunUV.y, corner.y, edgeU.y, edgeV.y)) {
#if IR_SUN_QUERY_STATS
        sunQueryStats.counts[kSunQueryFaceMisses] += 1u;
#endif
        return -1.0;
    }
    const float2 uv = projectedFaceCoordinates(
        float2(sunUV.x - corner.x, sunUV.y - corner.y),
        float2(edgeU.x, edgeU.y), float2(edgeV.x, edgeV.y), determinant);
    if (!projectedFaceContainsClosed(sunUV, float2(corner.x, corner.y),
            float2(edgeU.x, edgeU.y), float2(edgeV.x, edgeV.y), determinant, uv)) {
#if IR_SUN_QUERY_STATS
        sunQueryStats.counts[kSunQueryFaceMisses] += 1u;
#endif
        return -1.0;
    }
    // An uncertain boundary hit must never extrapolate depth beyond the face.
    const float u = uv.x < 0.0 ? 0.0 : (uv.x > 1.0 ? 1.0 : uv.x);
    const float v = uv.y < 0.0 ? 0.0 : (uv.y > 1.0 ? 1.0 : uv.y);
    return sunZ - (corner.z + u * edgeU.z + v * edgeV.z);
}

#endif

#ifndef IR_SUN_SHADOW_SAMPLE_METAL_INCLUDED
#define IR_SUN_SHADOW_SAMPLE_METAL_INCLUDED

// Mirrors shaders/ir_sun_shadow_sample.glsl. Shared sun-shadow sampling — the
// FrameDataSun layout, the cascade PCF sampler, and the world-space
// worldSunShadowFactor() lookup — used by BOTH c_compute_sun_shadow (the
// per-world-pixel screen-space pass) and c_lighting_to_trixel (the opt-in
// detached re-voxelize world-receive path). On Metal the
// sun-depth map (buffer 28) is a kernel argument, so it threads through as a
// `device const uint *` parameter rather than a global SSBO.

// Map-dim constants, the shared sunSpaceProject basis, unpackSunDepth, and
// sunCascadeKernelInterior — one source with the caster bake.
#ifndef IR_SUN_PROJECTION_METAL_INCLUDED
#define IR_SUN_PROJECTION_METAL_INCLUDED

#include <metal_stdlib>
using namespace metal;

// Mirrors shaders/ir_sun_projection.glsl. Sun-space projection shared by the
// caster bake (c_bake_sun_shadow_map) and the receiver lookup
// (ir_sun_shadow_sample), so caster depth and receiver lookup use one basis and
// cannot drift apart. CPU twin: IRMath::sunSpaceProject.

constant int kSunShadowMapDim = 1024;
constant int kCascadeTexelCount = kSunShadowMapDim * kSunShadowMapDim;
constant float kSunDepthScale = 1024.0;
constant float kSunDepthOffset = 512.0;

// Interior margin (texels) for sunCascadeKernelInterior. Sized so that when a
// receiver's 2x2 PCF kernel is accepted, its caster — same sun ray, offset in
// UV only by the receiver's kNormalBiasVoxels shift plus the caster's
// half-cell rounding, both sub-texel to low-single-texel at practical texel
// sizes — is guaranteed to have landed inside the map too (the bake's point
// write cannot have been bounds-dropped for an accepted receiver).
constant int kSunCascadeInteriorMarginTexels = 2;

// Sun-space projection of a WORLD point: .xy = UV along the (uHat, vHat)
// orthonormal basis (perpendicular to the sun ray — every caster on a
// receiver's sun ray shares the receiver's UV), .z = depth along the sun ray
// (-sunDir; larger = farther from the sun, packSunDepth's input).
inline float3 sunSpaceProject(float3 pos3D, float3 uHat, float3 vHat, float3 sunDir) {
    return float3(dot(pos3D, uHat), dot(pos3D, vHat), -dot(pos3D, sunDir));
}

// Caster pack / receiver unpack — one co-located inverse pair, so what
// casters store and what receivers compare cannot drift.
//
// Bit layout: quantized depth in the high 24 bits, the low BYTE carries the
// coverage-splat DISPLACEMENT VECTOR — a two's-complement nibble each for dx
// (bits [7:4]) and dy (bits [3:0]), the sun-texel offset of THIS write from its
// caster's own texel under the box splat. The radius is capped at
// kSunSplatMaxTexels = 7 (system_bake_sun_shadow_map.hpp) — r7 is the largest
// radius that ROUND-TRIPS: r8 would emit dx = 8, which the nibble aliases to -8
// on unpack, so the receiver would reconstruct the origin texel on the WRONG SIDE
// of the caster. A larger radius needs the displacement field widened past 8
// bits. A DIRECT (caster's-own-texel) write is (dx,dy) = (0,0):
//   - low byte 0 ⇒ the packed word is exactly the quantized depth `<< 8`, so the
//     radius-0 per-axis / smooth-yaw / detached paths carry no splat bits;
//   - atomic_fetch_min over the packed word is depth-major (high 24 bits) and, at
//     equal quantized depth, a direct write's 0 low byte beats any splat's
//     nonzero low byte, so a genuine caster's own-texel depth always wins its
//     texel (strengthens the saturated-host invariant — docs/design/sun-shadow-bake-coverage.md).
// Max packed = (2^20 << 8) | 0xFF = 2^28+255 << the 0xFFFFFFFF empty sentinel.
//
// The full displacement vector lets the receiver reconstruct the write's ORIGIN
// texel and run an EXACT same-plane test — rejecting a same-face self-occluder at
// any splat distance while keeping a genuine cast at the base bias
// (ir_sun_shadow_sample), where a widened bias would erode genuine shadows. Why a
// stored vector rather than a widened bias: docs/design/sun-shadow-bake-coverage.md.
// Mirrors GLSL.
inline uint packSunDepth(float sunZ, int2 splatOffset) {
    float biased = clamp(sunZ + kSunDepthOffset, 0.0, kSunDepthOffset * 2.0);
    uint lowByte = (uint(splatOffset.x & 0xF) << 4) | uint(splatOffset.y & 0xF);
    return (uint(biased * kSunDepthScale) << 8) | lowByte;
}

// Offset -8 is outside the legacy splat radius and identifies center-evaluated geometry.
inline uint packSunSurfaceDepth(float sunZ) {
    return packSunDepth(sunZ, int2(-8));
}

inline bool sunWriteIsSurface(uint packedDepth) {
    return (packedDepth & 0xF0u) == 0x80u || (packedDepth & 0x0Fu) == 0x08u;
}

// A -8 nibble is unavailable to legacy splats. The other nibble stores a
// six-face ID; which nibble is reserved selects world or camera-aligned axes.
// 0x88 is analytic geometry; 0x89 identifies rigid source faces in the query index.
inline uint sunVoxelFaceMarker(int faceId, int basis) {
    if (basis == 2) return 0x89u;
    return basis == 1 ? (uint(faceId) << 4u) | 0x08u : 0x80u | uint(faceId);
}

inline int sunVoxelFaceId(uint packedDepth) {
    uint marker = packedDepth & 0xFFu;
    if (marker >= 0x80u && marker <= 0x85u) return int(marker & 0x0Fu);
    if ((marker & 0x0Fu) == 0x08u && (marker >> 4u) <= 5u) return int(marker >> 4u);
    return -1;
}

inline bool sunVoxelFaceViewAligned(uint packedDepth) {
    return (packedDepth & 0x0Fu) == 0x08u;
}

inline float unpackSunDepth(uint packedDepth) {
    return float(packedDepth >> 8) / kSunDepthScale - kSunDepthOffset;
}

// True iff this sun-map write is a DIRECT caster's-own-texel write (low byte 0),
// vs a coverage-splat neighbour. Direct writes take the receiver's plain
// near-rejection; splat writes take the same-plane test.
inline bool sunWriteIsDirect(uint packedDepth) {
    return (packedDepth & 0xFFu) == 0u;
}

// The coverage-splat displacement vector (sun texels) this write was splatted
// from its caster's own texel: two sign-extended two's-complement nibbles.
// (0,0) for a direct write. The receiver reconstructs originTexel = px - offset.
inline int2 unpackSunSplatOffset(uint packedDepth) {
    int dx = int((packedDepth >> 4u) & 0xFu);
    int dy = int(packedDepth & 0xFu);
    if (dx >= 8) dx -= 16;
    if (dy >= 8) dy -= 16;
    return int2(dx, dy);
}

// May this receiver sample the cascade at (origin, texelSz)? True only where
// its 2x2 PCF kernel sits kSunCascadeInteriorMarginTexels inside the map. Outside,
// the caller must select the covering (outer) cascade instead: a kernel that
// straddles the map edge silently loses the out-of-bounds taps — and near the
// cascade-0 AABB boundary the matching casters may have been bounds-dropped
// by the bake — so edge receivers read a partially-baked region as "lit".
inline bool sunCascadeKernelInterior(float2 sunUV, float2 origin, float2 texelSz) {
    int2 base = int2(floor((sunUV - origin) / texelSz - 0.5f));
    return base.x >= kSunCascadeInteriorMarginTexels &&
           base.y >= kSunCascadeInteriorMarginTexels &&
           base.x + 1 < kSunShadowMapDim - kSunCascadeInteriorMarginTexels &&
           base.y + 1 < kSunShadowMapDim - kSunCascadeInteriorMarginTexels;
}

#endif // IR_SUN_PROJECTION_METAL_INCLUDED


// Shared SDF primitive evaluators for the trixel pipeline.  Mirrors
// shaders/ir_sdf_common.glsl and the CPU-side `IRMath::SDF` namespace
// (engine/math/include/irreden/math/sdf.hpp).  The shape rasterizer
// (`c_shapes_to_trixel_body.metal`) and the sun-shadow shader
// (`c_compute_sun_shadow.metal`) both #include this header.
//
// Anyone touching one branch of `evaluateSDF` must update the GLSL mirror
// in shaders/ir_sdf_common.glsl and the CPU helpers in IRMath::SDF.
#ifndef IR_SDF_COMMON_METAL_INCLUDED
#define IR_SDF_COMMON_METAL_INCLUDED

#include <metal_stdlib>
using namespace metal;

constant uint SHAPE_BOX          = 0u;
constant uint SHAPE_SPHERE       = 1u;
constant uint SHAPE_CYLINDER     = 2u;
constant uint SHAPE_ELLIPSOID    = 3u;
constant uint SHAPE_CURVED_PANEL = 4u;
constant uint SHAPE_WEDGE        = 5u;
constant uint SHAPE_TAPERED_BOX  = 6u;
constant uint SHAPE_CUSTOM_SDF   = 7u;
constant uint SHAPE_CONE         = 8u;
constant uint SHAPE_TORUS        = 9u;

inline float sdfBox(float3 p, float3 halfExtents) {
    const float3 d = abs(p) - halfExtents;
    return max(d.x, max(d.y, d.z));
}

inline float sdfSphere(float3 p, float radius) {
    return length(p) - radius;
}

inline float sdfCylinder(float3 p, float radius, float halfHeight) {
    const float2 d = abs(float2(length(p.xy), p.z)) - float2(radius, halfHeight);
    return min(max(d.x, d.y), 0.0) + length(max(d, float2(0.0)));
}

inline float sdfEllipsoid(float3 p, float3 radii) {
    if (radii.x <= 0.0 || radii.y <= 0.0 || radii.z <= 0.0) {
        return 1.0;
    }
    const float k0 = length(p / radii);
    if (k0 < 1e-6) {
        return -min(radii.x, min(radii.y, radii.z));
    }
    const float k1 = length(p / (radii * radii));
    return k0 * (k0 - 1.0) / k1;
}

inline float sdfTaperedBox(float3 p, float3 halfExtents, float taper) {
    const float taperFactor =
        mix(1.0, taper,
            clamp((p.z + halfExtents.z) / (2.0 * halfExtents.z), 0.0, 1.0));
    const float3 scaled =
        float3(p.xy / max(taperFactor, 0.001), p.z);
    return sdfBox(scaled, halfExtents);
}

inline float sdfCone(float3 p, float baseRadius, float halfHeight) {
    const float t =
        clamp((p.z + halfHeight) / (2.0 * halfHeight), 0.0, 1.0);
    const float radiusAtZ = baseRadius * (1.0 - t);
    const float dRadial = length(p.xy) - radiusAtZ;
    const float dZ = abs(p.z) - halfHeight;
    const float dOutside =
        length(max(float2(dRadial, dZ), float2(0.0)));
    const float dInside = min(max(dRadial, dZ), 0.0);
    return dOutside + dInside;
}

inline float sdfTorus(float3 p, float majorR, float minorR) {
    const float q = length(p.xy) - majorR;
    return length(float2(q, p.z)) - minorR;
}

inline float sdfWedge(float3 p, float3 halfExtents) {
    const float boxD = sdfBox(p, halfExtents);
    const float planeD =
        p.z - halfExtents.z * (1.0 - p.x / max(halfExtents.x, 0.001));
    return max(boxD, planeD);
}

inline float sdfCurvedPanel(float3 p, float3 halfExtents, float curvature) {
    const float nx = p.x / max(halfExtents.x, 0.001);
    const float zMid = curvature * halfExtents.x * nx * nx;
    const float dThickness = abs(p.z - zMid) - halfExtents.z;
    const float dX = abs(p.x) - halfExtents.x;
    const float dY = abs(p.y) - halfExtents.y;
    const float dOutside =
        length(max(float3(dX, dY, dThickness), float3(0.0)));
    const float dInside = min(max(dX, max(dY, dThickness)), 0.0);
    return dOutside + dInside;
}

// Generic SDF dispatch.  Returns the signed distance from `localPos`
// (already transformed into the shape's local frame) to the shape surface.
inline float evaluateSDF(float3 localPos, uint shapeType, float4 params) {
    const float3 halfSize = params.xyz * 0.5;
    switch (shapeType) {
        case SHAPE_BOX:          return sdfBox(localPos, halfSize);
        case SHAPE_SPHERE:       return sdfSphere(localPos, params.x);
        case SHAPE_CYLINDER:     return sdfCylinder(localPos, params.x, halfSize.z);
        case SHAPE_ELLIPSOID:    return sdfEllipsoid(localPos, halfSize);
        case SHAPE_TAPERED_BOX:  return sdfTaperedBox(localPos, halfSize, params.w);
        case SHAPE_CONE:         return sdfCone(localPos, params.x, halfSize.z);
        case SHAPE_TORUS:        return sdfTorus(localPos, params.x, params.y);
        case SHAPE_WEDGE:        return sdfWedge(localPos, halfSize);
        case SHAPE_CURVED_PANEL: return sdfCurvedPanel(localPos, halfSize, params.w);
        default:                 return sdfBox(localPos, halfSize);
    }
}

// |a*d + b| <= H solved for d. Degenerate (a == 0) returns either an empty
// or all-d slab depending on |b| vs H.
//
// Threshold 1e-6 catches FP near-degenerate slopes at irrational yaws near
// pi/4, where (cos-sin)/3 is tiny but nonzero (at exactly pi/4, cos==sin in
// IEEE-754 so (c-s)/3 == 0). A smaller threshold lets 1/|a| blow up past 1e6
// across that cluster. The +/-1e18 sentinel is an all-d slab the downstream
// min/max swallows.
inline bool slabFromLinear(
    float a,
    float b,
    float H,
    thread float& dLo,
    thread float& dHi
) {
    if (fabs(a) < 1e-6) {
        if (fabs(b) <= H) {
            dLo = -1e18;
            dHi = 1e18;
            return true;
        }
        return false;
    }
    const float invA = 1.0 / a;
    const float t1 = (-H - b) * invA;
    const float t2 = ( H - b) * invA;
    dLo = min(t1, t2);
    dHi = max(t1, t2);
    return true;
}

// Bounds and iso coordinates share the caller's density. No cell expansion,
// origin rounding, or depth quantization is applied here. The normal is in
// the unrotated box frame; outputs are valid only on a finite-box hit.
inline bool boxSurfaceIntervalYaw(
    float iX, float iY,
    float3 hExt,
    float yawC,
    float yawS,
    thread float& dEntry,
    thread float& dExit,
    thread float3& entryNormal
) {
    const float ax = (yawC - yawS) / 3.0;
    const float bx = -(yawC + yawS) * 0.5 * iX - (yawC - yawS) * iY / 6.0;
    const float ay = (yawC + yawS) / 3.0;
    const float by =  (yawC - yawS) * 0.5 * iX - (yawC + yawS) * iY / 6.0;
    const float az = 1.0 / 3.0;
    const float bz = iY / 3.0;

    float dxLo, dxHi, dyLo, dyHi, dzLo, dzHi;
    if (!slabFromLinear(ax, bx, hExt.x, dxLo, dxHi)) return false;
    if (!slabFromLinear(ay, by, hExt.y, dyLo, dyHi)) return false;
    if (!slabFromLinear(az, bz, hExt.z, dzLo, dzHi)) return false;

    dEntry = max(dxLo, max(dyLo, dzLo));
    dExit  = min(dxHi, min(dyHi, dzHi));
    if (dEntry > dExit) return false;
    // At a shared edge either plane is valid; ties choose X, then Y, then Z.
    if (dxLo >= dyLo && dxLo >= dzLo) {
        entryNormal = float3(ax > 0.0 ? -1.0 : 1.0, 0.0, 0.0);
    } else if (dyLo >= dzLo) {
        entryNormal = float3(0.0, ay > 0.0 ? -1.0 : 1.0, 0.0);
    } else {
        entryNormal = float3(0.0, 0.0, -1.0);
    }
    return true;
}

#endif // IR_SDF_COMMON_METAL_INCLUDED

inline int sdfRayQuadraticRoots(float a, float b, float c, thread float2& roots) {
    if (a == 0.0) {
        if (b == 0.0) return 0;
        roots = float2(-c / b);
        return 1;
    }
    float discriminant = b * b - 4.0 * a * c;
    float roundingTolerance = 4.0e-7 * (b * b + abs(4.0 * a * c));
    if (discriminant < -roundingTolerance) return 0;
    if (discriminant <= 0.0) {
        roots = float2(-b / (2.0 * a));
        return 1;
    }
    float radical = sqrt(discriminant);
    float q = -0.5 * (b + (b < 0.0 ? -radical : radical));
    if (q == 0.0) {
        roots = float2(-b / (2.0 * a));
        return 1;
    }
    float first = q / a;
    float second = c / q;
    roots = float2(min(first, second), max(first, second));
    return 2;
}

inline bool sdfRaySlab(float origin, float direction, float minimum, float maximum,
                thread float& nearDepth, thread float& farDepth) {
    if (direction == 0.0) return origin >= minimum && origin <= maximum;
    float a = (minimum - origin) / direction;
    float b = (maximum - origin) / direction;
    nearDepth = max(nearDepth, min(a, b));
    farDepth = min(farDepth, max(a, b));
    return nearDepth <= farDepth;
}

inline bool sdfRaySphere(float3 origin, float3 direction, float radius,
                  float nearDepth, float farDepth, thread float& depth) {
    float3 start = origin + direction * nearDepth;
    if (dot(start, start) <= radius * radius) {
        depth = nearDepth;
        return true;
    }
    float projection = dot(start, direction);
    float3 closest = start - direction * projection;
    float chordSquared = radius * radius - dot(closest, closest);
    if (chordSquared < -4.0e-7 * radius * radius) return false;
    depth = nearDepth - projection - sqrt(max(chordSquared, 0.0));
    return depth >= nearDepth && depth <= farDepth;
}

// Coefficients use distance from nearDepth as their polynomial variable.
inline bool sdfRayQuadraticInterval(float a, float b, float c,
                             float nearDepth, float farDepth, thread float& depth) {
    if (c <= 0.0) {
        depth = nearDepth;
        return true;
    }
    float2 roots;
    int count = sdfRayQuadraticRoots(a, b, c, roots);
    for (int index = 0; index < count; ++index) {
        float candidate = nearDepth + roots[index];
        if (candidate >= nearDepth && candidate <= farDepth) {
            depth = candidate;
            return true;
        }
    }
    return false;
}

inline bool sdfRayCylinder(float3 origin, float3 direction, float radius,
                    float minimumZ, float maximumZ,
                    float nearDepth, float farDepth, thread float& depth) {
    if (!sdfRaySlab(origin.z, direction.z, minimumZ, maximumZ, nearDepth, farDepth))
        return false;
    float3 start = origin + direction * nearDepth;
    return sdfRayQuadraticInterval(dot(direction.xy, direction.xy),
        2.0 * dot(start.xy, direction.xy), dot(start.xy, start.xy) - radius * radius,
        nearDepth, farDepth, depth);
}

inline float sdfRayCubicValue(float4 coefficients, float x) {
    return ((coefficients.x * x + coefficients.y) * x + coefficients.z) * x + coefficients.w;
}

// The quadratic derivative partitions the cubic into monotone intervals.
// Every real root in [-1,1], including repeated roots, is an interval boundary
// or the sole sign crossing in an interval.
inline int sdfRayCubicRoots(float4 coefficients, thread float3& roots) {
    float2 critical;
    int criticalCount = sdfRayQuadraticRoots(3.0 * coefficients.x,
        2.0 * coefficients.y, coefficients.z, critical);
    float boundaries[4];
    int boundaryCount = 1;
    boundaries[0] = -1.0;
    for (int index = 0; index < criticalCount; ++index) {
        if (critical[index] > -1.0 && critical[index] < 1.0)
            boundaries[boundaryCount++] = critical[index];
    }
    boundaries[boundaryCount++] = 1.0;
    int count = 0;
    for (int index = 0; index < boundaryCount - 1; ++index) {
        float left = boundaries[index];
        float right = boundaries[index + 1];
        float leftValue = sdfRayCubicValue(coefficients, left);
        float rightValue = sdfRayCubicValue(coefficients, right);
        if (leftValue == 0.0 && count < 3) roots[count++] = left;
        if ((leftValue < 0.0 && rightValue > 0.0) ||
            (leftValue > 0.0 && rightValue < 0.0)) {
            for (int iteration = 0; iteration < 24; ++iteration) {
                float middle = 0.5 * (left + right);
                float value = sdfRayCubicValue(coefficients, middle);
                if ((leftValue < 0.0) == (value < 0.0)) {
                    left = middle;
                    leftValue = value;
                } else right = middle;
            }
            if (count < 3) roots[count++] = 0.5 * (left + right);
        }
    }
    if (sdfRayCubicValue(coefficients, 1.0) == 0.0 && count < 3) roots[count++] = 1.0;
    return count;
}

inline float sdfRayTorusValue(float3 point, float majorRadius, float minorRadius) {
    float radial = length(point.xy) - majorRadius;
    return radial * radial + point.z * point.z - minorRadius * minorRadius;
}

inline bool sdfRayTorus(float3 origin, float3 direction, float majorRadius, float minorRadius,
                 float nearDepth, float farDepth, thread float& depth) {
    // A unit interval and shape-relative coordinates condition the derivative;
    // geometric evaluation avoids subtracting quartic terms at thin tube rims.
    float scale = max(majorRadius + minorRadius, 1.0e-6);
    float middleDepth = 0.5 * (nearDepth + farDepth);
    float halfRange = 0.5 * (farDepth - nearDepth);
    float3 rayCenter = origin + direction * middleDepth;
    float3 rayDelta = direction * halfRange;
    float3 center = rayCenter / scale;
    float3 delta = rayDelta / scale;
    float major = majorRadius / scale;
    float minor = minorRadius / scale;
    float a = dot(delta, delta);
    float b = 2.0 * dot(center, delta);
    float c = dot(center, center) + major * major - minor * minor;
    float radialA = dot(delta.xy, delta.xy);
    float radialB = 2.0 * dot(center.xy, delta.xy);
    float4 derivative = float4(4.0 * a * a, 6.0 * a * b,
        2.0 * (b * b + 2.0 * a * c - 4.0 * major * major * radialA),
        2.0 * b * c - 4.0 * major * major * radialB);
    float3 critical;
    int criticalCount = sdfRayCubicRoots(derivative, critical);
    float left = -1.0;
    float leftValue = sdfRayTorusValue(rayCenter - rayDelta, majorRadius, minorRadius);
    if (leftValue <= 0.0) {
        depth = nearDepth;
        return true;
    }
    for (int index = 0; index <= criticalCount; ++index) {
        float right = index < criticalCount ? critical[index] : 1.0;
        float rightValue = sdfRayTorusValue(rayCenter + rayDelta * right, majorRadius, minorRadius);
        // Tangencies have no sign crossing. Their residual is limited by the
        // float operations on the radii, rather than a ray-march hit tolerance.
        float roundingTolerance = 4.0e-7 * (majorRadius + minorRadius) * minorRadius;
        if (rightValue >= 0.0 && rightValue <= roundingTolerance) {
            depth = middleDepth + halfRange * right;
            return true;
        }
        if (rightValue <= 0.0) {
            for (int iteration = 0; iteration < 24; ++iteration) {
                float midpoint = 0.5 * (left + right);
                float value = sdfRayTorusValue(rayCenter + rayDelta * midpoint, majorRadius, minorRadius);
                if (value > 0.0) left = midpoint;
                else right = midpoint;
            }
            depth = middleDepth + halfRange * right;
            return true;
        }
        left = right;
    }
    return false;
}

inline bool sdfRayConeBody(float3 origin, float3 direction, float radius, float halfHeight,
                    float threshold, float nearDepth, float farDepth, thread float& depth) {
    if (!sdfRaySlab(origin.z, direction.z, -halfHeight, halfHeight, nearDepth, farDepth))
        return false;
    float3 start = origin + direction * nearDepth;
    float slope = radius / (2.0 * halfHeight);
    float startRadius = radius * 0.5 + threshold - slope * start.z;
    float radiusDelta = -slope * direction.z;
    return sdfRayQuadraticInterval(
        dot(direction.xy, direction.xy) - radiusDelta * radiusDelta,
        2.0 * (dot(start.xy, direction.xy) - startRadius * radiusDelta),
        dot(start.xy, start.xy) - startRadius * startRadius,
        nearDepth, farDepth, depth);
}

// The direction is unit length; the interval is the caller's shape AABB clip.
// These solids match evaluateSDF <= threshold, including its rounded caps.
inline bool sdfRayHit(uint shapeType, float4 params, float3 origin, float3 direction,
               float threshold, float nearDepth, float farDepth, thread float& depth) {
    if (nearDepth > farDepth) return false;
    if (shapeType == SHAPE_SPHERE)
        return sdfRaySphere(origin, direction, params.x + threshold, nearDepth, farDepth, depth);
    if (shapeType == SHAPE_TORUS)
        return sdfRayTorus(origin, direction, params.x, params.y + threshold, nearDepth, farDepth, depth);
    float halfHeight = 0.5 * params.z;
    float candidate;
    bool hit = false;
    depth = farDepth;
    if (shapeType == SHAPE_CYLINDER) {
        if (sdfRayCylinder(origin, direction, params.x + threshold, -halfHeight, halfHeight,
                           nearDepth, depth, candidate)) { depth = candidate; hit = true; }
        if (sdfRayCylinder(origin, direction, params.x, -halfHeight - threshold, halfHeight + threshold,
                           nearDepth, depth, candidate)) { depth = candidate; hit = true; }
        if (threshold == 0.0) return hit;
        for (int cap = 0; cap < 2; ++cap) {
            float capHeight = cap == 0 ? -halfHeight : halfHeight;
            float capNear = nearDepth;
            float capFar = depth;
            float lower = cap == 0 ? capHeight - threshold : capHeight;
            float upper = cap == 0 ? capHeight : capHeight + threshold;
            if (sdfRaySlab(origin.z, direction.z, lower, upper, capNear, capFar) &&
                sdfRayTorus(origin - float3(0.0, 0.0, capHeight), direction, params.x, threshold,
                             capNear, capFar, candidate))
                { depth = candidate; hit = true; }
        }
        return hit;
    }
    if (shapeType != SHAPE_CONE) return false;
    if (sdfRayConeBody(origin, direction, params.x, halfHeight, threshold, nearDepth, depth, candidate))
        { depth = candidate; hit = true; }
    if (sdfRaySphere(origin - float3(0.0, 0.0, halfHeight), direction, threshold,
                     nearDepth, depth, candidate)) { depth = candidate; hit = true; }
    if (sdfRayCylinder(origin, direction, params.x, -halfHeight - threshold, -halfHeight,
                       nearDepth, depth, candidate)) { depth = candidate; hit = true; }
    if (threshold == 0.0) return hit;
    float capNear = nearDepth;
    float capFar = depth;
    if (sdfRaySlab(origin.z, direction.z, -halfHeight - threshold, -halfHeight, capNear, capFar) &&
        sdfRayTorus(origin + float3(0.0, 0.0, halfHeight), direction, params.x, threshold,
                     capNear, capFar, candidate)) { depth = candidate; hit = true; }
    return hit;
}


inline float3 shapeSunHalfExtent(uint shapeType, float4 params, float threshold) {
    float3 extent;
    if (shapeType == SHAPE_SPHERE) extent = float3(params.x);
    else if (shapeType == SHAPE_TORUS)
        extent = float3(params.x + params.y, params.x + params.y, params.y);
    else extent = float3(params.x, params.x, params.z * 0.5);
    return extent + float3(threshold);
}


// Axisymmetric records contain sun-space center, unit symmetry axis, and
// (radius, height or torus minor radius, rendered field threshold).
inline float sourceShapeRaySeparation(float2 sunUV, float sunZ, uint shapeType,
                               float3 center, float3 axis, float3 parameters) {
    float4 params = shapeType == SHAPE_TORUS
        ? float4(parameters.x, parameters.y, 0.0, 0.0)
        : float4(parameters.x, 0.0, parameters.y, 0.0);
    float radius = length(shapeSunHalfExtent(shapeType, params, parameters.z));
    float2 delta = sunUV - center.xy;
    float discriminant = radius * radius - dot(delta, delta);
    if (discriminant < 0.0) return -1.0;
    float nearDepth = center.z - sqrt(discriminant);
    float farDepth = center.z + sqrt(discriminant);
    if (nearDepth >= sunZ) return -1.0;
    float3 perpendicular = normalize(cross(axis, abs(axis.z) < 0.9 ? float3(0, 0, 1) : float3(0, 1, 0)));
    float3 tangent = cross(axis, perpendicular);
    float3 offset = float3(delta, -center.z);
    float3 origin = float3(dot(offset, perpendicular), dot(offset, tangent), dot(offset, axis));
    float3 direction = float3(perpendicular.z, tangent.z, axis.z);
    const float3 halfExtent = shapeSunHalfExtent(shapeType, params, parameters.z);
    for (int coordinate = 0; coordinate < 3; ++coordinate) {
        if (!sdfRaySlab(origin[coordinate], direction[coordinate], -halfExtent[coordinate],
                        halfExtent[coordinate], nearDepth, farDepth)) return -1.0;
    }
    float depth;
    if (!sdfRayHit(shapeType, params, origin, direction, parameters.z, nearDepth, farDepth, depth)) return -1.0;
    return sunZ - depth;
}


#ifndef IR_SUN_FACE_OVERFLOW_REFERENCE
#define IR_SUN_FACE_OVERFLOW_REFERENCE 0
#endif
constant uint kSourceFaceOverflowReferenceBudget = 256u;

constant float kNormalBiasVoxels = 0.5;
constant float kShadowBiasTexelScale = 2.0;
constant float kShadowBiasSlopeMin = 0.05;
constant float kShadowBiasQuantNoise = 4.0 / kSunDepthScale;
constant float kCascadeBlendRange = 8.0;

struct FrameDataSun {
    float4 sunDirection;
    float sunIntensity;
    float sunAmbient;
    int shadowsEnabled;
    int aoEnabled;
    float4 sunBasisU; // xyz: sun basis; w: finite caster coverage
    float4 sunBasisV;
    float2 sunBufferOriginUV;
    float2 sunBufferTexelSize;
    float2 cascadeOriginUV_0;
    float2 cascadeTexelSize_0;
    float2 cascadeOriginUV_1;
    float2 cascadeTexelSize_1;
    float cascadeSplitDepth;
    int cascadeCount;
    float sunSplatMaxTexels;  // unused here (sun-map bake only)
    // Maximum shadow-throw window (sun-Z voxels). BAKE_SUN_SHADOW_MAP sets it
    // from kSunShadowMaxDistance — the SAME distance the feeder / bake AABB
    // sweep uses — so a baked caster is receivable at its full throw and the
    // two cannot drift.
    float sunMaxShadowThrow;
    float4 sunCasterViewToWorld;
    int4 fogCeilingEnabled;
};

inline float sampleCascadeShadow(
    float2 sunUV, float sunZ, float3 normal, float3 sunDir, float3 uHat, float3 vHat,
    float2 origin, float2 texelSz, int bufferOffset,
    device const uint *sunDepthBuf, float maxShadowThrow, bool surfaceReceiver, float4 casterViewToWorld,
    float3 pcfOffset
#if IR_SUN_QUERY_STATS
    , thread SunQueryStats &sunQueryStats
#endif
) {
#if IR_SUN_QUERY_STATS
    sunQueryStats.counts[kSunQueryCascades] += 1u;
#endif
    const uint sourceFaceCount = sunDepthBuf[kSourceFaceHeaderOffset];
    const bool hasSourceFaces = sourceFaceCount != 0u;
    bool sourceQueryComplete = !hasSourceFaces;
    if (surfaceReceiver && hasSourceFaces) {
        const int2 tile = int2(floor((sunUV - origin) / (texelSz * float(kSourceFaceTileEdge))));
        if (all(tile >= int2(0)) && all(tile < int2(kSourceFaceTilesPerAxis))) {
            const uint tileIndex = uint(bufferOffset / kCascadeTexelCount) * kSourceFaceTilesPerAxis * kSourceFaceTilesPerAxis
                + uint(tile.y) * kSourceFaceTilesPerAxis + uint(tile.x);
            const uint tileBase = sourceFaceTileBase(tileIndex);
            const uint count = sunDepthBuf[tileBase];
            sourceQueryComplete = sourceFaceQueryComplete(count)
                && (count <= kSourceFaceTileCapacity || sunDepthBuf[kSourceFaceSpillCounterOffset] <= kSourceFaceSpillCapacity);
            // A complete small record pool is an exact reference for an incomplete tile.
            const bool queryAllFaces = IR_SUN_FACE_OVERFLOW_REFERENCE != 0
                && !sourceQueryComplete && sourceFaceCount <= kSourceFaceOverflowReferenceBudget
                && sourceFaceCount <= kSourceFaceCapacity;
            sourceQueryComplete = sourceQueryComplete || queryAllFaces;
#if IR_SUN_QUERY_STATS
            if (!sourceQueryComplete) sunQueryStats.counts[kSunQueryIncomplete] += 1u;
#endif
            const uint candidateCount = queryAllFaces ? sourceFaceCount : count;
            if (sourceQueryComplete && dot(normal, sunDir) > 0.0) {
#if IR_SUN_QUERY_STATS
                sunQueryStats.counts[kSunQueryIndexed] += 1u;
#endif
                uint spill = !queryAllFaces && count > kSourceFaceTileCapacity
                    ? sunDepthBuf[kSourceFaceSpillHeadOffset + tileIndex] : 0xFFFFFFFFu;
                for (uint candidate = 0; candidate < candidateCount; ++candidate) {
#if IR_SUN_QUERY_STATS
                    sunQueryStats.counts[kSunQueryCandidates] += 1u;
#endif
                    uint faceIndex;
                    if (queryAllFaces) {
                        faceIndex = candidate;
                    } else if (candidate < kSourceFaceTileCapacity) {
                        faceIndex = sunDepthBuf[tileBase + 1u + candidate];
                    } else {
                        const uint node = kSourceFaceSpillNodeOffset + spill * kSourceFaceSpillNodeWords;
                        faceIndex = sunDepthBuf[node];
                        spill = sunDepthBuf[node + 1u];
                    }
                    const uint record = kSourceFaceRecordOffset + kSourceFaceRecordWords * faceIndex;
                    const float3 corner = float3(as_type<float>(sunDepthBuf[record]), as_type<float>(sunDepthBuf[record+1u]), as_type<float>(sunDepthBuf[record+2u]));
                    const float3 edgeU = float3(as_type<float>(sunDepthBuf[record+3u]), as_type<float>(sunDepthBuf[record+4u]), as_type<float>(sunDepthBuf[record+5u]));
                    const float3 edgeV = float3(as_type<float>(sunDepthBuf[record+6u]), as_type<float>(sunDepthBuf[record+7u]), as_type<float>(sunDepthBuf[record+8u]));
                    const uint type = sunDepthBuf[record + 9u];
#if IR_SUN_QUERY_STATS
                    if (type != 0u) sunQueryStats.counts[kSunQueryShapeCandidates] += 1u;
#endif
                    const float separation = type == 0u
                        ? sourceFaceRaySeparation(sunUV, sunZ, corner, edgeU, edgeV
#if IR_SUN_QUERY_STATS
                            , sunQueryStats
#endif
                        )
                        : sourceShapeRaySeparation(sunUV, sunZ, type, corner, edgeU, edgeV);
                    if (separation > kShadowBiasQuantNoise && separation < maxShadowThrow) {
#if IR_SUN_QUERY_STATS
                        sunQueryStats.counts[kSunQueryBlocked] += 1u;
                        sunQueryStats.counts[kSunQueryFirstBlockerVisits] += candidate + 1u;
#endif
                        return 1.0;
                    }
                }
#if IR_SUN_QUERY_STATS
                sunQueryStats.counts[kSunQueryExhausted] += 1u;
#endif
            }
#if IR_SUN_QUERY_STATS
        } else {
            sunQueryStats.counts[kSunQueryOutside] += 1u;
#endif
        }
    }
    // Finite footprints are rasterized at sun texel centers. Query their cell
    // without blending coverage across its boundary or moving the receiver.
    int2 nearestPixel = int2(floor((sunUV - origin) / texelSz));
    if (surfaceReceiver && nearestPixel.x >= 0 && nearestPixel.y >= 0 &&
        nearestPixel.x < kSunShadowMapDim && nearestPixel.y < kSunShadowMapDim) {
        // Indexed and other casters retain independent depths: rejecting an indexed
        // footprint must not discard another caster hidden behind its map sample.
        for (int layer = 0; layer < 2; ++layer) {
            if (layer == 1 && sourceQueryComplete) continue;
            uint nearest = sunDepthBuf[bufferOffset + nearestPixel.y * kSunShadowMapDim + nearestPixel.x
                + (layer == 1 ? int(kSourceFaceFallbackOffset) : 0)];
            if (sunWriteIsSurface(nearest)) {
                float facing = dot(normal, sunDir);
                if (facing <= 0.0) return 0.0;
                float3 planeNormal = normal;
                const int casterFace = sunVoxelFaceId(nearest);
                if (casterFace >= 0) {
                    planeNormal = faceOutwardNormal6(casterFace);
                    if (sunVoxelFaceViewAligned(nearest))
                        planeNormal = rotateByQuat(planeNormal, casterViewToWorld);
                }
                float2 gradient = float2(dot(planeNormal, uHat), dot(planeNormal, vHat)) / dot(planeNormal, sunDir);
                float2 tapUV = origin + (float2(nearestPixel) + 0.5) * texelSz;
                float casterZ = unpackSunDepth(nearest) + dot(gradient, sunUV - tapUV);
                const float2 receiverGradient = float2(dot(normal, uHat), dot(normal, vHat)) / facing;
                const float receiverSeparation = sunZ + dot(receiverGradient, tapUV - sunUV) - unpackSunDepth(nearest);
                const float casterSeparation = sunZ - casterZ;
                // A frontmost tap alone cannot establish coverage at the receiver.
                // Require front-to-back order on both planes before accepting it.
                if (min(casterSeparation, receiverSeparation) > kShadowBiasQuantNoise &&
                    max(casterSeparation, receiverSeparation) < maxShadowThrow) return 1.0;
            }
        }
    }
    float slope = max(kShadowBiasSlopeMin, dot(normal, sunDir));
    float texelSize = max(texelSz.x, texelSz.y);
    // Receiver tolerance accounts for slope, map resolution and depth quantization.
    float bias = texelSize * kShadowBiasTexelScale / slope + kShadowBiasQuantNoise;

    // Receiver-plane depth gradient in sun-UV, used only by the splat-tap
    // same-plane test below. With (uHat, vHat, sunDir) orthonormal and depth
    // z = -dot(P, sunDir), a displacement within the receiver plane gives
    // dz/du = dot(uHat, normal)/dot(sunDir, normal) (and likewise v), with
    // dot(sunDir, normal) == slope — so the plane's depth at sun-UV q is
    // sunZ + dot(gradUV, q - sunUV). Sign is + (a coplanar occluder at the write
    // origin must reproduce its own depth → h ~ 0 → lit). Mirrors the GLSL twin.
    float2 gradUV = float2(dot(normal, uHat), dot(normal, vHat)) / slope;

    // The source-face and nearest-tap queries use the exact receiver; only the
    // canvas-baked coverage layer takes the caller's sun-space offset.
    sunUV += pcfOffset.xy;
    sunZ += pcfOffset.z;

    // Map samples lie at texel centers; integer coordinates address those samples.
    float2 sunPxF = (sunUV - origin) / texelSz - 0.5f;
    int2 base = int2(floor(sunPxF));
    float2 frac = sunPxF - float2(base);
    float shadowAccum = 0.0;
    for (int dy = 0; dy < 2; ++dy) {
        for (int dx = 0; dx < 2; ++dx) {
            int2 px = base + int2(dx, dy);
            if (px.x < 0 || px.x >= kSunShadowMapDim ||
                px.y < 0 || px.y >= kSunShadowMapDim) continue;
            uint stored = sunDepthBuf[bufferOffset + px.y * kSunShadowMapDim + px.x];
            if (!surfaceReceiver && hasSourceFaces)
                stored = min(stored, sunDepthBuf[kSourceFaceFallbackOffset + bufferOffset + px.y * kSunShadowMapDim + px.x]);
            if (stored == 0xFFFFFFFFu || (surfaceReceiver && sunWriteIsSurface(stored))) continue;
            float nearestZ = unpackSunDepth(stored);
            float weight = mix(1.0f - frac.x, frac.x, float(dx))
                         * mix(1.0f - frac.y, frac.y, float(dy));
            // Far shadow-throw window — raw sun-Z gap, on BOTH tap regimes.
            // maxShadowThrow == the feeder / bake sweep (kSunShadowMaxDistance) so
            // a baked caster is receivable at its full throw. Mirrors the GLSL twin.
            float depthDiff = sunZ - nearestZ;
            if (depthDiff - bias >= maxShadowThrow) continue;

            if (sunWriteIsDirect(stored) || sunWriteIsSurface(stored)) {
                // Direct and finite surface writes compare depth without splat-origin recovery.
                if (depthDiff > bias) shadowAccum += weight;
            } else {
                // Coverage-SPLAT neighbour: reconstruct the write's origin
                // and reject an occluder that lies in the RECEIVER's own plane
                // (a same-face self-hit → h ~ 0 → lit at any splat distance); a
                // genuine cast sits far above the plane (h ~ caster height → shadow
                // at the base tolerance, no widening → no erosion). Mirrors GLSL.
                int2 offset = unpackSunSplatOffset(stored);
                int2 originTexel = px - offset;
                float2 originUV = origin + (float2(originTexel) + 0.5f) * texelSz;
                float expectedZ = sunZ + dot(gradUV, originUV - sunUV);
                float h = expectedZ - nearestZ;
                if (h > bias) shadowAccum += weight;
            }
        }
    }
    return shadowAccum;
}

// Direct-sun visibility at a world-space surface: 1.0 lit, 0.0 occluded.
// Ambient lighting is composed separately. isoDepth selects/blends cascades.
inline float worldSunShadowFactorImpl(
    float3 pos3D, float3 normal, float isoDepth,
    constant FrameDataSun &sun, device const uint *sunDepthBuf, bool surfaceReceiver, float4 casterViewToWorld,
    float pcfNormalBias
#if IR_SUN_QUERY_STATS
    , thread SunQueryStats &sunQueryStats
#endif
) {
    float3 sunDir = sun.sunDirection.xyz;
    float3 uHat = sun.sunBasisU.xyz;
    float3 vHat = sun.sunBasisV.xyz;
    const float3 pcfOffset = sunSpaceProject(normal * pcfNormalBias, uHat, vHat, sunDir);
    // Shared caster/receiver projection — the bake derives every
    // caster's sun UV + depth from this same function, so cast and receive
    // cannot drift.
    float3 sunProj = sunSpaceProject(
        pos3D, uHat, vHat, sunDir
    );
    float2 sunUV = sunProj.xy;
    float sunZ = sunProj.z;

    int firstCascade = 0;
    int cascadeSamples = 1;
    float blend = 0.0;
    if (sun.cascadeCount > 1) {
        float distToSplit = isoDepth - sun.cascadeSplitDepth;
        // Covering-cascade fallback: the near cascade is valid for
        // this receiver only where its PCF kernel sits interior to the map —
        // its AABB was built from a depth-capped corner set, so a receiver
        // near the map edge (screen corners, the split blend band past the
        // cap) can straddle a region where taps fall out of bounds and the
        // matching casters were bounds-dropped by the bake. Selecting the
        // covering far cascade there trades texel resolution for a complete
        // kernel instead of silently reading the missing region as "lit"
        // (partial face dropout). The gate is per-receiver-UV, uniform across
        // a voxel's faces, so a straddling voxel's faces select consistently.
        bool nearInterior =
            sunCascadeKernelInterior(sunUV, sun.cascadeOriginUV_0, sun.cascadeTexelSize_0);
        if (nearInterior && distToSplit < -kCascadeBlendRange) {
            firstCascade = 0;
        } else if (!nearInterior || distToSplit > kCascadeBlendRange) {
            firstCascade = 1;
        } else {
            cascadeSamples = 2;
            blend = smoothstep(-kCascadeBlendRange, kCascadeBlendRange, distToSplit);
        }
    }
    // Keep cascade selection at one exact-query call site.
    float shadowAccum = 0.0;
    for (int sampleIndex = 0; sampleIndex < cascadeSamples; ++sampleIndex) {
        const int cascade = firstCascade + sampleIndex;
        float2 origin = sun.sunBufferOriginUV;
        float2 texelSize = sun.sunBufferTexelSize;
        if (sun.cascadeCount > 1) {
            origin = cascade == 0 ? sun.cascadeOriginUV_0 : sun.cascadeOriginUV_1;
            texelSize = cascade == 0 ? sun.cascadeTexelSize_0 : sun.cascadeTexelSize_1;
        }
        const float shadow = sampleCascadeShadow(
            sunUV, sunZ, normal, sunDir, uHat, vHat,
            origin, texelSize, cascade * kCascadeTexelCount, sunDepthBuf, sun.sunMaxShadowThrow, surfaceReceiver, casterViewToWorld,
            pcfOffset
#if IR_SUN_QUERY_STATS
            , sunQueryStats
#endif
        );
        shadowAccum = sampleIndex == 0 ? shadow : mix(shadowAccum, shadow, blend);
    }
    return 1.0f - shadowAccum;
}

// Raster-origin receivers retain their outward sampling offset.
inline float worldSunShadowFactor(
    float3 pos3D, float3 normal, float isoDepth,
    constant FrameDataSun &sunFrameData, device const uint *sunDepthBuf
#if IR_SUN_QUERY_STATS
    , thread SunQueryStats &sunQueryStats
#endif
) {
    return worldSunShadowFactorImpl(pos3D + normal * kNormalBiasVoxels, normal, isoDepth, sunFrameData, sunDepthBuf, false, float4(0.0, 0.0, 0.0, 1.0), 0.0
#if IR_SUN_QUERY_STATS
        , sunQueryStats
#endif
    );
}

inline float worldSurfaceSunShadowFactor(
    float3 pos3D, float3 normal, float isoDepth, float4 casterViewToWorld,
    constant FrameDataSun &sunFrameData, device const uint *sunDepthBuf
#if IR_SUN_QUERY_STATS
    , thread SunQueryStats &sunQueryStats
#endif
) {
    return worldSunShadowFactorImpl(pos3D, normal, isoDepth, sunFrameData, sunDepthBuf, true, casterViewToWorld, 0.0
#if IR_SUN_QUERY_STATS
        , sunQueryStats
#endif
    );
}

// Finite shape fragments: the canvas-baked coverage splats of the shape's own
// cells are calibrated against the raster receiver's outward offset, so the
// exact fragment position would fail their same-plane test near a face edge.
inline float worldShapeSurfaceSunShadowFactor(
    float3 pos3D, float3 normal, float isoDepth, float4 casterViewToWorld,
    constant FrameDataSun &sunFrameData, device const uint *sunDepthBuf
#if IR_SUN_QUERY_STATS
    , thread SunQueryStats &sunQueryStats
#endif
) {
    return worldSunShadowFactorImpl(pos3D, normal, isoDepth, sunFrameData, sunDepthBuf, true, casterViewToWorld, kNormalBiasVoxels
#if IR_SUN_QUERY_STATS
        , sunQueryStats
#endif
    );
}

#endif // IR_SUN_SHADOW_SAMPLE_METAL_INCLUDED

kernel void initialize(device uint* buffer [[buffer(0)]],
                       constant uint2& config [[buffer(1)]],
                       uint id [[thread_position_in_grid]]) {
    const uint count=config.x, kind=config.y;
    if(id==0){
        buffer[kSourceFaceHeaderOffset]=count;
        buffer[sourceFaceTileBase(0)]=count;
        buffer[kSourceFaceSpillCounterOffset]=count>kSourceFaceTileCapacity
            ? count-kSourceFaceTileCapacity : 0u;
        buffer[kSourceFaceSpillHeadOffset]=0u;
    }
    if(id<kSourceFaceTileCapacity)buffer[sourceFaceTileBase(0)+1u+id]=id;
    else {
        const uint node=kSourceFaceSpillNodeOffset+(id-kSourceFaceTileCapacity)*2u;
        buffer[node]=id;
        buffer[node+1u]=id+1u<count?id+1u-kSourceFaceTileCapacity:0xFFFFFFFFu;
    }
    float3 corner=float3(2,2,0), u=float3(1,0,0), v=float3(0,1,0);
    if(kind==1u){corner=float3(0,2,0);u=float3(2,2,0);v=float3(2,-2,0);}
    if(kind==2u || (kind==3u && id==0u) || (kind==4u && id+1u==count)){
        corner=float3(0,0,kind==2u?3.0:0.0);u=float3(4,0,0);v=float3(0,4,0);
    }
    const uint record=kSourceFaceRecordOffset+id*kSourceFaceRecordWords;
    for(uint axis=0;axis<3;++axis){
        buffer[record+axis]=as_type<uint>(corner[axis]);
        buffer[record+3u+axis]=as_type<uint>(u[axis]);
        buffer[record+6u+axis]=as_type<uint>(v[axis]);
    }
    buffer[record+9u]=0u;
}
kernel void probe(device const uint* buffer [[buffer(0)]],
                  device uint* output [[buffer(1)]], uint id [[thread_position_in_grid]]) {
    const float2 point=0.25+float2(id%256u,(id/256u)%256u)/512.0;
#if IR_SUN_QUERY_STATS
    SunQueryStats stats={};
#endif
    const float shadow=sampleCascadeShadow(point,2.0,float3(0,0,1),float3(0,0,1),
        float3(1,0,0),float3(0,1,0),float2(0),float2(1),0,buffer,128.0,true,
        float4(0,0,0,1),float3(0)
#if IR_SUN_QUERY_STATS
        ,stats
#endif
    );
#if IR_SUN_QUERY_STATS
    for(uint counter=0;counter<kSunQueryCounterCount;++counter)
        output[id*11u+1u+counter]=stats.counts[counter];
    output[id*11u]=as_type<uint>(shadow);
#else
    output[id]=as_type<uint>(shadow);
#endif
}
