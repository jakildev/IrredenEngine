
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
int main(int argc,char** argv){@autoreleasepool{
    if(argc!=6)return 2;
    const NSUInteger queries=std::strtoul(argv[3],nullptr,10);
    const NSUInteger rounds=std::strtoul(argv[4],nullptr,10);
    const bool measure=std::strcmp(argv[5],"measure")==0;
    id<MTLDevice> device=MTLCreateSystemDefaultDevice();
    if(!device){std::fprintf(stderr,"No Metal device\n");return 2;}
    NSError* error=nil;
    id<MTLComputePipelineState> pipelines[2],initialize=nil;
    for(int mode=0;mode<2;++mode){
        NSString* source=[NSString stringWithContentsOfFile:@(argv[mode+1])
                           encoding:NSUTF8StringEncoding error:&error];
        id<MTLLibrary> lib=[device newLibraryWithSource:source options:nil error:&error];
        if(!lib){std::fprintf(stderr,"%s\n",error.description.UTF8String);return 2;}
        pipelines[mode]=[device newComputePipelineStateWithFunction:
            [lib newFunctionWithName:@"probe"] error:&error];
        if(!pipelines[mode]){std::fprintf(stderr,"%s\n",error.description.UTF8String);return 2;}
        if(mode==0)initialize=[device newComputePipelineStateWithFunction:
            [lib newFunctionWithName:@"initialize"] error:&error];
    }
    if(!initialize)return 2;
    id<MTLBuffer> buffer=[device newBufferWithLength:30146568
                          options:MTLResourceStorageModeShared];
    id<MTLBuffer> output=[device newBufferWithLength:queries*11*sizeof(uint32_t)
                          options:MTLResourceStorageModeShared];
    if(!buffer||!output)return 2;
    id<MTLCommandQueue> queue=[device newCommandQueue];
    NSMutableArray* reports=[NSMutableArray array];
    for(NSUInteger round=0;round<(measure?rounds+2:1);++round){
        for(uint32_t order=0;order<10;++order){
            const uint32_t cell=round%2?9u-order:order;
            const uint32_t count=cell<5?64u:256u, kind=cell%5;
            uint32_t config[]={count,kind};
            std::memset(buffer.contents,0xff,buffer.length);
            id<MTLCommandBuffer> setup=[queue commandBuffer];
            id<MTLComputeCommandEncoder> enc=[setup computeCommandEncoder];
            [enc setComputePipelineState:initialize];[enc setBuffer:buffer offset:0 atIndex:0];
            [enc setBytes:config length:sizeof(config) atIndex:1];
            [enc dispatchThreads:MTLSizeMake(count,1,1)
                  threadsPerThreadgroup:MTLSizeMake(MIN(count,initialize.maxTotalThreadsPerThreadgroup),1,1)];
            [enc endEncoding];[setup commit];[setup waitUntilCompleted];
            if(setup.status!=MTLCommandBufferStatusCompleted)return 3;
            for(int mode=0;mode<(round==0?2:1);++mode){
                std::memset(output.contents,0xcd,output.length);
                id<MTLCommandBuffer> command=[queue commandBuffer];
                const uint32_t dispatches=mode==0&&measure?8u:1u;
                for(uint32_t batch=0;batch<dispatches;++batch){
                    enc=[command computeCommandEncoder];
                    [enc setComputePipelineState:pipelines[mode]];
                    [enc setBuffer:buffer offset:0 atIndex:0];
                    [enc setBuffer:output offset:0 atIndex:1];
                    [enc dispatchThreads:MTLSizeMake(queries,1,1)
                          threadsPerThreadgroup:MTLSizeMake(MIN(256,pipelines[mode].maxTotalThreadsPerThreadgroup),1,1)];
                    [enc endEncoding];
                }
                [command commit];[command waitUntilCompleted];
                if(command.status!=MTLCommandBufferStatusCompleted)return 3;
                const uint32_t* words=(uint32_t*)output.contents;
                const uint32_t expectedShadow=kind>=3?0x3f800000u:0u;
                const uint32_t visits=kind==3?1u:count;
                const uint32_t misses=kind==2||kind==3?0u:(kind==4?count-1u:count);
                const uint32_t expected[]={1,1,visits,misses,0,kind>=3?1u:0u,
                    kind>=3?visits:0u,kind<3?1u:0u,0,0};
                for(NSUInteger i=0;i<queries;++i){
                    if(words[i*(mode?11:1)]!=expectedShadow){
                        std::fprintf(stderr,"shadow mismatch cell %u receiver %lu\n",cell,i);
                        return 4;
                    }
                    if(mode)for(uint32_t k=0;k<10;++k)if(words[i*11+1+k]!=expected[k]){
                        std::fprintf(stderr,"counter mismatch cell %u counter %u: %u != %u\n",
                            cell,k,words[i*11+1+k],expected[k]);return 4;
                    }
                }
                const double ms=(command.GPUEndTime-command.GPUStartTime)*1000.0/dispatches;
                if(measure&&(!std::isfinite(ms)||ms<=0)){
                    std::fprintf(stderr,"Invalid GPU timestamps\n");return 5;
                }
                if(measure&&mode==0&&round>=2)[reports addObject:@{@"round":@(round-2),
                    @"count":@(count),@"kind":@(kind),@"gpu_ms":@(ms),
                    @"candidate_visits_per_receiver":@(visits),@"face_misses_per_receiver":@(misses)}];
            }
        }
    }
    NSDictionary* result=@{@"device":device.name,@"queries":@(queries),
        @"rounds":@(measure?rounds:0),@"measurement":@(measure),@"warmup_rounds":@(measure?2:0),
        @"dispatches_per_sample":@(measure?8:1),@"compile_options":@"nil (runtime default)",
        @"diagnostic_all_receivers_validated":@YES,@"samples":reports};
    NSData* json=[NSJSONSerialization dataWithJSONObject:result options:0 error:&error];
    std::fwrite(json.bytes,1,json.length,stdout);std::printf("\n");return 0;
}}
