#include <irreden/ir_args.hpp>
#include <irreden/ir_engine.hpp>
#include <irreden/ir_system.hpp>
#include <irreden/ir_entity.hpp>
#include <irreden/ir_input.hpp>
#include <irreden/ir_video.hpp>
#include <irreden/ir_window.hpp>
#include <irreden/ir_render.hpp>
#include <irreden/ir_constants.hpp>
#include <irreden/render/camera.hpp>
#include <irreden/render/cull_viewport_state.hpp>
#include <irreden/render/default_pivot_latch.hpp>
#include <irreden/render/shape_sample_probe.hpp>

#include <irreden/asset/voxel_set_format.hpp>
#include <irreden/voxel/dense_bridge.hpp>
#include <irreden/script/lua_script.hpp>
#include <irreden/script/prefab_api.hpp>

#include "lod_scene.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <iterator>
#include <numbers>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>
// COMPONENTS
#include <irreden/common/components/component_auto_spin_lua.hpp>
#include <irreden/common/components/component_local_transform.hpp>
#include <irreden/voxel/components/component_voxel_set.hpp>
#include <irreden/voxel/components/component_voxel_pool.hpp>
#include <irreden/voxel/voxel_pool_api.hpp>
#include <irreden/voxel/components/component_shape_descriptor.hpp>
#include <irreden/voxel/components/component_joint.hpp>
#include <irreden/voxel/components/component_skeleton.hpp>
#include <irreden/render/components/component_canvas_ao_texture.hpp>
#include <irreden/render/components/component_canvas_light_volume.hpp>
#include <irreden/render/components/component_canvas_sun_shadow.hpp>
#include <irreden/render/components/component_light_source.hpp>
#include <irreden/render/components/component_light_blocker.hpp>
#include <irreden/render/components/component_triangle_canvas_textures.hpp>
#include <irreden/render/components/component_trixel_framebuffer.hpp>
#include <irreden/render/components/component_trixel_canvas_render_behavior.hpp>
#include <irreden/render/camera.hpp>

// SYSTEMS
#include <irreden/update/systems/system_auto_spin_local_transform.hpp>
#include <irreden/update/systems/system_prefab_lod_parts.hpp>
#include <irreden/update/systems/system_propagate_transform.hpp>
#include <irreden/render/systems/system_gate_voxel_sets_by_lod.hpp>
#include <irreden/render/systems/system_lod_update.hpp>
#include <irreden/voxel/systems/system_rebuild_grid_voxels.hpp>
#include <irreden/voxel/systems/system_update_voxel_set_children.hpp>
#include <irreden/input/systems/system_input_key_mouse.hpp>
#include <irreden/render/systems/system_voxel_to_trixel.hpp>
#include <irreden/render/systems/system_update_voxel_positions_gpu.hpp>
#include <irreden/render/systems/system_update_joint_matrices.hpp>
#include <irreden/common/rotation_mode.hpp>
#include <irreden/render/systems/system_shapes_to_trixel.hpp>
#include <irreden/render/systems/system_build_distance_hiz.hpp>
#include <irreden/render/systems/system_build_light_occlusion_grid.hpp>
#include <irreden/render/systems/system_compute_voxel_ao.hpp>
#include <irreden/render/systems/system_resolve_per_axis_screen_depth.hpp>
#include <irreden/render/systems/system_bake_sun_shadow_map.hpp>
#include <irreden/render/systems/system_compute_sun_shadow.hpp>
#include <irreden/render/systems/system_compute_light_volume.hpp>
#include <irreden/render/systems/system_lighting_to_trixel.hpp>
#include <irreden/render/systems/system_debug_culling_minimap.hpp>
#include <irreden/render/systems/system_debug_overlay.hpp>
#include <irreden/render/systems/system_trixel_to_framebuffer.hpp>
#include <irreden/render/systems/system_framebuffer_to_screen.hpp>
#include <irreden/render/systems/system_gui_canvas_to_screen.hpp>
#include <irreden/render/systems/system_sprites_to_screen.hpp>
#include <irreden/render/camera_controls.hpp>
#include <irreden/common/settings_registry.hpp>
#include <irreden/common/sim_clock.hpp>
#include <irreden/render/cursor_pivot.hpp>
#include <irreden/render/gui_test_assertions.hpp>
#include <irreden/render/help_overlay.hpp>
#include <irreden/render/settings_menu.hpp>
#include <irreden/render/systems/system_text_to_trixel.hpp>
#include <irreden/render/systems/system_render_velocity_2d_iso.hpp>
#include <irreden/render/systems/system_auto_yaw_rotate.hpp>
#include <irreden/render/systems/system_sync_viewport_subjects.hpp>
#include <irreden/render/systems/system_viewport_to_framebuffer.hpp>
#include <irreden/render/viewport.hpp>

// COMMAND SUITES
#include <irreden/common/command_suite_capture.hpp>
#include <irreden/render/commands/command_toggle_culling_freeze.hpp>
#include <irreden/render/commands/command_toggle_culling_minimap.hpp>

namespace {

// ROI crop tables are framebuffer-pixel coords; values below assume the
// 1280x720 default game resolution (`kGameResolution`). On HiDPI hosts the
// framebuffer is a power-of-two larger and the crops land in the upper-left
// quadrant of the captured image — still useful for edge-fidelity inspection
// at a given fixed offset. Pixel-precise crop placement is intentionally a
// per-host iteration point; refine the coords as the demo's content evolves.
constexpr IRVideo::RoiCrop kCropsZoom4Origin[] = {
    {520, 280, 128, 128, "center_cube_top"},
    {220, 280, 128, 128, "left_cube_silhouette"},
    {820, 280, 128, 128, "right_cube_silhouette"},
};

constexpr IRVideo::RoiCrop kCropsZoom8Origin[] = {
    {520, 280, 128, 128, "center_cube_top"},
    {300, 400, 128, 128, "lower_left_face"},
};

// --pivot-focus-demo: a tall strip over screen center where the pinned
// pillar sits. With the focus pinned the pillar holds this crop steady across
// the yaw sweep; with --pivot-origin it swings out of frame. Coords are a per-host
// iteration point (see the kCrops* note above). Tuned for the HiDPI 2x
// framebuffer (pillar pivot-pins at frame center ~(1280,720) of 2560x1440).
// Linux/1x smoke: update to ~{490, 100, 300, 520} (center≈(640,360) of
// 1280x720) and re-baseline after confirming the pillar stays centered.
constexpr IRVideo::RoiCrop kCropsPivotPillar[] = {
    {1130, 460, 300, 520, "pivot_pillar_center"},
};

constexpr IRVideo::AutoScreenshotShot kShots[] = {
    {1.0f, vec2(0, 0), 0.0f, "zoom1_origin"},
    {2.0f, vec2(0, 0), 0.0f, "zoom2_origin"},
    {4.0f,
     vec2(0, 0),
     0.0f,
     "zoom4_origin",
     kCropsZoom4Origin,
     sizeof(kCropsZoom4Origin) / sizeof(kCropsZoom4Origin[0])},
    {1.0f, vec2(1, 0), 0.0f, "zoom1_odd_offset"},
    {8.0f,
     vec2(0, 0),
     0.0f,
     "zoom8_origin",
     kCropsZoom8Origin,
     sizeof(kCropsZoom8Origin) / sizeof(kCropsZoom8Origin[0])},
    {4.0f, vec2(3, 5), 0.0f, "zoom4_offset_3_5"},
    // LOD swap: the co-located stack renders exactly ONE variant per
    // zoom band — cube (zoom 1-3) -> cone (zoom 4-15) -> sphere (zoom >=16) —
    // never stacked. This whole-scene shot samples the finest (sphere) tier.
    {16.0f, vec2(0, 0), 0.0f, "zoom16_lod_fine_sphere"},

    // Dedicated LOD swap series: cameraIso (16,-16) centers the
    // co-located LOD stack at world (0,-16,0) (= -pos3DtoPos2DIso((0,-16,0))),
    // with the single-LOD control cylinder beside it. As zoom climbs the stack
    // visibly swaps silhouette (cube -> cone -> sphere) while the control holds
    // constant — the unambiguous "LOD is working" read the issue asks for.
    {1.0f, vec2(16, -16), 0.0f, "lod_swap_zoom1_cube"},
    {2.0f, vec2(16, -16), 0.0f, "lod_swap_zoom2_cube"},
    {4.0f, vec2(16, -16), 0.0f, "lod_swap_zoom4_cone"},
    {8.0f, vec2(16, -16), 0.0f, "lod_swap_zoom8_cone"},
    {16.0f, vec2(16, -16), 0.0f, "lod_swap_zoom16_sphere"},

    // Rotation coverage: four cardinals + one inter-cardinal expose
    // rotation-only regressions (checkerboard, inter-cardinal
    // deformation, future face-normal / shadow-AABB / chunk-mask bugs) that
    // a yaw=0 shot list cannot catch. zoom8 close-ups make sub-pixel
    // parity artifacts visible at full pixel scale.
    {4.0f, vec2(0, 0), IRMath::kHalfPi, "zoom4_yaw90"},
    {4.0f, vec2(0, 0), IRMath::kPi, "zoom4_yaw180"},
    {4.0f, vec2(0, 0), 3.0f * IRMath::kHalfPi, "zoom4_yaw270"},
    {4.0f, vec2(0, 0), IRMath::kQuarterPi, "zoom4_yaw45_inter_cardinal"},
    {8.0f,
     vec2(0, 0),
     IRMath::kPi,
     "zoom8_yaw180",
     kCropsZoom8Origin,
     sizeof(kCropsZoom8Origin) / sizeof(kCropsZoom8Origin[0])},

    // Camera-focus pivot coverage: the camera is panned off-origin and
    // then yawed. With RotationPivotMode::CAMERA_CENTER (the engine default)
    // the world point under screen center stays pinned across the whole sweep —
    // the same focused content sits at the same screen pixel in all four shots.
    // The ORIGIN pivot (reproducible via --pivot-origin) instead swings
    // that content in an arc. A shot list with only unpanned-or-yaw0 entries
    // cannot catch a pivot regression: the CAMERA_CENTER correction is the
    // identity unless the camera is BOTH panned and rotated, so every existing
    // shot is byte-identical between the two modes. yaw45 also exercises the
    // per-axis smooth-yaw scatter base (perAxisBase_) under the pivot.
    {4.0f, vec2(16, 16), 0.0f, "zoom4_pan16_yaw0_pivot"},
    {4.0f, vec2(16, 16), IRMath::kHalfPi, "zoom4_pan16_yaw90_pivot"},
    {4.0f, vec2(16, 16), IRMath::kPi, "zoom4_pan16_yaw180_pivot"},
    {4.0f, vec2(16, 16), IRMath::kQuarterPi, "zoom4_pan16_yaw45_pivot"},
};

constexpr IRVideo::AutoScreenshotShot kShadowFootprintShots[] = {
    {4.0f, vec2(0.0f), 0.0f, "shadow_footprint_yaw0"},
    {4.0f, vec2(0.0f), IRMath::kQuarterPi, "shadow_footprint_yaw45"},
};

// A voxel cube falling over a voxel floor in quarter-voxel steps: shot i holds
// the caster at kMovingCasterStart + i * kMovingCasterStep. At zoom 2 with a
// base subdivision of 2 the raster places it on a quarter-voxel lattice while a
// sun-map texel spans about a voxel, so a cast shadow that follows sub-voxel
// placement moves on every shot.
constexpr vec3 kMovingCasterStart{-2.0f, -2.0f, -4.0f};
constexpr vec3 kMovingCasterStep{0.0f, 0.0f, 0.25f};
constexpr int kMovingCasterSubdivisions = 2;
constexpr vec3 kMovingCasterSunDirection{0.5f, 0.7f, -0.5f};
constexpr IRVideo::AutoScreenshotShot kMovingCasterShots[] = {
    {2.0f, vec2(0.0f), 0.0f, "moving_caster_0"},
    {2.0f, vec2(0.0f), 0.0f, "moving_caster_1"},
    {2.0f, vec2(0.0f), 0.0f, "moving_caster_2"},
    {2.0f, vec2(0.0f), 0.0f, "moving_caster_3"},
    {2.0f, vec2(0.0f), 0.0f, "moving_caster_4"},
    {2.0f, vec2(0.0f), 0.0f, "moving_caster_5"},
    {2.0f, vec2(0.0f), 0.0f, "moving_caster_6"},
    {2.0f, vec2(0.0f), 0.0f, "moving_caster_7"},
    {2.0f, vec2(0.0f), 0.0f, "moving_caster_8"},
};
bool g_movingCaster = false;
IREntity::EntityId g_movingCasterEntity = IREntity::kNullEntity;

int g_autoWarmupFrames = 0; // 0 = --auto-screenshot not requested
int g_autoRecordFrames = 0; // 0 = --auto-record not requested
bool g_depthColor = false;
bool g_checkerboard = false; // opt-in via --checkerboard; flickered, off by default
// Sim rate in effect before the PAUSE SIMULATION setting was flipped on, so
// unpausing restores it instead of hard-resetting to 1x — the contract
// `System<SETTINGS_MENU>::destroyMenu()` keeps for its own pause path, and this
// demo is the reference other creations copy the setter shape from.
float g_timeScaleBeforePause = 1.0f;
// --occlusion-cull: force the voxel-pool chunk-occlusion HZB
// pre-pass on (off by default in the engine). A test hook so the cull can be
// exercised before the measurement demo lands. On the sparse shape_debug
// scene nothing is inter-object-occluded, so output must stay identical (a hole
// would be a false-positive cull bug).
bool g_occlusionCull = false;
// --gpu-voxel-smoke: spawn one voxel cube routed through the GPU
// voxel-position prepass with a fixed 45° rotation. Off by default so the
// standard scene stays byte-identical; the rotated cube is direct proof the
// prepass applied modelToWorld (the CPU world-position path is translation-only).
bool g_gpuVoxelSmoke = false;
// --skin-smoke: spawn one 2-bone rigged voxel bar skinned through the
// binding-17 bone→slot seed path, with the second joint posed off its bind
// pose. Off by default so the standard scene stays byte-identical; the visible
// bend at the bar's midpoint is direct proof the per-voxel slots route through
// the joint skin matrices (a rigid entity transform cannot bend a set).
bool g_skinSmoke = false;
bool g_shadowFootprintProbe = false;
int g_autoProfileFrames = 0; // 0 = disabled
int g_autoProfileCount = 0;
float g_initialZoom = 0.0f; // 0 = use engine default
float g_initialYawRadians = 0.0f;
float g_initialYaw = 0.0f;
bool g_initialYawSet = false;
// --pivot-origin: force RotationPivotMode::ORIGIN (the
// world-origin pivot) instead of the CAMERA_CENTER engine default. Lets the
// same panned+rotated shot list be captured in both modes for an A/B compare —
// CAMERA_CENTER pins the focused content at screen center, ORIGIN swings it in
// an arc. Off by default so the demo exercises the shipped default.
bool g_pivotOrigin = false;
IRRender::DebugOverlayMode g_debugOverlay = IRRender::DebugOverlayMode::NONE;
// --load-vxs <path>: load a DENSE-mode .vxs and render it alongside the built-in
// shape fixtures. Empty = not requested. When the path names one file of a
// `<base>_frame_<N>.vxs` set (what the voxel editor writes for a multi-frame
// animation), every sibling frame loads and the set plays back.
std::string g_loadVxsPath;
// --vxs-frame <N>: pin a multi-frame set to frame N instead of playing it back,
// so a screenshot names the pose it captured. Negative = play back.
int g_vxsFrame = -1;

// The loaded animation's frames and the entity they swap into. A single-frame
// asset holds exactly one entry and never registers the playback system, so its
// render path is byte-identical to the pre-animation one.
std::vector<std::vector<IRComponents::C_Voxel>> g_vxsFrames;
IREntity::EntityId g_vxsEntity = IREntity::kNullEntity;
// Playback rate, read from frame 0's `fps` META entry (the editor writes it
// from its FPS slider). The editor's own default when the key is absent.
float g_vxsFps = 12.0f;
// Accepted range for that entry. tickVxsPlayback casts kFPS / fps to int, so the
// floor keeps the quotient representable; the ceiling is the tick rate, past
// which every tick would advance a frame anyway.
constexpr float kVxsMinFps = 0.01f;
constexpr float kVxsMaxFps = static_cast<float>(IRConstants::kFPS);
// Ticks elapsed since the playback system started, so the cadence is counted in
// engine ticks rather than wall time. File-scope rather than a tick-local
// static, per .claude/rules/cpp-systems.md.
int g_vxsPlaybackTick = 0;

// Sibling frame files of a `<base>_frame_<N>.vxs` path, frame-ordered and
// contiguous from 0. A path without that suffix — or one whose frame 0 sibling
// is missing — resolves to just itself, so a single-file asset loads exactly as
// it did before multi-frame support.
//
// The `_frame_<N>` shape is the voxel editor's, written by
// `creations/editors/voxel_editor/scene_io.hpp` `detail::framePath` — this is
// the only reader of it outside that editor, and the two have to agree. The
// convention is not lifted into a shared header because there is exactly one
// writer and one reader; a rename on either side is a two-file edit, which the
// back-pointers here and at framePath are meant to make findable.
std::vector<std::string> resolveVxsFramePaths(const std::string &path) {
    namespace fs = std::filesystem;
    const fs::path given(path);
    const std::string stem = given.stem().string(); // drops the ".vxs"
    const std::string marker = "_frame_";
    const std::size_t markerAt = stem.rfind(marker);
    if (markerAt == std::string::npos)
        return {path};
    const std::string index = stem.substr(markerAt + marker.size());
    if (index.empty() || !std::all_of(index.begin(), index.end(), [](unsigned char c) {
            return std::isdigit(c) != 0;
        }))
        return {path};

    const fs::path dir = given.parent_path();
    const std::string base = stem.substr(0, markerAt);
    std::vector<std::string> frames;
    for (int frame = 0;; ++frame) {
        const fs::path candidate =
            dir / (base + marker + std::to_string(frame) + given.extension().string());
        if (!fs::exists(candidate))
            break;
        frames.push_back(candidate.string());
    }
    // A set that does not start at frame 0 (the caller pointed at frame 3 of a
    // set whose earlier files are absent) is not an animation this can play, so
    // fall back to the single file the caller actually named.
    return frames.empty() ? std::vector<std::string>{path} : frames;
}

// Advance the loaded animation one step every `kVxsFramesPerStep` ticks. The
// engine drives a fixed-step UPDATE under --auto-screenshot (isAutoCaptureActive
// pins one tick per render frame), so a tick-counted cadence steps the same way
// on every host instead of drifting with the frame time.
void tickVxsPlayback();

// Swap frame `index`'s voxels into the loaded set: a span copy over the
// already-allocated pool records, no reallocation.
//
// The copy writes the raw `voxels_` span, so it closes with
// `resyncAfterRawEdits()` (engine/prefabs/irreden/voxel/CLAUDE.md). The
// load-bearing half is the pool's active mask: it mirrors `color_.alpha_ != 0`,
// it is what `c_voxel_visibility_compact` reads *instead of* alpha, and
// it lives in the pool rather than in the voxel records — so copying records
// updates alpha and leaves the mask describing the frame that just left, and
// the swap renders a blend of the two poses. Same call, same reason, as the
// editor's own loadFrameToLive.
void showVxsFrame(int index) {
    if (g_vxsEntity == IREntity::kNullEntity || g_vxsFrames.empty())
        return;
    const std::vector<IRComponents::C_Voxel> &frame =
        g_vxsFrames[static_cast<std::size_t>(index) % g_vxsFrames.size()];
    auto &set = IREntity::getComponent<IRComponents::C_VoxelSetNew>(g_vxsEntity);
    if (frame.size() != set.voxels_.size())
        return;
    std::copy(frame.begin(), frame.end(), set.voxels_.begin());
    set.resyncAfterRawEdits();
}

void tickVxsPlayback() {
    if (g_vxsFrames.size() <= 1)
        return;
    const int ticksPerStep =
        IRMath::max(1, static_cast<int>(static_cast<float>(IRConstants::kFPS) / g_vxsFps));
    ++g_vxsPlaybackTick;
    if (g_vxsPlaybackTick % ticksPerStep != 0)
        return;
    showVxsFrame(g_vxsPlaybackTick / ticksPerStep);
}

// --spin-yaw [deg/sec]: drive the camera's Z-yaw at a constant
// rate so the cardinal/residual rebracket can be eyeballed (live) or sampled
// at N evenly-spaced angles (auto-screenshot). 0 = flag not requested.
float g_spinYawDegPerSec = 0.0f;
// In auto-screenshot + spin-yaw mode, --auto-screenshot's value is
// reinterpreted as "shot count across one rotation"; default 24 → every 15°
// which hits every cardinal (0/90/180/270°) and every rebracket (45/135/...).
int g_spinYawShotCount = 24;

// --spin-shape <name>: spawn a single shape centred at the origin (so
// camera Z-yaw-about-origin keeps it screen-centred) instead of the full
// side-by-side fixture scene — the per-shape isolation the temporal-jitter
// sweep harness (scripts/dev/shape-rotate-jitter-sweep) needs. Empty = full
// scene (default, byte-identical). --spin-shape-voxel renders the voxel-pool
// twin instead of the SDF solver, so both render paths can be scored.
std::string g_spinShapeType;
bool g_spinShapeVoxel = false;
// Centred ROI crop attached to every --spin-shape sweep shot so the jitter
// metric decodes a small PNG per frame — a full-framebuffer 100+-frame sweep
// is otherwise minutes of pure-Python PNG decode. Sized from the live
// framebuffer at sweep-build time; one shared crop suffices because the single
// shape stays screen-centred under yaw-about-origin.
IRVideo::RoiCrop g_spinShapeCrop{};

// Dynamic shot table populated at startup when --spin-yaw + --auto-screenshot
// are both set. Lives at namespace scope so the pointer handed to
// IRVideo::AutoScreenshotConfig outlives the game loop. The label strings
// are backed by a parallel buffer so each AutoScreenshotShot::label_ pointer
// remains stable.
std::vector<IRVideo::AutoScreenshotShot> g_spinYawShots;
std::vector<std::array<char, 32>> g_spinYawShotLabels;

// --cull-validate: frozen-cull free-fly validation harness. Requires
// --auto-screenshot. Builds a paired live/frozen camera sweep — a live
// (cull-tracking) pass followed by a frozen pass over the SAME poses with the
// cull pinned at a deliberately wide reference. Pairwise-diffing the on-screen
// region of cv_live_NNN vs cv_frozen_NNN proves the live cull never drops
// on-screen content under yaw + camera movement. Same stable-storage discipline
// as the spin-yaw buffers above.
bool g_cullValidate = false;
std::vector<IRVideo::AutoScreenshotShot> g_cullValidateShots;
std::vector<std::array<char, 40>> g_cullValidateShotLabels;

// --pivot-focus-demo: spawn a tall, off-center voxel pillar and drive a
// yaw sweep that pins the camera Z-yaw pivot on the pillar's TRUE-depth center
// via AutoScreenshotShot::pivotFocusWorld_. With the focus set the pillar
// rotates in place — it stays at screen center across the whole sweep,
// including its z>0 body. Add --pivot-origin for the A/B where the z=0
// screen-center pivot swings it in an arc. Requires --auto-screenshot. Same
// stable-storage discipline as the buffers above.
bool g_pivotFocusDemo = false;
std::vector<IRVideo::AutoScreenshotShot> g_pivotFocusShots;
std::vector<std::array<char, 40>> g_pivotFocusShotLabels;
// World center of the --pivot-focus-demo pillar. Off the world origin in x/y AND
// at z > 0, so the origin pivot exhibits BOTH defects: its z=0 focus lands
// horizontally offset from a centered tall column, and an off-origin column
// orbits the origin. Shared by the spawn and the shot table so
// the focus exactly matches the rendered geometry.
constexpr vec3 kPivotPillarCenter = vec3(8.0f, -8.0f, 10.0f);

// --pivot-verify <block>: deterministic rotation-pivot invariance harness.
// Each block spawns ONE vertical voxel cylinder (Z-yaw-invariant silhouette, so
// its whole-silhouette centroid is immune to face-triplet changes) and sweeps
// the camera yaw through cardinals + non-cardinals at a fixed pan; jitter_probe
// --stationary then asserts the centroid holds its frame-0 position. Blocks:
//   focus-ctr     — explicit focus on the probe center, probe at screen center.
//   focus-off     — explicit focus on the probe center, probe panned off-center
//                   (catches errors that vanish exactly at screen center).
//   center-column — DEFAULT pivot; probe on the pinned vertical column (the
//                   depth-0 focus's xy) at z > 0. Verifies the implemented
//                   contract: the pivot correction pins the column
//                   {W : W.xy == F.xy}, so this probe must hold even though it
//                   renders below screen center.
//   center-depth  — DEFAULT pivot; probe AT the viewport center but at z > 0:
//                   on the center iso RAY, off the pinned column by (z, z) in
//                   xy. Encodes the ratified contract: the SURFACE point under
//                   the crosshair holds its screen position.
//   background-center — DEFAULT pivot, BACKGROUND center pixel: the probe sits
//                   on the pinned column but high enough in z that the
//                   viewport-center iso ray passes UNDER it (the ray is within
//                   the column's radius only for |z| <= r/sqrt(2)), so the
//                   center pixel reads background and the derive must fall back
//                   to `isoPixelToPos3D(viewCenterIso, 0)` — the depth-0
//                   point. Discharges the acceptance criterion; center-column cannot, because its
//                   center pixel hits the probe and so never exercises the
//                   fallback.
//   center-axis   — DEFAULT pivot, probe axis through the point where the
//                   yaw-0 viewport-center ray enters its near cap, so the
//                   acquired surface point IS the probe's own axis point and
//                   rotating about it maps the column onto itself — the
//                   derived-focus twin of focus-ctr. It isolates how far the
//                   derive lands from that axis: a regression to the
//                   iso-depth-0 focus swings the probe about a point 8.5 world
//                   units away.
//   cursor-latch  — CURSOR pivot: center-axis's probe on an integer axis
//                   through the near-cap voxel the ray enters, and
//                   the focus comes from IRPrefab::CursorPivot::resolveFocusWorld
//                   — the real castVoxelRay path — with a synthetic cursor
//                   parked on the viewport-center anchor's screen pixel. The
//                   latch is resolved ONCE (mirroring mouse-DOWN) and held for
//                   the sweep. Because the resolved surface point sits on the
//                   probe's own axis, this block carries BOTH oracles: the
//                   whole-silhouette centroid gate AND a `[pivot-focus-assert]`
//                   line against the same analytic oracle center-axis uses.
//                   A regression to the iso-depth-0 latch lands 8.5
//                   world units off, an order of magnitude outside the gate.
//                   Runs on the GUI-test cycler rather than the plain
//                   auto-screenshot one: it needs synthetic cursor input and a
//                   per-frame hook (the shot cycler clears the pivot focus at
//                   every shot boundary, and the latched point is only known
//                   at runtime so it cannot ride the shot table).
//   acquire-continuity — DEFAULT pivot at a base yaw (--yaw, default 0), the
//                   center-depth probe placed on that yaw's crosshair ray. The
//                   view settles with the crosshair on background, pans the
//                   probe under it, then takes two yaw steps just above the
//                   latch's settle delta: each is a gesture that acquires the
//                   probe's surface. The last three shots straddle the first
//                   acquisition, and a displacement-free acquisition leaves
//                   them identical; the log shows the anchor jumping from the
//                   depth-0 point onto the probe.
//
// Every DEFAULT-pivot block emits a per-shot `[pivot-focus-assert]` line: the
// focus the engine derived from its live composite-depth readback against the
// geometric target for that shot (see logPivotFocusAssert). Which blocks ALSO
// carry a whole-silhouette centroid gate, and why the two default blocks above
// cannot, is `docs/design/camera-yaw-pivot.md` §"Known deviations" deviation 2
// — `scripts/pivot-verify.py` owns the routing.
// Requires --auto-screenshot (value = warmup frames per shot); score with
// scripts/pivot-verify.py. Same stable-storage discipline as the other tables.
std::string g_pivotVerifyBlock = "off";
// --pivot-verify-sdf: probe via the SDF solver instead of the voxel pool, so
// the two render paths' pivot conventions can be compared A/B — a layer that
// pins while the other orbits means the paths disagree on the rendered-center
// convention (invisible at yaw 0: a (0.5,0.5,0.5) offset rides the iso depth
// axis and projects to zero until rotated).
bool g_pivotVerifySdf = false;
std::vector<IRVideo::AutoScreenshotShot> g_pivotVerifyShots;
std::vector<std::array<char, 40>> g_pivotVerifyShotLabels;
// --gui-test: swap the capture table for the headless help-overlay GUI test.
// Flag-gated so the standing render-verify tables are untouched —
// the overlay is default-hidden and this is the only run that opens it.
bool g_guiTest = false;
// --continuous-zoom-gui-test: swap the capture table for the fractional-zoom
// picking GUI test (kContinuousZoomGuiShots). Turns the continuous zoom policy
// on for the run.
bool g_continuousZoomGuiTest = false;
// The cull-eviction fixture replaces both the scene and capture table;
// keep it flag-gated so the standing render references retain their scene.
bool g_cullEvictTest = false;
// The DENSE LOD-swap fixture replaces both the scene and capture table; keep it
// flag-gated so the standing render references retain their scene.
bool g_lodDenseSwap = false;
bool g_lodScene = false;
IRShapeDebug::LodScene g_lodSceneState;

// --viewport-portrait: a secondary-viewport fixture. One blue voxel cube and
// one orange decoy sit in the world at zoom 1; a viewport pinned to a GUI
// rectangle on the right views only the blue cube, through its own camera at
// zoom 16. The second shot yaws the WORLD camera a quarter turn — the portrait
// must not move. The sun, ambient and albedo are the values
// scripts/render-detached-lighting-metric.py computes its expected face
// colours from, so that oracle reads the portrait region directly.
bool g_viewportPortrait = false;
constexpr vec3 kPortraitSunDirection = vec3(-0.42f, -0.60f, -0.55f);
constexpr float kPortraitSunAmbient = 0.30f;
constexpr Color kPortraitSubjectColor{80, 120, 240, 255};
constexpr Color kPortraitDecoyColor{240, 160, 70, 255};
constexpr float kPortraitZoom = 16.0f;
constexpr IRVideo::AutoScreenshotShot kViewportPortraitShots[] = {
    {1.0f, vec2(0, 0), 0.0f, "portrait_world_z1"},
    {1.0f, vec2(0, 0), IRMath::kHalfPi, "portrait_world_z1_world_yaw90"},
};
// --viewport-lod-swap (with --viewport-portrait): the subject is two co-located
// variants on disjoint LOD bands, both tagged. The world at zoom 1 draws the
// coarse orange cube; the portrait at zoom 16 draws the fine blue ball. The
// cube's edges reach past the ball, so a portrait that stacked both — its own
// tier ignored — shows an orange cube with the ball's faces inset.
bool g_viewportLodSwap = false;
constexpr Color kPortraitCoarseColor{220, 150, 70, 255};
constexpr IRVideo::AutoScreenshotShot kViewportLodSwapShots[] = {
    {1.0f, vec2(0, 0), 0.0f, "portrait_lod_swap_z1"},
};

// --load-prefab <path>: the scene is the prefab manifest at <path> (exe-relative)
// spawned at the origin, so each shot shows the parts its LOD bands select at
// that zoom. Empty = not requested. The manifest is evaluated in the World's
// Lua state, which the binding registration in main() hands over at init.
std::string g_loadPrefabPath;
IRScript::LuaScript *g_prefabLua = nullptr;
std::vector<IRVideo::AutoScreenshotShot> g_loadPrefabShots;
std::vector<std::array<char, 40>> g_loadPrefabShotLabels;
// cursor-latch runs the same poses through the GUI-test cycler; its shots wrap
// g_pivotVerifyShots (whose labels this table's label_ pointers still target,
// so both vectors must outlive the game loop).
std::vector<IRVideo::GuiTestShot> g_cursorLatchShots;
// Anchor of the DEFAULT-pivot blocks: an integer world point at iso depth 0
// (x + y + z == 0) so `isoPixelToPos3D(viewCenterIso, 0)` — the default-pivot
// focus derivation in getEffectiveCameraIso — recovers it EXACTLY when the pan
// places it under the viewport center. Integer placement keeps the probe on
// the voxel lattice (no displaced-pool tie noise in the measurement).
constexpr vec3 kPivotVerifyDefaultAnchor = vec3(12.0f, -12.0f, 0.0f);
// Probe z for the DEFAULT-pivot blocks. center-depth's xy displacement off the
// pinned column equals this value in both axes (iso-ray geometry), so the
// predicted master-drift scales with it.
constexpr float kPivotVerifyProbeZ = 10.0f;
// focus-off: iso offset of the pan away from probe-centered, so the pinned
// probe holds a NON-center screen position.
constexpr vec2 kPivotVerifyOffCenterIso = vec2(14.0f, 9.0f);
// The probe cylinder: radius kPivotVerifyProbeRadius about the vertical (z)
// axis, kPivotVerifyProbeHeight tall, carved into a voxel grid of half-extent
// kPivotVerifyProbeHalfExtent. Shared by the spawn and by the analytic focus
// oracle so the rendered geometry and the predicted focus cannot drift. Note
// the grid's z half-extent CLIPS the cylinder's 8.5 half-height to 8 — the
// oracle bounds its walk by the grid, not by the SDF alone, for that reason.
constexpr float kPivotVerifyProbeRadius = 4.0f;
constexpr float kPivotVerifyProbeHeight = 17.0f;
constexpr vec4 kPivotVerifyProbeParams =
    vec4(kPivotVerifyProbeRadius, kPivotVerifyProbeRadius, kPivotVerifyProbeHeight, 0.0f);
constexpr ivec3 kPivotVerifyProbeHalfExtent = ivec3(5, 5, 8);
// center-axis's grid is EVEN in x and y: centered on a half-integer xy, its
// voxels stay on the integer lattice while the cylinder's axis runs along cell
// boundaries — through the point where the yaw-0 crosshair ray enters the near
// cap (see pivotVerifyProbeCenter).
constexpr ivec3 kPivotVerifyAxisProbeGridSize =
    ivec3(10, 10, 2 * kPivotVerifyProbeHalfExtent.z + 1);
// background-center gets a SHORTER column. It has to clear the viewport-center
// ray in z for the center pixel to read background, and at zoom 8 a full-height
// probe pushed that far down the screen runs off the bottom of the framebuffer
// — a clipped silhouette's centroid is yaw-dependent, so the block would read
// DRIFT for a reason that has nothing to do with the pivot (measured 3.42px at
// zoom 8 before the shortening; 0.97/1.27 after).
constexpr float kPivotVerifyBackgroundProbeHeight = 9.0f;
constexpr vec4 kPivotVerifyBackgroundProbeParams =
    vec4(kPivotVerifyProbeRadius, kPivotVerifyProbeRadius, kPivotVerifyBackgroundProbeHeight, 0.0f);
constexpr ivec3 kPivotVerifyBackgroundProbeHalfExtent = ivec3(5, 5, 4);
// background-center: probe z on the pinned column, chosen so the
// viewport-center iso ray misses the cylinder entirely. The ray
// `anchor + t*(1,1,1)` sits within the carve's surface shell (radius + the
// half-voxel threshold, 4.5) only while `t*sqrt(2) <= 4.5`, i.e. t <= 3.18; the
// carved probe spans [z - 4, z + 4] = [4, 12], clear of that band, so the center
// pixel reads background while the probe itself stays on the pinned column (and
// therefore must hold its screen position).
constexpr float kPivotVerifyBackgroundProbeZ = 8.0f;

// The carve of the --pivot-verify probe for the active block. Shared by the
// spawn and by the analytic focus oracle, so the rendered geometry and the
// predicted focus cannot drift.
vec4 pivotVerifyProbeParams() {
    return g_pivotVerifyBlock == "background-center" ? kPivotVerifyBackgroundProbeParams
                                                     : kPivotVerifyProbeParams;
}

// Cells per axis of the probe's voxel grid, centered on pivotVerifyProbeCenter.
ivec3 pivotVerifyProbeGridSize() {
    if (g_pivotVerifyBlock == "center-axis") {
        return kPivotVerifyAxisProbeGridSize;
    }
    const ivec3 halfExtent = g_pivotVerifyBlock == "background-center"
                                 ? kPivotVerifyBackgroundProbeHalfExtent
                                 : kPivotVerifyProbeHalfExtent;
    return 2 * halfExtent + ivec3(1);
}
// `[pivot-focus-assert]` bounds for a gesture's acquisition, in world units
// along the crosshair ray of the frame it acquired from. @p rayStepWorld is the
// world length of one yawed iso-depth unit along that ray (sqrt(3)/3 at every
// yaw). Both are derived from how the store keys a fragment, never fitted to
// readings: docs/design/camera-yaw-pivot.md §"Latch policy".
//
// A cardinal source's key sits on the store's lattice, which the latch removes
// (DefaultPivotLatch::kCardinalStoreLatticeDepth). What is left is where the
// keyed micro-face starts against where the ray enters the surface: at most
// one micro-face, 2/effSub depth units. The target is that entry point.
float pivotVerifyCardinalTolerance(int effectiveSubdivisions, float rayStepWorld) {
    return 2.0f / static_cast<float>(effectiveSubdivisions) * rayStepWorld;
}

// A per-axis (non-cardinal) source's key is its face origin's yawed depth,
// stored quantized. The target is the ray point level with the winning cell's
// center, and a face origin sits at most `0.5 * (|c - s| + |c + s| + 1)` depth
// units from its cell's center at (c, s) = (cos yaw, sin yaw); the store adds
// one quantum, 1/effSub.
float pivotVerifyPerAxisBound(float yaw, int effectiveSubdivisions, float rayStepWorld) {
    const float c = IRMath::cos(yaw);
    const float sn = IRMath::sin(yaw);
    const float faceOriginOffset = 0.5f * (IRMath::abs(c - sn) + IRMath::abs(c + sn) + 1.0f);
    return (faceOriginOffset + 1.0f / static_cast<float>(effectiveSubdivisions)) * rayStepWorld;
}
// cursor-latch's own tolerance: ONE world unit, i.e. one voxel.
//
// This block's focus is a `castVoxelRay` SURFACE hit — the marched point where
// the ray first lands inside the winning voxel's unit cube — while the analytic
// oracle predicts that voxel's CENTER. `castVoxelRay` accepts a sample when
// `roundVec3HalfUp(sample - origin)` is the voxel's cell, so the hit is within
// half a voxel of the center on every axis and the L2 gap is bounded by the
// cube's half-diagonal, `sqrt(3)/2 ~= 0.87`. That bound is TIGHT here rather
// than pessimistic: the iso ray runs along (1,1,1), so it enters through the
// cell's near corner and the measured delta is exactly 0.87 (macOS/Metal,
// zoom 4). Rounding the bound up to a whole voxel keeps the assert off a
// knife-edge float comparison without blunting it — the regression this block
// exists to catch, a revert to the iso-depth-0 latch, lands ~8.5 world units
// off, so the gate still has ~8x of margin.
constexpr float kCursorLatchFocusToleranceWorld = 1.0f;
// center-axis / cursor-latch: the lattice step along the yaw-0 viewport-center
// ray at which the probe's near cap sits.
constexpr float kPivotVerifyAxisProbeStep = 6.0f;

// acquire-continuity: the yaw of each of its two gesture steps — a few times
// the default pivot latch's settle delta, so each step is a gesture while the
// scene barely rotates. Not closer: the camera clamps yaw to (-π + 1e-4, π),
// which eats one settle delta of a step taken from a base yaw of π.
constexpr float kPivotVerifyAcquireYawStep = 5.0f * IRRender::DefaultPivotLatch::kYawSettleDelta;
// acquire-continuity: iso offset of the settle pan away from probe-centered —
// the viewport-center ray lands ~28 world units clear of the probe.
constexpr vec2 kPivotVerifyAcquireBackgroundIso = vec2(-40.0f, 0.0f);

// Iso coordinate of the main canvas center with no camera applied: a world
// point W sits under the crosshair when `P_yaw(W) + effectiveCameraIso` equals
// it.
vec2 pivotVerifyCanvasCenterIso() {
    const ivec2 canvasSize = ivec2(IRRender::getMainCanvasSizeTrixels());
    return vec2(canvasSize) * 0.5f - vec2(IRMath::trixelOriginOffsetX1(canvasSize));
}

// Camera pan that places kPivotVerifyDefaultAnchor under the exact viewport
// center: inverts `viewCenterIso = canvasCenterIso - cameraIso`
// (getEffectiveCameraIso's default-focus derivation, before any acquisition) at
// `viewCenterIso == pos3DtoPos2DIso(anchor)`.
vec2 pivotVerifyDefaultPan() {
    return pivotVerifyCanvasCenterIso() - IRMath::pos3DtoPos2DIso(kPivotVerifyDefaultAnchor);
}

float pivotVerifyBaseYaw() {
    return g_initialYawSet ? g_initialYaw : 0.0f;
}

// World center of the --pivot-verify probe cylinder for the active block.
vec3 pivotVerifyProbeCenter() {
    if (g_pivotVerifyBlock == "center-column") {
        // On the pinned vertical column (anchor xy), shifted to z > 0.
        return vec3(kPivotVerifyDefaultAnchor.x, kPivotVerifyDefaultAnchor.y, kPivotVerifyProbeZ);
    }
    if (g_pivotVerifyBlock == "center-depth") {
        // On the viewport-center iso RAY at z = kPivotVerifyProbeZ: same screen
        // position as the anchor, off the pinned column by (z, z) in xy.
        return kPivotVerifyDefaultAnchor + vec3(kPivotVerifyProbeZ);
    }
    if (g_pivotVerifyBlock == "acquire-continuity") {
        // center-depth's probe, on the viewport-center ray of the BASE yaw —
        // the ray through the anchor along R_z(+yaw)·(1,1,1) — snapped to the
        // lattice. `isoPixelToPos3DYawed(0, 3z, yaw)` is exactly
        // z·R_z(+yaw)·(1,1,1).
        const vec3 alongRay = IRMath::isoPixelToPos3DYawed(
            vec2(0.0f),
            3.0f * kPivotVerifyProbeZ,
            pivotVerifyBaseYaw()
        );
        return kPivotVerifyDefaultAnchor + vec3(IRMath::roundVec3HalfUp(alongRay));
    }
    if (g_pivotVerifyBlock == "background-center") {
        // On the pinned column, lifted clear of the viewport-center ray so the
        // center pixel reads background (see kPivotVerifyBackgroundProbeZ).
        return vec3(
            kPivotVerifyDefaultAnchor.x,
            kPivotVerifyDefaultAnchor.y,
            kPivotVerifyBackgroundProbeZ
        );
    }
    // Offsetting either axis probe's center by the grid's z half-extent is what
    // puts the near cap — not the mid-height — at the step.
    const float axisProbeZ =
        kPivotVerifyAxisProbeStep + static_cast<float>(kPivotVerifyProbeHalfExtent.z);
    if (g_pivotVerifyBlock == "center-axis") {
        // Axis through the point where the yaw-0 viewport-center ray ENTERS the
        // near cap — the visible surface the default pivot acquires — so every
        // rotation about it maps the column onto itself. The ray runs along
        // (1,1,1) from the anchor and meets the cap's face plane, half a voxel
        // in front of the cap cells, at xy half a voxel short of the step: a
        // half-integer axis, hence the even grid.
        const float entryStep = kPivotVerifyAxisProbeStep - 0.5f;
        return vec3(
            kPivotVerifyDefaultAnchor.x + entryStep,
            kPivotVerifyDefaultAnchor.y + entryStep,
            axisProbeZ
        );
    }
    if (g_pivotVerifyBlock == "cursor-latch") {
        // Axis ON the viewport-center ray, through the center of the near-cap
        // voxel the ray enters: castVoxelRay names that voxel, and its center
        // is the probe's own axis point.
        return vec3(
            kPivotVerifyDefaultAnchor.x + kPivotVerifyAxisProbeStep,
            kPivotVerifyDefaultAnchor.y + kPivotVerifyAxisProbeStep,
            axisProbeZ
        );
    }
    // focus-ctr / focus-off pin the same off-origin z>0 center the
    // --pivot-focus-demo pillar uses.
    return kPivotPillarCenter;
}

// True for the blocks that exercise the DEFAULT (derived) pivot focus rather
// than an explicit setRotationPivotFocus. These are the blocks the
// pinned-point oracle applies to.
bool pivotVerifyIsDefaultBlock() {
    return g_pivotVerifyBlock == "center-column" || g_pivotVerifyBlock == "center-depth" ||
           g_pivotVerifyBlock == "background-center" || g_pivotVerifyBlock == "center-axis" ||
           g_pivotVerifyBlock == "acquire-continuity";
}

// World offset from the probe center of the cell at grid index @p index —
// createVoxelPoolShapeSized's own layout (a C_VoxelSetNew centered about its
// position), for an odd or even grid alike.
vec3 pivotVerifyProbeCellOffset(ivec3 index) {
    return vec3(index) - vec3(pivotVerifyProbeGridSize()) * 0.5f + vec3(0.5f);
}

// True when the probe's carve keeps the voxel at grid index @p index —
// createVoxelPoolShapeSized's own predicate over the same grid, so the rendered
// geometry and every oracle below cannot drift.
bool pivotVerifyProbeCellCarved(ivec3 index) {
    const ivec3 size = pivotVerifyProbeGridSize();
    // Outside the carved grid there is no voxel to win, however the unbounded
    // SDF reads there.
    if (index.x < 0 || index.y < 0 || index.z < 0 || index.x >= size.x || index.y >= size.y ||
        index.z >= size.z) {
        return false;
    }
    const auto sdfType = static_cast<IRMath::SDF::ShapeType>(IRRender::ShapeType::CYLINDER);
    const vec4 sdfParams = IRMath::SDF::effectiveParams(sdfType, pivotVerifyProbeParams());
    return IRMath::SDF::evaluate(pivotVerifyProbeCellOffset(index), sdfType, sdfParams) <=
           IRMath::SDF::kSurfaceThreshold;
}

// cursor-latch's oracle: the center of the voxel `castVoxelRay` names under the
// cursor parked on the anchor's pixel — the first carved voxel on the yaw-0
// viewport-center ray `anchor + a*(1,1,1)`. That probe is spawned on the
// integer lattice with its axis on the ray, so the voxel centers on the ray are
// the integer a. Returns the anchor when no voxel on the ray is carved.
vec3 pivotVerifyAnalyticFocus() {
    const vec3 center = pivotVerifyProbeCenter();
    const vec3 gridOrigin = center - vec3(pivotVerifyProbeGridSize()) * 0.5f + vec3(0.5f);
    // The ray leaves the carved grid for good once its z clears the grid top;
    // z along the ray IS a, so that bound is the walk's end.
    const int lastStep = static_cast<int>(center.z) + pivotVerifyProbeGridSize().z;
    for (int step = 0; step <= lastStep; ++step) {
        const vec3 world = kPivotVerifyDefaultAnchor + vec3(static_cast<float>(step));
        if (pivotVerifyProbeCellCarved(IRMath::roundVec3HalfUp(world - gridOrigin))) {
            return world;
        }
    }
    return kPivotVerifyDefaultAnchor;
}

// What the crosshair ray of one frame meets first: a carved probe cell, and
// where the ray enters it.
struct PivotCrosshairHit {
    // A per-axis source's target is the crosshair-ray point level with this
    // center in yawed depth: that store keys a fragment by its face origin,
    // which sits about the cell center, not on the surface.
    vec3 cellCenter_ = vec3(0.0f);
    // Where the ray enters the cell's unit cube — the visible surface. A
    // cardinal source's target.
    vec3 entry_ = vec3(0.0f);
};

// World length of one yawed iso-depth unit along a crosshair ray:
// `isoPixelToPos3D`'s depth step is (1,1,1)/3, and a Z-yaw preserves its length.
constexpr float kPivotVerifyDepthUnitWorld = 0.57735027f;

// The first carved cell the ray through canvas iso @p iso meets in a frame
// drawn at @p yaw, or nothing when it meets none (a gesture from that frame
// holds). The ray is every world point that projects to that iso at that pose,
// `isoPixelToPos3DYawed(iso, depth, yaw)`; each carved cell is intersected with
// it exactly (slab test on its unit cube) and the nearest entry wins. A ray
// that only touches a cube's edge or corner does not enter it.
std::optional<PivotCrosshairHit> pivotVerifyRayHit(float yaw, vec2 iso) {
    const vec3 rayOrigin = IRMath::isoPixelToPos3DYawed(iso, 0.0f, yaw);
    const vec3 rayStep = IRMath::isoPixelToPos3DYawed(iso, 1.0f, yaw) - rayOrigin;
    const vec3 center = pivotVerifyProbeCenter();
    const ivec3 size = pivotVerifyProbeGridSize();
    constexpr float kMinChordDepth = 1e-4f;
    std::optional<PivotCrosshairHit> hit;
    float nearestEntry = 0.0f;
    for (int z = 0; z < size.z; ++z) {
        for (int y = 0; y < size.y; ++y) {
            for (int x = 0; x < size.x; ++x) {
                const ivec3 index = ivec3(x, y, z);
                if (!pivotVerifyProbeCellCarved(index)) {
                    continue;
                }
                const vec3 cellCenter = center + pivotVerifyProbeCellOffset(index);
                float enter = -1e30f;
                float exit = 1e30f;
                for (int axis = 0; axis < 3; ++axis) {
                    const float lo = cellCenter[axis] - 0.5f - rayOrigin[axis];
                    const float hi = cellCenter[axis] + 0.5f - rayOrigin[axis];
                    if (IRMath::abs(rayStep[axis]) < 1e-7f) {
                        if (lo > 0.0f || hi < 0.0f) {
                            enter = 1e30f;
                        }
                        continue;
                    }
                    const float t0 = lo / rayStep[axis];
                    const float t1 = hi / rayStep[axis];
                    enter = IRMath::max(enter, IRMath::min(t0, t1));
                    exit = IRMath::min(exit, IRMath::max(t0, t1));
                }
                if (exit - enter <= kMinChordDepth || (hit.has_value() && enter >= nearestEntry)) {
                    continue;
                }
                nearestEntry = enter;
                hit = PivotCrosshairHit{cellCenter, rayOrigin + rayStep * enter};
            }
        }
    }
    return hit;
}

// What the rays through one pixel's footprint meet: the crosshair ray and its
// eight neighbours one game pixel away — 1/zoom iso units at the shot's zoom. A
// line tested against unit cubes has no pixel footprint, so the pixel the
// readback samples can show any cell one of these rays enters first.
struct PivotCrosshairFootprint {
    std::optional<PivotCrosshairHit> center_;
    // Distinct centers of the first cell each footprint ray enters.
    std::vector<vec3> cellCenters_;
    // Some footprint ray meets the probe where the crosshair ray does not, or
    // misses it where the crosshair ray hits: whether the pixel shows the probe
    // at all is undecidable, so a gesture's hold/acquire classification from
    // that frame is reported, not graded.
    bool grazes_ = false;
};

PivotCrosshairFootprint pivotVerifyCrosshairFootprint(float yaw, vec2 iso, float zoom) {
    PivotCrosshairFootprint footprint;
    footprint.center_ = pivotVerifyRayHit(yaw, iso);
    const float step = 1.0f / zoom;
    for (int dy = -1; dy <= 1; ++dy) {
        for (int dx = -1; dx <= 1; ++dx) {
            const std::optional<PivotCrosshairHit> hit =
                (dx == 0 && dy == 0)
                    ? footprint.center_
                    : pivotVerifyRayHit(
                          yaw,
                          iso + vec2(static_cast<float>(dx), static_cast<float>(dy)) * step
                      );
            if (hit.has_value() != footprint.center_.has_value()) {
                footprint.grazes_ = true;
            }
            if (!hit.has_value()) {
                continue;
            }
            std::vector<vec3> &cells = footprint.cellCenters_;
            if (std::find(cells.begin(), cells.end(), hit->cellCenter_) == cells.end()) {
                cells.push_back(hit->cellCenter_);
            }
        }
    }
    return footprint;
}

// The point on the ray through canvas iso @p iso at @p yaw level with @p point in
// yawed depth.
vec3 pivotVerifyRayPointLevelWith(float yaw, vec2 iso, vec3 point) {
    const vec3 rayOrigin = IRMath::isoPixelToPos3DYawed(iso, 0.0f, yaw);
    const vec3 rayStep = IRMath::isoPixelToPos3DYawed(iso, 1.0f, yaw) - rayOrigin;
    return rayOrigin +
           rayStep * (IRMath::dot(point - rayOrigin, rayStep) / IRMath::dot(rayStep, rayStep));
}

// The view (camera pan + zoom) the sweep's FIRST capture frame rendered, latched
// to check the precondition below. Per-process, which is per-pass: pivot-verify.py
// runs one demo invocation per (block, zoom).
vec2 g_pivotFocusAssertCameraIso = vec2(0.0f);
vec2 g_pivotFocusAssertZoom = vec2(0.0f);
bool g_hasPivotFocusAssertView = false;

// Per-gesture oracle state for the DEFAULT-pivot blocks, carried from one
// capture to the next: what the previous shot's settled frame showed, and where
// a gesture starting from that frame must acquire.
struct PivotGestureOracle {
    bool hasPrevious_ = false;
    // Camera yaw of the first frame the tracker saw — the pose shot 0 is
    // compared against.
    float startYaw_ = 0.0f;
    float yaw_ = 0.0f;
    vec2 cameraIso_ = vec2(0.0f);
    vec3 derived_ = vec3(0.0f);
    // What a gesture acquiring from the previous capture's frame is graded
    // against: that frame's crosshair iso and pixel footprint, whether it was a
    // cardinal frame (entry target) or a per-axis one (level-with-center
    // target), and the bound for that class.
    vec2 sourceIso_ = vec2(0.0f);
    PivotCrosshairFootprint sourceFootprint_;
    bool sourceCardinal_ = false;
    float sourceTolerance_ = 0.0f;
    // Frames since the previous capture on which the default focus moved while
    // the camera pan and zoom held — i.e. the latch itself changed.
    int latchMoves_ = 0;
    bool hasFrame_ = false;
    vec3 frameFocus_ = vec3(0.0f);
    vec2 frameCameraIso_ = vec2(0.0f);
    vec2 frameZoom_ = vec2(0.0f);
};
PivotGestureOracle g_pivotGestureOracle;

// Per-frame half of the per-gesture oracle (a RENDER-tail system ahead of the
// shot cycler, so it reads each frame's settled state before a new shot's pose
// is applied): counts the frames on which the latch moved. A move whose frame
// also moved the camera is not counted — a pan carries the focus with it — so
// the pure-yaw gestures of these blocks each show exactly one move.
void trackPivotFocusFrame() {
    if (!pivotVerifyIsDefaultBlock()) {
        return;
    }
    PivotGestureOracle &oracle = g_pivotGestureOracle;
    const vec3 focus = IRRender::getDefaultRotationPivotFocus();
    const vec2 cameraIso = IRRender::getCameraPosition2DIso();
    const vec2 zoom = IRRender::getCameraZoom();
    if (oracle.hasFrame_ && cameraIso == oracle.frameCameraIso_ && zoom == oracle.frameZoom_ &&
        focus != oracle.frameFocus_) {
        ++oracle.latchMoves_;
    }
    if (!oracle.hasFrame_) {
        oracle.startYaw_ = IRPrefab::Camera::getYaw();
    }
    oracle.hasFrame_ = true;
    oracle.frameFocus_ = focus;
    oracle.frameCameraIso_ = cameraIso;
    oracle.frameZoom_ = zoom;
}

// `[pivot-focus-assert]` tolerance for a HOLD — a shot the latch must not
// re-acquire in, whose focus is the previous one carried by any pan. Exact up
// to the float error of re-deriving the point from the camera.
constexpr float kPivotFocusHoldToleranceWorld = 1e-3f;

// --pivot-verify cursor-latch state: the focus the cursor latched, resolved
// once from the real castVoxelRay path and held for the rest of the sweep (the
// mouse-DOWN latch policy — a pivot that re-follows the live cursor would feed
// back into the rotation it controls).
vec3 g_cursorLatchFocus = vec3(0.0f);
bool g_cursorLatchResolved = false;
// --cursor-pivot-indicator: also spawn the drag marker at the latched point,
// so the cursor-latch capture doubles as the indicator's ENABLED-path test
// (docs/agents/VALIDATION.md §"Default-off features need a positive enabled-path
// test"). A headless run cannot synthesize the Ctrl+Shift+middle-drag chord —
// GuiInputEvent carries no key modifiers — so this drives the same
// IRPrefab::CursorPivot calls the drag makes, minus the button state machine.
// Off by default: the marker is extra silhouette, and cursor-latch's reported
// centroid deviation should measure the probe alone.
bool g_cursorPivotIndicator = false;
IREntity::EntityId g_cursorLatchIndicator = IREntity::kNullEntity;

void logPivotCompositeDepth(int shotIndex) {
    if (g_pivotVerifyBlock != "center-axis") {
        return;
    }
    const IRRender::CompositeDepthSample sample =
        IRRender::readbackCompositeDepth(IRRender::getMainFramebufferCenterPixel());
    const IRRender::DecodedCompositeDepth decoded = IRRender::decodeCompositeDepth(sample.rawDist_);
    IR_LOG_INFO(
        "[pivot-composite-depth] block={} shot={} yaw={} subject={} valid={} tier={} "
        "raw_iso={} eff_sub={}",
        g_pivotVerifyBlock,
        shotIndex,
        IRPrefab::Camera::getYaw(),
        g_pivotVerifySdf ? "sdf" : "voxel",
        sample.valid_ ? 1 : 0,
        decoded.tier_,
        decoded.iso_,
        IRRender::getVoxelRenderEffectiveSubdivisions()
    );
}

void logPivotFocusAssert(int shotIndex) {
    const bool cursorLatch = g_pivotVerifyBlock == "cursor-latch";
    if (!pivotVerifyIsDefaultBlock() && !cursorLatch) {
        return;
    }
    logPivotCompositeDepth(shotIndex);
    // `view_held` reports whether the camera pan/zoom still matches the first
    // capture's — a precondition for the sweep blocks, whose shot tables hold
    // the view fixed; acquire-continuity pans by design.
    const vec2 cameraIso = IRRender::getCameraPosition2DIso();
    const vec2 zoom = IRRender::getCameraZoom();
    if (!g_hasPivotFocusAssertView) {
        g_pivotFocusAssertCameraIso = cameraIso;
        g_pivotFocusAssertZoom = zoom;
        g_hasPivotFocusAssertView = true;
    }
    const bool viewHeld =
        cameraIso == g_pivotFocusAssertCameraIso && zoom == g_pivotFocusAssertZoom;
    const float yaw = IRPrefab::Camera::getYaw();

    if (cursorLatch) {
        // The cursor latch is resolved once and held for the sweep, so it is
        // asserted against the yaw-0 analytic focus on every shot.
        const vec3 analytic = pivotVerifyAnalyticFocus();
        const float worldDelta = IRMath::length(g_cursorLatchFocus - analytic);
        IR_LOG_INFO(
            "[pivot-focus-assert] block={} shot={} yaw={} gesture=0 latch_moves=0 "
            "derived=({},{},{}) target=({},{},{}) world_delta={} tolerance={} view_held={} "
            "result={}",
            g_pivotVerifyBlock,
            shotIndex,
            yaw,
            g_cursorLatchFocus.x,
            g_cursorLatchFocus.y,
            g_cursorLatchFocus.z,
            analytic.x,
            analytic.y,
            analytic.z,
            worldDelta,
            kCursorLatchFocusToleranceWorld,
            viewHeld ? 1 : 0,
            worldDelta <= kCursorLatchFocusToleranceWorld ? "PASS" : "FAIL"
        );
        return;
    }

    // Each shot is a one-frame pose snap, so a shot whose yaw differs from the
    // previous capture's is one rotation gesture, acquired from the previous
    // shot's settled frame. The expected focus is:
    //   - gesture over a surface from a cardinal frame — where that frame's
    //     crosshair ray enters the surface, within one micro-face (half the
    //     store lattice on the SDF probe);
    //   - gesture over a surface from a per-axis frame — the crosshair-ray point
    //     level with the center of a cell some ray of the pixel's footprint
    //     enters first, within the derived bound of at least one such cell;
    //   - gesture over background, or no gesture — the previous focus carried by
    //     the pan, exactly (the latch holds);
    //   - shot 0 — the never-acquired depth-0 point under the viewport center.
    // And the latch may move at most once in a gesture shot, never otherwise.
    // Reported, not graded (result=SKIP): a gesture whose source footprint
    // grazes the probe (skip=grazing), and a per-axis gesture on the SDF probe
    // (skip=sdf-per-axis) — the per-axis bound is derived from the voxel
    // store's face origins, which an SDF fragment does not have.
    PivotGestureOracle &oracle = g_pivotGestureOracle;
    const vec3 derived = IRRender::getDefaultRotationPivotFocus();
    // The latch's own gesture test: a yaw change above its settle delta.
    const float previousYaw = oracle.hasPrevious_ ? oracle.yaw_ : oracle.startYaw_;
    const bool gesture =
        IRMath::abs(yaw - previousYaw) > IRRender::DefaultPivotLatch::kYawSettleDelta;
    vec3 target = IRMath::isoPixelToPos3D(pivotVerifyCanvasCenterIso() - cameraIso, 0.0f);
    vec3 targetCell = target;
    float tolerance = kPivotFocusHoldToleranceWorld;
    const char *source = "none";
    const char *skip = nullptr;
    int footprintCells = 0;
    bool neighbourCell = false;
    const bool targetKnown = oracle.hasPrevious_ || !gesture;
    const PivotCrosshairFootprint &footprint = oracle.sourceFootprint_;
    if (oracle.hasPrevious_) {
        if (gesture && footprint.center_.has_value()) {
            const PivotCrosshairHit &hit = *footprint.center_;
            tolerance = oracle.sourceTolerance_;
            source = oracle.sourceCardinal_ ? "cardinal" : "per-axis";
            if (oracle.sourceCardinal_) {
                target = hit.entry_;
                targetCell = hit.cellCenter_;
            } else {
                // The crosshair ray's own cell, else the nearest of the
                // footprint's cells — each on the crosshair ray the latch
                // recovers along — so neighbour_cell=1 marks a reading that
                // passes only on a cell a neighbouring ray enters.
                footprintCells = static_cast<int>(footprint.cellCenters_.size());
                targetCell = hit.cellCenter_;
                target = pivotVerifyRayPointLevelWith(oracle.yaw_, oracle.sourceIso_, targetCell);
                if (IRMath::length(derived - target) > tolerance) {
                    float nearest = IRMath::length(derived - target);
                    for (const vec3 &cell : footprint.cellCenters_) {
                        const vec3 level =
                            pivotVerifyRayPointLevelWith(oracle.yaw_, oracle.sourceIso_, cell);
                        const float delta = IRMath::length(derived - level);
                        if (delta < nearest) {
                            nearest = delta;
                            target = level;
                            targetCell = cell;
                        }
                    }
                }
                neighbourCell = targetCell != hit.cellCenter_;
                if (g_pivotVerifySdf) {
                    skip = "sdf-per-axis";
                }
            }
        } else {
            target = oracle.derived_ + IRMath::isoPixelToPos3D(oracle.cameraIso_ - cameraIso, 0.0f);
            targetCell = target;
        }
        if (gesture && footprint.grazes_) {
            skip = "grazing";
        }
    }
    const bool graded = skip == nullptr;
    const float worldDelta = IRMath::length(derived - target);
    const bool movesOk = oracle.latchMoves_ <= (gesture ? 1 : 0);
    const bool pass = targetKnown && worldDelta <= tolerance && movesOk;
    IR_LOG_INFO(
        "[pivot-focus-assert] block={} shot={} yaw={} gesture={} latch_moves={} "
        "derived=({},{},{}) target=({},{},{}) source={} cell=({},{},{}) footprint_cells={} "
        "neighbour_cell={} skip={} world_delta={} tolerance={} view_held={} result={}",
        g_pivotVerifyBlock,
        shotIndex,
        yaw,
        gesture ? 1 : 0,
        oracle.latchMoves_,
        derived.x,
        derived.y,
        derived.z,
        target.x,
        target.y,
        target.z,
        source,
        targetCell.x,
        targetCell.y,
        targetCell.z,
        footprintCells,
        neighbourCell ? 1 : 0,
        graded ? "none" : skip,
        worldDelta,
        tolerance,
        viewHeld ? 1 : 0,
        !graded ? "SKIP" : (pass ? "PASS" : "FAIL")
    );

    // This frame is the source of the next shot's gesture, if it is one.
    const vec2 crosshairIso = pivotVerifyCanvasCenterIso() - IRRender::getEffectiveCameraIso();
    const int effectiveSubdivisions = IRRender::getVoxelRenderEffectiveSubdivisions();
    const float rayStepWorld = kPivotVerifyDepthUnitWorld;
    oracle.hasPrevious_ = true;
    oracle.yaw_ = yaw;
    oracle.cameraIso_ = cameraIso;
    oracle.derived_ = derived;
    oracle.sourceIso_ = crosshairIso;
    oracle.sourceFootprint_ = pivotVerifyCrosshairFootprint(yaw, crosshairIso, zoom.x);
    oracle.sourceCardinal_ = IRPrefab::Camera::computeYawSplit(yaw).second == 0.0f;
    if (oracle.sourceCardinal_) {
        oracle.sourceTolerance_ = pivotVerifyCardinalTolerance(effectiveSubdivisions, rayStepWorld);
    } else {
        oracle.sourceTolerance_ = pivotVerifyPerAxisBound(yaw, effectiveSubdivisions, rayStepWorld);
    }
    oracle.latchMoves_ = 0;
}

// Per-shot `[cull-validate] DOMAIN-STATE` line for the --cull-validate sweep
// (AutoScreenshotConfig::onCaptureFrame_, fired on the settled capture frame):
// the state half of the cull gate. scripts/cull-verify.py's image assertion is
// relative — cv_live_i against cv_frozen_i from the same run — so a freeze that
// accepts the call and pins nothing makes the frozen phase a second live
// capture and every pair byte-identical. That failure is invisible in pixels;
// it is only visible in the viewport the frames were culled against, which is
// what this line reports.
//
// Two freeze facts, because they fail independently: `frozen` is the flag
// applyShotCameraState wrote, `cull_frozen` is what updateCullViewport last
// honoured. A setter that is ignored reds the first; a cull update that stops
// running on the captured frame reds the second.
//
// `cam` / `zoom` are getEffectiveCameraIso() and getCameraZoom() — the two
// values updateCullViewport itself consumes — so pinned-vs-live is a
// like-for-like comparison rather than a proxy that can disagree with the cull
// under smooth-yaw pivot compensation. The capture-frame hook runs after
// SHAPES_TO_TRIXEL, so getCullViewport() is post-update for the frame the
// screenshot holds, not one frame stale.
void logCullValidateState(int shotIndex) {
    const auto &cull = IRRender::getCullViewport();
    const vec2 liveCameraIso = IRRender::getEffectiveCameraIso();
    const vec2 liveZoom = IRRender::getCameraZoom();
    const bool labelKnown =
        shotIndex >= 0 && shotIndex < static_cast<int>(g_cullValidateShotLabels.size());
    IR_LOG_INFO(
        "[cull-validate] DOMAIN-STATE shot={} index={} frozen={} cull_frozen={} "
        "cull_cam={:.4f},{:.4f} cull_zoom={:.4f},{:.4f} cull_canvas={},{} "
        "cam={:.4f},{:.4f} zoom={:.4f},{:.4f}",
        labelKnown ? g_cullValidateShotLabels[shotIndex].data() : "unlabeled",
        shotIndex,
        IRRender::isCullingFrozen() ? 1 : 0,
        cull.frozen_ ? 1 : 0,
        cull.cameraIso_.x,
        cull.cameraIso_.y,
        cull.zoom_.x,
        cull.zoom_.y,
        cull.canvasSize_.x,
        cull.canvasSize_.y,
        liveCameraIso.x,
        liveCameraIso.y,
        liveZoom.x,
        liveZoom.y
    );
}

// Per-frame hook for the cursor-latch block (GuiTestConfig::onAssertFrame_,
// fired every frame a shot is live). Three jobs, in order:
//
//  1. Park the synthetic cursor on the viewport-center anchor's screen pixel.
//     The pixel is derived from the live camera terms via
//     worldPos3DToMouseScreenPx rather than hard-coded as "framebuffer / 2",
//     so it survives retina scaling and letterboxing. The anchor is at iso
//     depth 0 and is NOT the expected answer — the answer is the surface the
//     ray through it first meets.
//  2. Latch ONCE, on the first shot's capture frame: by then the injected
//     cursor has landed and the scene has settled, so castVoxelRay sees what a
//     real click would. Shot 0 is yaw 0, where the pivot correction is the
//     identity, so nothing is mis-rendered before the latch exists.
//  3. Re-assert the latched focus every frame — applyShotCameraState clears it
//     at every shot boundary, and it cannot ride the shot table because the
//     point is not known until runtime.
void cursorLatchOnFrame(int shotIndex, bool isCaptureFrame) {
    if (!g_cursorLatchResolved) {
        IRInput::injectMouseMove(IRRender::worldPos3DToMouseScreenPx(kPivotVerifyDefaultAnchor));
        if (!isCaptureFrame) {
            return;
        }
        g_cursorLatchFocus = IRPrefab::CursorPivot::resolveFocusWorld();
        g_cursorLatchResolved = true;
        IRPrefab::CursorPivot::showIndicator(g_cursorLatchIndicator, g_cursorLatchFocus);
    }
    IRRender::setRotationPivotFocus(g_cursorLatchFocus);
    if (isCaptureFrame) {
        logPivotFocusAssert(shotIndex);
    }
}

// --pan-sweep: hold yaw + zoom fixed and step the camera iso
// position in fine sub-trixel increments across ~2 trixels, capturing one frame
// per step. A static scene must translate SMOOTHLY across the sweep — any
// per-frame +/-1px oscillation as the camera crosses a trixel boundary is the
// anti-vibration jitter (the sub-pixel decomposition disagreeing with the
// integer canvas placement). Defaults to yaw 45 deg (residual != 0 → per-axis
// composite active) so it exercises rotation; override with --yaw. Requires
// --auto-screenshot (its value sets the step count, min 2).
bool g_panSweep = false;
std::vector<IRVideo::AutoScreenshotShot> g_panSweepShots;
std::vector<std::array<char, 40>> g_panSweepShotLabels;

// --yaw-sweep: hold camera position + zoom fixed and step the
// camera Z-yaw in fine increments, capturing one frame per step. The companion
// to --pan-sweep: it exercises jitter during ROTATION (the effective camera iso
// changes via the RotationPivotMode drift-cancel as yaw advances, so the per-axis
// composite's camera-offset decomposition is swept). The range stays inside ONE
// cardinal quadrant (residual yaw 0..π/4, constant visible-face triplet) so a
// Z-yaw-invariant probe (a vertical cylinder) has a stable silhouette and any
// per-frame centroid wobble is jitter, not a face-triplet flip. Requires
// --auto-screenshot.
bool g_yawSweep = false;
std::vector<IRVideo::AutoScreenshotShot> g_yawSweepShots;
std::vector<std::array<char, 40>> g_yawSweepShotLabels;

// --zoom-continuous: put the camera on the continuous zoom policy before any
// zoom is applied, so --zoom and every shot's zoom land unsnapped.
bool g_zoomContinuous = false;

// --zoom-calibration: replace the fixture scene with one unlit cube whose
// vertical silhouette edges sit a whole number of iso cells from the view
// centre at kZoomCalibrationCamera. Flat albedo on an empty background, so a
// metric reads the silhouette by exact colour, and far enough off-centre that
// a zoom moves its near edge several tenths of a framebuffer pixel per 0.005
// of zoom. Implied by --zoom-sweep; given on its own it lets --pan-sweep
// capture the same subject.
bool g_zoomCalibration = false;

// One retained owner readback on the first settled capture, before the spin advances.
bool g_shapeSampleProbe = false;
bool g_shapeSampleProbeAttempted = false;
bool g_shapeSampleProbePassed = false;
ivec2 g_shapeSampleProbePixel{-1};
std::string g_shapeSampleProbeOutput;

// --zoom-sweep <from> <to> <count>: hold the camera at kZoomCalibrationCamera
// and step the requested zoom linearly across <count> shots. With
// --zoom-continuous the subject must grow smoothly; without it the same
// requests snap, which is the sweep's own negative control. Combined with
// --pan-sweep the camera also pans half a cell across the sweep. Requires
// --auto-screenshot.
bool g_zoomSweep = false;
float g_zoomSweepFrom = 0.0f;
float g_zoomSweepTo = 0.0f;
int g_zoomSweepCount = 0;
std::vector<IRVideo::AutoScreenshotShot> g_zoomSweepShots;
std::vector<std::array<char, 40>> g_zoomSweepShotLabels;

// Off the world iso origin on purpose: with the camera on it, a split that
// never carries its raster phase is exact, and the sweep could not tell the
// two apart.
constexpr vec2 kZoomCalibrationCamera = vec2(16.0f, 16.0f);
constexpr ivec3 kZoomCalibrationBoxSize = ivec3(5);
// CORNER-anchored: the cube spans world x in [-4, 1), y in [5, 10), so its
// silhouette covers iso x in [4, 14] — 20 to 30 cells from the view centre at
// the calibration camera. Ten cells wide, so every 0.1 step of zoom changes
// the on-screen width by two framebuffer pixels.
constexpr vec3 kZoomCalibrationBoxWorld = vec3(-4.0f, 5.0f, -8.0f);
constexpr float kZoomCalibrationNearEdgeIsoX = 4.0f;
constexpr float kZoomCalibrationFarEdgeIsoX = 14.0f;
constexpr Color kZoomCalibrationColor = Color{255, 96, 0, 255};

// Per-shot `[zoom-calibration]` line (AutoScreenshotConfig::onCaptureFrame_,
// fired on the settled capture frame): the placement the composite drew this
// frame with, in the terms scripts/render-continuous-zoom-metric.py needs to
// predict where the calibration cube's near edge lands and how far that is
// from a raster tie. `edge_fb` is each silhouette edge's offset from the
// framebuffer centre in framebuffer pixels, before the pixel grid rounds it.
void logZoomCalibrationState(int shotIndex) {
    const vec2 cameraIso = IRRender::getEffectiveCameraIso();
    const vec2 zoom = IRRender::getCameraZoom();
    const ivec2 scale = IRRender::getOutputScaleFactor();
    const int density = IRMath::max(IRRender::getVoxelRenderEffectiveSubdivisions(), 1);
    const IRMath::CameraRasterPhase *frame = IRPrefab::Camera::zoomFrame(cameraIso, zoom);
    const EntityId mainCanvas = IRRender::getCanvas("main");
    const auto behaviorOpt =
        IREntity::getComponentOptional<C_TrixelCanvasRenderBehavior>(mainCanvas);
    const C_TrixelCanvasRenderBehavior behavior =
        behaviorOpt.has_value() ? **behaviorOpt : C_TrixelCanvasRenderBehavior{};
    const vec2 gather = IRSystem::System<IRSystem::TRIXEL_TO_FRAMEBUFFER>::canvasGatherTranslation(
        frame,
        behavior,
        cameraIso,
        zoom / static_cast<float>(density),
        density
    );
    const ivec2 residual = IRPrefab::Camera::screenResidual(cameraIso, zoom, scale);
    const ivec2 backing = IREntity::getComponent<C_TriangleCanvasTextures>(mainCanvas).size_;
    const double texelPx = 2.0 * static_cast<double>(zoom.x) / density;
    const double rasterTexels =
        static_cast<double>(IRMath::floor(cameraIso.x * static_cast<float>(density)));
    // The canvas store's iso frame sits one texel up-left of the raw canvas
    // index (the same `+ (1, 1)` as `IRRender::mouseCanvasTexelWorld()`).
    const double originTexel = static_cast<double>(IRMath::trixelOriginOffsetZ1(backing).x) + 1.0;
    const auto edgeFramebufferPx = [&](float edgeIsoX) {
        const double texel = originTexel + rasterTexels + static_cast<double>(edgeIsoX) * density;
        return static_cast<double>(gather.x) + (texel - 0.5 * backing.x) * texelPx;
    };
    IR_LOG_INFO(
        "[zoom-calibration] index={} continuous={} zoom={:.6f} density={} "
        "cam={:.6f},{:.6f} scale={} phase={:.9f},{:.9f} gather={:.9f},{:.9f} residual={},{} "
        "edge_fb={:.9f},{:.9f}",
        shotIndex,
        IRPrefab::Camera::isZoomContinuous() ? 1 : 0,
        zoom.x,
        density,
        cameraIso.x,
        cameraIso.y,
        scale.x,
        frame != nullptr ? frame->phase_.x : 0.0,
        frame != nullptr ? frame->phase_.y : 0.0,
        gather.x,
        gather.y,
        residual.x,
        residual.y,
        edgeFramebufferPx(kZoomCalibrationNearEdgeIsoX),
        edgeFramebufferPx(kZoomCalibrationFarEdgeIsoX)
    );
}

void onShapeDebugCaptureFrame(int shotIndex) {
    if (g_zoomCalibration)
        logZoomCalibrationState(shotIndex);
    if (g_shapeSampleProbe && !g_shapeSampleProbeAttempted) {
        g_shapeSampleProbeAttempted = true;
        g_shapeSampleProbePassed = IRPrefab::ShapeSampleProbe::writeFirstCapture(
            g_shapeSampleProbePixel,
            g_shapeSampleProbeOutput
        );
    }
}

// Shared shot-table emission for the sweep-flag family below (--spin-yaw,
// --pivot-focus-demo, --pivot-verify, --pan-sweep, --yaw-sweep): reserves
// both vectors up front — `shots`/`labels` must never reallocate mid-loop,
// since every shot's `label_` points into `labels` — then for each index
// formats the label (`formatLabel`) and asks `makeShot` for the rest of the
// shot's fields.
template <typename LabelArray, typename FormatLabelFn, typename MakeShotFn>
void emitSweepShots(
    std::vector<IRVideo::AutoScreenshotShot> &shots,
    std::vector<LabelArray> &labels,
    int n,
    FormatLabelFn &&formatLabel,
    MakeShotFn &&makeShot
) {
    labels.reserve(n);
    shots.reserve(n);
    for (int i = 0; i < n; ++i) {
        auto &label = labels.emplace_back();
        formatLabel(label, i);
        IRVideo::AutoScreenshotShot shot = makeShot(i);
        shot.label_ = label.data();
        shots.push_back(shot);
    }
}

void registerCliArgs() {
    IRArgs::Parser &args = IREngine::args();
    args.optionalInt(
        "--auto-profile",
        "Run N frames (default 300) with frame timing, then exit",
        300
    );
    args.numbers(
        "--shape-sample-probe",
        "Read one retained main-canvas owner at screenshot X Y on the first auto capture",
        2
    );
    args.string(
        "--shape-sample-probe-output",
        "JSON output for the first capture only",
        "shape-sample-probe.json"
    );
    args.flag("--ao-contact-probe", "Isolate a voxel inside corner and convex cube for AO");
    args.flag("--no-ao", "Disable ambient occlusion for lighting isolation");
    args.flag("--no-shadows", "Disable sun shadows for lighting isolation");
    args.flag("--depth-color", "Tint each voxel by local iso-depth (front=red, back=blue)");
    args.flag("--checkerboard", "Tint alternating voxels darker (flickers; off by default)");
    args.flag(
        "--occlusion-cull",
        "Force the voxel-pool chunk-occlusion HZB pre-pass ON (off by default)"
    );
    args.flag("--gpu-voxel-smoke", "Spawn one cube routed through the GPU voxel-position prepass");
    args.flag("--pivot-focus-demo", "Yaw sweep pinning the pivot on a tall pillar (#1921)");
    args.flag("--skin-smoke", "Spawn one 2-bone rigged voxel bar skinned via binding-17 (#1605)");
    args.flag(
        "--shadow-footprint-probe",
        "Isolate grounded voxel/SDF cone and torus pairs on a measured receiver plane"
    );
    args.flag(
        "--moving-caster",
        "Voxel cube over a voxel floor, falling a quarter voxel per capture shot"
    );
    args.flag(
        "--lod-scene",
        "Shared prefab assets, resident/lazy parts and moving attached LOD variants"
    );
    args.flag("--pan-sweep", "Fine fixed-yaw camera-pan jitter sweep (#1944)");
    args.flag("--yaw-sweep", "Fine fixed-position camera-yaw jitter sweep (#1944)");
    args.enumValue(
        "--pivot-verify",
        "Rotation-pivot invariance sweep block "
        "(off|focus-ctr|focus-off|center-column|center-depth|background-center|center-axis"
        "|cursor-latch|acquire-continuity)",
        {"off",
         "focus-ctr",
         "focus-off",
         "center-column",
         "center-depth",
         "background-center",
         "center-axis",
         "cursor-latch",
         "acquire-continuity"},
        "off"
    );
    args.flag(
        "--pivot-verify-sdf",
        "Render the --pivot-verify probe via the SDF solver instead of the voxel pool"
    );
    args.flag(
        "--cursor-pivot-indicator",
        "Show the cursor-pivot marker at the latched point (--pivot-verify cursor-latch)"
    );
    args.number(
        "--zoom",
        "Initial camera zoom (snapped to nearest power of two unless --zoom-continuous)",
        0.0f
    );
    args.flag(
        "--zoom-continuous",
        "Put the camera on the continuous zoom policy: any zoom in range, no power-of-two snap"
    );
    args.flag(
        "--zoom-calibration",
        "Replace the scene with the continuous-zoom calibration cube (implied by --zoom-sweep)"
    );
    args.numbers(
        "--zoom-sweep",
        "Zoom sweep <from> <to> <count> on the calibration cube at a fixed off-origin camera; "
        "add --pan-sweep to pan across it as well; needs --auto-screenshot",
        3
    );
    args.flag(
        "--continuous-zoom-gui-test",
        "Replace the capture table with the fractional-zoom picking GUI test (continuous zoom "
        "2.5); needs --auto-screenshot"
    );
    args.string("--debug-overlay", "Debug overlay mode (e.g. none, depth, normals)", "none");
    args.number("--yaw", "Initial camera Z-yaw in radians", 0.0f);
    args.flag("--pivot-origin", "Force the legacy world-origin Z-yaw pivot (#1352 A/B)");
    args.flag("--cull-validate", "Frozen-cull free-fly validation sweep (#1438)");
    args.string(
        "--load-prefab",
        "Replace the scene + capture table with this prefab manifest (exe-relative path) "
        "spawned at the origin, captured at zoom 1x / 4x / 16x; needs --auto-screenshot",
        ""
    );
    args.string(
        "--load-vxs",
        "Path to a DENSE-mode .vxs to load and render alongside fixtures (a "
        "<base>_frame_<N>.vxs path loads the whole animation)",
        ""
    );
    args.number(
        "--vxs-frame",
        "Pin the loaded .vxs animation to this frame instead of playing "
        "it back (#766)",
        -1.0f
    );
    args.optionalInt(
        "--spin-yaw",
        "Drive camera Z-yaw (deg/sec live, default 30; shot-count across one rotation when "
        "combined with --auto-screenshot)",
        30
    );
    args.string(
        "--spin-shape",
        "Spawn a single named shape centred at origin instead of the full fixture scene (#1922)",
        ""
    );
    args.flag("--spin-shape-voxel", "Render the --spin-shape via the voxel-pool twin, not the SDF");
    args.flag("--spin-shape-floor", "Add an isolated floor receiver to --spin-shape");
    args.flag(
        "--gui-test",
        "Replace the capture table with the headless help-overlay GUI test (#2550); "
        "needs --auto-screenshot"
    );
    args.flag(
        "--cull-evict-test",
        "Replace the scene + capture table with the #2830 cull-invalidation fixture: two "
        "occupancy poses alternated in place at a fixed cardinal camera; needs --auto-screenshot"
    );
    args.flag(
        "--lod-dense-swap",
        "Replace the scene + capture table with two co-located DENSE voxel sets on disjoint LOD "
        "bands, captured on either side of the swap; needs --auto-screenshot"
    );
    args.flag(
        "--viewport-portrait",
        "Replace the scene + capture table with the secondary-viewport fixture: a world cube at "
        "zoom 1 and its GUI-pinned portrait at zoom 16"
    );
    args.flag(
        "--viewport-lod-swap",
        "With --viewport-portrait: the subject is a coarse/fine pair on disjoint LOD bands; the "
        "world draws the coarse variant and the portrait the fine one"
    );
    args.number(
        "--viewport-yaw",
        "Z-yaw in radians of the --viewport-portrait camera (the world camera is unaffected)",
        0.0f
    );
}

// Absent value flags preserve the demo defaults. This runs before World
// construction so invalid combinations cannot leave a partially initialized engine.
void readCliArgs() {
    const IRArgs::Parser &args = IREngine::args();

    g_shapeSampleProbe = args.wasProvided("--shape-sample-probe");
    if (g_shapeSampleProbe) {
        const auto &pixel = args.getFloats("--shape-sample-probe");
        // Stay inside exactly representable integer float coordinates before conversion.
        if (pixel[0] >= 0 && pixel[1] >= 0 && pixel[0] < 16777216 && pixel[1] < 16777216 &&
            IRMath::floor(pixel[0]) == pixel[0] && IRMath::floor(pixel[1]) == pixel[1])
            g_shapeSampleProbePixel = ivec2(pixel[0], pixel[1]);
        g_shapeSampleProbeOutput = args.getString("--shape-sample-probe-output");
    }
    g_autoWarmupFrames = args.autoScreenshotWarmupFrames();
    g_autoRecordFrames = args.autoRecordFrames();

    // --auto-profile: 0 when absent, else the frame count (300 if bare).
    if (args.wasProvided("--auto-profile")) {
        g_autoProfileFrames = args.getInt("--auto-profile");
    }
    g_depthColor = args.getFlag("--depth-color");
    g_checkerboard = args.getFlag("--checkerboard");
    g_occlusionCull = args.getFlag("--occlusion-cull");
    g_gpuVoxelSmoke = args.getFlag("--gpu-voxel-smoke");
    g_pivotFocusDemo = args.getFlag("--pivot-focus-demo");
    g_skinSmoke = args.getFlag("--skin-smoke");
    g_shadowFootprintProbe = args.getFlag("--shadow-footprint-probe");
    g_movingCaster = args.getFlag("--moving-caster");
    g_panSweep = args.getFlag("--pan-sweep");
    g_yawSweep = args.getFlag("--yaw-sweep");
    g_pivotVerifyBlock = args.getEnum("--pivot-verify");
    g_pivotVerifySdf = args.getFlag("--pivot-verify-sdf");
    g_guiTest = args.getFlag("--gui-test");
    g_cullEvictTest = args.getFlag("--cull-evict-test");
    g_lodDenseSwap = args.getFlag("--lod-dense-swap");
    g_lodScene = args.getFlag("--lod-scene");
    g_viewportPortrait = args.getFlag("--viewport-portrait");
    g_viewportLodSwap = g_viewportPortrait && args.getFlag("--viewport-lod-swap");
    g_cursorPivotIndicator = args.getFlag("--cursor-pivot-indicator");
    g_continuousZoomGuiTest = args.getFlag("--continuous-zoom-gui-test");
    g_zoomContinuous = args.getFlag("--zoom-continuous") || g_continuousZoomGuiTest;
    if (args.wasProvided("--zoom-sweep")) {
        const std::vector<float> &sweep = args.getFloats("--zoom-sweep");
        g_zoomSweep = true;
        g_zoomSweepFrom = sweep[0];
        g_zoomSweepTo = sweep[1];
        g_zoomSweepCount = IRMath::max(2, static_cast<int>(sweep[2]));
    }
    g_zoomCalibration = g_zoomSweep || args.getFlag("--zoom-calibration");

    if (args.wasProvided("--zoom")) {
        const float zoom = args.getFloat("--zoom");
        if (zoom > 0.0f) {
            g_initialZoom = zoom;
        }
    }
    if (args.wasProvided("--debug-overlay")) {
        g_debugOverlay =
            IRRender::debugOverlayModeFromString(args.getString("--debug-overlay").c_str());
    }
    if (args.wasProvided("--yaw")) {
        const float yaw = args.getFloat("--yaw");
        g_initialYawRadians = yaw;
        g_initialYaw = yaw;
        g_initialYawSet = true;
    }
    g_pivotOrigin = args.getFlag("--pivot-origin") || g_shadowFootprintProbe;
    g_cullValidate = args.getFlag("--cull-validate");
    if (args.wasProvided("--load-prefab")) {
        g_loadPrefabPath = args.getString("--load-prefab");
    }
    if (args.wasProvided("--load-vxs")) {
        g_loadVxsPath = args.getString("--load-vxs");
    }
    if (args.wasProvided("--vxs-frame")) {
        g_vxsFrame = static_cast<int>(args.getFloat("--vxs-frame"));
    }
    // --spin-yaw: 0 (disabled) when absent, else the rate (30 if bare). The
    // optional value reads as an int — fractional deg/sec is truncated.
    if (args.wasProvided("--spin-yaw")) {
        g_spinYawDegPerSec = static_cast<float>(args.getInt("--spin-yaw"));
    }
    if (args.wasProvided("--spin-shape")) {
        g_spinShapeType = args.getString("--spin-shape");
    }
    g_spinShapeVoxel = args.getFlag("--spin-shape-voxel");
}

} // namespace

void initSystems();
void initCommands();
void initEntities();
void registerDemoSettings();

int main(int argc, char **argv) {
    registerCliArgs();
    IREngine::args().parse(argc, argv);
    readCliArgs();
    if (g_lodScene &&
        (g_guiTest || g_continuousZoomGuiTest || g_cullValidate || g_spinYawDegPerSec > 0.0f ||
         g_pivotFocusDemo || g_pivotVerifyBlock != "off" || g_zoomSweep || g_panSweep ||
         g_yawSweep || g_shadowFootprintProbe || g_movingCaster || g_lodDenseSwap ||
         g_viewportPortrait || g_zoomCalibration || g_cullEvictTest || g_shapeSampleProbe ||
         !g_loadPrefabPath.empty() || !g_loadVxsPath.empty() || !g_spinShapeType.empty() ||
         IREngine::args().getFlag("--ao-contact-probe"))) {
        IR_LOG_ERROR("--lod-scene cannot be combined with another scene or capture override");
        return 2;
    }
    if (g_shapeSampleProbe && (g_shapeSampleProbePixel.x < 0 || g_autoWarmupFrames <= 0)) {
        IR_LOG_ERROR(
            "--shape-sample-probe requires integer screenshot coordinates and --auto-screenshot"
        );
        return 2;
    }

    if (IREngine::args().getFlag("--spin-shape-floor")) {
        if (g_spinShapeType.empty()) {
            IR_LOG_ERROR("--spin-shape-floor requires --spin-shape");
            return 2;
        }
        if (g_viewportPortrait || IREngine::args().getFlag("--ao-contact-probe") ||
            g_cullEvictTest || g_lodDenseSwap || g_lodScene || !g_loadPrefabPath.empty() ||
            g_pivotVerifyBlock != "off" || g_pivotFocusDemo || g_zoomCalibration) {
            IR_LOG_ERROR("--spin-shape-floor cannot be combined with another scene override");
            return 2;
        }
    }

    IREngine::registerLuaBindings([](IRScript::LuaScript &lua) {
        if (IREngine::args().wasProvided("--load-prefab") || g_lodScene) {
            lua.bindLuaDrivenEcs();
            // The engine components a manifest's `components` may name.
            lua.registerTypeFromTraits<IRComponents::C_AutoSpin>();
            g_prefabLua = &lua;
        }
    });
    IREngine::init(argv[0]);

    // --spin-yaw + --auto-screenshot: reinterpret the screenshot value as
    // "shots across one rotation", and use a small internal warmup. This is
    // the regression-detection mode — N static frames at evenly-spaced yaws
    // so a render-verify diff can pinpoint the angle a glitch appears at.
    if (g_spinYawDegPerSec > 0.0f && g_autoWarmupFrames > 0) {
        g_spinYawShotCount = g_autoWarmupFrames;
        g_autoWarmupFrames = 10;
        IR_LOG_INFO(
            "Spin-yaw: warmup reset to 10 frames (--auto-screenshot value {} reinterpreted as shot "
            "count)",
            g_spinYawShotCount
        );
    }

    IR_LOG_INFO("Starting creation: shape_debug");
    if (g_autoProfileFrames > 0) {
        IREngine::enableFrameTiming(true);
    }
    initSystems();
    initCommands();
    initEntities();
    // After initEntities: the tint setters re-apply over the shapes it created.
    registerDemoSettings();
    if (g_zoomContinuous) {
        IRPrefab::Camera::setZoomContinuous(true);
        IR_LOG_INFO("Camera zoom policy: continuous (--zoom-continuous)");
    }
    if (g_initialZoom > 0.0f) {
        IRRender::setCameraZoom(g_initialZoom);
        vec2 actualZoom = IRRender::getCameraZoom();
        IR_LOG_INFO(
            "Initial zoom: requested={}, getCameraZoom()={}, effective_subdivisions={} ({})",
            g_initialZoom,
            actualZoom.x,
            IRRender::getVoxelRenderEffectiveSubdivisions(),
            g_zoomContinuous ? "continuous policy, stored as requested"
                             : "snapped to nearest power of two"
        );
    }
    if (g_debugOverlay != IRRender::DebugOverlayMode::NONE) {
        IRRender::setDebugOverlay(g_debugOverlay);
    }
    if (g_occlusionCull) {
        IRRender::setVoxelOcclusionCullEnabled(true);
        IR_LOG_INFO("Voxel chunk-occlusion cull forced ON (--occlusion-cull, #1294 child 2/3)");
    }
    if (g_initialYawRadians != 0.0f) {
        IRPrefab::Camera::setYaw(g_initialYawRadians);
        IR_LOG_INFO(
            "Initial camera Z-yaw: {} rad ({} deg)",
            g_initialYawRadians,
            g_initialYawRadians * (180.0f / std::numbers::pi_v<float>)
        );
    }
    if (g_initialYawSet) {
        IRPrefab::Camera::setYaw(g_initialYaw);
        IR_LOG_INFO("Initial yaw: {} rad", g_initialYaw);
    }
    if (g_pivotOrigin) {
        IRRender::setRotationPivotMode(IRRender::RotationPivotMode::ORIGIN);
        IR_LOG_INFO(
            "RotationPivotMode: ORIGIN (--pivot-origin) — Z-yaw pivots about the world origin"
        );
    }
    if (g_cullValidate) {
        // The cull viewport also drives the sun-shadow-feeder AABB
        // (shadowFeederCullViewport), so a frozen wide cull bakes *different*
        // shadows than the live cull — a confound that otherwise dominates the
        // live-vs-frozen diff. Disabling sun shadows leaves the cull's only
        // on-screen effect as which voxels rasterize, so the diff isolates
        // voxel retention. (The interactive F10 path keeps shadows.)
        IRRender::setSunShadowsEnabled(false);
        IR_LOG_INFO(
            "Cull-validate: sun shadows disabled to isolate voxel retention from "
            "shadow-feeder coupling"
        );
    }
    IREngine::gameLoop();
    return g_shapeSampleProbe && (!g_shapeSampleProbeAttempted || !g_shapeSampleProbePassed) ? 2
                                                                                             : 0;
}

// ---------------------------------------------------------------------------
// Help-overlay + settings-menu GUI test (--gui-test)
// ---------------------------------------------------------------------------
// Positive-fire coverage for both discoverability surfaces: byte-identity with
// them hidden (render-verify) only proves the OFF path is a no-op, so this
// drives the ON paths end to end.
//
// Overlay: inject the toggle key, assert the overlay is visible AND
// actually emitted glyphs AND that its text carries a camera-suite entry with
// its description (which is what proves adoption costs zero per-demo wiring),
// then toggle back and assert it is hidden again.
//
// Menu: open on Escape and assert rows actually materialized, then
// CLICK the "PAUSE SIMULATION" checkbox through the real input path and assert
// BOTH halves — the widget latched checked, and `IRSim` actually stopped. The
// second is the one that proves the registered setter ran; a widget that
// toggles without reaching its setting is exactly the failure a flag-only
// assertion would miss. Then untoggle and close.
//
// Flag-gated: the standing kShots table and every render-verify reference are
// untouched by this run.
namespace {

// F1 is shape_debug's toggle (IRPrefab::HelpOverlay::kDefaultToggleButton).
// Injected during RENDER, so the binding fires on the following frame's INPUT
// phase; the 3-frame settle window covers that latency.
constexpr IRVideo::GuiInputEvent kHelpOpenEvents[] = {
    {0, IRVideo::GuiInputEvent::Type::PRESS, IRMath::ivec2(0), vec2(0.0f), IRInput::kKeyButtonF1},
    {1, IRVideo::GuiInputEvent::Type::RELEASE, IRMath::ivec2(0), vec2(0.0f), IRInput::kKeyButtonF1},
};

// A second press on the next shot toggles it back off.
constexpr IRVideo::GuiInputEvent kHelpCloseEvents[] = {
    {0, IRVideo::GuiInputEvent::Type::PRESS, IRMath::ivec2(0), vec2(0.0f), IRInput::kKeyButtonF1},
    {1, IRVideo::GuiInputEvent::Type::RELEASE, IRMath::ivec2(0), vec2(0.0f), IRInput::kKeyButtonF1},
};

// Escape toggles the settings menu in this demo — the camera suite is
// registered with `{.omit_ = {CLOSE_WINDOW}}`, so it does not quit.
constexpr IRVideo::GuiInputEvent kMenuOpenEvents[] = {
    {0,
     IRVideo::GuiInputEvent::Type::PRESS,
     IRMath::ivec2(0),
     vec2(0.0f),
     IRInput::kKeyButtonEscape},
    {1,
     IRVideo::GuiInputEvent::Type::RELEASE,
     IRMath::ivec2(0),
     vec2(0.0f),
     IRInput::kKeyButtonEscape},
};

constexpr IRVideo::GuiInputEvent kMenuCloseEvents[] = {
    {0,
     IRVideo::GuiInputEvent::Type::PRESS,
     IRMath::ivec2(0),
     vec2(0.0f),
     IRInput::kKeyButtonEscape},
    {1,
     IRVideo::GuiInputEvent::Type::RELEASE,
     IRMath::ivec2(0),
     vec2(0.0f),
     IRInput::kKeyButtonEscape},
};

// Indices into registerDemoSettings()'s registration order.
constexpr int kRotationPivotSettingIndex = 0;
constexpr int kDebugOverlaySettingIndex = 1;
constexpr int kCheckerboardSettingIndex = 3;
constexpr int kPauseSettingIndex = 4;

// Enum-row values the two dropdown shots drive to. Both start at the engine
// default and move off it, so each assertion is a positive fire rather than a
// tautology over a value that was already there.
constexpr int kPivotCameraCenter = static_cast<int>(IRRender::RotationPivotMode::CAMERA_CENTER);
constexpr int kPivotOrigin = static_cast<int>(IRRender::RotationPivotMode::ORIGIN);
constexpr int kOverlayNone = static_cast<int>(IRRender::DebugOverlayMode::NONE);
constexpr int kOverlayAo = static_cast<int>(IRRender::DebugOverlayMode::AO);

// One left-click, aimed at a screen pixel that is not known until run time: the
// menu centers itself on the GUI canvas and a dropdown's item strip only exists
// while expanded, so `fillClickTargets()` fills every target from the live panel
// each frame (the runtime-filled-events pattern voxel_editor's probe-map shots
// use). The MOVE establishes hover; PRESS/RELEASE carry the same position so the
// widget state machine sees a click that begins and ends inside one hitbox.
struct ClickTriple {
    IRVideo::GuiInputEvent events_[3]{
        {0, IRVideo::GuiInputEvent::Type::MOVE, IRMath::ivec2(0)},
        {1,
         IRVideo::GuiInputEvent::Type::PRESS,
         IRMath::ivec2(0),
         vec2(0.0f),
         IRInput::kMouseButtonLeft},
        {2,
         IRVideo::GuiInputEvent::Type::RELEASE,
         IRMath::ivec2(0),
         vec2(0.0f),
         IRInput::kMouseButtonLeft},
    };

    void aimAt(IRMath::ivec2 screenPx) {
        for (IRVideo::GuiInputEvent &event : events_) {
            event.screenPx_ = screenPx;
        }
    }
};

ClickTriple g_pauseOnClick;
ClickTriple g_pauseOffClick;
// The CHECKERBOARD shot's capture is visible-effect evidence: the tint reaches
// the scene behind the open menu, so the frame pairs against settings_menu_open
// at identical framing.
ClickTriple g_checkerboardOnClick;
// An ENUM row takes two clicks — one on the header to expand, one on the item.
ClickTriple g_pivotExpandClick;
ClickTriple g_pivotItemClick;
ClickTriple g_overlayExpandClick;
ClickTriple g_overlayItemClick;
ClickTriple g_quitClick;

// Cursor-to-pixel oracle. A click that lands is a round trip — GUI trixel →
// cursor → GUI trixel — and a forward and inverse mapping that are wrong by the
// same factor pass it. This pair ties the cursor to drawn pixels instead: the
// PAUSE checkbox box repaints in its hover colour only while the cursor's GUI
// trixel is inside the row, and the assertion reads the screen target at the
// cursor's own pixel, so it passes only when the row is drawn where the cursor
// is. `_idle` parks the cursor in the canvas corner and samples the box at the
// pixel the next shot's cursor will occupy; `_row` moves there and requires
// that pixel to have changed.
struct HoverPixelOracle {
    IRVideo::GuiInputEvent awayEvents_[1]{
        {0, IRVideo::GuiInputEvent::Type::MOVE, IRMath::ivec2(1)},
    };
    IRVideo::GuiInputEvent hoverEvents_[1]{
        {0, IRVideo::GuiInputEvent::Type::MOVE, IRMath::ivec2(0)},
    };
    bool idleSampled_ = false;
    Color idle_{};
};
HoverPixelOracle g_hoverPixel;

void fillClickTargets() {
    const IRMath::ivec2 pausePx = IRPrefab::SettingsMenu::rowWidgetScreenPx(kPauseSettingIndex);
    if (pausePx == IRMath::ivec2(0)) {
        return; // menu not open yet this frame; the next one fills it
    }
    // The center of the checkbox's box, not of the row: the box is the only
    // part of an unchecked checkbox row whose fill follows the hover state.
    const EntityId pauseWidget = IRPrefab::SettingsMenu::rowWidget(kPauseSettingIndex);
    const IRMath::ivec2 pausePos = IREntity::getComponent<C_GuiPosition>(pauseWidget).pos_;
    const IRMath::ivec2 pauseSize = IREntity::getComponent<C_Widget>(pauseWidget).size_;
    const float boxHalf =
        static_cast<float>(IRPrefab::Widget::defaultTheme().checkboxBoxSize_) * 0.5f;
    g_hoverPixel.hoverEvents_[0].screenPx_ = IRRender::guiTrixelToScreenPx(vec2(
        static_cast<float>(pausePos.x) + boxHalf,
        static_cast<float>(pausePos.y) + static_cast<float>(pauseSize.y) * 0.5f
    ));
    g_pauseOnClick.aimAt(pausePx);
    g_pauseOffClick.aimAt(pausePx);
    g_checkerboardOnClick.aimAt(
        IRPrefab::SettingsMenu::rowWidgetScreenPx(kCheckerboardSettingIndex)
    );
    g_pivotExpandClick.aimAt(IRPrefab::SettingsMenu::rowWidgetScreenPx(kRotationPivotSettingIndex));
    g_overlayExpandClick.aimAt(
        IRPrefab::SettingsMenu::rowWidgetScreenPx(kDebugOverlaySettingIndex)
    );
    g_quitClick.aimAt(IRPrefab::SettingsMenu::quitButtonScreenPx());

    // Item rows exist only between the two clicks, so these resolve during the
    // expand shot rather than at first open. `enumItemScreenPx` reads ivec2(0)
    // while collapsed — keep the last good aim instead of zeroing the target,
    // which would send the following shot's click to the screen corner.
    const IRMath::ivec2 pivotItemPx =
        IRPrefab::SettingsMenu::enumItemScreenPx(kRotationPivotSettingIndex, kPivotOrigin);
    if (pivotItemPx != IRMath::ivec2(0)) {
        g_pivotItemClick.aimAt(pivotItemPx);
    }
    const IRMath::ivec2 overlayItemPx =
        IRPrefab::SettingsMenu::enumItemScreenPx(kDebugOverlaySettingIndex, kOverlayAo);
    if (overlayItemPx != IRMath::ivec2(0)) {
        g_overlayItemClick.aimAt(overlayItemPx);
    }
}

// ---------------------------------------------------------------------------
// GPU hover entity-id parity fixture (--gui-test)
// ---------------------------------------------------------------------------
// Hover identity follows display identity: the trixel→framebuffer gather
// hover-gates on the cursor's RAW canvas texel (`floor(displayOrigin)` vs the
// CPU `mouseCanvasTexelWorld()`) and reads the entity id at that same texel,
// so every hovered fragment reports the id of what it displays. The triangle
// lattice (`trixelFramebufferSamplePosition`, `mouseTrixelPositionWorld()`)
// is not in the hover path at all — its cell straddles two raw texel rows, so
// a hover compare in that space selects fragments displaying two different
// texels. Nothing else in the harness can see either defect: `picksVoxel` is a
// CPU ray cast, and the widget assertions route hover over targets many
// trixels wide.
//
// Single voxels alone in an empty region of the fixture scene, each framed by
// itself with render subdivisions off so a canvas texel is a 2·zoom × zoom
// game-px rectangle and a quarter-texel aim clears the cell diagonal by several
// pixels (the diagonal is where a lattice-space compare would start selecting
// the row above). The cursor rests in the voxel's top-right (Z-face) texel:
//   `_above_diagonal` — texel fract (0.5, 0.25), row above empty canvas. A
//     lattice-shifted id read reports nothing; the raw read reports the voxel.
//   `_below_diagonal` — texel fract (0.5, 0.75), same voxel: the lattice
//     shift would not fire here, so every contract reports the voxel. The
//     control that proves the aim lands on the voxel.
//   `_row_above_occupied` — the `_above_diagonal` aim on a second voxel whose
//     row above holds a nearer neighbour voxel, evaluated on each of the last
//     three live frames. Under the raw compare every frame names the voxel;
//     a lattice-space compare with a raw read flips between the voxel and
//     its neighbour from frame to frame (two writers, two texels, one
//     non-atomic SSBO slot), and a lattice-space read names the neighbour
//     every frame.
constexpr vec3 kHoverParityVoxelWorld = vec3(-40.0f, -40.0f, 0.0f);
// 16 canvas rows below the isolated voxel (same column): far enough that
// neither site is within a row of the other's cursor texel.
constexpr vec3 kHoverParityStackedVoxelWorld = vec3(-48.0f, -48.0f, 0.0f);
// One canvas row up (`iso.y = -x - y + 2z` → -1, `iso.x = x - y` unchanged)
// and one iso-depth unit nearer, so it is the texel a lattice shift lands on
// and it wins a depth arbitration against the voxel under the cursor.
constexpr vec3 kHoverParityNeighbourOffset = vec3(0.5f, 0.5f, 0.0f);
constexpr float kHoverParityZoom = 16.0f;
constexpr Color kHoverParityColor = Color{240, 200, 60, 255};
constexpr Color kHoverParityNeighbourColor = Color{60, 120, 240, 255};
// `worldPos3DToMouseScreenPx` aims at canvas iso `iso(P) + 0.5`, and the
// gather samples that at the centre of raw texel `base + (1, 1)` — the CPU
// iso frame sits one texel up-left of the raw canvas index, the `+ (1, 1)`
// in `mouseCanvasTexelWorld()`. Rows are `iso.y = -x - y + 2z`, so a
// world-z offset dz moves the aim 2·dz rows while the column stays at
// `base.x + 1`, fract 0.5: -0.625 lands on row 0 at fract 0.25, -0.375 on
// row 0 at fract 0.75.
constexpr float kHoverParityAboveDiagonalZ = -0.625f;
constexpr float kHoverParityBelowDiagonalZ = -0.375f;
// Trailing live frames the stacked shot must agree on. The harness settles
// three frames after the MOVE before its capture frame, and the readback lags
// the draw by one, so three is every settled readback the shot has.
constexpr int kHoverParityStableFrames = 3;

// One fixture shot: the voxel site it frames, the aim (a world-z offset from
// the site, resolved to screen px at runtime because it depends on the live
// camera the shot applies), and the assertion naming the entity created at
// init. MOVE at offset 1 so the hook has re-aimed under the shot's camera
// before the event fires.
struct HoverParityShot {
    vec3 voxelWorld_;
    float worldZOffset_;
    IRVideo::GuiInputEvent events_[1]{
        {1, IRVideo::GuiInputEvent::Type::MOVE, IRMath::ivec2(0)},
    };
    IRPrefab::GuiTest::Assertion assertions_[1];
};

constexpr int kNumHoverParityShots = 3;

struct HoverParityFixture {
    IREntity::EntityId voxelEntity_ = IREntity::kNullEntity;
    IREntity::EntityId stackedVoxelEntity_ = IREntity::kNullEntity;
    IREntity::EntityId neighbourEntity_ = IREntity::kNullEntity;
    HoverParityShot shots_[kNumHoverParityShots]{
        {kHoverParityVoxelWorld, kHoverParityAboveDiagonalZ},
        {kHoverParityVoxelWorld, kHoverParityBelowDiagonalZ},
        {kHoverParityStackedVoxelWorld, kHoverParityAboveDiagonalZ},
    };
    IRRender::SubdivisionMode restoreSubdivisionMode_ = IRRender::SubdivisionMode::FULL;
    int lastShot_ = -1;
};
HoverParityFixture g_hoverParity;

// ---------------------------------------------------------------------------
// Drag-pan tracking fixture (--gui-test)
// ---------------------------------------------------------------------------
// A middle-drag pan is a grab: the content under the cursor at the press stays
// under it for the whole drag. The cursor delta arrives in window points and
// the pan divides it by a step size in viewport pixels, so on a display whose
// framebuffer is denser than its window the two only agree through the
// point-to-pixel conversion — without it the content travels a fraction of the
// cursor's distance and slides out from under it.
//
// The shot hovers the isolated hover-parity voxel, presses, drags further than
// the voxel is wide on screen at any content scale the fixture runs at, and
// releases; the GPU hover readback must still name the voxel at the cursor's
// new position. The voxel sits alone in an empty region, so a pan that falls
// short reads no entity at all.
constexpr IRMath::ivec2 kDragPanCursorDelta{160, 96};
constexpr int kDragPanStableFrames = 2;

struct DragPanShot {
    // Offsets start at 1 so the hook has aimed under the shot's camera before
    // the first event fires; the release leaves the camera where the drag put
    // it, which is the pose the settle frames and the assertion then observe.
    IRVideo::GuiInputEvent events_[4]{
        {1, IRVideo::GuiInputEvent::Type::MOVE, IRMath::ivec2(0)},
        {2,
         IRVideo::GuiInputEvent::Type::PRESS,
         IRMath::ivec2(0),
         vec2(0.0f),
         IRInput::kMouseButtonMiddle},
        {3, IRVideo::GuiInputEvent::Type::MOVE, IRMath::ivec2(0)},
        {5,
         IRVideo::GuiInputEvent::Type::RELEASE,
         IRMath::ivec2(0),
         vec2(0.0f),
         IRInput::kMouseButtonMiddle},
    };
    IRPrefab::GuiTest::Assertion assertions_[1];
    bool aimed_ = false;
};
DragPanShot g_dragPan;

constexpr int kDragPanShotIndex = kNumHoverParityShots;

// Aimed once, on the shot's first live frame: the drag moves the camera, so a
// re-aim on a later frame would chase the voxel instead of holding the cursor
// path fixed.
void onDragPanAssertFrame(int shotIndex) {
    if (shotIndex != kDragPanShotIndex || g_dragPan.aimed_) {
        return;
    }
    g_dragPan.aimed_ = true;
    const IRMath::ivec2 start = IRRender::worldPos3DToMouseScreenPx(
        kHoverParityVoxelWorld + vec3(0.0f, 0.0f, kHoverParityBelowDiagonalZ)
    );
    g_dragPan.events_[0].screenPx_ = start;
    g_dragPan.events_[1].screenPx_ = start;
    g_dragPan.events_[2].screenPx_ = start + kDragPanCursorDelta;
    g_dragPan.events_[3].screenPx_ = start + kDragPanCursorDelta;
}

IREntity::EntityId createHoverParityVoxel(vec3 world, Color color) {
    return IREntity::createEntity(
        C_LocalTransform{world},
        C_VoxelSetNew{ivec3(1), color, IRComponents::EntityAnchor::CORNER}
    );
}

void initHoverParityFixture() {
    g_hoverParity.voxelEntity_ = createHoverParityVoxel(kHoverParityVoxelWorld, kHoverParityColor);
    g_hoverParity.stackedVoxelEntity_ =
        createHoverParityVoxel(kHoverParityStackedVoxelWorld, kHoverParityColor);
    g_hoverParity.neighbourEntity_ = createHoverParityVoxel(
        kHoverParityStackedVoxelWorld + kHoverParityNeighbourOffset,
        kHoverParityNeighbourColor
    );
    g_hoverParity.shots_[0].assertions_[0] = IRPrefab::GuiTest::hoveredEntityId(
        g_hoverParity.voxelEntity_,
        "hover_id_above_diagonal_is_raw_texel"
    );
    g_hoverParity.shots_[1].assertions_[0] = IRPrefab::GuiTest::hoveredEntityId(
        g_hoverParity.voxelEntity_,
        "hover_id_below_diagonal_is_voxel"
    );
    g_hoverParity.shots_[2].assertions_[0] = IRPrefab::GuiTest::hoveredEntityId(
        g_hoverParity.stackedVoxelEntity_,
        "hover_id_row_above_occupied_is_stable",
        kHoverParityStableFrames
    );
    g_dragPan.assertions_[0] = IRPrefab::GuiTest::hoveredEntityId(
        g_hoverParity.voxelEntity_,
        "hover_id_follows_drag_pan",
        kDragPanStableFrames
    );
    IR_LOG_INFO(
        "--- hover-parity fixture: entity {} at ({},{},{}); stacked entity {} at ({},{},{}), "
        "neighbour {} one row above ---",
        g_hoverParity.voxelEntity_,
        kHoverParityVoxelWorld.x,
        kHoverParityVoxelWorld.y,
        kHoverParityVoxelWorld.z,
        g_hoverParity.stackedVoxelEntity_,
        kHoverParityStackedVoxelWorld.x,
        kHoverParityStackedVoxelWorld.y,
        kHoverParityStackedVoxelWorld.z,
        g_hoverParity.neighbourEntity_
    );
}

void aimHoverParity(HoverParityShot &shot) {
    const IRMath::ivec2 px = IRRender::worldPos3DToMouseScreenPx(
        shot.voxelWorld_ + vec3(0.0f, 0.0f, shot.worldZOffset_)
    );
    for (IRVideo::GuiInputEvent &event : shot.events_) {
        event.screenPx_ = px;
    }
}

// Subdivisions off for exactly the fixture shots: under FULL a texel is a 2×1
// game-px rectangle at every zoom and the diagonal is sub-pixel, so the aim
// could not resolve which side of it the cursor sits on. Restored on the first
// frame of the shot after the block so the rest of the run renders as before.
void onHoverParityAssertFrame(int shotIndex) {
    if (shotIndex != g_hoverParity.lastShot_) {
        g_hoverParity.lastShot_ = shotIndex;
        if (shotIndex == 0) {
            g_hoverParity.restoreSubdivisionMode_ = IRRender::getSubdivisionMode();
            IRRender::setSubdivisionMode(IRRender::SubdivisionMode::NONE);
        } else if (shotIndex == kNumHoverParityShots) {
            IRRender::setSubdivisionMode(g_hoverParity.restoreSubdivisionMode_);
        }
    }
    if (shotIndex >= kNumHoverParityShots) {
        return;
    }
    aimHoverParity(g_hoverParity.shots_[shotIndex]);
}

// The pivot trio runs panned off-origin at a non-cardinal yaw: ORIGIN and
// CAMERA_CENTER only differ once the camera is away from the world origin AND
// rotating, so at the standard zoom4/pan0/yaw0 framing the two modes render
// identically and the "visible effect" pair would be vacuous. Same pose as the
// standing `zoom4_pan16_yaw45_pivot` render-verify shot, for the same reason.
constexpr IRVideo::GuiTestShot kHelpOverlayGuiShots[] = {
    // Hover parity block first: no overlay or menu is up, so the fixture voxel
    // is the only hoverable content under the cursor. Camera centred on the
    // shot's voxel (`cameraIso` is the negated world iso of the screen centre).
    {{kHoverParityZoom,
      -IRMath::pos3DtoPos2DIso(kHoverParityVoxelWorld),
      0.0f,
      "hover_parity_above_diagonal"},
     g_hoverParity.shots_[0].events_,
     1},
    {{kHoverParityZoom,
      -IRMath::pos3DtoPos2DIso(kHoverParityVoxelWorld),
      0.0f,
      "hover_parity_below_diagonal"},
     g_hoverParity.shots_[1].events_,
     1},
    {{kHoverParityZoom,
      -IRMath::pos3DtoPos2DIso(kHoverParityStackedVoxelWorld),
      0.0f,
      "hover_parity_row_above_occupied"},
     g_hoverParity.shots_[2].events_,
     1},
    {{kHoverParityZoom,
      -IRMath::pos3DtoPos2DIso(kHoverParityVoxelWorld),
      0.0f,
      "drag_pan_tracks_cursor"},
     g_dragPan.events_,
     4},
    {{4.0f, vec2(0.0f), 0.0f, "help_overlay_open"}, kHelpOpenEvents, 2},
    {{4.0f, vec2(0.0f), 0.0f, "help_overlay_closed"}, kHelpCloseEvents, 2},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_open"}, kMenuOpenEvents, 2},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_hover_idle"}, g_hoverPixel.awayEvents_, 1},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_hover_row"}, g_hoverPixel.hoverEvents_, 1},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_pause_on"}, g_pauseOnClick.events_, 3},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_pause_off"}, g_pauseOffClick.events_, 3},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_checkerboard_on"}, g_checkerboardOnClick.events_, 3},
    // Pivot A/B: `_before` is the CAMERA_CENTER reference at the pose the
    // `_origin` capture repeats, both with the dropdown collapsed, so the only
    // difference between the two frames is the mode the click wrote.
    {{4.0f, vec2(16, 16), IRMath::kQuarterPi, "settings_menu_pivot_before"}, nullptr, 0},
    {{4.0f, vec2(16, 16), IRMath::kQuarterPi, "settings_menu_pivot_expand"},
     g_pivotExpandClick.events_,
     3},
    {{4.0f, vec2(16, 16), IRMath::kQuarterPi, "settings_menu_pivot_origin"},
     g_pivotItemClick.events_,
     3},
    // Debug-overlay A/B, same shape, back at the standard framing.
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_overlay_before"}, nullptr, 0},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_overlay_expand"}, g_overlayExpandClick.events_, 3},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_overlay_ao"}, g_overlayItemClick.events_, 3},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_closed"}, kMenuCloseEvents, 2},
    // Reopened so the QUIT click below has a live panel to hit; its assertions
    // also cover the re-seed contract — a second open rebuilds every widget from
    // the settings' current getters, not from the values the first open latched.
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_reopened"}, kMenuOpenEvents, 2},
    {{4.0f, vec2(0.0f), 0.0f, "settings_menu_quit"}, g_quitClick.events_, 3},
};
constexpr int kNumHelpOverlayGuiShots =
    static_cast<int>(sizeof(kHelpOverlayGuiShots) / sizeof(kHelpOverlayGuiShots[0]));
static_assert(
    kHelpOverlayGuiShots[kDragPanShotIndex].inputs_ == g_dragPan.events_,
    "kDragPanShotIndex must name the drag-pan shot — its aim hook keys on it"
);

bool helpOverlayVisiblePredicate(const void *context, std::string &actual) {
    const bool expected = *static_cast<const bool *>(context);
    const bool visible = IRPrefab::HelpOverlay::isVisible();
    actual = visible ? "visible" : "hidden";
    return visible == expected;
}

// Glyph commands are batched and uploaded inside the overlay's endTick, so the
// count is the only after-the-fact evidence it drew rather than merely flipped
// its flag. Expect > 0 while open, exactly 0 while closed.
bool helpOverlayGlyphsPredicate(const void *context, std::string &actual) {
    const bool expectGlyphs = *static_cast<const bool *>(context);
    const int count = IRPrefab::HelpOverlay::lastGlyphCommandCount();
    actual = std::to_string(count);
    return expectGlyphs ? count > 0 : count == 0;
}

// The overlay wraps a row to the GUI canvas, so on a narrow canvas an entry
// spans lines, its words separated by a newline and a hanging indent.
// Collapsing each whitespace run to one space recovers the row as registered.
std::string collapseWhitespace(const std::string &text) {
    std::string collapsed;
    collapsed.reserve(text.size());
    bool pendingSpace = false;
    for (const char c : text) {
        if (std::isspace(static_cast<unsigned char>(c)) != 0) {
            pendingSpace = !collapsed.empty();
            continue;
        }
        if (pendingSpace) {
            collapsed += ' ';
            pendingSpace = false;
        }
        collapsed += c;
    }
    return collapsed;
}

// The zero-per-demo-wiring claim: shape_debug never describes the camera keys,
// yet the overlay must render one of them WITH the description the engine's
// command catalog supplies.
bool helpOverlayCameraEntryPredicate(const void *context, std::string &actual) {
    const char *needle = static_cast<const char *>(context);
    const std::string text = collapseWhitespace(IRPrefab::HelpOverlay::builtText());
    const bool found = text.find(needle) != std::string::npos;
    actual = found ? "found" : (text.empty() ? "empty-text" : "missing");
    return found;
}

// --- Screen-target readback --------------------------------------------------
//
// Glyph commands batched and a panel inside the GUI canvas say the overlay was
// laid out, not that anyone can see it: the canvas still has to reach the
// screen target at the right place and scale. These assertions read the
// composited frame itself.
//
// The image is the whole screen target, RGBA8, rows top-first. It is read by a
// system at the RENDER tail — after the last pass that draws to the target,
// where the readback is defined in every window mode — on each live frame of a
// shot that asks for it. The assertion hook runs ahead of the composite, so on
// the capture frame it reads the previous frame's image, which the settle
// window has already made the frame being captured. Whole-target rather than a
// sub-rectangle because the backends disagree on which edge a region's y is
// measured from.
struct ScreenProbe {
    bool wanted_ = false;
    bool valid_ = false;
    IRMath::ivec2 size_ = IRMath::ivec2(0);
    std::vector<std::uint8_t> rgba_;

    bool contains(IRMath::ivec2 px) const {
        return valid_ && px.x >= 0 && px.y >= 0 && px.x < size_.x && px.y < size_.y;
    }

    Color at(IRMath::ivec2 px) const {
        const std::size_t i = (static_cast<std::size_t>(px.y) * static_cast<std::size_t>(size_.x) +
                               static_cast<std::size_t>(px.x)) *
                              4u;
        return Color{rgba_[i], rgba_[i + 1], rgba_[i + 2], rgba_[i + 3]};
    }
};
ScreenProbe g_screenProbe;

void readScreenProbe() {
    g_screenProbe.valid_ = false;
    if (!g_screenProbe.wanted_) {
        return;
    }
    IRWindow::getFramebufferSize(g_screenProbe.size_);
    if (g_screenProbe.size_.x <= 0 || g_screenProbe.size_.y <= 0) {
        return;
    }
    g_screenProbe.rgba_.resize(
        static_cast<std::size_t>(g_screenProbe.size_.x) *
        static_cast<std::size_t>(g_screenProbe.size_.y) * 4u
    );
    g_screenProbe.valid_ = IRRender::readDefaultFramebuffer(
        0,
        0,
        g_screenProbe.size_.x,
        g_screenProbe.size_.y,
        g_screenProbe.rgba_.data()
    );
}

constexpr int kScreenProbeColorTolerance = 4;

bool colorsMatch(Color a, Color b, int tolerance) {
    return IRMath::abs(static_cast<int>(a.red_) - static_cast<int>(b.red_)) <= tolerance &&
           IRMath::abs(static_cast<int>(a.green_) - static_cast<int>(b.green_)) <= tolerance &&
           IRMath::abs(static_cast<int>(a.blue_) - static_cast<int>(b.blue_)) <= tolerance;
}

std::string colorString(Color color) {
    return "(" + std::to_string(color.red_) + "," + std::to_string(color.green_) + "," +
           std::to_string(color.blue_) + ")";
}

// Screen-target pixel a GUI-canvas point is drawn at: the GUI canvas spans the
// main framebuffer, which the screen pass draws centered in the target at the
// output scale. Built from the target's own extent rather than through the
// cursor mapping, so it states where the frame must put the point instead of
// where the engine's cursor chain believes it did.
vec2 guiTrixelToScreenTargetPx(vec2 guiTrixel, IRMath::ivec2 screenTargetSize) {
    const vec2 guiSize =
        vec2(IREntity::getComponent<C_TriangleCanvasTextures>(IRRender::getCanvas("gui")).size_);
    const vec2 quadSize = vec2(
                              IREntity::getComponent<C_TrixelCanvasFramebuffer>("mainFramebuffer")
                                  .getResolutionPlusBuffer()
                          ) *
                          vec2(IRRender::getOutputScaleFactor());
    return (vec2(screenTargetSize) - quadSize) * 0.5f + guiTrixel / guiSize * quadSize;
}

// The panel the overlay painted lies wholly on the GUI canvas — the layout
// half of "nothing is cut off".
bool helpOverlayPanelInsideCanvasPredicate(const void *, std::string &actual) {
    const IRPrefab::HelpOverlay::GuiRect panel = IRPrefab::HelpOverlay::panelRect();
    const IRMath::ivec2 canvas =
        IREntity::getComponent<C_TriangleCanvasTextures>(IRRender::getCanvas("gui")).size_;
    actual = "panel=" + std::to_string(panel.pos_.x) + "," + std::to_string(panel.pos_.y) + "+" +
             std::to_string(panel.size_.x) + "x" + std::to_string(panel.size_.y) +
             " canvas=" + std::to_string(canvas.x) + "x" + std::to_string(canvas.y);
    return panel.size_.x > 0 && panel.size_.y > 0 && panel.pos_.x >= 0 && panel.pos_.y >= 0 &&
           panel.pos_.x + panel.size_.x <= canvas.x && panel.pos_.y + panel.size_.y <= canvas.y;
}

// The screen half: the first command row's glyph box maps inside the screen
// target, and text-colored pixels are actually there. An overlay composited at
// the wrong scale or offset keeps every other assertion in this shot green —
// its glyphs are still batched and its panel still fits the canvas.
bool helpOverlayFirstRowOnFramePredicate(const void *, std::string &actual) {
    const IRPrefab::HelpOverlay::GuiRect row =
        IRPrefab::HelpOverlay::textLineRect(IRPrefab::HelpOverlay::kFirstCommandLine);
    if (!g_screenProbe.valid_ || row.size_.x <= 0) {
        actual = g_screenProbe.valid_ ? "no-command-row" : "no-readback";
        return false;
    }
    const vec2 lo = guiTrixelToScreenTargetPx(vec2(row.pos_), g_screenProbe.size_);
    const vec2 hi = guiTrixelToScreenTargetPx(vec2(row.pos_ + row.size_), g_screenProbe.size_);
    const IRMath::ivec2 bandLo{
        static_cast<int>(IRMath::floor(lo.x)),
        static_cast<int>(IRMath::floor(lo.y))
    };
    const IRMath::ivec2 bandHi{
        static_cast<int>(IRMath::ceil(hi.x)),
        static_cast<int>(IRMath::ceil(hi.y))
    };
    const bool onFrame =
        g_screenProbe.contains(bandLo) && g_screenProbe.contains(bandHi - IRMath::ivec2(1));
    int textPixels = 0;
    if (onFrame) {
        const Color textColor = IRPrefab::Widget::defaultTheme().textIdle_;
        for (int y = bandLo.y; y < bandHi.y; ++y) {
            for (int x = bandLo.x; x < bandHi.x; ++x) {
                if (colorsMatch(
                        g_screenProbe.at(IRMath::ivec2(x, y)),
                        textColor,
                        kScreenProbeColorTolerance
                    )) {
                    ++textPixels;
                }
            }
        }
    }
    actual = "text_px=" + std::to_string(textPixels) + " band=" + std::to_string(bandLo.x) + "," +
             std::to_string(bandLo.y) + "+" + std::to_string(bandHi.x - bandLo.x) + "x" +
             std::to_string(bandHi.y - bandLo.y) +
             " target=" + std::to_string(g_screenProbe.size_.x) + "x" +
             std::to_string(g_screenProbe.size_.y) + (onFrame ? "" : " off-frame");
    return onFrame && textPixels > 0;
}

// Screen-target pixel under a cursor resting at the hover oracle's row target.
IRMath::ivec2 hoverOraclePixel() {
    const vec2 px =
        IRRender::windowPointsToFramebufferPx(vec2(g_hoverPixel.hoverEvents_[0].screenPx_));
    return IRMath::ivec2{
        static_cast<int>(IRMath::floor(px.x)),
        static_cast<int>(IRMath::floor(px.y))
    };
}

// A change smaller than this is not a repaint; the idle and hover fills differ
// by 20 or more in every channel.
constexpr int kHoverRepaintMinDelta = 8;

bool hoverIdlePixelPredicate(const void *, std::string &actual) {
    const IRMath::ivec2 px = hoverOraclePixel();
    if (!g_screenProbe.contains(px)) {
        actual = g_screenProbe.valid_ ? "target-off-frame" : "no-readback";
        return false;
    }
    g_hoverPixel.idle_ = g_screenProbe.at(px);
    g_hoverPixel.idleSampled_ = true;
    actual = "rgb=" + colorString(g_hoverPixel.idle_) + " px=" + std::to_string(px.x) + "," +
             std::to_string(px.y);
    return true;
}

bool hoverRowPixelPredicate(const void *, std::string &actual) {
    const IRMath::ivec2 px = hoverOraclePixel();
    if (!g_screenProbe.contains(px) || !g_hoverPixel.idleSampled_) {
        actual = g_screenProbe.valid_ ? "no-idle-sample" : "no-readback";
        return false;
    }
    const Color hovered = g_screenProbe.at(px);
    actual = "rgb=" + colorString(hovered) + " idle=" + colorString(g_hoverPixel.idle_) +
             " px=" + std::to_string(px.x) + "," + std::to_string(px.y);
    return !colorsMatch(hovered, g_hoverPixel.idle_, kHoverRepaintMinDelta - 1);
}

constexpr bool kExpectVisible = true;
constexpr bool kExpectHidden = false;
constexpr char kCameraSuiteEntry[] = "CAMERA UP - PAN THE CAMERA UP WHILE HELD";

const IRPrefab::GuiTest::Assertion kHelpOpenAssertions[] = {
    IRPrefab::GuiTest::predicate(&helpOverlayVisiblePredicate, &kExpectVisible, "overlay_visible"),
    IRPrefab::GuiTest::predicate(&helpOverlayGlyphsPredicate, &kExpectVisible, "glyphs_batched"),
    IRPrefab::GuiTest::predicate(
        &helpOverlayCameraEntryPredicate, kCameraSuiteEntry, "camera_entry_described"
    ),
    IRPrefab::GuiTest::predicate(
        &helpOverlayPanelInsideCanvasPredicate, nullptr, "overlay_bounds_inside_canvas"
    ),
    IRPrefab::GuiTest::predicate(
        &helpOverlayFirstRowOnFramePredicate, nullptr, "first_command_row_on_frame"
    ),
};

const IRPrefab::GuiTest::Assertion kHelpClosedAssertions[] = {
    IRPrefab::GuiTest::predicate(&helpOverlayVisiblePredicate, &kExpectHidden, "overlay_hidden"),
    IRPrefab::GuiTest::predicate(&helpOverlayGlyphsPredicate, &kExpectHidden, "no_glyphs_batched"),
};

// --- Settings-menu predicates --------------------------------------

bool settingsMenuOpenPredicate(const void *context, std::string &actual) {
    const bool expected = *static_cast<const bool *>(context);
    const bool open = IRPrefab::SettingsMenu::isOpen();
    actual = open ? "open" : "closed";
    return open == expected;
}

// The toggle flag alone cannot distinguish "the menu opened" from "the command
// fired but the system never built anything". Live rows are that evidence, and
// on the closed shot they prove teardown actually destroyed the widgets rather
// than leaving them on the canvas.
bool settingsMenuRowsPredicate(const void *context, std::string &actual) {
    const bool expectRows = *static_cast<const bool *>(context);
    const int rows = IRPrefab::SettingsMenu::liveRowCount();
    actual = std::to_string(rows);
    return expectRows ? rows > 0 : rows == 0;
}

std::string guiRectString(const IRPrefab::GuiRect &rect) {
    return std::to_string(rect.pos_.x) + "," + std::to_string(rect.pos_.y) + "+" +
           std::to_string(rect.size_.x) + "x" + std::to_string(rect.size_.y);
}

bool settingsMenuLayoutPredicate(const void *, std::string &actual) {
    const IRPrefab::GuiRect panel = IRPrefab::SettingsMenu::panelRect();
    bool valid = panel.size_.x > 0 && panel.size_.y > 0;
    actual = "stacked=" + std::to_string(IRPrefab::SettingsMenu::enumRowsStacked() ? 1 : 0) +
             " panel=" + guiRectString(panel);
    const int rowCount = IRPrefab::SettingsMenu::liveRowCount();
    for (int i = 0; i < rowCount; ++i) {
        const IRPrefab::GuiRect control = IRPrefab::SettingsMenu::rowControlRect(i);
        actual += " row" + std::to_string(i) + "-control=" + guiRectString(control);
        valid = IRPrefab::contains(panel, control) && valid;
    }
    for (const int index : {kRotationPivotSettingIndex, kDebugOverlaySettingIndex}) {
        const IRPrefab::GuiRect label = IRPrefab::SettingsMenu::rowLabelRect(index);
        const IRPrefab::GuiRect control = IRPrefab::SettingsMenu::rowControlRect(index);
        actual += " row" + std::to_string(index) + "-label=" + guiRectString(label);
        valid = IRPrefab::contains(panel, label) && !IRPrefab::intersects(label, control) && valid;
    }
    return valid;
}

// Widget-side half of the click: the checkbox latched.
bool pauseCheckboxPredicate(const void *context, std::string &actual) {
    const bool expected = *static_cast<const bool *>(context);
    const EntityId widget = IRPrefab::SettingsMenu::rowWidget(kPauseSettingIndex);
    if (widget == IREntity::kNullEntity) {
        actual = "no-widget";
        return false;
    }
    const bool checked = IRPrefab::Widget::checkboxState(widget);
    actual = checked ? "checked" : "unchecked";
    return checked == expected;
}

// Engine-side half: the registered setter actually ran and stopped the clock.
// This is the assertion that fails if the menu renders and latches but never
// reaches the setting behind it.
bool simPausedPredicate(const void *context, std::string &actual) {
    const bool expected = *static_cast<const bool *>(context);
    const bool paused = IRSim::isPaused();
    actual = paused ? "paused" : "running";
    return paused == expected;
}

const IRPrefab::GuiTest::Assertion kMenuOpenAssertions[] = {
    IRPrefab::GuiTest::predicate(&settingsMenuOpenPredicate, &kExpectVisible, "menu_open"),
    IRPrefab::GuiTest::predicate(&settingsMenuRowsPredicate, &kExpectVisible, "rows_spawned"),
    IRPrefab::GuiTest::predicate(
        &settingsMenuLayoutPredicate, nullptr, "settings_rows_inside_panel"
    ),
};

const IRPrefab::GuiTest::Assertion kMenuHoverIdleAssertions[] = {
    IRPrefab::GuiTest::predicate(&hoverIdlePixelPredicate, nullptr, "row_pixel_idle_sampled"),
};

const IRPrefab::GuiTest::Assertion kMenuHoverRowAssertions[] = {
    IRPrefab::GuiTest::predicate(
        &hoverRowPixelPredicate, nullptr, "row_pixel_repaints_under_cursor"
    ),
};

const IRPrefab::GuiTest::Assertion kMenuPauseOnAssertions[] = {
    IRPrefab::GuiTest::predicate(&pauseCheckboxPredicate, &kExpectVisible, "checkbox_checked"),
    IRPrefab::GuiTest::predicate(&simPausedPredicate, &kExpectVisible, "sim_paused"),
};

const IRPrefab::GuiTest::Assertion kMenuPauseOffAssertions[] = {
    IRPrefab::GuiTest::predicate(&pauseCheckboxPredicate, &kExpectHidden, "checkbox_unchecked"),
    IRPrefab::GuiTest::predicate(&simPausedPredicate, &kExpectHidden, "sim_running"),
};

// The render-side half of a live toggle: the setter did not merely flip a
// global, it re-applied the tint flag onto the shapes the shader reads. Without
// this, `applyTintFlags()` could silently no-op and the capture would look
// unchanged for a reason no assertion names.
bool shapeCheckerboardFlagPredicate(const void *context, std::string &actual) {
    const bool expected = *static_cast<const bool *>(context);
    int flagged = 0;
    int total = 0;
    IREntity::forEachComponent<C_ShapeDescriptor>([&flagged,
                                                   &total](EntityId &, C_ShapeDescriptor &desc) {
        ++total;
        if ((desc.flags_ & IRRender::SHAPE_FLAG_CHECKERBOARD) != 0) {
            ++flagged;
        }
    });
    actual = std::to_string(flagged) + "/" + std::to_string(total) + " flagged";
    return expected ? (total > 0 && flagged == total) : flagged == 0;
}

const IRPrefab::GuiTest::Assertion kMenuCheckerboardOnAssertions[] = {
    IRPrefab::GuiTest::predicate(&pauseCheckboxPredicate, &kExpectHidden, "pause_still_off"),
    IRPrefab::GuiTest::predicate(
        &shapeCheckerboardFlagPredicate, &kExpectVisible, "shapes_checkerboard_flagged"
    ),
};

const IRPrefab::GuiTest::Assertion kMenuClosedAssertions[] = {
    IRPrefab::GuiTest::predicate(&settingsMenuOpenPredicate, &kExpectHidden, "menu_closed"),
    IRPrefab::GuiTest::predicate(&settingsMenuRowsPredicate, &kExpectHidden, "rows_destroyed"),
};

// --- Enum-row (dropdown) predicates ----------------------------------------
//
// The two ENUM settings are the remaining live toggles from the plan's
// acceptance criterion 2. Each is driven by two clicks (expand, then pick an
// item) and asserted on both halves, like the checkbox above: the dropdown
// latched the index AND the engine-side getter moved.

// Which registered setting's row, and what its dropdown / engine value should
// read there. One struct serves every enum-row assertion so the predicates stay
// parameterized by data rather than duplicated per setting.
struct EnumExpectation {
    int settingIndex_;
    int value_;
};

constexpr EnumExpectation kPivotDropdownOrigin{kRotationPivotSettingIndex, kPivotOrigin};
constexpr EnumExpectation kOverlayDropdownAo{kDebugOverlaySettingIndex, kOverlayAo};
constexpr EnumExpectation kPivotDropdownExpanded{kRotationPivotSettingIndex, 1};
constexpr EnumExpectation kPivotDropdownCollapsed{kRotationPivotSettingIndex, 0};
constexpr EnumExpectation kOverlayDropdownExpanded{kDebugOverlaySettingIndex, 1};

// Widget-side half of an enum click: the dropdown latched the picked index.
bool enumDropdownIndexPredicate(const void *context, std::string &actual) {
    const auto &expected = *static_cast<const EnumExpectation *>(context);
    const EntityId widget = IRPrefab::SettingsMenu::rowWidget(expected.settingIndex_);
    if (widget == IREntity::kNullEntity) {
        actual = "no-widget";
        return false;
    }
    const int index = IRPrefab::Widget::dropdownSelectedIndex(widget);
    actual = "index=" + std::to_string(index);
    return index == expected.value_;
}

// A dropdown only shows its item strip between the two clicks, so this is what
// distinguishes "the expand click landed" from "the row never reacted" — and, on
// the item shot, that picking a row collapsed it again.
bool enumDropdownOpenPredicate(const void *context, std::string &actual) {
    const auto &expected = *static_cast<const EnumExpectation *>(context);
    const EntityId widget = IRPrefab::SettingsMenu::rowWidget(expected.settingIndex_);
    if (widget == IREntity::kNullEntity) {
        actual = "no-widget";
        return false;
    }
    const bool open = IRPrefab::Widget::isDropdownOpen(widget);
    actual = open ? "expanded" : "collapsed";
    return open == (expected.value_ != 0);
}

// Engine-side half: the registered setter reached IRRender. These are the
// assertions that fail if the dropdown latches an index the setting never sees.
bool rotationPivotPredicate(const void *context, std::string &actual) {
    const int expected = *static_cast<const int *>(context);
    const int mode = static_cast<int>(IRRender::getRotationPivotMode());
    actual = "pivot=" + std::to_string(mode);
    return mode == expected;
}

bool debugOverlayPredicate(const void *context, std::string &actual) {
    const int expected = *static_cast<const int *>(context);
    const int mode = static_cast<int>(IRRender::getDebugOverlay());
    actual = "overlay=" + std::to_string(mode);
    return mode == expected;
}

// The QUIT button's only observable is engine-side: the click asked the window
// to close. See kMenuQuitShotIndex below for why this one cannot be evaluated
// on a capture frame like every other assertion.
bool windowCloseRequestedPredicate(const void *context, std::string &actual) {
    const bool expected = *static_cast<const bool *>(context);
    const bool requested = IRWindow::isCloseRequested();
    actual = requested ? "close-requested" : "still-open";
    return requested == expected;
}

const IRPrefab::GuiTest::Assertion kMenuPivotBeforeAssertions[] = {
    IRPrefab::GuiTest::predicate(&rotationPivotPredicate, &kPivotCameraCenter, "pivot_default"),
    IRPrefab::GuiTest::predicate(
        &enumDropdownOpenPredicate, &kPivotDropdownCollapsed, "pivot_dropdown_collapsed"
    ),
};

const IRPrefab::GuiTest::Assertion kMenuPivotExpandAssertions[] = {
    IRPrefab::GuiTest::predicate(
        &enumDropdownOpenPredicate, &kPivotDropdownExpanded, "pivot_dropdown_expanded"
    ),
    // Expanding must not write the setting — otherwise the item click below
    // would be asserting a change that the header click already made.
    IRPrefab::GuiTest::predicate(
        &rotationPivotPredicate, &kPivotCameraCenter, "pivot_unchanged_by_expand"
    ),
};

const IRPrefab::GuiTest::Assertion kMenuPivotOriginAssertions[] = {
    IRPrefab::GuiTest::predicate(
        &enumDropdownIndexPredicate, &kPivotDropdownOrigin, "pivot_dropdown_origin"
    ),
    IRPrefab::GuiTest::predicate(&rotationPivotPredicate, &kPivotOrigin, "pivot_mode_origin"),
    IRPrefab::GuiTest::predicate(
        &enumDropdownOpenPredicate, &kPivotDropdownCollapsed, "pivot_dropdown_collapsed"
    ),
};

const IRPrefab::GuiTest::Assertion kMenuOverlayBeforeAssertions[] = {
    IRPrefab::GuiTest::predicate(&debugOverlayPredicate, &kOverlayNone, "overlay_default"),
};

const IRPrefab::GuiTest::Assertion kMenuOverlayExpandAssertions[] = {
    IRPrefab::GuiTest::predicate(
        &enumDropdownOpenPredicate, &kOverlayDropdownExpanded, "overlay_dropdown_expanded"
    ),
};

const IRPrefab::GuiTest::Assertion kMenuOverlayAoAssertions[] = {
    IRPrefab::GuiTest::predicate(
        &enumDropdownIndexPredicate, &kOverlayDropdownAo, "overlay_dropdown_ao"
    ),
    IRPrefab::GuiTest::predicate(&debugOverlayPredicate, &kOverlayAo, "overlay_mode_ao"),
};

// A second open rebuilds every widget from the settings' *current* getters, so
// the pivot dropdown must come back on ORIGIN — the value the earlier click
// wrote, not the CAMERA_CENTER the first open latched.
const IRPrefab::GuiTest::Assertion kMenuReopenedAssertions[] = {
    IRPrefab::GuiTest::predicate(&settingsMenuOpenPredicate, &kExpectVisible, "menu_reopened"),
    IRPrefab::GuiTest::predicate(&settingsMenuRowsPredicate, &kExpectVisible, "rows_respawned"),
    IRPrefab::GuiTest::predicate(
        &enumDropdownIndexPredicate, &kPivotDropdownOrigin, "pivot_reseeded_from_getter"
    ),
};

const IRPrefab::GuiTest::Assertion kMenuQuitAssertions[] = {
    IRPrefab::GuiTest::predicate(
        &windowCloseRequestedPredicate, &kExpectVisible, "quit_requested_close"
    ),
};

// Per-shot assertion table, indexed by shot. One row per kHelpOverlayGuiShots
// entry — a table rather than a chain of ternaries so adding a shot is one
// line in each array and the static_assert below catches a missed pairing.
struct ShotAssertions {
    const IRPrefab::GuiTest::Assertion *assertions_;
    int count_;
    // The shot's assertions read g_screenProbe, so the RENDER-tail readback
    // runs while it is live.
    bool readsScreen_ = false;
};

template <std::size_t N>
constexpr ShotAssertions
shotAssertions(const IRPrefab::GuiTest::Assertion (&table)[N], bool readsScreen = false) {
    return ShotAssertions{table, static_cast<int>(N), readsScreen};
}

const ShotAssertions kShotAssertions[] = {
    shotAssertions(g_hoverParity.shots_[0].assertions_),
    shotAssertions(g_hoverParity.shots_[1].assertions_),
    shotAssertions(g_hoverParity.shots_[2].assertions_),
    shotAssertions(g_dragPan.assertions_),
    shotAssertions(kHelpOpenAssertions, true),
    shotAssertions(kHelpClosedAssertions),
    shotAssertions(kMenuOpenAssertions),
    shotAssertions(kMenuHoverIdleAssertions, true),
    shotAssertions(kMenuHoverRowAssertions, true),
    shotAssertions(kMenuPauseOnAssertions),
    shotAssertions(kMenuPauseOffAssertions),
    shotAssertions(kMenuCheckerboardOnAssertions),
    shotAssertions(kMenuPivotBeforeAssertions),
    shotAssertions(kMenuPivotExpandAssertions),
    shotAssertions(kMenuPivotOriginAssertions),
    shotAssertions(kMenuOverlayBeforeAssertions),
    shotAssertions(kMenuOverlayExpandAssertions),
    shotAssertions(kMenuOverlayAoAssertions),
    shotAssertions(kMenuClosedAssertions),
    shotAssertions(kMenuReopenedAssertions),
    shotAssertions(kMenuQuitAssertions),
};
static_assert(
    static_cast<int>(sizeof(kShotAssertions) / sizeof(kShotAssertions[0])) ==
        kNumHelpOverlayGuiShots,
    "every --gui-test shot needs an assertion row — a shot without one would "
    "capture silently and prove nothing"
);

// First shot that opens the menu; from here on every live frame re-aims the
// click targets. Pinned structurally, like its kMenuQuitShotIndex neighbor: the
// fill gate keys on this index, so a shot inserted ahead of the menu block would
// silently stop aiming the early menu clicks and leave them at the screen
// corner. Identified by the events the shot carries — the label is not
// constexpr-comparable, and kMenuOpenEvents IS what "opens the menu" means here.
constexpr int kMenuOpenShotIndex = kDragPanShotIndex + 3;
constexpr bool isFirstMenuOpeningShot(int index) {
    for (int i = 0; i < index; ++i) {
        if (kHelpOverlayGuiShots[i].inputs_ == kMenuOpenEvents) {
            return false;
        }
    }
    return kHelpOverlayGuiShots[index].inputs_ == kMenuOpenEvents;
}
static_assert(
    isFirstMenuOpeningShot(kMenuOpenShotIndex),
    "kMenuOpenShotIndex must name the FIRST shot that opens the settings menu — "
    "the click-target fill gate keys on it"
);

// The QUIT click ends the run: `applyEdits()` calls `IRWindow::closeWindow()`
// during that click's INPUT phase, and `World::gameLoop()` tests
// `shouldClose()` at the top of the next iteration — so this shot gets exactly
// one more RENDER tick and never reaches its post-settle capture frame.
// Evaluating on `isCaptureFrame` like every other shot would emit nothing at
// all, which reads as a silent pass. Evaluate the moment the close is observed
// instead, through the same `GuiTest::evaluate` emitter the capture path uses —
// gui-verify.py parses one format, and a second emitter is one drift away from
// being unparseable.
constexpr int kMenuQuitShotIndex = kMenuOpenShotIndex + 14;
static_assert(
    kMenuQuitShotIndex == kNumHelpOverlayGuiShots - 1,
    "the QUIT shot ends the run — a shot appended after it would never execute"
);
bool g_quitAssertionsEmitted = false;

// The overlay assertions need no widget/click latching, but the menu's do
// (C_WidgetState::fireAction_ is a one-frame pulse), and GuiTest::onFrame owns
// both the latching and the capture-frame dispatch.
IRPrefab::GuiTest::LatchState g_helpOverlayLatch;

// ---------------------------------------------------------------------------
// Fractional-zoom picking fixture (--continuous-zoom-gui-test)
// ---------------------------------------------------------------------------
// The hover-parity and drag-pan targets again, at a continuous zoom of 2.5.
// One trixel is then 5 x 2.5 game pixels, so every screen <-> iso conversion
// in the picking chain runs on a fractional vertical step: a step truncated to
// whole pixels moves the dragged content 2.5 / 2 as far as the cursor, and
// aims the off-centre hover a fifth of its distance from the screen centre
// short of the voxel.
//
// The three parity shots run with render subdivisions off, as in --gui-test,
// and frame their voxel at the screen centre; there the step cancels out and
// they prove only that the continuous placement draws what the hover reads.
// The drag-pan shot and the off-centre shot run under FULL, where 2.5 rasters
// at three backing texels per iso unit: they exercise the gather translation
// and the entity-id read at a fractional backing-texel pitch, and they are the
// two the step is load-bearing for.
constexpr float kContinuousGuiZoom = 2.5f;
// Iso cells between the screen centre and the voxel in the off-centre shot.
constexpr vec2 kContinuousGuiOffCentreIso = vec2(18.0f, 26.0f);

struct ContinuousZoomOffCentreShot {
    IRVideo::GuiInputEvent events_[1]{
        {1, IRVideo::GuiInputEvent::Type::MOVE, IRMath::ivec2(0)},
    };
    IRPrefab::GuiTest::Assertion assertions_[1];
};
ContinuousZoomOffCentreShot g_continuousOffCentre;

constexpr int kContinuousOffCentreShotIndex = kDragPanShotIndex + 1;

constexpr IRVideo::GuiTestShot kContinuousZoomGuiShots[] = {
    {{kContinuousGuiZoom,
      -IRMath::pos3DtoPos2DIso(kHoverParityVoxelWorld),
      0.0f,
      "continuous_zoom_hover_above_diagonal"},
     g_hoverParity.shots_[0].events_,
     1},
    {{kContinuousGuiZoom,
      -IRMath::pos3DtoPos2DIso(kHoverParityVoxelWorld),
      0.0f,
      "continuous_zoom_hover_below_diagonal"},
     g_hoverParity.shots_[1].events_,
     1},
    {{kContinuousGuiZoom,
      -IRMath::pos3DtoPos2DIso(kHoverParityStackedVoxelWorld),
      0.0f,
      "continuous_zoom_hover_row_above_occupied"},
     g_hoverParity.shots_[2].events_,
     1},
    {{kContinuousGuiZoom,
      -IRMath::pos3DtoPos2DIso(kHoverParityVoxelWorld),
      0.0f,
      "continuous_zoom_drag_pan_tracks_cursor"},
     g_dragPan.events_,
     4},
    {{kContinuousGuiZoom,
      -IRMath::pos3DtoPos2DIso(kHoverParityVoxelWorld) + kContinuousGuiOffCentreIso,
      0.0f,
      "continuous_zoom_hover_off_centre"},
     g_continuousOffCentre.events_,
     1},
};
constexpr int kNumContinuousZoomGuiShots =
    static_cast<int>(sizeof(kContinuousZoomGuiShots) / sizeof(kContinuousZoomGuiShots[0]));
static_assert(
    kContinuousZoomGuiShots[kDragPanShotIndex].inputs_ == g_dragPan.events_,
    "kDragPanShotIndex must name the drag-pan shot in this table too — its aim hook keys on it"
);
static_assert(
    kContinuousZoomGuiShots[kContinuousOffCentreShotIndex].inputs_ == g_continuousOffCentre.events_,
    "kContinuousOffCentreShotIndex must name the off-centre shot — its aim hook keys on it"
);

const ShotAssertions kContinuousZoomShotAssertions[] = {
    shotAssertions(g_hoverParity.shots_[0].assertions_),
    shotAssertions(g_hoverParity.shots_[1].assertions_),
    shotAssertions(g_hoverParity.shots_[2].assertions_),
    shotAssertions(g_dragPan.assertions_),
    shotAssertions(g_continuousOffCentre.assertions_),
};
static_assert(
    static_cast<int>(
        sizeof(kContinuousZoomShotAssertions) / sizeof(kContinuousZoomShotAssertions[0])
    ) == kNumContinuousZoomGuiShots,
    "every --continuous-zoom-gui-test shot needs an assertion row"
);

IRPrefab::GuiTest::LatchState g_continuousZoomLatch;

// After initHoverParityFixture: the off-centre shot hovers its isolated voxel.
void initContinuousZoomGuiFixture() {
    g_continuousOffCentre.assertions_[0] = IRPrefab::GuiTest::hoveredEntityId(
        g_hoverParity.voxelEntity_,
        "hover_id_off_centre_is_voxel",
        kDragPanStableFrames
    );
}

// Cull-invalidation fixture: one allocation, a fixed cardinal camera, and
// two poses in disjoint pool chunks. Reallocation or yaw-driven invalidation
// would hide a missing in-place alpha notification. Edits use the public
// editVoxels path, with no manual cache eviction.
//
// GUI-ASSERT checks pool-derived bounds and visibility: correct voxel alpha
// alone cannot prove that the new pose reaches the rasterizer.

constexpr IRMath::ivec3 kCullEvictSize = IRMath::ivec3(16, 16, 8);        // 2048 slots = 8 chunks
constexpr int kCullEvictLayerSlots = kCullEvictSize.x * kCullEvictSize.y; // 256 == one chunk
// Both pose predicates read "one z-layer IS one pool chunk". That holds only
// while the layer's slot count equals the pool's chunk granularity — pin it,
// or a chunk-size change silently turns the fixture into a weaker test.
static_assert(
    kCullEvictLayerSlots == IRRender::kVoxelChunkSize,
    "cull-evict fixture: one z-layer must be exactly one pool chunk"
);
constexpr int kCullEvictLiveLayers = 2;
constexpr Color kCullEvictColor = Color{80, 220, 160, 255};

// Pose 0 lights the bottom two z-layers, pose 1 the top two. `index3DtoIndex1D`
// is x-fastest with z slowest, so one z-layer is exactly one 256-slot chunk and
// the two poses never share one.
int cullEvictFirstLiveLayer(int pose) {
    return pose == 0 ? 0 : kCullEvictSize.z - kCullEvictLiveLayers;
}

struct CullEvictFixture {
    IREntity::EntityId setEntity_ = IREntity::kNullEntity;
    IREntity::EntityId canvasEntity_ = IREntity::kNullEntity;
    int lastShot_ = -1;
    int pose_ = -1;
};
CullEvictFixture g_cullEvict;

// One shot's expected pose, read by both the pose driver and the predicates.
struct CullEvictShotSpec {
    int pose_;
    const char *label_;
};
constexpr CullEvictShotSpec kCullEvictSpecs[] = {
    {0, "cull_evict_pose_a"},
    {1, "cull_evict_pose_b"},
    // Back to pose A: a fixture that only ever grows its bounds would pass the
    // first two shots on a conservative superset. This one must SHRINK again.
    {0, "cull_evict_pose_a_again"},
};
constexpr int kNumCullEvictShots =
    static_cast<int>(sizeof(kCullEvictSpecs) / sizeof(kCullEvictSpecs[0]));

constexpr IRVideo::GuiTestShot kCullEvictShots[] = {
    {IRVideo::AutoScreenshotShot{4.0f, vec2(0, 0), 0.0f, kCullEvictSpecs[0].label_}, nullptr, 0},
    {IRVideo::AutoScreenshotShot{4.0f, vec2(0, 0), 0.0f, kCullEvictSpecs[1].label_}, nullptr, 0},
    {IRVideo::AutoScreenshotShot{4.0f, vec2(0, 0), 0.0f, kCullEvictSpecs[2].label_}, nullptr, 0},
};
static_assert(
    sizeof(kCullEvictShots) / sizeof(kCullEvictShots[0]) ==
        static_cast<std::size_t>(kNumCullEvictShots),
    "kCullEvictShots and kCullEvictSpecs must stay paired"
);

// Swap which cells of the ALREADY-ALLOCATED span are live. Routes through the
// encapsulated raw-edit API — no allocation, no position write, and no cache
// eviction of any kind.
void applyCullEvictPose(int pose) {
    if (g_cullEvict.setEntity_ == IREntity::kNullEntity) {
        return;
    }
    C_VoxelSetNew &voxelSet = IREntity::getComponent<C_VoxelSetNew>(g_cullEvict.setEntity_);
    const int firstLive = cullEvictFirstLiveLayer(pose);
    voxelSet.editVoxels([firstLive](int index, C_Voxel &voxel, vec3) {
        const int layer = index / kCullEvictLayerSlots;
        if (layer >= firstLive && layer < firstLive + kCullEvictLiveLayers) {
            voxel.color_ = kCullEvictColor;
        } else {
            voxel.deactivate();
        }
    });
    g_cullEvict.pose_ = pose;
}

// The bounds a from-scratch recompute would produce for a chunk's CURRENT
// occupancy. The predicates below compare the pool's cached entry against this,
// so a stale bound fails on its values rather than on a coarse "did it move".
ChunkBounds cullEvictOracle(const C_VoxelPool &pool, int chunk) {
    ChunkBounds bounds;
    const int begin = chunk * IRRender::kVoxelChunkSize;
    const int end = IRMath::min(begin + IRRender::kVoxelChunkSize, pool.getLiveVoxelCount());
    for (int i = begin; i < end; ++i) {
        if (pool.getColors()[i].color_.alpha_ == 0) {
            continue;
        }
        const vec3 pos = pool.getPositionGlobals()[i].pos_;
        bounds.expand(IRMath::pos3DtoPos2DIso(pos));
        bounds.minDepth_ =
            IRMath::min(bounds.minDepth_, static_cast<float>(IRMath::pos3DtoDistance(pos)));
    }
    return bounds;
}

C_VoxelPool *cullEvictPool() {
    if (g_cullEvict.canvasEntity_ == IREntity::kNullEntity) {
        return nullptr;
    }
    auto poolOpt = IREntity::getComponentOptional<C_VoxelPool>(g_cullEvict.canvasEntity_);
    return poolOpt.has_value() ? poolOpt.value() : nullptr;
}

// Predicate 1 — every chunk's CACHED bounds equal its current occupancy's
// bounds. This is the assertion the defect fails: a frozen chunk keeps the
// previous pose's extent while the oracle follows the alpha.
bool cullEvictBoundsMatchOccupancy(const void *, std::string &actual) {
    C_VoxelPool *pool = cullEvictPool();
    if (pool == nullptr) {
        actual = "no-pool";
        return false;
    }
    const int chunkCount = pool->getChunkCount();
    const std::vector<ChunkBounds> &cached = pool->getChunkBounds();
    if (static_cast<int>(cached.size()) < chunkCount) {
        actual = "bounds-not-built";
        return false;
    }
    for (int c = 0; c < chunkCount; ++c) {
        const ChunkBounds want = cullEvictOracle(*pool, c);
        const ChunkBounds &got = cached[static_cast<std::size_t>(c)];
        if (got.isoMin_ != want.isoMin_ || got.isoMax_ != want.isoMax_) {
            actual = "chunk=" + std::to_string(c) + " cached=[" + std::to_string(got.isoMin_.x) +
                     "," + std::to_string(got.isoMin_.y) + ".." + std::to_string(got.isoMax_.x) +
                     "," + std::to_string(got.isoMax_.y) + "] want=[" +
                     std::to_string(want.isoMin_.x) + "," + std::to_string(want.isoMin_.y) + ".." +
                     std::to_string(want.isoMax_.x) + "," + std::to_string(want.isoMax_.y) + "]";
            return false;
        }
    }
    actual = "all " + std::to_string(chunkCount) + " chunks match occupancy";
    return true;
}

// Predicate 2 — the chunks with a non-empty bound are EXACTLY the ones this
// shot's pose lights. Pins the pose rather than merely "something changed", so
// the fixture cannot pass by holding a conservative superset of both poses.
bool cullEvictLiveChunksMatchPose(const void *context, std::string &actual) {
    const int pose = *static_cast<const int *>(context);
    C_VoxelPool *pool = cullEvictPool();
    if (pool == nullptr) {
        actual = "no-pool";
        return false;
    }
    const int firstLive = cullEvictFirstLiveLayer(pose);
    const std::vector<ChunkBounds> &cached = pool->getChunkBounds();
    std::string live;
    bool ok = true;
    for (int c = 0; c < pool->getChunkCount(); ++c) {
        if (static_cast<std::size_t>(c) >= cached.size()) {
            ok = false;
            break;
        }
        // An empty chunk keeps the inverted sentinel, so min > max.
        const bool nonEmpty = cached[static_cast<std::size_t>(c)].isoMin_.x <=
                              cached[static_cast<std::size_t>(c)].isoMax_.x;
        const bool expected = c >= firstLive && c < firstLive + kCullEvictLiveLayers;
        if (nonEmpty) {
            live += (live.empty() ? "" : ",") + std::to_string(c);
        }
        ok = ok && (nonEmpty == expected);
    }
    actual = "pose=" + std::to_string(pose) + " liveChunks=[" + live +
             "] wantFirst=" + std::to_string(firstLive);
    return ok;
}

// Predicate 3 — the cull query the UPDATE movers ask, per chunk range. A
// chunk holding no live voxels keeps the inverted sentinel and must answer
// "not visible" for ANY viewport; a chunk holding the live pose must answer
// "visible" for a viewport around one of its voxels. Under the defect the
// chunks that held the PREVIOUS pose keep its bounds, so the dark half answers
// visible and the movers keep servicing geometry that is no longer there.
//
// Deliberately NOT phrased as "a viewport around the dark pose must miss the
// live chunks": the iso projection collapses x, y and z onto two axes, so a
// 16x16 slab's iso AABB legitimately contains a distant layer's corner. That
// framing failed here against correct bounds — a false alarm, not a finding.
bool cullEvictRangeVisibility(const void *context, std::string &actual) {
    const int pose = *static_cast<const int *>(context);
    C_VoxelPool *pool = cullEvictPool();
    if (pool == nullptr || g_cullEvict.setEntity_ == IREntity::kNullEntity) {
        actual = "no-pool";
        return false;
    }
    const C_VoxelSetNew &voxelSet = IREntity::getComponent<C_VoxelSetNew>(g_cullEvict.setEntity_);
    const int liveLayer = cullEvictFirstLiveLayer(pose);
    const int darkLayer = cullEvictFirstLiveLayer(pose == 0 ? 1 : 0);
    const auto slotOf = [&](int layer) {
        return voxelSet.voxelStartIdx_ + static_cast<std::size_t>(layer * kCullEvictLayerSlots);
    };
    const std::size_t liveSlot = slotOf(liveLayer);
    const vec2 iso = IRMath::pos3DtoPos2DIso(pool->getPositionGlobals()[liveSlot].pos_);
    const IsoBounds2D atLiveVoxel{iso - vec2(0.25f), iso + vec2(0.25f)};
    const std::size_t halfSpan =
        static_cast<std::size_t>(kCullEvictLiveLayers * kCullEvictLayerSlots);
    const bool liveRange = pool->isRangeVisible(liveSlot, halfSpan, atLiveVoxel);
    const bool darkRange = pool->isRangeVisible(slotOf(darkLayer), halfSpan, atLiveVoxel);
    actual = "liveChunkRange=" + std::string(liveRange ? "visible" : "culled") +
             " darkChunkRange=" + std::string(darkRange ? "visible" : "culled");
    return liveRange && !darkRange;
}

IRPrefab::GuiTest::LatchState g_cullEvictLatch;

const IRPrefab::GuiTest::Assertion kCullEvictAssertions[] = {
    IRPrefab::GuiTest::predicate(&cullEvictBoundsMatchOccupancy, nullptr, "bounds_match_occupancy"),
    IRPrefab::GuiTest::predicate(
        &cullEvictLiveChunksMatchPose, &g_cullEvict.pose_, "live_chunks_match_pose"
    ),
    IRPrefab::GuiTest::predicate(
        &cullEvictRangeVisibility, &g_cullEvict.pose_, "range_visible_at_live_pose_only"
    ),
};
constexpr int kNumCullEvictAssertions =
    static_cast<int>(sizeof(kCullEvictAssertions) / sizeof(kCullEvictAssertions[0]));

void onCullEvictAssertFrame(int shotIndex, bool isCaptureFrame) {
    // Apply the pose once, on the shot's first live frame; the harness's settle
    // frames then let the render pipeline re-derive bounds before capture.
    if (shotIndex != g_cullEvict.lastShot_) {
        g_cullEvict.lastShot_ = shotIndex;
        applyCullEvictPose(kCullEvictSpecs[shotIndex].pose_);
    }
    IRPrefab::GuiTest::onFrame(
        g_cullEvictLatch,
        shotIndex,
        isCaptureFrame,
        kCullEvictSpecs[shotIndex].label_,
        kCullEvictAssertions,
        kNumCullEvictAssertions
    );
}

// --lod-dense-swap: two DENSE sets sharing one origin on disjoint LOD bands, so
// exactly one rasterizes per zoom. The coarse cube's corners reach past the
// fine sphere's radius and the two differ in color, so a frame that stacked
// both — the band being ignored — shows the cube's corners through the sphere.
//   coarse cube   band [LOD_3 .. LOD_4]  -> zoom < 4
//   fine   sphere band [LOD_0 .. LOD_2]  -> zoom >= 4
constexpr IRVideo::AutoScreenshotShot kLodDenseSwapShots[] = {
    {2.0f, vec2(0, 0), 0.0f, "lod_dense_swap_z2"},
    {8.0f, vec2(0, 0), 0.0f, "lod_dense_swap_z8"},
};

struct LodVariantPair {
    EntityId coarse_;
    EntityId fine_;
};

// A coarse cube (band [LOD_3 .. LOD_4]) and a fine ball (band [LOD_0 .. LOD_2])
// centered on the origin of the active canvas. The ball is inscribed in its own
// box, so a cube at least as wide reaches past it.
LodVariantPair
spawnLodVariantPair(int coarseSize, Color coarseColor, int fineSize, Color fineColor) {
    const EntityId coarse = IREntity::createEntity(
        C_LocalTransform{vec3(0.0f)},
        C_VoxelSetNew{ivec3(coarseSize), coarseColor, IRComponents::EntityAnchor::CENTER}
    );
    C_VoxelSetNew &coarseSet = IREntity::getComponent<C_VoxelSetNew>(coarse);
    coarseSet.lodMin_ = IRRender::LodLevel::LOD_4;
    coarseSet.lodMax_ = IRRender::LodLevel::LOD_3;

    const EntityId fine = IREntity::createEntity(
        C_LocalTransform{vec3(0.0f)},
        C_VoxelSetNew{ivec3(fineSize), fineColor, IRComponents::EntityAnchor::CENTER}
    );
    C_VoxelSetNew &fineSet = IREntity::getComponent<C_VoxelSetNew>(fine);
    const float radius = 0.5f * static_cast<float>(fineSize);
    fineSet.carve([radius](vec3 position) { return IRMath::length(position) > radius; });
    fineSet.lodMin_ = IRRender::LodLevel::LOD_2;
    fineSet.lodMax_ = IRRender::LodLevel::LOD_0;
    return {coarse, fine};
}

void initLodDenseSwapScene() {
    spawnLodVariantPair(8, Color{220, 150, 70, 255}, 12, Color{90, 160, 230, 255});
}

// --load-prefab: one shot per tier family a composite prefab's bands key on
// (LOD_4, LOD_2, LOD_0), labeled after the manifest's file stem.
void buildLoadPrefabShots() {
    std::string stem = std::filesystem::path(g_loadPrefabPath).filename().string();
    constexpr std::string_view kSuffix = ".prefab.lua";
    if (stem.size() > kSuffix.size() &&
        stem.compare(stem.size() - kSuffix.size(), kSuffix.size(), kSuffix) == 0) {
        stem.resize(stem.size() - kSuffix.size());
    }
    constexpr int kDefaultZooms[] = {1, 4, 16};
    const int requestedZoom = static_cast<int>(g_initialZoom);
    const int *zooms = kDefaultZooms;
    int numZooms = static_cast<int>(std::size(kDefaultZooms));
    if (g_initialZoom > 0.0f) {
        zooms = &requestedZoom;
        numZooms = 1;
    }
    emitSweepShots(
        g_loadPrefabShots,
        g_loadPrefabShotLabels,
        numZooms,
        [&](auto &label, int i) {
            std::snprintf(label.data(), label.size(), "prefab_%s_z%d", stem.c_str(), zooms[i]);
        },
        [&](int i) {
            IRVideo::AutoScreenshotShot shot{};
            shot.zoom_ = static_cast<float>(zooms[i]);
            shot.cameraIso_ = vec2(0.0f, 0.0f);
            return shot;
        }
    );
}

void initLoadPrefabScene() {
    IR_ASSERT(g_prefabLua != nullptr, "--load-prefab: the World's Lua state was never bound");
    IRPrefab::Prefab::registerPrefab("load_prefab", g_loadPrefabPath);
    const IRPrefab::Prefab::SpawnResult spawned =
        IRPrefab::Prefab::spawnPrefab(*g_prefabLua, "load_prefab", vec3(0.0f));
    if (spawned.entity_ == IREntity::kNullEntity) {
        IR_LOG_ERROR("--load-prefab: '{}' failed to spawn: {}", g_loadPrefabPath, spawned.error_);
        std::exit(EXIT_FAILURE);
    }
    IR_LOG_INFO("--load-prefab: spawned '{}' -> entity {}", g_loadPrefabPath, spawned.entity_);
}

void initCullEvictScene() {
    const EntityId canvas = IRRender::getActiveCanvasEntity();
    g_cullEvict.canvasEntity_ = canvas;
    const EntityId entity = IREntity::createEntity(
        C_LocalTransform{vec3(0.0f, 0.0f, 0.0f)},
        C_VoxelSetNew{kCullEvictSize, kCullEvictColor, IRComponents::EntityAnchor::CENTER, canvas}
    );
    g_cullEvict.setEntity_ = entity;
    const C_VoxelSetNew &voxelSet = IREntity::getComponent<C_VoxelSetNew>(entity);
    IR_LOG_INFO(
        "--- #2830 cull-eviction fixture: {} voxels at pool slot {} ({} chunks) ---",
        voxelSet.numVoxels_,
        voxelSet.voxelStartIdx_,
        voxelSet.numVoxels_ / IRRender::kVoxelChunkSize
    );
    // The span must start chunk-aligned, or "one z-layer == one chunk" — the
    // premise both pose predicates read — quietly stops holding.
    IR_ASSERT(
        voxelSet.voxelStartIdx_ % IRRender::kVoxelChunkSize == 0,
        "cull-evict fixture expects a chunk-aligned span, got startIdx={}",
        voxelSet.voxelStartIdx_
    );
    applyCullEvictPose(0);
}

void onHelpOverlayAssertFrame(int shotIndex, bool isCaptureFrame) {
    onHoverParityAssertFrame(shotIndex);
    onDragPanAssertFrame(shotIndex);
    // Every live frame from the first menu shot on: the panel centers itself and
    // a dropdown's item strip exists only while expanded, so the targets have to
    // be resolved continuously rather than once at first open.
    if (shotIndex >= kMenuOpenShotIndex) {
        fillClickTargets();
    }
    const ShotAssertions &shot = kShotAssertions[shotIndex];
    g_screenProbe.wanted_ = shot.readsScreen_;
    IRPrefab::GuiTest::onFrame(
        g_helpOverlayLatch,
        shotIndex,
        isCaptureFrame,
        kHelpOverlayGuiShots[shotIndex].render_.label_,
        shot.assertions_,
        shot.count_
    );
    if (shotIndex == kMenuQuitShotIndex && !g_quitAssertionsEmitted &&
        IRWindow::isCloseRequested()) {
        IRPrefab::GuiTest::evaluate(
            g_helpOverlayLatch,
            shotIndex,
            kHelpOverlayGuiShots[shotIndex].render_.label_,
            shot.assertions_,
            shot.count_
        );
        g_quitAssertionsEmitted = true;
    }
}

void onContinuousZoomGuiAssertFrame(int shotIndex, bool isCaptureFrame) {
    onHoverParityAssertFrame(shotIndex);
    onDragPanAssertFrame(shotIndex);
    if (shotIndex == kContinuousOffCentreShotIndex) {
        // Re-aimed every live frame through the picking chain's own inverse:
        // the cursor lands on the voxel only if that inverse and the composite
        // agree on where a point this far from the centre is drawn.
        g_continuousOffCentre.events_[0].screenPx_ = IRRender::worldPos3DToMouseScreenPx(
            kHoverParityVoxelWorld + vec3(0.0f, 0.0f, kHoverParityBelowDiagonalZ)
        );
    }
    const ShotAssertions &shot = kContinuousZoomShotAssertions[shotIndex];
    IRPrefab::GuiTest::onFrame(
        g_continuousZoomLatch,
        shotIndex,
        isCaptureFrame,
        kContinuousZoomGuiShots[shotIndex].render_.label_,
        shot.assertions_,
        shot.count_
    );
}

} // namespace

void initSystems() {
    std::list<IRSystem::SystemId> updatePipeline{
        IRSystem::createSystem<IRSystem::LOD_UPDATE>(),
        IRSystem::createSystem<IRSystem::GATE_VOXEL_SETS_BY_LOD>(),
        IRSystem::createSystem<IRSystem::PROPAGATE_TRANSFORM>(),
        IRSystem::createSystem<IRSystem::UPDATE_VOXEL_SET_CHILDREN>(),
        IRSystem::createSystem<IRSystem::REBUILD_GRID_VOXELS>(),
        IRSystem::createSystem<IRSystem::REBUILD_GRID_VOXELS_IMPLICIT>()
    };
    if (!g_loadPrefabPath.empty() || g_lodScene) {
        // After LOD_UPDATE, so the parts follow this tick's tier, and before
        // PROPAGATE_TRANSFORM, so a part spawned this tick is placed this tick
        // and a part's spin reaches its world transform the tick it turns.
        const auto propagate = std::next(updatePipeline.begin(), 2);
        updatePipeline.insert(propagate, IRSystem::createSystem<IRSystem::PREFAB_LOD_PARTS>());
        updatePipeline.insert(
            propagate,
            IRSystem::createSystem<IRSystem::AUTO_SPIN_LOCAL_TRANSFORM>()
        );
    }
    // --load-vxs animation playback: swap the next frame's voxels
    // into the loaded set on a fixed tick cadence derived from the asset's own
    // FPS. Registered whenever a set was requested for playback — the entity
    // does not exist yet (initEntities runs after this), so the frame count is
    // not knowable here; the tick no-ops for a single-frame asset.
    //
    // Pushed to the FRONT: the swap has to land before UPDATE_VOXEL_SET_CHILDREN
    // and the grid rebuilds run, so everything downstream sees one pose for the
    // whole tick. Appended at the end instead, the frame that swaps renders the
    // arriving colours against the departing pose's uploaded state and captures
    // as a blend of the two.
    //
    // The swap targets one known entity, so it runs in beginTick rather than a
    // per-entity tick (.claude/rules/cpp-ecs.md, alternative 3). C_VoxelSetNew
    // is the archetype filter only because the system needs SOME filter; the
    // per-entity function is deliberately empty.
    if (!g_loadVxsPath.empty() && g_vxsFrame < 0) {
        updatePipeline.push_front(
            IRSystem::createSystem<IRComponents::C_VoxelSetNew>(
                "ShapeDebugVxsPlayback",
                [](const IRComponents::C_VoxelSetNew &) {},
                []() { tickVxsPlayback(); }
            )
        );
    }
    IRSystem::registerPipeline(IRTime::Events::UPDATE, updatePipeline);
    // Settings menu rides the INPUT pipeline: its widget chain needs
    // the cursor state INPUT_KEY_MOUSE publishes, and polling the widgets in
    // INPUT means a toggle applies before the same frame renders.
    std::list<IRSystem::SystemId> inputPipeline{
        IRSystem::createSystem<IRSystem::INPUT_KEY_MOUSE>()
    };
    inputPipeline.splice(inputPipeline.end(), IRPrefab::SettingsMenu::inputSystems());
    IRSystem::registerPipeline(IRTime::Events::INPUT, inputPipeline);

    std::list<IRSystem::SystemId> renderPipeline = IRPrefab::Camera::standardControlSystems();
    // --spin-yaw live mode: drive the camera each frame. In auto-screenshot
    // mode the per-shot setYaw() supplies the rotation instead — running both
    // would double-rotate between shots and break the "evenly-spaced" contract.
    if (g_spinYawDegPerSec > 0.0f &&
        g_autoWarmupFrames == 0) { // == 0: no auto-screenshot requested
        const float radPerFrame =
            g_spinYawDegPerSec * IRMath::kPi / 180.0f / static_cast<float>(IRConstants::kFPS);
        renderPipeline.push_front(IRSystem::createSystem<IRSystem::AUTO_YAW_ROTATE>(radPerFrame));
        IR_LOG_INFO(
            "Spin-yaw live: {} deg/sec ({} rad/frame at {} fps)",
            g_spinYawDegPerSec,
            radPerFrame,
            IRConstants::kFPS
        );
    }
    // GPU voxel-position prepass — writes binding 5 for
    // GPU-transform-indirected voxel sets before STAGE_1 reads it. A no-op (no
    // dispatch) unless a voxel set opts in via gpuTransformSlot_, so the default
    // scene stays byte-identical. Created up-front so its SystemId can order the
    // render pipeline below (before STAGE_1).
    const IRSystem::SystemId updateVoxelPositionsId =
        IRSystem::createSystem<IRSystem::UPDATE_VOXEL_POSITIONS_GPU>();
    // Joint skin-matrix upload + per-voxel bone→slot seeding.
    // Before UPDATE_VOXEL_POSITIONS_GPU so binding 18 holds the skin matrices
    // when the prepass dispatches; a no-op (zero skeletons) unless --skin-smoke
    // rigs a set, so the default scene stays byte-identical.
    const IRSystem::SystemId updateJointMatricesId =
        IRSystem::createSystem<IRSystem::UPDATE_JOINT_MATRICES>();
    // Captured for the culling minimap's light + caster domains —
    // the minimap reads these systems' per-frame gather state back rather
    // than re-running its own light/caster query. Assigned in-place inside
    // the initializer list below (NOT hoisted out as their own create()
    // calls) — a braced-init-list evaluates left-to-right, and
    // BAKE_SUN_SHADOW_MAP::create() depends on a named resource
    // RESOLVE_PER_AXIS_SCREEN_DEPTH::create() creates earlier in this same
    // list; calling create() early breaks that ordering.
    IRSystem::SystemId bakeSunShadowMapId = IRSystem::kNullSystemId;
    IRSystem::SystemId computeLightVolumeId = IRSystem::kNullSystemId;
    IRSystem::SystemId trixelToFramebufferId = IRSystem::kNullSystemId;
    renderPipeline.insert(
        renderPipeline.end(),
        {
            IRSystem::createSystem<IRSystem::RENDERING_VELOCITY_2D_ISO>(),
            IRSystem::createSystem<IRSystem::BUILD_LIGHT_OCCLUSION_GRID>(),
            updateJointMatricesId,
            updateVoxelPositionsId,
            IRSystem::createSystem<IRSystem::VOXEL_TO_TRIXEL_STAGE_1>(),
            IRSystem::createSystem<IRSystem::SHAPES_TO_TRIXEL>(),
            IRSystem::createSystem<IRSystem::COMPUTE_VOXEL_AO>(),
            // Hi-Z max-depth mip chain over the (now final) distance texture,
            // for next frame's voxel occlusion cull. Produces
            // only — renders unchanged.
            IRSystem::createSystem<IRSystem::COMPUTE_DISTANCE_HIZ>(),
            IRSystem::createSystem<IRSystem::RESOLVE_PER_AXIS_SCREEN_DEPTH>(),
            (bakeSunShadowMapId = IRSystem::createSystem<IRSystem::BAKE_SUN_SHADOW_MAP>()),
            IRSystem::createSystem<IRSystem::COMPUTE_SUN_SHADOW>(),
            (computeLightVolumeId = IRSystem::createSystem<IRSystem::COMPUTE_LIGHT_VOLUME>()),
            IRSystem::createSystem<IRSystem::LIGHTING_TO_TRIXEL>(),
        }
    );
    // Registry-driven command help overlay, F1. TEXT_TO_TRIXEL first —
    // shape_debug had no GUI text before, and the overlay needs its GUI-canvas
    // clear plus the shared text GPU resources. Both land before
    // TRIXEL_TO_FRAMEBUFFER composites the gui canvas. The overlay is hidden by
    // default and an empty gui canvas composites to nothing, so `--auto-screenshot`
    // captures stay byte-identical.
    renderPipeline.push_back(IRSystem::createSystem<IRSystem::TEXT_TO_TRIXEL>());
    renderPipeline.splice(renderPipeline.end(), IRPrefab::HelpOverlay::systems());
    // Settings-menu widgets draw on the same GUI canvas, after the
    // overlay so an open menu paints over it. Both are default-off and own no
    // entities until opened, so captures stay byte-identical.
    renderPipeline.splice(renderPipeline.end(), IRPrefab::SettingsMenu::renderSystems());
    renderPipeline.insert(
        renderPipeline.end(),
        {
            (trixelToFramebufferId = IRSystem::createSystem<IRSystem::TRIXEL_TO_FRAMEBUFFER>()),
            IRSystem::System<IRSystem::DEBUG_CULLING_MINIMAP>::create({
                .lightVolumeSystemId_ = computeLightVolumeId,
                .bakeSunShadowSystemId_ = bakeSunShadowMapId,
            }),
            // The minimap draws through the IRDebug queue; DEBUG_OVERLAY flushes and clears it.
            IRSystem::createSystem<IRSystem::DEBUG_OVERLAY>(),
            IRSystem::createSystem<IRSystem::FRAMEBUFFER_TO_SCREEN>(),
            IRSystem::createSystem<IRSystem::SPRITE_TO_SCREEN>(),
            IRSystem::createSystem<IRSystem::GUI_CANVAS_TO_SCREEN>(),
        }
    );
    if (g_viewportPortrait) {
        // The sync feeds the viewport's pool before the voxel raster reads it;
        // the composite lands on top of the world + GUI composite.
        renderPipeline.insert(
            std::find(
                renderPipeline.begin(),
                renderPipeline.end(),
                IRSystem::findSystem(IRSystem::VOXEL_TO_TRIXEL_STAGE_1)
            ),
            IRSystem::createSystem<IRSystem::SYNC_VIEWPORT_SUBJECTS>()
        );
        renderPipeline.insert(
            std::next(
                std::find(renderPipeline.begin(), renderPipeline.end(), trixelToFramebufferId)
            ),
            IRSystem::createSystem<IRSystem::VIEWPORT_TO_FRAMEBUFFER>()
        );
    }
    // Off during --auto-screenshot / --auto-record captures — the minimap is
    // a live debug aid, not part of the render-verify golden image or a
    // reviewer clip. Interactive / --auto-profile runs default it visible;
    // F11 (initCommands below) toggles it either way.
    IRRender::setCullingMinimapEnabled(g_autoWarmupFrames == 0 && g_autoRecordFrames == 0);

    if (g_autoProfileFrames > 0) {
        IRSystem::SystemId autoProfileId = IRSystem::createSystem<C_VoxelSetNew>(
            "AutoProfile",
            [](C_VoxelSetNew &) {},
            []() {
                ++g_autoProfileCount;
                if (g_autoProfileCount >= g_autoProfileFrames) {
                    IR_LOG_INFO("Auto-profile: {} frames collected, exiting", g_autoProfileFrames);
                    IRWindow::closeWindow();
                }
            }
        );
        renderPipeline.push_back(autoProfileId);
    }

    if (g_autoWarmupFrames > 0 && g_cullEvictTest) {
        IRVideo::GuiTestConfig cfg{};
        cfg.warmupFrames_ = g_autoWarmupFrames;
        // The pose swap lands on a shot's first live frame; the settle window
        // has to be long enough for STAGE_1 to re-derive the bounds and
        // rasterize from them before the capture frame.
        cfg.settleFrames_ = 4;
        cfg.shots_ = kCullEvictShots;
        cfg.numShots_ = kNumCullEvictShots;
        cfg.onAssertFrame_ = &onCullEvictAssertFrame;
        renderPipeline.push_back(IRVideo::createGuiTestSystem(cfg));
    } else if (g_autoWarmupFrames > 0 && g_guiTest) {
        IRVideo::GuiTestConfig cfg{};
        cfg.warmupFrames_ = g_autoWarmupFrames;
        cfg.settleFrames_ = 3;
        cfg.shots_ = kHelpOverlayGuiShots;
        cfg.numShots_ = kNumHelpOverlayGuiShots;
        cfg.onAssertFrame_ = &onHelpOverlayAssertFrame;
        // Ahead of the composite, not at the tail: TRIXEL_TO_FRAMEBUFFER's
        // beginTick resets HoveredEntityIdBuffer for the frame it is about to
        // draw, so a HOVERED_ENTITY_ID read after it sees the reset, never the
        // completed previous frame. Every widget renderer has already run at
        // this point, so the click targets the hook resolves are current.
        renderPipeline.insert(
            std::find(renderPipeline.begin(), renderPipeline.end(), trixelToFramebufferId),
            IRVideo::createGuiTestSystem(cfg)
        );
        // At the tail, past every pass that draws to the screen target.
        renderPipeline.push_back(
            IRSystem::createSystem<C_VoxelSetNew>(
                "GuiTestScreenProbe",
                [](C_VoxelSetNew &) {},
                []() { readScreenProbe(); }
            )
        );
    } else if (g_autoWarmupFrames > 0 && g_continuousZoomGuiTest) {
        IRVideo::GuiTestConfig cfg{};
        cfg.warmupFrames_ = g_autoWarmupFrames;
        cfg.settleFrames_ = 3;
        cfg.shots_ = kContinuousZoomGuiShots;
        cfg.numShots_ = kNumContinuousZoomGuiShots;
        cfg.onAssertFrame_ = &onContinuousZoomGuiAssertFrame;
        // Ahead of the composite for the same reason as --gui-test: the hover
        // readback has to be taken before TRIXEL_TO_FRAMEBUFFER resets it.
        renderPipeline.insert(
            std::find(renderPipeline.begin(), renderPipeline.end(), trixelToFramebufferId),
            IRVideo::createGuiTestSystem(cfg)
        );
    } else if (g_autoWarmupFrames > 0) {
        IRVideo::AutoScreenshotConfig cfg{};
        cfg.warmupFrames_ = g_autoWarmupFrames;
        cfg.settleFrames_ = 3;
        if (g_zoomCalibration || g_shapeSampleProbe) {
            cfg.onCaptureFrame_ = &onShapeDebugCaptureFrame;
        }
        // Set by the one block that needs scripted cursor input + a per-frame
        // hook (--pivot-verify cursor-latch); every other sweep stays on the
        // plain auto-screenshot cycler.
        bool useGuiTestCycler = false;
        if (g_cullValidate) {
            // Frozen-cull free-fly validation harness. Two phases over
            // the SAME pose list: (1) live cull, (2) cull frozen at a wide
            // reference. A wide freeze reference (zoom 1 at origin) has an iso
            // cull viewport that is a superset of every sweep pose, so a frozen
            // frame is the "cull-effectively-disabled" ground truth — every
            // voxel geometrically on-screen at that pose is drawn. Pairwise-
            // diffing the on-screen region of cv_live_NNN against cv_frozen_NNN
            // proves the live cull never drops on-screen content. Capture order
            // makes screenshot_i (live i) pair with screenshot_(i + n + 1)
            // (frozen i); the freeze-ref shot sits between the two phases.
            const float sweepZoom = g_initialZoom > 0.0f ? g_initialZoom : 4.0f;
            constexpr int kYawSteps = 8;
            const vec2 kPanOffsets[] = {vec2(12, 0), vec2(-12, 0), vec2(0, 12), vec2(0, -12)};
            constexpr int kNumPans = sizeof(kPanOffsets) / sizeof(kPanOffsets[0]);
            const int posesPerPhase = kYawSteps + kNumPans;
            // live poses + freeze-ref + frozen poses + unfreeze
            const int totalShots = posesPerPhase * 2 + 2;
            g_cullValidateShotLabels.reserve(totalShots);
            g_cullValidateShots.reserve(totalShots);

            const auto emitShot = [&](float zoom,
                                      vec2 cam,
                                      float yaw,
                                      const char *fmt,
                                      int idx,
                                      IRVideo::CullAction action) {
                auto &label = g_cullValidateShotLabels.emplace_back();
                std::snprintf(label.data(), label.size(), fmt, idx);
                IRVideo::AutoScreenshotShot shot{};
                shot.zoom_ = zoom;
                shot.cameraIso_ = cam;
                shot.yawRadians_ = yaw;
                shot.label_ = label.data();
                shot.cullAction_ = action;
                g_cullValidateShots.push_back(shot);
            };

            // The pose list: a full yaw rotation at the focus, then a pan sweep
            // at a non-cardinal yaw (residual != 0 → per-axis composite active)
            // so camera *movement* under rotation is exercised, not just
            // rotation in place.
            const auto emitPhase = [&](const char *fmt) {
                for (int i = 0; i < kYawSteps; ++i) {
                    const float yaw =
                        (static_cast<float>(i) / static_cast<float>(kYawSteps)) * IRMath::kTwoPi;
                    emitShot(sweepZoom, vec2(0, 0), yaw, fmt, i, IRVideo::CullAction::NONE);
                }
                for (int i = 0; i < kNumPans; ++i) {
                    emitShot(
                        sweepZoom,
                        kPanOffsets[i],
                        IRMath::kQuarterPi,
                        fmt,
                        kYawSteps + i,
                        IRVideo::CullAction::NONE
                    );
                }
            };

            emitPhase("cv_live_%03d");
            // Freeze the cull at the wide reference between the two phases.
            emitShot(1.0f, vec2(0, 0), 0.0f, "cv_freeze_ref_%03d", 0, IRVideo::CullAction::FREEZE);
            emitPhase("cv_frozen_%03d");
            // Release the freeze so the harness leaves global state clean.
            emitShot(
                sweepZoom,
                vec2(0, 0),
                0.0f,
                "cv_unfreeze_%03d",
                0,
                IRVideo::CullAction::UNFREEZE
            );

            cfg.shots_ = g_cullValidateShots.data();
            cfg.numShots_ = static_cast<int>(g_cullValidateShots.size());
            cfg.onCaptureFrame_ = &logCullValidateState;
            IR_LOG_INFO(
                "Cull-validate sweep: {} poses/phase, {} total shots (live + frozen) at zoom={}",
                posesPerPhase,
                cfg.numShots_,
                sweepZoom
            );
        } else if (g_spinYawDegPerSec > 0.0f) {
            // Sweep one full rotation at camera=(0,0). Default zoom=4 matches
            // the rotation-coverage shots for scene-scale smoothness;
            // pass --zoom to sweep at high zoom (e.g. 16), where rotation-only
            // parity glitches (black faces, checkerboard) are
            // visible at full pixel scale. The regression set baselines both.
            const float sweepZoom = g_initialZoom > 0.0f ? g_initialZoom : 4.0f;
            const int n = IRMath::max(2, g_spinYawShotCount);
            // In --spin-shape mode the single shape is screen-centred under
            // yaw-about-origin, so attach a centred ROI crop sized to half the
            // shorter framebuffer edge: the jitter sweep then scores small
            // per-frame PNGs instead of the full retina framebuffer.
            const bool useSpinShapeCrop = !g_spinShapeType.empty();
            if (useSpinShapeCrop) {
                ivec2 fb{0, 0};
                IRWindow::getFramebufferSize(fb);
                const int side = IRMath::max(64, IRMath::min(fb.x, fb.y) / 2);
                g_spinShapeCrop = {(fb.x - side) / 2, (fb.y - side) / 2, side, side, "center"};
            }
            emitSweepShots(
                g_spinYawShots,
                g_spinYawShotLabels,
                n,
                [n](auto &label, int i) {
                    std::snprintf(label.data(), label.size(), "spin_yaw_%03d_of_%03d", i, n);
                },
                [&](int i) {
                    const float yaw =
                        (static_cast<float>(i) / static_cast<float>(n)) * IRMath::kTwoPi;
                    IRVideo::AutoScreenshotShot shot{sweepZoom, vec2(0, 0), yaw};
                    if (useSpinShapeCrop) {
                        shot.crops_ = &g_spinShapeCrop;
                        shot.numCrops_ = 1;
                    }
                    return shot;
                }
            );
            cfg.shots_ = g_spinYawShots.data();
            cfg.numShots_ = static_cast<int>(g_spinYawShots.size());
            if (IREngine::args().getFlag("--spin-shape-floor")) {
                cfg.onCaptureFrame_ = [](int shotIndex) {
                    const vec2 step = IRRender::getTriangleStepSizeScreen();
                    const ivec2 viewport = IRRender::getViewport();
                    const vec2 camera = IRRender::getEffectiveCameraIso();
                    IR_LOG_INFO(
                        "SHADOW-FOOTPRINT shot={} subdivisions={} step={},{} viewport={},{} "
                        "camera={},{}",
                        shotIndex,
                        IRRender::getVoxelRenderEffectiveSubdivisions(),
                        step.x,
                        step.y,
                        viewport.x,
                        viewport.y,
                        camera.x,
                        camera.y
                    );
                };
            }
            IR_LOG_INFO(
                "Spin-yaw sweep: {} shots across one rotation at zoom={}",
                cfg.numShots_,
                sweepZoom
            );
        } else if (g_pivotFocusDemo) {
            // Pin the camera Z-yaw pivot on the tall pillar's true-depth center
            // across a yaw sweep. centerPan brings the pillar to screen
            // center at yaw 0; with the focus set it stays there for EVERY yaw —
            // the pillar rotates in place while the default scene sweeps around
            // it. Run the same flag with --pivot-origin for the A/B: the
            // z=0 screen-center pivot swings the pillar out in an arc.
            const float sweepZoom = g_initialZoom > 0.0f ? g_initialZoom : 4.0f;
            // Pan so the pillar lands at screen center at yaw 0: the producers
            // place content at screen `iso(W) + cameraIso`, so centering the
            // pillar (`screen == 0`) needs `cameraIso == -iso(pillarCenter)`.
            const vec2 centerPan = -IRMath::pos3DtoPos2DIso(kPivotPillarCenter);
            const float yaws[] =
                {0.0f, IRMath::kHalfPi, IRMath::kPi, 3.0f * IRMath::kHalfPi, IRMath::kQuarterPi};
            constexpr int n = sizeof(yaws) / sizeof(yaws[0]);
            emitSweepShots(
                g_pivotFocusShots,
                g_pivotFocusShotLabels,
                n,
                [](auto &label, int i) {
                    std::snprintf(label.data(), label.size(), "pivot_focus_yaw_%03d", i);
                },
                [&](int i) {
                    IRVideo::AutoScreenshotShot shot{};
                    shot.zoom_ = sweepZoom;
                    shot.cameraIso_ = centerPan;
                    shot.yawRadians_ = yaws[i];
                    shot.crops_ = kCropsPivotPillar;
                    shot.numCrops_ = sizeof(kCropsPivotPillar) / sizeof(kCropsPivotPillar[0]);
                    shot.pivotFocusWorld_ = kPivotPillarCenter;
                    shot.hasPivotFocus_ = true;
                    return shot;
                }
            );
            cfg.shots_ = g_pivotFocusShots.data();
            cfg.numShots_ = static_cast<int>(g_pivotFocusShots.size());
            IR_LOG_INFO(
                "Pivot-focus demo: {} yaw shots pinned on pillar ({}, {}, {}) at zoom={}",
                cfg.numShots_,
                kPivotPillarCenter.x,
                kPivotPillarCenter.y,
                kPivotPillarCenter.z,
                sweepZoom
            );
        } else if (g_pivotVerifyBlock != "off") {
            // Pivot-invariance sweep (see the block comment on
            // g_pivotVerifyBlock). One probe, fixed pan, yaw stepped through
            // cardinals AND non-cardinals — both the cardinal gather and the
            // per-axis residual path must hold the pin.
            const float sweepZoom = g_initialZoom > 0.0f ? g_initialZoom : 4.0f;
            const bool explicitFocus =
                g_pivotVerifyBlock == "focus-ctr" || g_pivotVerifyBlock == "focus-off";
            vec2 pan;
            if (explicitFocus) {
                pan = -IRMath::pos3DtoPos2DIso(kPivotPillarCenter);
                if (g_pivotVerifyBlock == "focus-off") {
                    pan += kPivotVerifyOffCenterIso;
                }
            } else {
                pan = pivotVerifyDefaultPan();
            }
            const float sweepYaws[] = {
                0.0f,
                IRMath::kPi / 6.0f,
                IRMath::kQuarterPi,
                IRMath::kHalfPi,
                2.0f * IRMath::kPi / 3.0f,
                IRMath::kPi,
                IRMath::kPi + IRMath::kQuarterPi,
                3.0f * IRMath::kHalfPi,
                IRMath::kTwoPi - IRMath::kQuarterPi
            };
            // acquire-continuity: settle on background at the base yaw, pan the
            // probe under the crosshair, then two gesture steps.
            const float baseYaw = pivotVerifyBaseYaw();
            const float acquireYaws[] = {
                baseYaw,
                baseYaw,
                baseYaw + kPivotVerifyAcquireYawStep,
                baseYaw + 2.0f * kPivotVerifyAcquireYawStep
            };
            const vec2 acquirePans[] = {pan + kPivotVerifyAcquireBackgroundIso, pan, pan, pan};
            const bool acquireBlock = g_pivotVerifyBlock == "acquire-continuity";
            const float *yaws = acquireBlock ? acquireYaws : sweepYaws;
            const int n = acquireBlock ? static_cast<int>(std::size(acquireYaws))
                                       : static_cast<int>(std::size(sweepYaws));
            emitSweepShots(
                g_pivotVerifyShots,
                g_pivotVerifyShotLabels,
                n,
                [](auto &label, int i) {
                    std::snprintf(
                        label.data(),
                        label.size(),
                        "pv_%s_yaw_%03d",
                        g_pivotVerifyBlock.c_str(),
                        i
                    );
                },
                [&](int i) {
                    IRVideo::AutoScreenshotShot shot{};
                    shot.zoom_ = sweepZoom;
                    shot.cameraIso_ = acquireBlock ? acquirePans[i] : pan;
                    shot.yawRadians_ = yaws[i];
                    if (explicitFocus) {
                        shot.pivotFocusWorld_ = kPivotPillarCenter;
                        shot.hasPivotFocus_ = true;
                    }
                    return shot;
                }
            );
            cfg.shots_ = g_pivotVerifyShots.data();
            cfg.numShots_ = static_cast<int>(g_pivotVerifyShots.size());
            cfg.onCaptureFrame_ = &logPivotFocusAssert;
            // cursor-latch drives the SAME poses through the GUI-test cycler so
            // it gets synthetic cursor input and a per-frame hook (see the
            // block comment on g_pivotVerifyBlock). Its shots carry no scripted
            // input table — cursorLatchOnFrame injects the cursor itself, from
            // live camera terms it can only read at runtime.
            useGuiTestCycler = g_pivotVerifyBlock == "cursor-latch";
            if (useGuiTestCycler) {
                g_cursorLatchShots.reserve(g_pivotVerifyShots.size());
                for (const IRVideo::AutoScreenshotShot &shot : g_pivotVerifyShots) {
                    g_cursorLatchShots.push_back(IRVideo::GuiTestShot{shot, nullptr, 0});
                }
            }
            const vec3 probeCenter = pivotVerifyProbeCenter();
            IR_LOG_INFO(
                "Pivot-verify block '{}': {} yaw shots, pan ({},{}), probe ({},{},{}) at zoom={}",
                g_pivotVerifyBlock,
                cfg.numShots_,
                pan.x,
                pan.y,
                probeCenter.x,
                probeCenter.y,
                probeCenter.z,
                sweepZoom
            );
        } else if (g_zoomSweep) {
            // Zoom sweep on the calibration cube. Yaw defaults to 0 (the
            // cardinal gather); --yaw moves it onto the per-axis composite.
            const float sweepYaw = g_initialYawSet ? g_initialYaw : 0.0f;
            const int n = g_zoomSweepCount;
            // Half a cell across the sweep: enough for the whole-pixel offset
            // to tick several times while the zoom moves, and short enough that
            // the calibration cube's near edge stays clear of a raster tie in
            // every shot of the 2.50 -> 2.60 sweep the metric grades.
            const vec2 pan = g_panSweep ? vec2(0.5f, 0.0f) : vec2(0.0f);
            emitSweepShots(
                g_zoomSweepShots,
                g_zoomSweepShotLabels,
                n,
                [n](auto &label, int i) {
                    std::snprintf(label.data(), label.size(), "zoom_sweep_%03d_of_%03d", i, n);
                },
                [&](int i) {
                    const float t = static_cast<float>(i) / static_cast<float>(n - 1);
                    IRVideo::AutoScreenshotShot shot{};
                    shot.zoom_ = g_zoomSweepFrom + (g_zoomSweepTo - g_zoomSweepFrom) * t;
                    shot.cameraIso_ = kZoomCalibrationCamera + pan * t;
                    shot.yawRadians_ = sweepYaw;
                    return shot;
                }
            );
            cfg.shots_ = g_zoomSweepShots.data();
            cfg.numShots_ = static_cast<int>(g_zoomSweepShots.size());
            IR_LOG_INFO(
                "Zoom-sweep: {} shots, zoom {}->{} at cameraIso ({},{})->({},{}) yaw={} rad, "
                "policy={}",
                cfg.numShots_,
                g_zoomSweepFrom,
                g_zoomSweepTo,
                kZoomCalibrationCamera.x,
                kZoomCalibrationCamera.y,
                kZoomCalibrationCamera.x + pan.x,
                kZoomCalibrationCamera.y + pan.y,
                sweepYaw,
                g_zoomContinuous ? "continuous" : "snapped"
            );
        } else if (g_panSweep) {
            // Fine pan sweep at a FIXED yaw (jitter diagnosis). Steps the
            // camera iso across 2 trixels in X so the integer game-px part of the
            // anti-vibration decomposition ticks twice; a correct pipeline
            // translates the scene smoothly, a broken one oscillates +/-1px at
            // each tick. yaw defaults to 45 deg (per-axis composite active).
            const float sweepZoom = g_initialZoom > 0.0f ? g_initialZoom : 4.0f;
            const float sweepYaw = g_initialYawSet ? g_initialYaw : IRMath::kQuarterPi;
            const int n = IRMath::max(2, g_autoWarmupFrames > 0 ? g_spinYawShotCount : 24);
            const vec2 base = vec2(16.0f, 16.0f);
            emitSweepShots(
                g_panSweepShots,
                g_panSweepShotLabels,
                n,
                [n](auto &label, int i) {
                    std::snprintf(label.data(), label.size(), "pan_sweep_%03d_of_%03d", i, n);
                },
                [&](int i) {
                    const float t = static_cast<float>(i) / static_cast<float>(n - 1);
                    IRVideo::AutoScreenshotShot shot{};
                    shot.zoom_ = sweepZoom;
                    shot.cameraIso_ = base + vec2(2.0f * t, 0.0f);
                    shot.yawRadians_ = sweepYaw;
                    return shot;
                }
            );
            cfg.shots_ = g_panSweepShots.data();
            cfg.numShots_ = static_cast<int>(g_panSweepShots.size());
            IR_LOG_INFO(
                "Pan-sweep: {} shots, cameraIso ({},{})->({},{}) at yaw={} rad zoom={}",
                cfg.numShots_,
                base.x,
                base.y,
                base.x + 2.0f,
                base.y,
                sweepYaw,
                sweepZoom
            );
        } else if (g_yawSweep) {
            // Fine yaw sweep at FIXED camera position (jitter diagnosis,
            // rotation half). Steps yaw across [0.05, 0.70] rad — inside the first
            // cardinal quadrant (< π/4 ≈ 0.785), so the per-axis visible-face
            // triplet is constant and a vertical cylinder probe's silhouette is
            // Z-yaw-invariant: smooth centroid = pass, oscillation = jitter.
            const float sweepZoom = g_initialZoom > 0.0f ? g_initialZoom : 4.0f;
            const int n = IRMath::max(2, 24);
            constexpr float kYawLo = 0.05f;
            constexpr float kYawHi = 0.70f;
            emitSweepShots(
                g_yawSweepShots,
                g_yawSweepShotLabels,
                n,
                [n](auto &label, int i) {
                    std::snprintf(label.data(), label.size(), "yaw_sweep_%03d_of_%03d", i, n);
                },
                [&](int i) {
                    const float t = static_cast<float>(i) / static_cast<float>(n - 1);
                    IRVideo::AutoScreenshotShot shot{};
                    shot.zoom_ = sweepZoom;
                    shot.cameraIso_ = vec2(0.0f, 0.0f);
                    shot.yawRadians_ = kYawLo + (kYawHi - kYawLo) * t;
                    return shot;
                }
            );
            cfg.shots_ = g_yawSweepShots.data();
            cfg.numShots_ = static_cast<int>(g_yawSweepShots.size());
            IR_LOG_INFO(
                "Yaw-sweep: {} shots, yaw {}->{} rad at cameraIso (0,0) zoom={}",
                cfg.numShots_,
                kYawLo,
                kYawHi,
                sweepZoom
            );
        } else if (g_shadowFootprintProbe) {
            IRVideo::setAutoScreenshotShots(cfg, kShadowFootprintShots);
        } else if (g_movingCaster) {
            IRVideo::setAutoScreenshotShots(cfg, kMovingCasterShots);
            // The capture frame of shot i places the caster for shot i + 1,
            // which then settles before its own capture.
            cfg.onCaptureFrame_ = [](int shotIndex) {
                IREntity::getComponent<C_LocalTransform>(g_movingCasterEntity).translation_ =
                    kMovingCasterStart + kMovingCasterStep * static_cast<float>(shotIndex + 1);
            };
        } else if (g_lodScene) {
            IRVideo::setAutoScreenshotShots(cfg, IRShapeDebug::LodScene::shots_);
            cfg.settleFrames_ = IRConstants::kPrefabPartsTierSettleTicks + 12;
            cfg.onCaptureFrame_ = [](int shotIndex) { g_lodSceneState.capture(shotIndex); };
        } else if (g_lodDenseSwap) {
            IRVideo::setAutoScreenshotShots(cfg, kLodDenseSwapShots);
        } else if (g_viewportLodSwap) {
            IRVideo::setAutoScreenshotShots(cfg, kViewportLodSwapShots);
        } else if (g_viewportPortrait) {
            IRVideo::setAutoScreenshotShots(cfg, kViewportPortraitShots);
        } else if (!g_loadPrefabPath.empty()) {
            buildLoadPrefabShots();
            cfg.shots_ = g_loadPrefabShots.data();
            cfg.numShots_ = static_cast<int>(g_loadPrefabShots.size());
            // A shot's zoom changes the tier on its first frame; the parts
            // follow once the tier has settled and their spawns flushed.
            cfg.settleFrames_ = IRConstants::kPrefabPartsTierSettleTicks + 3;
        } else {
            IRVideo::setAutoScreenshotShots(cfg, kShots);
        }
        if (pivotVerifyIsDefaultBlock()) {
            // Ahead of the shot cycler, so each frame is read before a new
            // shot's pose lands. C_VoxelSetNew is the archetype filter only
            // because the system needs SOME filter; beginTick runs regardless.
            renderPipeline.push_back(
                IRSystem::createSystem<C_VoxelSetNew>(
                    "ShapeDebugPivotFocusTrack",
                    [](const C_VoxelSetNew &) {},
                    []() { trackPivotFocusFrame(); }
                )
            );
        }
        if (useGuiTestCycler) {
            IRVideo::GuiTestConfig guiCfg{};
            guiCfg.warmupFrames_ = cfg.warmupFrames_;
            guiCfg.settleFrames_ = cfg.settleFrames_;
            guiCfg.shots_ = g_cursorLatchShots.data();
            guiCfg.numShots_ = static_cast<int>(g_cursorLatchShots.size());
            guiCfg.onAssertFrame_ = &cursorLatchOnFrame;
            renderPipeline.push_back(IRVideo::createGuiTestSystem(guiCfg));
        } else {
            renderPipeline.push_back(IRVideo::createAutoScreenshotSystem(cfg));
        }
    }
    IRVideo::appendAutoRecordIfRequested(renderPipeline, g_autoRecordFrames);

    IRSystem::registerPipeline(IRTime::Events::RENDER, renderPipeline);
}

void initCommands() {
    // Escape opens the settings menu instead of quitting; the menu's
    // QUIT button is the replacement exit, so quitting is two inputs away
    // rather than one. Omitting the one row leaves every other camera binding
    // unchanged.
    IRPrefab::Camera::registerStandardKeyboardCommands({.omit_ = {IRCommand::CLOSE_WINDOW}});
    IRCommand::registerCaptureCommands();
    // Interactive cull-freeze toggle: freeze the cull viewport at the
    // current camera pose, then free-fly (WASD pan / mouse drag / scroll zoom,
    // all from standardControlSystems) to see exactly what the frozen cull
    // retains as the camera moves. F10 matches the other demos' binding.
    IRCommand::createCommand<IRCommand::TOGGLE_CULLING_FREEZE>(
        IRInput::KEY_MOUSE,
        IRInput::PRESSED,
        IRInput::kKeyButtonF10
    );
    // Culling-minimap visibility toggle. F11 sits next to F10's
    // freeze toggle — the two are commonly used together (freeze, then
    // inspect the minimap's light/caster domains while free-flying).
    IRCommand::createCommand<IRCommand::TOGGLE_CULLING_MINIMAP>(
        IRInput::KEY_MOUSE,
        IRInput::PRESSED,
        IRInput::kKeyButtonF11
    );
    // F1 lists every command registered above — including the camera bundle
    // and the two culling toggles — with its description.
    IRPrefab::HelpOverlay::registerToggleCommand();
    // Escape opens the settings menu built from registerDemoSettings().
    IRPrefab::SettingsMenu::registerToggleCommand();
    // Rotation-pivot mode cycle: swap which Ctrl+middle-drag chord
    // latches the clicked surface point, so the screen-center default and the
    // cursor latch can be compared live under the SAME gesture instead of
    // across a restart. F9 sits with the other F-key demo toggles.
    IRCommand::createCommand(IRInput::KEY_MOUSE, IRInput::PRESSED, IRInput::kKeyButtonF9, []() {
        const bool cursorLatched = !IRPrefab::Camera::cursorPivotByDefault();
        IRPrefab::Camera::setCursorPivotByDefault(cursorLatched);
        IR_LOG_INFO(
            "[rotation-pivot] Ctrl+middle-drag now rotates about {}; "
            "Ctrl+Shift+middle-drag takes the other.",
            cursorLatched ? "the CURSOR-latched surface point" : "the SCREEN-CENTER default focus"
        );
    });
}

// ---------------------------------------------------------------------------
// Live-togglable demo settings
// ---------------------------------------------------------------------------

// Re-apply the debug tint to every live SDF shape. `--depth-color` and
// `--checkerboard` bake their flag into `C_ShapeDescriptor` at creation; the
// flags are read by the shader every frame, so rewriting them here flips the
// tint live with no entity churn.
//
// Voxel-pool shapes (`--spin-shape-voxel`) are NOT re-tinted: their tint is
// baked into per-voxel colors by `applyCheckerboard` / `applyDepthColor`, and
// reverting needs each set's pre-tint base color, which the demo does not
// retain. The default scene is SDF, which is what these two settings drive.
void applyTintFlags() {
    IREntity::forEachComponent<C_ShapeDescriptor>([](EntityId &, C_ShapeDescriptor &desc) {
        desc.flags_ &= ~(IRRender::SHAPE_FLAG_DEPTH_COLOR | IRRender::SHAPE_FLAG_CHECKERBOARD);
        if (g_depthColor) {
            desc.flags_ |= IRRender::SHAPE_FLAG_DEPTH_COLOR;
        } else if (g_checkerboard) {
            desc.flags_ |= IRRender::SHAPE_FLAG_CHECKERBOARD;
        }
    });
}

void registerDemoSettings() {
    IRPrefab::Settings::registerEnum(
        "ROTATION PIVOT",
        {"ORIGIN", "CAMERA CENTER"},
        [] { return static_cast<int>(IRRender::getRotationPivotMode()); },
        [](int mode) {
            IRRender::setRotationPivotMode(static_cast<IRRender::RotationPivotMode>(mode));
        }
    );
    // Labels are indexed by DebugOverlayMode, so the order here is the enum's
    // order, not a display preference.
    IRPrefab::Settings::registerEnum(
        "DEBUG OVERLAY",
        {"NONE",
         "AO",
         "LIGHT LEVEL",
         "SHADOW",
         "PER AXIS ID",
         "PER AXIS ORIGIN",
         "UNLIT",
         "PER AXIS MARGIN"},
        [] { return static_cast<int>(IRRender::getDebugOverlay()); },
        [](int mode) { IRRender::setDebugOverlay(static_cast<IRRender::DebugOverlayMode>(mode)); }
    );
    // Depth-color and checkerboard are mutually exclusive on the CLI path
    // (if/else); the setters keep that invariant rather than letting the menu
    // reach a combination the flag path cannot express.
    IRPrefab::Settings::registerBool(
        "DEPTH COLOR",
        [] { return g_depthColor; },
        [](bool on) {
            g_depthColor = on;
            if (on) {
                g_checkerboard = false;
            }
            applyTintFlags();
        }
    );
    IRPrefab::Settings::registerBool(
        "CHECKERBOARD",
        [] { return g_checkerboard; },
        [](bool on) {
            g_checkerboard = on;
            if (on) {
                g_depthColor = false;
            }
            applyTintFlags();
        }
    );
    // Pause is a registered setting rather than the menu's `pauseSimWhileOpen_`
    // flag: exposing it as a row makes it observable (the GUI test asserts the
    // clock actually stopped), and the two would otherwise both write the clock.
    IRPrefab::Settings::registerBool(
        "PAUSE SIMULATION",
        [] { return IRSim::isPaused(); },
        [](bool paused) {
            if (!paused) {
                IRSim::setTimeScale(g_timeScaleBeforePause);
                return;
            }
            // Guarded so a redundant pause (an external writer zeroed the clock
            // first) cannot latch 0 as the rate to come back to.
            if (!IRSim::isPaused()) {
                g_timeScaleBeforePause = IRSim::timeScale();
            }
            IRSim::pause();
        }
    );
}

void applyCheckerboard(C_VoxelSetNew &voxelSet, Color baseColor) {
    for (int i = 0; i < voxelSet.numVoxels_; ++i) {
        if (voxelSet.voxels_[i].color_.alpha_ == 0)
            continue;
        ivec3 cellPos = IRMath::roundVec3HalfUp(voxelSet.positions_[i].pos_);
        Color c = baseColor;
        if (((cellPos.x + cellPos.y + cellPos.z) & 1) != 0) {
            c.red_ = static_cast<std::uint8_t>(c.red_ * 0.55f);
            c.green_ = static_cast<std::uint8_t>(c.green_ * 0.55f);
            c.blue_ = static_cast<std::uint8_t>(c.blue_ * 0.55f);
        }
        voxelSet.voxels_[i].color_ = c;
    }
}

// Bounding half-extent mirroring the GPU formula in
// system_shapes_to_trixel.hpp / c_shapes_to_trixel_body.glsl, so that CPU depth
// normalization uses the exact same range as the GPU shader.
// Classic HSV->RGB (h,s,v in [0,1]) matching the shader's hsvToRgb helper.
vec3 hsvToRgbCpu(vec3 c) {
    const vec4 K(1.0f, 2.0f / 3.0f, 1.0f / 3.0f, 3.0f);
    vec3 p = IRMath::abs(IRMath::fract(vec3(c.x) + vec3(K)) * 6.0f - vec3(K.w));
    return c.z * IRMath::mix(vec3(K.x), IRMath::clamp(p - vec3(K.x), vec3(0.0f), vec3(1.0f)), c.y);
}

// Color each active voxel by its LOCAL iso-depth (x+y+z), normalized to
// [0,1] across the shape's bounding dExtent.  Matches the GPU depth-color
// path in c_shapes_to_trixel_body.glsl exactly, so the voxel-pool mirror is
// indistinguishable from the SDF render.
void applyDepthColor(C_VoxelSetNew &voxelSet, IRRender::ShapeType type, vec4 sdfParams) {
    auto sdfType = static_cast<IRMath::SDF::ShapeType>(type);
    vec3 boundingHalf = IRMath::SDF::boundingHalf(sdfType, sdfParams);
    // Match GPU: in iso camera convention, smaller d = closer, so visible
    // window is [-dColor, +dColor/3] and front → t=0 (red), back → t=1.
    float dColor = boundingHalf.x + boundingHalf.y + boundingHalf.z;
    float denom = IRMath::max((4.0f / 3.0f) * dColor, 1.0f);

    for (int i = 0; i < voxelSet.numVoxels_; ++i) {
        if (voxelSet.voxels_[i].color_.alpha_ == 0)
            continue;
        ivec3 cellPos = IRMath::roundVec3HalfUp(voxelSet.positions_[i].pos_);
        float d = static_cast<float>(cellPos.x + cellPos.y + cellPos.z);
        float t = IRMath::clamp((d + dColor) / denom, 0.0f, 1.0f);
        vec3 rgb = hsvToRgbCpu(vec3(0.66f * t, 1.0f, 1.0f));
        Color c{
            static_cast<std::uint8_t>(IRMath::clamp(rgb.x, 0.0f, 1.0f) * 255.0f),
            static_cast<std::uint8_t>(IRMath::clamp(rgb.y, 0.0f, 1.0f) * 255.0f),
            static_cast<std::uint8_t>(IRMath::clamp(rgb.z, 0.0f, 1.0f) * 255.0f),
            255
        };
        voxelSet.voxels_[i].color_ = c;
    }
}

// Create a voxel-pool entity carved to match an SDF shape.  Allocates a
// centered box of @p size cells, then deactivates every voxel whose SDF value
// exceeds the 0.5 surface threshold. An even size puts the cells, and so the
// shape's center, half a voxel off the lattice of @p position.
EntityId createVoxelPoolShapeSized(
    vec3 position, IRRender::ShapeType type, vec4 shapeParams, Color color, ivec3 size
) {
    EntityId entity =
        IREntity::createEntity(C_LocalTransform{position}, C_VoxelSetNew{size, color, true});
    auto &vs = IREntity::getComponent<C_VoxelSetNew>(entity);

    auto sdfType = static_cast<IRMath::SDF::ShapeType>(type);
    vec4 sdfParams = IRMath::SDF::effectiveParams(sdfType, shapeParams);

    // Batch-evaluate the SDF over the whole grid via the shared helper rather
    // than calling evaluate() per cell. evaluateGrid samples each cell at
    // vec3(x,y,z) - size*0.5 + 0.5 in index3DtoIndex1D order — bit-identical to
    // the centered positions C_VoxelSetNew laid out for centerAroundOrigin — so
    // distances[i] lines up one-for-one with voxel i.
    std::vector<float> distances(static_cast<std::size_t>(vs.numVoxels_));
    IRMath::SDF::evaluateGrid(vs.size_, sdfType, sdfParams, distances);

    int activeCount = 0;
    vs.editVoxels([&](int i, C_Voxel &voxel, vec3) {
        if (distances[i] > IRMath::SDF::kSurfaceThreshold) {
            voxel.deactivate();
        } else {
            ++activeCount;
        }
    });
    // Debug tint is opt-in: --depth-color visualizes z-bands; --checkerboard
    // distinguishes adjacent same-color voxels. Default is plain shape color
    // — the checkerboard path was flickering frame-to-frame and breaking
    // visual regression tests.
    if (g_depthColor) {
        applyDepthColor(vs, type, sdfParams);
        // Set the scatter path's per-pixel depth-color mode so non-cardinal
        // yaw evaluates hue continuously in the fragment shader.
        vec3 bh = IRMath::SDF::boundingHalf(sdfType, sdfParams);
        IRRender::setDepthColorDebug(true, bh.x + bh.y + bh.z);
    } else if (g_checkerboard) {
        applyCheckerboard(vs, color);
    }

    IR_LOG_INFO(
        "VoxelPool shape entity={} canvas={} total={} active={}",
        entity,
        vs.canvasEntity_,
        vs.numVoxels_,
        activeCount
    );
    return entity;
}

// createVoxelPoolShapeSized over the odd, lattice-centered box of half-extent
// @p halfExtent.
EntityId createVoxelPoolShape(
    vec3 position, IRRender::ShapeType type, vec4 shapeParams, Color color, ivec3 halfExtent
) {
    return createVoxelPoolShapeSized(position, type, shapeParams, color, halfExtent * 2 + ivec3(1));
}

// Directly-authored asymmetric voxel figure — the non-uniform stress case for
// analytic per-axis-scatter edge coverage. Unlike the symmetric SDF
// primitives, it has appendages (a horizontal right arm, a RAISED diagonal
// staircase left arm, two legs in an offset stance) and slanted, non-axis-aligned
// surface planes (the staircase arm + a head visor), so under camera Z-yaw many
// differently-oriented silhouette edges face the camera at once — exactly where a
// corner-spike / dashing / seam regression would show. Centred at origin so
// --spin-shape's yaw-about-origin keeps it screen-locked. Opt-in (--spin-shape
// figure); never in the default scene, so committed references stay byte-identical.
EntityId createCustomVoxelFigure(vec3 position, Color color) {
    const ivec3 size{13, 9, 17}; // centred: x[-6,6] y[-4,4] z[-8,8] — demo native scale
    EntityId entity =
        IREntity::createEntity(C_LocalTransform{position}, C_VoxelSetNew{size, color, true});
    auto &vs = IREntity::getComponent<C_VoxelSetNew>(entity);

    const auto box = [](int v, int lo, int hi) { return v >= lo && v <= hi; };
    const auto solid = [&](int x, int y, int z) -> bool {
        if (box(x, -2, 2) && box(y, -1, 1) && box(z, -3, 4))
            return true; // torso
        if (box(x, -1, 1) && box(y, -1, 1) && box(z, 5, 7))
            return true; // head (adjacent to torso top at z=4)
        if (box(x, 3, 5) && box(y, 0, 1) && box(z, 1, 2))
            return true;               // right arm (box appendage)
        for (int s = 0; s <= 3; ++s) { // left arm (raised staircase)
            if (x == -3 - s && box(y, -1, 0) && z == 3 + s)
                return true;
        }
        if (box(x, -2, -1) && box(y, -1, 1) && box(z, -8, -4))
            return true; // left leg
        if (box(x, 1, 2) && box(y, 0, 2) && box(z, -8, -4))
            return true;               // right leg (offset stance)
        for (int s = 0; s <= 1; ++s) { // head visor (slanted plane)
            if (box(x, -1, 1) && y == 2 + s && z == 6 - s)
                return true;
        }
        return false;
    };

    int activeCount = 0;
    vs.editVoxels([&](int, C_Voxel &voxel, vec3 p) {
        if (!solid(IRMath::round(p.x), IRMath::round(p.y), IRMath::round(p.z))) {
            voxel.deactivate();
        } else {
            ++activeCount;
        }
    });
    IR_LOG_INFO(
        "Custom voxel figure entity={} canvas={} size=({},{},{}) active={}",
        entity,
        vs.canvasEntity_,
        size.x,
        size.y,
        size.z,
        activeCount
    );
    return entity;
}

// Create an SDF shape entity at the given position.
EntityId createSDFShape(vec3 position, IRRender::ShapeType type, vec4 params, Color color) {
    C_ShapeDescriptor desc{type, params, color};
    // Same opt-in debug-tint toggle as createVoxelPoolShape, applied GPU-side
    // via shader flags. Default is no tint — the checkerboard path flickered
    // frame-to-frame on this side too.
    if (g_depthColor) {
        desc.flags_ |= IRRender::SHAPE_FLAG_DEPTH_COLOR;
    } else if (g_checkerboard) {
        desc.flags_ |= IRRender::SHAPE_FLAG_CHECKERBOARD;
    }
    EntityId entity = IREntity::createEntity(C_LocalTransform{position}, desc);
    auto &sd = IREntity::getComponent<C_ShapeDescriptor>(entity);
    IR_LOG_INFO(
        "SDF shape entity={} canvas={} type={} params=({},{},{},{})",
        entity,
        sd.canvasEntity_,
        static_cast<int>(type),
        params.x,
        params.y,
        params.z,
        params.w
    );
    return entity;
}

void setupCanvasLighting();

void initShadowFootprintProbeScene() {
    constexpr vec3 kShadowProbeFloorCenter{0.0f, 0.0f, 5.0f};
    constexpr vec4 kShadowProbeFloorParams{72.0f, 56.0f, 2.0f, 0.0f};
    constexpr vec3 kShadowProbeSunDirection{0.35f, 0.85f, -0.4f};
    constexpr vec4 kConeParams{4.0f, 4.0f, 8.0f, 0.0f};
    constexpr vec4 kTorusParams{4.0f, 2.0f, 0.0f, 0.0f};

    createVoxelPoolShape(
        vec3(-12.0f, -8.0f, 0.0f),
        IRRender::ShapeType::CONE,
        kConeParams,
        Color{220, 140, 100, 255},
        ivec3(5, 5, 4)
    );
    createSDFShape(
        vec3(-12.0f, 8.0f, 0.0f),
        IRRender::ShapeType::CONE,
        kConeParams,
        Color{240, 175, 125, 255}
    );
    createVoxelPoolShape(
        vec3(12.0f, -8.0f, 1.0f),
        IRRender::ShapeType::TORUS,
        kTorusParams,
        Color{100, 180, 220, 255},
        ivec3(7, 7, 3)
    );
    createSDFShape(
        vec3(12.0f, 8.0f, 2.0f),
        IRRender::ShapeType::TORUS,
        kTorusParams,
        Color{130, 205, 240, 255}
    );

    const EntityId floor = createSDFShape(
        kShadowProbeFloorCenter,
        IRRender::ShapeType::BOX,
        kShadowProbeFloorParams,
        Color{150, 150, 160, 255}
    );
    IREntity::setComponent(floor, C_LightBlocker{false, false, 0.0f});

    setupCanvasLighting();
    IRRender::setSunDirection(kShadowProbeSunDirection);
    const vec3 sun = IRRender::getSunDirection();
    const float captureZoom = kShadowFootprintShots[0].zoom_;
    const int effectiveSubdivisions =
        IRRender::getVoxelRenderEffectiveSubdivisionsForZoom(vec2(captureZoom));
    const float receiverHalfExtentZ = (kShadowProbeFloorParams.z - 1.0f) * 0.5f +
                                      0.5f / static_cast<float>(effectiveSubdivisions);
    const float receiverTopZ = kShadowProbeFloorCenter.z - receiverHalfExtentZ;
    const float analyticSurfaceThreshold = 0.5f / static_cast<float>(effectiveSubdivisions);
    IR_LOG_INFO(
        "Shadow-footprint probe: capture_zoom={} effective_subdivisions={} "
        "receiver_center_z={} receiver_size_z={} receiver_top_z={} "
        "analytic_surface_threshold={} sun=({},{},{}) "
        "cone_voxel_center=(-12,-8,0) cone_sdf_center=(-12,8,0) "
        "torus_voxel_center=(12,-8,1) torus_sdf_center=(12,8,2)",
        captureZoom,
        effectiveSubdivisions,
        kShadowProbeFloorCenter.z,
        kShadowProbeFloorParams.z,
        receiverTopZ,
        analyticSurfaceThreshold,
        sun.x,
        sun.y,
        sun.z
    );
}

// Spawn one voxel cube routed through the GPU voxel-position prepass.
// The fixed 45° SO(3) rotation can only reach the rendered voxels via the
// prepass — UPDATE_VOXEL_SET_CHILDREN folds in translation only — so a rotated
// cube on screen is the smoke test that the prepass computed modelToWorld *
// localPos for every voxel in this set. Opt-in (--gpu-voxel-smoke) so the
// default scene stays byte-identical.
void createGpuVoxelTransformSmoke() {
    const vec3 axis = IRMath::normalize(vec3(0.3f, 0.7f, 0.5f));
    const vec4 rot = IRMath::quatAxisAngle(axis, IRMath::kQuarterPi);
    const vec3 position = vec3(0.0f, 0.0f, -14.0f);
    const ivec3 halfExtent = ivec3(5, 5, 5);
    const ivec3 size = halfExtent * 2 + ivec3(1);

    EntityId entity = IREntity::createEntity(
        C_LocalTransform{position, rot},
        C_VoxelSetNew{size, Color{120, 220, 160, 255}, true}
    );
    auto &vs = IREntity::getComponent<C_VoxelSetNew>(entity);

    // Slot 0 carries this set's SO(3)+translation each frame; every owned voxel
    // points at slot 0 so the prepass transforms it instead of the CPU path.
    constexpr std::uint32_t kSmokeSlot = 0u;
    vs.gpuTransformSlot_ = kSmokeSlot;
    auto &pool = IREntity::getComponent<C_VoxelPool>(vs.canvasEntity_);
    pool.setTransformIndexForRange(
        vs.voxelStartIdx_,
        static_cast<size_t>(vs.numVoxels_),
        kSmokeSlot
    );
    IR_LOG_INFO(
        "GPU voxel-transform smoke entity={} canvas={} voxels={} slot={}",
        entity,
        vs.canvasEntity_,
        vs.numVoxels_,
        kSmokeSlot
    );
}

// Spawn one 2-bone rigged voxel bar skinned through the per-voxel bone→slot
// seed path. The bar spans x ∈ [-8, 8]; voxels left of the midpoint
// are painted bone 0 (root, at the left end), the rest bone 1 (elbow, at the
// midpoint, posed 30° off its bind rotation). UPDATE_JOINT_MATRICES allocates
// the skeleton's slot block on its first tick and auto-seeds binding 17 with
// `slotBase + bone_id`, so the right half visibly bends about the midpoint —
// a rigid entity transform cannot produce that, making the bend direct proof
// the per-voxel slots route through the joint skin matrices. Opt-in
// (--skin-smoke) so the default scene stays byte-identical.
void createSkinnedVoxelSmoke() {
    const vec3 position = vec3(0.0f, 16.0f, -14.0f);
    const ivec3 size = ivec3(17, 3, 3);

    EntityId rigRoot = IREntity::createEntity(
        C_LocalTransform{position},
        C_VoxelSetNew{size, Color{220, 140, 100, 255}, true}
    );
    auto &vs = IREntity::getComponent<C_VoxelSetNew>(rigRoot);

    // Paint bone ids from each voxel's entity-local x: left half follows the
    // root bone, right half the elbow.
    for (std::size_t i = 0; i < vs.voxels_.size(); ++i) {
        vs.voxels_[i].bone_id_ = (vs.positions_[i].pos_.x < 0.0f) ? 0 : 1;
    }

    // Root joint at the bar's left end; elbow at the midpoint, CHILD_OF the
    // root with a +8 local offset and posed 30° about +Y away from its rest.
    // bindPose_ holds the rig-root-local REST chain (no pose rotation), so the
    // elbow's skin matrix is non-identity and bends the right half.
    EntityId rootJoint =
        IREntity::createEntity(C_Joint{}, C_LocalTransform{vec3(-8.0f, 0.0f, 0.0f)});
    IREntity::setParent(rootJoint, rigRoot);
    const vec4 elbowPose = IRMath::quatAxisAngle(vec3(0.0f, 1.0f, 0.0f), IRMath::kPi / 6.0f);
    EntityId elbowJoint =
        IREntity::createEntity(C_Joint{}, C_LocalTransform{vec3(8.0f, 0.0f, 0.0f), elbowPose});
    IREntity::setParent(elbowJoint, rootJoint);

    C_Skeleton skeleton;
    skeleton.joints_ = {rootJoint, elbowJoint};
    skeleton.bindPose_ = {
        IRMath::SQT{vec3(1.0f), vec4(0.0f, 0.0f, 0.0f, 1.0f), vec3(-8.0f, 0.0f, 0.0f)},
        IRMath::SQT{vec3(1.0f), vec4(0.0f, 0.0f, 0.0f, 1.0f), vec3(0.0f, 0.0f, 0.0f)},
    };
    IREntity::setComponent(rigRoot, skeleton);

    IR_LOG_INFO(
        "Skinned voxel smoke entity={} canvas={} voxels={} joints={}",
        rigRoot,
        vs.canvasEntity_,
        vs.numVoxels_,
        skeleton.joints_.size()
    );
}

// ---------------------------------------------------------------------------
// Shape definitions — each entry produces one voxel-pool entity and one
// SDF entity, placed side by side for visual comparison.
// ---------------------------------------------------------------------------

struct ShapeTestCase {
    const char *label_;
    IRRender::ShapeType type_;
    vec4 params_;
    ivec3 halfExtent_;
    Color color_;
};

// Minimal scene for --pivot-focus-demo: a tall, off-center pillar plus
// four distinct ground markers ringing it (one per world cardinal). The dedicated
// shot table pins the camera Z-yaw pivot on the pillar's true center, so the
// pillar holds dead-center while the markers visibly orbit it; with
// --pivot-origin the z=0 origin pivot swings the whole group in an arc. Isolated
// from the cluttered default scene so the pin is unambiguous.
void initPivotFocusScene() {
    // Pillar at kPivotPillarCenter (z 0..20, off the world origin in x/y).
    createVoxelPoolShape(
        kPivotPillarCenter,
        IRRender::ShapeType::BOX,
        vec4(5, 5, 21, 0),
        Color{230, 200, 120, 255},
        ivec3(2, 2, 10)
    );
    // Asymmetric ground markers (z just above 0) so rotation is legible and its
    // direction unambiguous — distinct colors at +X / +Y / -X / -Y of the pillar.
    struct Marker {
        vec3 offset_;
        Color color_;
    };
    const Marker markers[] = {
        {vec3(14.0f, 0.0f, 0.0f), Color{220, 80, 80, 255}},
        {vec3(0.0f, 14.0f, 0.0f), Color{80, 120, 220, 255}},
        {vec3(-14.0f, 0.0f, 0.0f), Color{90, 200, 110, 255}},
        {vec3(0.0f, -14.0f, 0.0f), Color{210, 110, 210, 255}},
    };
    for (const auto &m : markers) {
        const vec3 pos = vec3(kPivotPillarCenter.x, kPivotPillarCenter.y, 1.0f) + m.offset_;
        createVoxelPoolShape(
            pos,
            IRRender::ShapeType::BOX,
            vec4(3, 3, 3, 0),
            m.color_,
            ivec3(1, 1, 1)
        );
    }
}

// Minimal scene for --pivot-verify: ONE bright vertical voxel cylinder centered
// on the active block's probe point, nothing else. The scorer uses a
// whole-frame THRESHOLD mask (any lit pixel), which is immune to the
// shading-orientation bias that contaminates a color-locked mask: sun/AO
// shading rotates with camera yaw, so a mask that keys on the lit base color
// tracks the lit faces and fabricates an orbit-like centroid swing on
// perfectly pinned geometry.
void initPivotVerifyScene() {
    const vec3 center = pivotVerifyProbeCenter();
    if (g_pivotVerifySdf) {
        createSDFShape(
            center,
            IRRender::ShapeType::CYLINDER,
            pivotVerifyProbeParams(),
            Color{235, 235, 235, 255}
        );
    } else {
        createVoxelPoolShapeSized(
            center,
            IRRender::ShapeType::CYLINDER,
            pivotVerifyProbeParams(),
            Color{235, 235, 235, 255},
            pivotVerifyProbeGridSize()
        );
    }
    // Spawn the cursor-pivot marker up front, hidden — cursorLatchOnFrame only
    // reveals it, once the latch resolves. It cannot be spawned from that hook:
    // the hook runs inside the RENDER pipeline, past SHAPES_TO_TRIXEL, so a
    // marker created there never reaches the render archetype (measured: zero
    // pixels changed). The real drag path spawns from CAMERA_MOUSE_ROTATE — also
    // a RENDER-pipeline system, but registered BEFORE SHAPES_TO_TRIXEL (this
    // demo splices standardControlSystems() at the head of renderPipeline), so
    // its spawn is visible to the pass the same frame. Ordering relative to
    // SHAPES_TO_TRIXEL is what decides this, not which pipeline the spawner
    // lives in.
    if (g_cursorPivotIndicator) {
        g_cursorLatchIndicator = IRPrefab::CursorPivot::createIndicator();
    }
    IR_LOG_INFO(
        "Pivot-verify scene: block '{}' probe {} cylinder at ({},{},{})",
        g_pivotVerifyBlock,
        g_pivotVerifySdf ? "SDF" : "voxel",
        center.x,
        center.y,
        center.z
    );
}

// Map a --spin-shape token to its ShapeType. Tokens match the lower-cased
// fixture shapes below; returns false (leaving `out` untouched) on an unknown
// name so the caller can diagnose it.
bool spinShapeTypeFromName(const std::string &name, IRRender::ShapeType &out) {
    struct SpinShapeName {
        const char *token_;
        IRRender::ShapeType type_;
    };
    static const SpinShapeName kSpinShapeNames[] = {
        {"box", IRRender::ShapeType::BOX},
        {"sphere", IRRender::ShapeType::SPHERE},
        {"cylinder", IRRender::ShapeType::CYLINDER},
        {"ellipsoid", IRRender::ShapeType::ELLIPSOID},
        {"cone", IRRender::ShapeType::CONE},
        {"torus", IRRender::ShapeType::TORUS},
        {"wedge", IRRender::ShapeType::WEDGE},
        {"curved_panel", IRRender::ShapeType::CURVED_PANEL},
    };
    for (const auto &entry : kSpinShapeNames) {
        if (name == entry.token_) {
            out = entry.type_;
            return true;
        }
    }
    return false;
}

// Canvas lighting setup shared by the full fixture scene and the --spin-shape
// single-shape scene: the main (voxel-pool) canvas needs the AO / sun-shadow /
// light-volume textures + C_TrixelCanvasRenderBehavior, or the lighting
// systems' archetype filter skips it and the shapes render unlit.
void setupCanvasLighting() {
    EntityId mainCanvas = IRRender::getActiveCanvasEntity();
    IR_LOG_INFO("Active canvas entity: {}", mainCanvas);

    const ivec2 canvasSize = IREntity::getComponent<C_TriangleCanvasTextures>(mainCanvas).size_;
    IREntity::setComponent(mainCanvas, C_CanvasAOTexture{canvasSize});
    IREntity::setComponent(mainCanvas, C_CanvasSunShadow{canvasSize});
    IREntity::setComponent(mainCanvas, C_CanvasLightVolume{});

    // The voxel-pool canvas prefab doesn't include this component, so the
    // AO / sun-shadow / light-volume / lighting systems' archetype filter
    // wouldn't otherwise match the main canvas and they'd silently skip it.
    IREntity::setComponent(mainCanvas, C_TrixelCanvasRenderBehavior{});

    // Default sun direction: high and slightly off-axis so every demo
    // shape casts a visible shadow without any further setup.
    IRRender::setSunDirection(vec3(0.35f, 0.85f, -0.4f));
    IRRender::setAOEnabled(!IREngine::args().getFlag("--no-ao"));
    IRRender::setSunShadowsEnabled(!IREngine::args().getFlag("--no-shadows"));
}

// The --viewport-portrait scene (see g_viewportPortrait).
void initViewportPortraitScene() {
    EntityId subject = IREntity::kNullEntity;
    EntityId fineVariant = IREntity::kNullEntity;
    if (g_viewportLodSwap) {
        const LodVariantPair pair =
            spawnLodVariantPair(4, kPortraitCoarseColor, 4, kPortraitSubjectColor);
        subject = pair.coarse_;
        fineVariant = pair.fine_;
    } else {
        subject = IREntity::createEntity(
            C_LocalTransform{vec3(0.0f)},
            C_VoxelSetNew{ivec3(4), kPortraitSubjectColor, true}
        );
    }
    IREntity::createEntity(
        C_LocalTransform{vec3(12.0f, -12.0f, 0.0f)},
        C_VoxelSetNew{ivec3(4), kPortraitDecoyColor, true}
    );

    // Right third of the screen, in GUI trixels whatever the GUI scale.
    const ivec2 guiSize = IREntity::getComponent<C_SizeTriangles>(IRRender::getCanvas("gui")).size_;
    IRPrefab::Viewport::Desc desc{};
    desc.rectOrigin_ = ivec2(guiSize.x * 5 / 8, guiSize.y / 4);
    desc.rectSize_ = ivec2(guiSize.x / 4, guiSize.y / 2);
    desc.zoom_ = kPortraitZoom;
    desc.yawRadians_ = IREngine::args().getFloat("--viewport-yaw");
    const EntityId viewport = IRPrefab::Viewport::create(desc, "portrait");
    IRPrefab::Viewport::setSubject(viewport, subject);
    if (fineVariant != IREntity::kNullEntity) {
        IREntity::setComponent(fineVariant, IRComponents::C_ViewportSubject{viewport});
    }
    IR_LOG_INFO(
        "Viewport-portrait: subject={} viewport={} rect=({},{} {}x{}) of gui {}x{} zoom={} yaw={}",
        subject,
        viewport,
        desc.rectOrigin_.x,
        desc.rectOrigin_.y,
        desc.rectSize_.x,
        desc.rectSize_.y,
        guiSize.x,
        guiSize.y,
        desc.zoom_,
        desc.yawRadians_
    );
}

void initEntities() {
    if (g_movingCaster) {
        IR_LOG_INFO("--- Moving sub-voxel caster scene ---");
        IREntity::createEntity(
            C_LocalTransform{vec3(0.0f, 0.0f, 4.0f)},
            C_VoxelSetNew{ivec3(40, 40, 1), Color{150, 150, 160, 255}, true}
        );
        g_movingCasterEntity = IREntity::createEntity(
            C_LocalTransform{kMovingCasterStart},
            C_VoxelSetNew{ivec3(4, 4, 4), Color{220, 140, 100, 255}, true}
        );
        setupCanvasLighting();
        IRRender::setSunDirection(kMovingCasterSunDirection);
        IRRender::setVoxelRenderSubdivisions(kMovingCasterSubdivisions);
        return;
    }
    if (g_shadowFootprintProbe) {
        IR_LOG_INFO("--- Shape shadow-footprint probe scene ---");
        initShadowFootprintProbeScene();
        return;
    }
    if (g_viewportPortrait) {
        IR_LOG_INFO("--- Secondary-viewport portrait fixture scene ---");
        initViewportPortraitScene();
        setupCanvasLighting();
        IRRender::setSunDirection(kPortraitSunDirection);
        IRRender::setSunAmbient(kPortraitSunAmbient);
        return;
    }
    if (IREngine::args().getFlag("--ao-contact-probe")) {
        const EntityId corner = IREntity::createEntity(
            C_LocalTransform{vec3(0.0f)},
            C_VoxelSetNew{ivec3(9, 9, 5), Color{180, 180, 180, 255}, true}
        );
        IREntity::getComponent<C_VoxelSetNew>(corner).carve([](vec3 position) {
            return position.x < 0.0f && position.y < 0.0f && position.z < 1.0f;
        });
        IREntity::createEntity(
            C_LocalTransform{vec3(12.0f, 0.0f, 0.0f)},
            C_VoxelSetNew{ivec3(5), Color{180, 180, 180, 255}, true}
        );
        setupCanvasLighting();
        return;
    }
    if (g_cullEvictTest) {
        IR_LOG_INFO("--- #2830 cull-invalidation fixture scene ---");
        initCullEvictScene();
        setupCanvasLighting();
        return;
    }
    if (g_lodScene) {
        g_lodSceneState.initialize(*g_prefabLua);
        setupCanvasLighting();
        return;
    }
    if (g_lodDenseSwap) {
        IR_LOG_INFO("--- DENSE LOD-swap fixture scene ---");
        initLodDenseSwapScene();
        setupCanvasLighting();
        return;
    }
    if (!g_loadPrefabPath.empty()) {
        IR_LOG_INFO("--- Prefab manifest scene ---");
        initLoadPrefabScene();
        setupCanvasLighting();
        return;
    }
    if (g_pivotVerifyBlock != "off") {
        IR_LOG_INFO("--- Pivot-verify probe scene ({}) ---", g_pivotVerifyBlock);
        initPivotVerifyScene();
        return;
    }
    if (g_zoomCalibration) {
        // No setupCanvasLighting: the cube keeps its flat albedo, so the
        // metric can pick the silhouette out by exact colour.
        IR_LOG_INFO("--- Continuous-zoom calibration scene ---");
        IREntity::createEntity(
            C_LocalTransform{kZoomCalibrationBoxWorld},
            C_VoxelSetNew{
                kZoomCalibrationBoxSize,
                kZoomCalibrationColor,
                IRComponents::EntityAnchor::CORNER
            }
        );
        return;
    }
    if (g_pivotFocusDemo) {
        IR_LOG_INFO("--- Camera pivot-focus demo scene (#1921) ---");
        initPivotFocusScene();
        return;
    }

    constexpr float kSpacingX = 16.0f;
    constexpr float kRowSeparationY = 12.0f;

    // params follow C_ShapeDescriptor conventions:
    //   BOX:          (sizeX, sizeY, sizeZ, 0)     — voxel counts per axis
    //   SPHERE:       (radius, radius, radius, 0)
    //   CYLINDER:     (radius, radius, height, 0)   — height = full height
    //   ELLIPSOID:    (2*rx, 2*ry, 2*rz, 0)        — diameters
    //   CONE:         (baseRadius, baseRadius, height, 0)
    //   TORUS:        (majorR, minorR, 0, 0)
    //   WEDGE:        (width, depth, height, 0)     — full sizes like BOX
    //   CURVED_PANEL: (width, depth, thickness, curvature)
    ShapeTestCase cases[] = {
        {"Box 7",
         IRRender::ShapeType::BOX,
         vec4(7, 7, 7, 0),
         ivec3(3, 3, 3),
         Color{100, 200, 220, 255}},

        {"Sphere r4",
         IRRender::ShapeType::SPHERE,
         vec4(4, 4, 4, 0),
         ivec3(5, 5, 5),
         Color{220, 180, 100, 255}},

        {"Cylinder",
         IRRender::ShapeType::CYLINDER,
         vec4(3, 3, 7, 0),
         ivec3(4, 4, 4),
         Color{100, 220, 140, 255}},

        {"Ellipsoid",
         IRRender::ShapeType::ELLIPSOID,
         vec4(8, 6, 4, 0),
         ivec3(5, 4, 3),
         Color{200, 130, 220, 255}},

        {"Cone",
         IRRender::ShapeType::CONE,
         vec4(4, 4, 8, 0),
         ivec3(5, 5, 4),
         Color{220, 140, 100, 255}},

        {"Torus",
         IRRender::ShapeType::TORUS,
         vec4(4, 2, 0, 0),
         ivec3(7, 7, 3),
         Color{100, 180, 220, 255}},

        {"Wedge",
         IRRender::ShapeType::WEDGE,
         vec4(7, 7, 7, 0),
         ivec3(4, 4, 4),
         Color{180, 220, 100, 255}},

        {"CurvedPanel",
         IRRender::ShapeType::CURVED_PANEL,
         vec4(8, 8, 2, 0.5f),
         ivec3(5, 5, 5),
         Color{220, 100, 180, 255}},
    };
    constexpr int kNumCases = sizeof(cases) / sizeof(cases[0]);

    // Origin-centred shapes stay screen-centred under camera yaw. The default
    // black background isolates temporal jitter; an optional neutral floor
    // permits shadow measurements without introducing local lights.
    if (!g_spinShapeType.empty()) {
        if (IREngine::args().getFlag("--spin-shape-floor")) {
            const EntityId floor = createSDFShape(
                vec3(0.0f, 0.0f, 5.0f),
                IRRender::ShapeType::BOX,
                vec4(64.0f, 64.0f, 2.0f, 0.0f),
                Color{150, 150, 160, 255}
            );
            IREntity::setComponent(floor, C_LightBlocker{false, false, 0.0f});
        }
        // "figure" is the non-uniform stress case (not an SDF primitive): a
        // directly-authored asymmetric voxel set with appendages + slanted
        // planes, to verify analytic edge coverage under camera yaw.
        if (g_spinShapeType == "figure") {
            createCustomVoxelFigure(vec3(0.0f, 0.0f, 0.0f), Color{210, 180, 140, 255});
            IR_LOG_INFO("Spin-shape single fixture: custom voxel figure");
            setupCanvasLighting();
            return;
        }
        IRRender::ShapeType want;
        if (spinShapeTypeFromName(g_spinShapeType, want)) {
            for (const auto &tc : cases) {
                if (tc.type_ != want) {
                    continue;
                }
                if (g_spinShapeVoxel) {
                    createVoxelPoolShape(
                        vec3(0.0f, 0.0f, 0.0f),
                        tc.type_,
                        tc.params_,
                        tc.color_,
                        tc.halfExtent_
                    );
                } else {
                    createSDFShape(vec3(0.0f, 0.0f, 0.0f), tc.type_, tc.params_, tc.color_);
                }
                IR_LOG_INFO(
                    "Spin-shape single fixture: {} ({})",
                    tc.label_,
                    g_spinShapeVoxel ? "voxel-pool" : "SDF"
                );
                break;
            }
        } else {
            IR_LOG_ERROR(
                "--spin-shape: unknown shape '{}' "
                "(box|sphere|cylinder|ellipsoid|cone|torus|wedge|curved_panel|figure)",
                g_spinShapeType
            );
        }
        setupCanvasLighting();
        return;
    }

    for (int i = 0; i < kNumCases; ++i) {
        auto &tc = cases[i];
        float xPos = i * kSpacingX;

        IR_LOG_INFO("--- {} ---", tc.label_);

        createVoxelPoolShape(
            vec3(xPos, 0.0f, 0.0f),
            tc.type_,
            tc.params_,
            tc.color_,
            tc.halfExtent_
        );

        createSDFShape(vec3(xPos, kRowSeparationY, 0.0f), tc.type_, tc.params_, tc.color_);
    }

    // LOD demonstration. The engine LOD filter is an inclusive band
    // [lodMax_ .. lodMin_], so co-located variants with DISJOINT bands render
    // exclusively — exactly one per zoom, swapping in place instead of
    // stacking. Three variants with deliberately distinct silhouettes
    // (cube -> cone -> sphere) share one world position; as the camera zooms
    // in the silhouette visibly changes, the unambiguous "LOD is working"
    // signal the issue asks for. A single-LOD control shape beside the stack
    // stays constant at every zoom for comparison.
    //
    // Bands vs. zoom (computeLodLevel: zoom<2 -> LOD_4, <4 -> LOD_3, <8 ->
    // LOD_2, <16 -> LOD_1, >=16 -> LOD_0):
    //   coarse cube   band [LOD_3 .. LOD_4]  -> zoom 1..3
    //   mid    cone   band [LOD_1 .. LOD_2]  -> zoom 4..15
    //   fine   sphere band [LOD_0 .. LOD_0]  -> zoom >=16 (persists at 32/64)
    // The coarsest variant keeps lodMin_ = LOD_4 (persists at min zoom); the
    // finest keeps lodMax_ = LOD_0 (persists past its threshold).
    constexpr float kLodFixtureY = -16.0f;
    constexpr float kLodControlX = 14.0f;
    struct LodVariant {
        IRRender::ShapeType type_;
        vec4 params_;
        IRRender::LodLevel lodMin_; // coarsest tier (largest index) visible
        IRRender::LodLevel lodMax_; // finest tier (smallest index) visible
        Color color_;
        const char *label_;
    };
    const LodVariant lodStack[] = {
        {IRRender::ShapeType::BOX,
         vec4(8, 8, 8, 0),
         IRRender::LodLevel::LOD_4,
         IRRender::LodLevel::LOD_3,
         Color{80, 130, 240, 255},
         "coarse cube (zoom 1-3)"},
        {IRRender::ShapeType::CONE,
         vec4(5, 5, 11, 0),
         IRRender::LodLevel::LOD_2,
         IRRender::LodLevel::LOD_1,
         Color{80, 240, 100, 255},
         "mid cone (zoom 4-15)"},
        {IRRender::ShapeType::SPHERE,
         vec4(4, 4, 4, 0),
         IRRender::LodLevel::LOD_0,
         IRRender::LodLevel::LOD_0,
         Color{240, 80, 80, 255},
         "fine sphere (zoom >=16)"},
    };
    for (const auto &v : lodStack) {
        IR_LOG_INFO("--- LOD variant: {} ---", v.label_);
        C_ShapeDescriptor desc{v.type_, v.params_, v.color_};
        desc.lodMin_ = v.lodMin_;
        desc.lodMax_ = v.lodMax_;
        IREntity::createEntity(C_LocalTransform{vec3(0.0f, kLodFixtureY, 0.0f)}, desc);
    }

    // Single-LOD control: default band (always visible), constant across the
    // whole zoom range so the swapping stack reads against a fixed reference.
    {
        IR_LOG_INFO("--- LOD control: constant cylinder (all zooms) ---");
        C_ShapeDescriptor control{
            IRRender::ShapeType::CYLINDER,
            vec4(4, 4, 9, 0),
            Color{230, 200, 90, 255}
        };
        IREntity::createEntity(C_LocalTransform{vec3(kLodControlX, kLodFixtureY, 0.0f)}, control);
    }

    // Rotation test: SDF shapes with non-identity entity rotation,
    // paired with unrotated copies for visual comparison.
    constexpr float kRotFixtureY = -32.0f;
    constexpr float kRotPairSpacing = 14.0f;
    struct RotFixture {
        const char *label_;
        IRRender::ShapeType type_;
        vec4 params_;
        vec3 axis_;
        float angleDeg_;
        Color color_;
    };
    const RotFixture rotFixtures[] = {
        {"Box 45° Z",
         IRRender::ShapeType::BOX,
         vec4(7, 7, 7, 0),
         vec3(0, 0, 1),
         45.0f,
         Color{100, 200, 220, 255}},
        {"Cylinder 30° Z",
         IRRender::ShapeType::CYLINDER,
         vec4(3, 3, 7, 0),
         vec3(0, 0, 1),
         30.0f,
         Color{100, 220, 140, 255}},
        {"Ellipsoid 45° Y",
         IRRender::ShapeType::ELLIPSOID,
         vec4(8, 6, 4, 0),
         vec3(0, 1, 0),
         45.0f,
         Color{200, 130, 220, 255}},
        {"Cone 60° X",
         IRRender::ShapeType::CONE,
         vec4(4, 4, 8, 0),
         vec3(1, 0, 0),
         60.0f,
         Color{220, 140, 100, 255}},
    };
    constexpr int kNumRotFixtures = sizeof(rotFixtures) / sizeof(rotFixtures[0]);
    for (int i = 0; i < kNumRotFixtures; ++i) {
        const auto &rf = rotFixtures[i];
        float xBase = i * (kRotPairSpacing * 2.0f);
        float angleRad = rf.angleDeg_ * IRMath::kPi / 180.0f;
        vec4 rot = IRMath::quatAxisAngle(rf.axis_, angleRad);

        createSDFShape(vec3(xBase, kRotFixtureY, 0.0f), rf.type_, rf.params_, rf.color_);

        C_ShapeDescriptor desc{rf.type_, rf.params_, rf.color_};
        if (g_depthColor)
            desc.flags_ |= IRRender::SHAPE_FLAG_DEPTH_COLOR;
        else if (g_checkerboard)
            desc.flags_ |= IRRender::SHAPE_FLAG_CHECKERBOARD;
        IREntity::createEntity(
            C_LocalTransform{vec3(xBase + kRotPairSpacing, kRotFixtureY, 0.0f), rot},
            desc
        );
    }

    // Floor so AO / sun-shadow lighting has a surface to fall on. +Z is
    // downward in this iso convention, so shape bottoms sit at max +z ≈ 4
    // (sphere r4, cone h8); floor sits just below at z ≈ 5.
    constexpr float kFloorZ = 5.0f;

    IR_LOG_INFO("--- Floor ---");
    EntityId floorEntity = createSDFShape(
        vec3((kNumCases - 1) * kSpacingX * 0.5f, kRowSeparationY * 0.5f, kFloorZ),
        IRRender::ShapeType::BOX,
        vec4(kNumCases * kSpacingX + 16.0f, kRowSeparationY + 24.0f, 2.0f, 0.0f),
        Color{150, 150, 160, 255}
    );
    IREntity::setComponent(floorEntity, C_LightBlocker{false, false, 0.0f});

    if (g_guiTest || g_continuousZoomGuiTest) {
        initHoverParityFixture();
    }
    if (g_continuousZoomGuiTest) {
        initContinuousZoomGuiFixture();
    }

    setupCanvasLighting();

    // Emissive point light placed between the shape rows so its colored
    // falloff is visible across both the voxel-pool and SDF copies of the
    // nearby shapes. Cyan reads cleanly against the warm shape palette.
    IREntity::createEntity(
        C_LocalTransform{vec3(40.0f, 6.0f, -2.0f)},
        C_LightSource{LightType::EMISSIVE, Color{80, 200, 255, 255}, 2.0f, static_cast<uint8_t>(30)}
    );

    // --load-vxs: load a DENSE-mode .vxs file and place the voxel set at the
    // origin so it can be compared against the procedural shapes. A
    // `<base>_frame_<N>.vxs` path brings in every sibling frame; frame 0 seeds
    // the entity and the rest are kept for the playback swap.
    if (!g_loadVxsPath.empty()) {
        const std::vector<std::string> framePaths = resolveVxsFramePaths(g_loadVxsPath);

        // Decode, translate and validate EVERY frame into CPU-owned vectors
        // before any of them reaches a C_VoxelSetNew, then build exactly one
        // set — the one the entity takes ownership of.
        //
        // The ordering is load-bearing. By this point the render canvas exists,
        // so C_VoxelSetNew's dense ctor takes the pooled path and reserves a
        // canvas voxel-pool span; the span comes back only in onDestroy(), which
        // the ECS calls for a component an entity owns. There is no destructor,
        // so a per-frame local strands a whole frame's worth of pool slots for
        // the process lifetime — invisible in a capture, and it scales with
        // animation length until the pool runs out. Building the one set after
        // the loop is also what makes the refusal total: a malformed frame N
        // leaves no entity and no reservation.
        std::vector<std::vector<IRComponents::C_Voxel>> frames;
        ivec3 frameBoundsMin{0};
        ivec3 frameBoundsMax{0};
        float framesFps = g_vxsFps;
        bool loadFailed = false;

        // Pool high-water mark, sampled either side of the load so the run log
        // states how many slots the whole set actually reserved. Zero when the
        // canvas has no pool component.
        const auto poolLiveVoxelCount = []() -> int {
            const IREntity::EntityId canvas = IRPrefab::VoxelPool::activeCanvasEntityOrNull();
            if (canvas == IREntity::kNullEntity)
                return 0;
            auto pool = IREntity::getComponentOptional<IRComponents::C_VoxelPool>(canvas);
            return pool ? pool.value()->getLiveVoxelCount() : 0;
        };
        const int poolLiveBefore = poolLiveVoxelCount();

        for (const std::string &framePath : framePaths) {
            auto loaded = IRAsset::loadDenseVoxelSet(framePath);
            if (!loaded.ok()) {
                IR_LOG_ERROR("--load-vxs: could not load '{}'", framePath);
                loadFailed = true;
                break;
            }
            const IRAsset::DenseVoxelSet &dense = loaded.value_.dense_;
            if (dense.voxels_.size() != dense.voxelCount()) {
                IR_LOG_ERROR("--load-vxs: voxel count mismatch in '{}'", framePath);
                loadFailed = true;
                break;
            }
            std::vector<IRComponents::C_Voxel> frameVoxels = IRPrefab::DenseVoxel::toVoxels(dense);
            if (frames.empty()) {
                frameBoundsMin = dense.boundsMin_;
                frameBoundsMax = dense.boundsMax_;
                // Frame 0's META carries the animation's playback rate.
                for (const IRAsset::MetaEntry &entry : dense.meta_) {
                    // A hand-edited or foreign sidecar can carry anything here,
                    // and a throw would take down a demo run over a playback
                    // rate — keep the editor's default instead.
                    if (entry.key_ != "fps")
                        continue;
                    const float fps = std::strtof(entry.value_.c_str(), nullptr);
                    if (fps >= kVxsMinFps && fps <= kVxsMaxFps) {
                        framesFps = fps;
                    } else {
                        IR_LOG_WARN(
                            "--load-vxs: '{}' has fps '{}' outside [{}, {}]; keeping {} FPS",
                            framePath,
                            entry.value_,
                            kVxsMinFps,
                            kVxsMaxFps,
                            framesFps
                        );
                    }
                }
            } else {
                // The one pooled set is built from frame 0's bounds and its
                // records stay indexed by that extent, so a swap is only a copy
                // when every frame shares frame 0's bounds — an equal count
                // alone (16×16×16 vs 8×32×16) would copy a later pose in at
                // the wrong coordinates. A partial animation would play a
                // stutter nobody asked for, so refuse the whole set rather
                // than the odd frame.
                const bool matchesFrame0 = frameVoxels.size() == frames.front().size() &&
                                           dense.boundsMin_ == frameBoundsMin &&
                                           dense.boundsMax_ == frameBoundsMax;
                if (!matchesFrame0) {
                    const ivec3 extent = dense.boundsMax_ - dense.boundsMin_;
                    const ivec3 extent0 = frameBoundsMax - frameBoundsMin;
                    IR_LOG_ERROR(
                        "--load-vxs: frame '{}' is {} voxels, {}x{}x{} from [{},{},{}]; frame 0 "
                        "is {} voxels, {}x{}x{} from [{},{},{}] — not an animation",
                        framePath,
                        frameVoxels.size(),
                        extent.x,
                        extent.y,
                        extent.z,
                        dense.boundsMin_.x,
                        dense.boundsMin_.y,
                        dense.boundsMin_.z,
                        frames.front().size(),
                        extent0.x,
                        extent0.y,
                        extent0.z,
                        frameBoundsMin.x,
                        frameBoundsMin.y,
                        frameBoundsMin.z
                    );
                    loadFailed = true;
                    break;
                }
            }
            frames.push_back(std::move(frameVoxels));
        }

        // `toVoxels` returns empty on a malformed record block; frame 0 empty
        // would seed nothing and every later frame would then be rejected for
        // disagreeing with it, so refuse the set outright and say why.
        if (!loadFailed && (frames.empty() || frames.front().empty())) {
            IR_LOG_ERROR("--load-vxs: '{}' decoded to zero voxels", g_loadVxsPath);
            loadFailed = true;
        }

        if (!loadFailed) {
            g_vxsFps = framesFps;
            g_vxsEntity = IREntity::createEntity(
                C_LocalTransform{vec3(-20.0f, -8.0f, 0.0f)},
                IRComponents::C_VoxelSetNew{
                    frameBoundsMin,
                    frameBoundsMax,
                    std::span<const IRComponents::C_Voxel>{frames.front()}
                }
            );
            g_vxsFrames = std::move(frames);
        }

        // Refusing the set has to be total. Checking the entity before the pool
        // count means a regression that moves entity creation back inside the
        // loop reports the live entity rather than the pool-count symptom it
        // also produces.
        if (loadFailed) {
            g_vxsFrames.clear();
            IR_ASSERT(
                g_vxsEntity == IREntity::kNullEntity,
                "--load-vxs refused '{}' but left voxel-set entity {} live",
                g_loadVxsPath,
                g_vxsEntity
            );
        }

        // One frame's worth of slots for the whole set, however many frames it
        // has — and nothing at all when the set was refused. Compared with `<=`
        // because the pool hands a recycled free span back without moving the
        // high-water mark, so the delta can only under-report a reservation,
        // never invent one: the bound fails on exactly the leak it guards and
        // has no false-positive branch.
        const std::size_t expectedVoxels = g_vxsFrames.empty() ? 0u : g_vxsFrames.front().size();
        const int poolReserved = poolLiveVoxelCount() - poolLiveBefore;
        IR_ASSERT(
            poolReserved <= static_cast<int>(expectedVoxels),
            "--load-vxs reserved {} pool voxels for {} frame(s); one entity-owned set is {}",
            poolReserved,
            g_vxsFrames.size(),
            expectedVoxels
        );

        if (!loadFailed) {
            IR_LOG_INFO(
                "--load-vxs: loaded '{}' -> entity {} ({} voxels, {} frame(s) at {} FPS, {} pool "
                "voxels reserved)",
                g_loadVxsPath,
                g_vxsEntity,
                expectedVoxels,
                g_vxsFrames.size(),
                g_vxsFps,
                poolReserved
            );
            if (g_vxsFrame >= 0)
                showVxsFrame(g_vxsFrame);
        }
    }

    if (g_gpuVoxelSmoke) {
        IR_LOG_INFO("--- GPU voxel-position prepass smoke (#1396) ---");
        createGpuVoxelTransformSmoke();
    }

    if (g_skinSmoke) {
        IR_LOG_INFO("--- Skinned voxel bone->slot smoke (#1605) ---");
        createSkinnedVoxelSmoke();
    }
}
